# Virtual Bot Server 테스트

이 디렉토리는 Virtual Bot Server의 메시지 시뮬레이션 테스트를 위한 파일들을 포함합니다.

## 파일 구조

- `test.py`: 메인 테스트 스크립트
- `test_messages.json`: 테스트 메시지 데이터셋

## 테스트 메시지 JSON 형식

```json
[
  {
    "text": "시작",
    "postback": "start"
  },
  {
    "text": "부산 날씨 알려줘",
    "postback": null
  }
]
```

### 필드 설명

- `text` (required): 사용자가 보낼 메시지 텍스트
- `postback` (optional): 포스트백 데이터. 첫 번째 메시지는 "start", 이후는 null

## 사용 방법

1. Virtual Bot Server 실행:

   ```bash
   cd /Users/youngilchung/workspace/Busan/busan-ai/virtual-bot-server
   ./1_start_local_app.sh
   ```

2. 테스트 메시지 파일 준비 (test_messages.json)

3. 테스트 실행:
   ```bash
   cd tests
   python test.py
   ```

## 동작 방식

1. JSON 파일에서 테스트 메시지를 로드
2. 첫 번째 메시지를 전송 (postback="start")
3. Virtual Bot Server로부터 응답을 기다림
4. 마지막 봇 응답 후 3초가 지나면 다음 메시지 전송
5. 모든 메시지가 전송될 때까지 반복

## 설정

`test.py` 파일 상단에서 다음 설정을 변경할 수 있습니다:

```python
BASE_URL = "http://localhost:8000"  # Virtual Bot Server URL
USER_ID = "test_user"                # 테스트 사용자 ID
BOT_ID = "test_bot"                  # 테스트 봇 ID
BOT_RESPONSE_WAIT_TIME = 3.0         # 봇 응답 후 대기 시간 (초)
TEST_MESSAGES_FILE = "test_messages.json"  # 테스트 메시지 파일명
```

## 로그 예시

```
================================================================================
🤖 Virtual Bot Server 테스트 시작
📍 서버 URL: http://localhost:8000
👤 사용자 ID: test_user
🤖 봇 ID: test_bot
📂 테스트 메시지 로드 완료: /path/to/test_messages.json
📊 로드된 메시지 수: 5
📝 테스트 메시지 수: 5
================================================================================

[1/5] 메시지 처리 시작
🚀 메시지 전송: text='시작', postback=start
✅ 메시지 전송 완료: status=200
⏳ 봇 응답 대기 중...
📨 봇 메시지 수신됨
✅ 봇 응답 완료 (3초 안정)
다음 메시지 준비...

[2/5] 메시지 처리 시작
🚀 메시지 전송: text='부산 날씨 알려줘', postback=None
...
```
