# Query Expand Tester

정적 테스트 페이지입니다.

## 파일
- index.html: 테스트 UI
- script.js: 질의 로드/호출/JSON 정리 로직
- styles.css: UI 스타일
- queries.txt: 테스트 질의 목록

## 접속
service-was 실행 후 아래 경로로 접속:

- /static/query-expand-tester/index.html

기본 API URL은 `/test/api/llm-studio/query-expand` 입니다.
필요 시 외부 LLM endpoint로 변경해서 호출할 수 있습니다.

## 출력
결과는 화면 하단 `결과 JSON`에 누적되며, `JSON 다운로드` 버튼으로 저장 가능합니다.
