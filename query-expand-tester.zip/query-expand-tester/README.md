# Query Expand Tester

정적 테스트 페이지입니다.

## 파일
- index.html: 테스트 UI
- script.js: 질의 적용/호출/JSON 정리 로직
- styles.css: UI 스타일
- queries.txt: 테스트 질의 목록

## 접속
service-was 실행 후 아래 경로로 접속:

- /static/query-expand-tester/index.html

기본 API URL은 Production endpoint 입니다.

- `http://99.1.82.207:8080/llm-studio/v1/api/task/generate/syncapi/busan_ai_llm/query_expand`

질의 소스는 파일 경로가 아니라 textarea에 붙여넣어 사용합니다.

## 출력
결과는 화면 하단 `결과 JSON`에 누적되며, `JSON 다운로드` 버튼으로 저장 가능합니다.
