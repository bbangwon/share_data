const state = {
  queries: [],
  results: [],
};

const el = {
  apiUrl: document.getElementById("apiUrl"),
  concurrency: document.getElementById("concurrency"),
  timeoutMs: document.getElementById("timeoutMs"),
  querySource: document.getElementById("querySource"),
  loadBtn: document.getElementById("loadBtn"),
  runSelectedBtn: document.getElementById("runSelectedBtn"),
  runAllBtn: document.getElementById("runAllBtn"),
  clearBtn: document.getElementById("clearBtn"),
  downloadBtn: document.getElementById("downloadBtn"),
  selectAllBtn: document.getElementById("selectAllBtn"),
  unselectAllBtn: document.getElementById("unselectAllBtn"),
  queryList: document.getElementById("queryList"),
  status: document.getElementById("status"),
  resultJson: document.getElementById("resultJson"),
};

function setStatus(text, kind = "") {
  el.status.textContent = text;
  el.status.className = `status ${kind}`.trim();
}

function normalizeQuery(line) {
  return line.replace(/^\s*\d+\.\s*/, "").trim();
}

function parseQueries(text) {
  return text
    .split(/\r?\n/)
    .map((line) => normalizeQuery(line))
    .filter(Boolean);
}

function renderQueryList() {
  el.queryList.innerHTML = "";
  state.queries.forEach((query, idx) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <input type="checkbox" data-index="${idx}" checked />
      <label>${idx + 1}. ${escapeHtml(query)}</label>
    `;
    el.queryList.appendChild(li);
  });
}

function getSelectedIndices() {
  const selected = [];
  el.queryList
    .querySelectorAll('input[type="checkbox"]')
    .forEach((checkbox) => {
      if (checkbox.checked) {
        selected.push(Number(checkbox.dataset.index));
      }
    });
  return selected;
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.innerText = text;
  return div.innerHTML;
}

function tryParseAnswerJson(answerText) {
  if (!answerText || typeof answerText !== "string") {
    return { parsed: null, error: "answer가 문자열이 아님" };
  }

  const firstBrace = answerText.indexOf("{");
  const lastBrace = answerText.lastIndexOf("}");
  if (firstBrace < 0 || lastBrace < 0 || lastBrace <= firstBrace) {
    return { parsed: null, error: "answer 내 JSON 블록을 찾지 못함" };
  }

  const jsonChunk = answerText.slice(firstBrace, lastBrace + 1);
  try {
    return { parsed: JSON.parse(jsonChunk), error: null };
  } catch {
    return { parsed: null, error: "answer JSON 파싱 실패" };
  }
}

async function callQueryExpand(apiUrl, query, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  const payload = {
    contents: query,
    dialog_history: [],
  };

  const startedAt = new Date().toISOString();
  const startedPerf = performance.now();

  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    let responseBody;
    const text = await response.text();
    try {
      responseBody = JSON.parse(text);
    } catch {
      responseBody = { raw: text };
    }

    const endedPerf = performance.now();
    const answer = responseBody?.llm_result?.answer;
    const parsedAnswer = tryParseAnswerJson(answer);

    return {
      ok: response.ok,
      status: response.status,
      started_at: startedAt,
      latency_ms: Number((endedPerf - startedPerf).toFixed(2)),
      request: payload,
      response: responseBody,
      parsed_answer: parsedAnswer.parsed,
      parse_error: parsedAnswer.error,
    };
  } catch (error) {
    const endedPerf = performance.now();
    return {
      ok: false,
      status: null,
      started_at: startedAt,
      latency_ms: Number((endedPerf - startedPerf).toFixed(2)),
      request: payload,
      response: null,
      parsed_answer: null,
      parse_error: null,
      error: error?.name === "AbortError" ? "요청 타임아웃" : String(error),
    };
  } finally {
    clearTimeout(timer);
  }
}

async function runQueries(indices) {
  if (!indices.length) {
    setStatus("선택된 질의가 없습니다.", "err");
    return;
  }

  const totalCount = indices.length;

  const apiUrl = el.apiUrl.value.trim();
  const timeoutMs = Number(el.timeoutMs.value || 60000);
  const concurrency = Math.max(
    1,
    Math.min(10, Number(el.concurrency.value || 1)),
  );

  state.results = [];
  renderResults();

  let done = 0;
  setStatus(`실행 시작: 총 ${indices.length}건`, "");

  const workers = Array.from({
    length: Math.min(concurrency, indices.length),
  }).map(async () => {
    while (indices.length) {
      const idx = indices.shift();
      if (idx === undefined) {
        return;
      }

      const query = state.queries[idx];
      const result = await callQueryExpand(apiUrl, query, timeoutMs);
      state.results.push({
        index: idx + 1,
        query,
        ...result,
      });

      done += 1;
      setStatus(`실행 중: ${done}/${totalCount} 완료`, "");
      renderResults();
    }
  });

  await Promise.all(workers);

  state.results.sort((a, b) => a.index - b.index);
  renderResults();

  const failCount = state.results.filter((r) => !r.ok).length;
  if (failCount > 0) {
    setStatus(`완료: ${state.results.length}건 (실패 ${failCount}건)`, "err");
  } else {
    setStatus(`완료: ${state.results.length}건`, "ok");
  }
}

function renderResults() {
  el.resultJson.textContent = JSON.stringify(
    {
      generated_at: new Date().toISOString(),
      total: state.results.length,
      results: state.results,
    },
    null,
    2,
  );
}

async function loadQueries() {
  try {
    const text = el.querySource.value.trim();
    if (!text) {
      throw new Error("질의 소스가 비어 있습니다.");
    }

    state.queries = parseQueries(text);
    if (!state.queries.length) {
      throw new Error("유효한 질의를 찾지 못했습니다.");
    }

    renderQueryList();

    setStatus(`질의 ${state.queries.length}건 적용 완료`, "ok");
  } catch (error) {
    setStatus(`질의 적용 실패: ${String(error)}`, "err");
  }
}

function downloadResults() {
  const content = el.resultJson.textContent || "{}";
  const blob = new Blob([content], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const now = new Date().toISOString().replace(/[:.]/g, "-");
  a.href = url;
  a.download = `query-expand-results-${now}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function setAllChecks(checked) {
  el.queryList
    .querySelectorAll('input[type="checkbox"]')
    .forEach((checkbox) => (checkbox.checked = checked));
}

el.loadBtn.addEventListener("click", loadQueries);
el.runSelectedBtn.addEventListener("click", () =>
  runQueries(getSelectedIndices()),
);
el.runAllBtn.addEventListener("click", () =>
  runQueries(state.queries.map((_, i) => i)),
);
el.clearBtn.addEventListener("click", () => {
  state.results = [];
  renderResults();
  setStatus("결과를 초기화했습니다.");
});
el.downloadBtn.addEventListener("click", downloadResults);
el.selectAllBtn.addEventListener("click", () => setAllChecks(true));
el.unselectAllBtn.addEventListener("click", () => setAllChecks(false));

renderResults();
