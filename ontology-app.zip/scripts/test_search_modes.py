"""검색 모드 비교 테스트 스크립트.

5가지 검색 모드를 동일 질의로 실행하고 결과를 비교합니다.

  hybrid              - Qdrant DBSF만 사용, 그래프 확장 없음
  hybrid+kg           - Qdrant + Neo4j KG expansion
  hybrid+query_graph  - Qdrant + Synthetic Query Graph expansion
  hybrid+combined     - Qdrant + KG + Query Graph 동시 사용 후 post-graph rerank
  auto                - routing 결과에 따라 hybrid/kg/query_graph/combined 자동 선택

사용 예:
  python -m scripts.test_search_modes --query "OIL1 발령 기준은?"
  python -m scripts.test_search_modes --query "방사능 누출 시 주민 대피 절차" --limit 5
  python -m scripts.test_search_modes --query "각 협업반의 담당 임무 목록" --document-key "원전안전..."
  python -m scripts.test_search_modes --query "..." --mode hybrid+combined  # 특정 모드만 실행
  python -m scripts.test_search_modes --query "..." --no-rerank             # rerank 비활성화
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import textwrap
import time
from typing import Any

# 프로젝트 루트를 sys.path에 추가
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.core.config import get_settings  # noqa: E402
from app.services.chunking_profiles import apply_search_overrides  # noqa: E402
from app.services.graph.search.workflow import SearchWorkflow  # noqa: E402

# ─────────────────────────────────────────────
# 5가지 모드 정의
# ─────────────────────────────────────────────
MODES: list[dict[str, Any]] = [
    {
        "name": "hybrid",
        "label": "① Hybrid only",
        "graph_mode": "hybrid",
        "graph_strategy": "kg",   # use_graph=False 이므로 무시됨
    },
    {
        "name": "hybrid+kg",
        "label": "② Hybrid + KG",
        "graph_mode": "graph",
        "graph_strategy": "kg",
    },
    {
        "name": "hybrid+query_graph",
        "label": "③ Hybrid + Query Graph",
        "graph_mode": "graph",
        "graph_strategy": "query_graph",
    },
    {
        "name": "hybrid+combined",
        "label": "④ Hybrid + Combined (KG + QG)",
        "graph_mode": "graph",
        "graph_strategy": "combined",
    },
    {
        "name": "auto",
        "label": "⑤ Auto (routing 기반 자동 선택)",
        "graph_mode": "auto",
        "graph_strategy": "auto",
    },
]

MODE_NAMES = [m["name"] for m in MODES]


# ─────────────────────────────────────────────
# 출력 헬퍼
# ─────────────────────────────────────────────
_SEP = "─" * 80
_SEP2 = "═" * 80


def _header(text: str) -> None:
    print(f"\n{_SEP2}")
    print(f"  {text}")
    print(_SEP2)


def _section(text: str) -> None:
    print(f"\n{_SEP}")
    print(f"  {text}")
    print(_SEP)


def _fmt_routing(routing: dict[str, Any]) -> str:
    if not routing:
        return "(없음)"
    qtypes = ", ".join(routing.get("query_types") or [])
    conf = routing.get("confidence", 0)
    activated = routing.get("graph_activated", False)
    router = routing.get("router", "rule_based")
    return f"query_types=[{qtypes}]  confidence={conf:.2f}  graph_activated={activated}  router={router}"


def _fmt_sources(sources: list[str]) -> str:
    return "+".join(sorted(set(sources))) if sources else "hybrid"


def _print_result(idx: int, result: dict[str, Any]) -> None:
    score = result.get("quality_score") or result.get("rerank_score") or result.get("score") or 0
    graph_score = result.get("graph_score")
    qg_score = result.get("query_graph_score")
    sources = _fmt_sources(result.get("retrieval_sources") or [])
    chunk_id = result.get("chunk_id") or "-"
    section = result.get("section_title") or result.get("section_path") or "-"
    text = result.get("text") or ""
    short_text = textwrap.shorten(text, width=120, placeholder="…")

    score_parts = [f"score={score:.4f}"]
    if graph_score:
        score_parts.append(f"graph={graph_score:.4f}")
    if qg_score:
        score_parts.append(f"qg={qg_score:.4f}")

    print(f"  [{idx}] {chunk_id:<30}  {' | '.join(score_parts)}")
    print(f"       sources={sources:<20}  section={section}")
    print(f"       {short_text}")

    # graph_paths가 있으면 표시
    paths = result.get("graph_paths") or result.get("query_graph_paths") or []
    if paths:
        print(f"       paths={paths[:2]}")


def _print_trace_summary(trace: list[dict[str, Any]]) -> None:
    if not trace:
        return
    rows = []
    for step in trace:
        node = step.get("node", "?")
        status = step.get("status", "?")
        elapsed = step.get("elapsed_ms")
        elapsed_str = f"{elapsed:.0f}ms" if elapsed is not None else "-"
        rows.append(f"    {node:<28} {status:<12} {elapsed_str}")
    print("\n  [trace]")
    print("\n".join(rows))


def _print_mode_result(mode: dict[str, Any], result: dict[str, Any], elapsed_s: float) -> None:
    routing = result.get("routing") or {}
    selected_strategy = result.get("selected_graph_strategy") or mode["graph_strategy"]
    qg_activated = result.get("query_graph_activated", False)
    post_rerank = result.get("post_graph_rerank_applied", False)
    total = result.get("total", 0)

    print(f"\n  routing   : {_fmt_routing(routing)}")
    print(f"  strategy  : {selected_strategy}  (qg_activated={qg_activated}, post_rerank={post_rerank})")
    print(f"  결과 수    : {total}개  ({elapsed_s:.2f}s)")

    results = result.get("results") or []
    if not results:
        print("  (결과 없음)")
        return

    print()
    for i, res in enumerate(results, 1):
        _print_result(i, res)

    _print_trace_summary(result.get("trace") or [])


# ─────────────────────────────────────────────
# 비교 요약 테이블
# ─────────────────────────────────────────────
def _print_comparison(query: str, all_results: list[tuple[dict[str, Any], dict[str, Any], float]]) -> None:
    _header(f"비교 요약  |  query: {query!r}")
    header = f"  {'모드':<22} {'전략':<14} {'결과 수':>5}  {'graph 소스 비율':>14}  {'시간':>7}"
    print(header)
    print("  " + "-" * 70)
    for mode, result, elapsed_s in all_results:
        if result is None:
            print(f"  {mode['name']:<22} {'ERROR':<14} {'':>5}  {'':>14}  {elapsed_s:>6.2f}s")
            continue
        total = result.get("total", 0)
        results = result.get("results") or []
        graph_count = sum(
            1 for r in results
            if "graph" in (r.get("retrieval_sources") or [])
        )
        graph_ratio = f"{graph_count}/{total}" if total else "0/0"
        selected = result.get("selected_graph_strategy") or mode["graph_strategy"]
        print(f"  {mode['name']:<22} {selected:<14} {total:>5}  {graph_ratio:>14}  {elapsed_s:>6.2f}s")

    # chunk_id 교집합 분석
    chunk_sets = []
    for mode, result, _ in all_results:
        if result:
            ids = {r.get("chunk_id") for r in (result.get("results") or []) if r.get("chunk_id")}
            chunk_sets.append((mode["name"], ids))

    if len(chunk_sets) >= 2:
        print(f"\n  {'':─<70}")
        print("  [chunk_id 교집합]")
        baseline_name, baseline_ids = chunk_sets[0]
        for name, ids in chunk_sets[1:]:
            common = baseline_ids & ids
            only_other = ids - baseline_ids
            print(f"    {baseline_name} ∩ {name:<22}: {len(common)}개 공통  |  {name}만 발굴: {len(only_other)}개")


# ─────────────────────────────────────────────
# 단일 모드 실행
# ─────────────────────────────────────────────
async def run_mode(
    workflow: SearchWorkflow,
    mode: dict[str, Any],
    *,
    query: str,
    limit: int,
    document_key: str | None,
    rerank: bool,
    retrieval_profile: str | None,
) -> tuple[dict[str, Any] | None, float]:
    t0 = time.perf_counter()
    try:
        result = await workflow.run(
            query=query,
            limit=limit,
            graph_mode=mode["graph_mode"],
            graph_strategy=mode["graph_strategy"],
            document_key=document_key,
            rerank=rerank,
            retrieval_profile=retrieval_profile,
        )
        elapsed = time.perf_counter() - t0
        return result, elapsed
    except Exception as exc:
        elapsed = time.perf_counter() - t0
        print(f"  ERROR: {exc}")
        return None, elapsed


# ─────────────────────────────────────────────
# 메인
# ─────────────────────────────────────────────
async def main(
    query: str,
    limit: int,
    document_key: str | None,
    rerank: bool,
    selected_modes: list[str],
    retrieval_profile: str | None,
    json_output: bool,
) -> None:
    settings = get_settings()
    if retrieval_profile:
        settings = apply_search_overrides(settings, retrieval_profile=retrieval_profile)
    workflow = SearchWorkflow(settings)

    modes_to_run = [m for m in MODES if m["name"] in selected_modes]

    _header(f"검색 모드 비교 테스트  |  query: {query!r}")
    print(f"  limit={limit}  rerank={rerank}  document_key={document_key or '(전체)'}  profile={retrieval_profile or '(default)'}")
    print(f"  실행 모드: {[m['name'] for m in modes_to_run]}")

    all_results: list[tuple[dict[str, Any], dict[str, Any] | None, float]] = []
    json_out: dict[str, Any] = {"query": query, "modes": []}

    for mode in modes_to_run:
        _section(mode["label"])
        result, elapsed = await run_mode(
            workflow, mode,
            query=query,
            limit=limit,
            document_key=document_key,
            rerank=rerank,
            retrieval_profile=retrieval_profile,
        )
        all_results.append((mode, result, elapsed))

        if result is not None:
            _print_mode_result(mode, result, elapsed)
        else:
            print(f"  실패 ({elapsed:.2f}s)")

        if json_output and result is not None:
            json_out["modes"].append({
                "mode": mode["name"],
                "elapsed_s": round(elapsed, 3),
                "selected_strategy": result.get("selected_graph_strategy"),
                "query_graph_activated": result.get("query_graph_activated"),
                "post_graph_rerank_applied": result.get("post_graph_rerank_applied"),
                "routing": result.get("routing"),
                "total": result.get("total"),
                "results": result.get("results"),
            })

    if len(modes_to_run) > 1:
        _print_comparison(query, all_results)

    if json_output:
        out_path = Path("test_search_modes_output.json")
        out_path.write_text(json.dumps(json_out, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n  JSON 결과 저장: {out_path.resolve()}")

    print(f"\n{_SEP2}\n")


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="5가지 검색 모드를 동일 질의로 실행해 결과를 비교합니다.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
        예시:
          python -m scripts.test_search_modes --query "OIL1 발령 기준은?"
          python -m scripts.test_search_modes --query "담당 부서 목록" --mode hybrid hybrid+kg
          python -m scripts.test_search_modes --query "소개 절차" --limit 3 --no-rerank --json
        """),
    )
    parser.add_argument("--query", "-q", required=True, help="검색 질의")
    parser.add_argument("--limit", "-l", type=int, default=5, help="결과 개수 (default: 5)")
    parser.add_argument("--document-key", "-d", default=None, help="특정 문서 필터 (생략 시 전체)")
    parser.add_argument(
        "--mode", "-m",
        nargs="+",
        choices=MODE_NAMES,
        default=MODE_NAMES,
        help=f"실행할 모드 (기본: 전체). 선택 가능: {MODE_NAMES}",
    )
    parser.add_argument("--no-rerank", action="store_true", help="rerank 비활성화")
    parser.add_argument("--profile", default=None, help="retrieval profile (large 등)")
    parser.add_argument("--json", action="store_true", dest="json_output", help="JSON 파일로도 저장")
    return parser.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    asyncio.run(
        main(
            query=args.query,
            limit=args.limit,
            document_key=args.document_key,
            rerank=not args.no_rerank,
            selected_modes=args.mode,
            retrieval_profile=args.profile,
            json_output=args.json_output,
        )
    )
