#!/usr/bin/env bash
# fastembed 모델을 models/fastembed/ 디렉토리에 미리 다운로드합니다.
# 빌드 전에 한 번만 실행하면 됩니다.
#
# 사용법:
#   chmod +x scripts/download_models.sh
#   ./scripts/download_models.sh
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
MODEL_DIR="$PROJECT_ROOT/models/fastembed"

mkdir -p "$MODEL_DIR"

echo "Downloading fastembed models into: $MODEL_DIR"
echo ""

FASTEMBED_CACHE_PATH="$MODEL_DIR" python -c "
from fastembed import SparseTextEmbedding
print('  [1/1] Qdrant/bm25 ...')
SparseTextEmbedding(model_name='Qdrant/bm25')
print('  Done.')
"

echo ""
echo "Downloaded files:"
find "$MODEL_DIR" -type f | sort
