from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.services.graph.search.nodes import (
    _build_auto_relation_allowlist,
    _select_graph_strategy,
)
from app.services.query_routing import route_query_rule_based


def main() -> None:
    args = _parse_args()
    rows = _read_jsonl(args.queries)
    selected = rows[args.offset :]
    if args.max_queries is not None:
        selected = selected[: args.max_queries]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.overwrite and args.output.exists():
        args.output.unlink()

    completed_keys = _completed_keys(args.output)
    pending_rows = [
        (index, row)
        for index, row in enumerate(selected, start=args.offset)
        if _result_key(row.get("query_id"), index, args.graph_mode, args.graph_strategy)
        not in completed_keys
    ]

    print(
        "[start] "
        f"queries={args.queries} output={args.output} "
        f"selected={len(selected)} already_done={len(selected) - len(pending_rows)} "
        f"pending={len(pending_rows)} graph_mode={args.graph_mode} "
        f"graph_strategy={args.graph_strategy}"
    )

    with args.output.open("a", encoding="utf-8") as output:
        for run_number, (index, row) in enumerate(pending_rows, start=1):
            result = route_cq_row(
                row,
                query_index=index,
                graph_mode=args.graph_mode,
                graph_strategy=args.graph_strategy,
            )
            output.write(json.dumps(result, ensure_ascii=False) + "\n")
            output.flush()
            completed_keys.add(
                _result_key(row.get("query_id"), index, args.graph_mode, args.graph_strategy)
            )
            print(
                f"[ok] 총 {len(pending_rows)}개 중 {run_number}번째 질문 완료 "
                f"({result.get('query_id') or index}) "
                f"types={','.join(result['query_types'])} "
                f"retrieval={result['selected_retrieval']} "
                f"strategy={result['selected_graph_strategy']} "
                f"confidence={result['confidence']}"
            )

    summary = summarize_results(
        _read_jsonl(args.output),
        graph_mode=args.graph_mode,
        graph_strategy=args.graph_strategy,
    )
    print(
        "[done] "
        f"ok={summary['ok_count']} graph_activated={summary['graph_activated_count']} "
        f"retrieval={summary['selected_retrieval_counts']} "
        f"strategy={summary['selected_graph_strategy_counts']} "
        f"query_types={summary['query_type_counts']}"
    )


def route_cq_row(
    row: dict[str, Any],
    *,
    query_index: int,
    graph_mode: str,
    graph_strategy: str,
) -> dict[str, Any]:
    query = str(row.get("query") or "").strip()
    if not query:
        raise ValueError(f"query is required at index {query_index}")

    decision = route_query_rule_based(query=query, graph_mode=graph_mode)  # type: ignore[arg-type]
    routing = decision.model_dump(mode="json")
    selected_graph_strategy = _select_graph_strategy(graph_strategy, routing=routing)
    relation_allowlist = _build_auto_relation_allowlist(list(routing.get("query_types") or []))

    return {
        "status": "ok",
        "query_index": query_index,
        "query_id": row.get("query_id"),
        "query": query,
        "priority": row.get("priority"),
        "category": row.get("category"),
        "expected_classes": row.get("expected_classes", []),
        "expected_relations": row.get("expected_relations", []),
        "graph_mode": graph_mode,
        "graph_strategy": graph_strategy,
        "selected_graph_strategy": selected_graph_strategy,
        "selected_retrieval": routing.get("selected_retrieval"),
        "graph_activated": bool(routing.get("graph_activated")),
        "query_types": routing.get("query_types") or [],
        "confidence": routing.get("confidence"),
        "reasons": routing.get("reasons") or [],
        "relation_allowlist": relation_allowlist,
        "routing": routing,
    }


def summarize_results(
    rows: list[dict[str, Any]],
    *,
    graph_mode: str,
    graph_strategy: str,
) -> dict[str, Any]:
    scoped = [
        row
        for row in rows
        if row.get("status") == "ok"
        and row.get("graph_mode") == graph_mode
        and row.get("graph_strategy") == graph_strategy
    ]
    query_type_counts: Counter[str] = Counter()
    for row in scoped:
        query_type_counts.update(str(item) for item in row.get("query_types") or [])

    return {
        "ok_count": len(scoped),
        "graph_activated_count": sum(1 for row in scoped if row.get("graph_activated")),
        "selected_retrieval_counts": dict(
            Counter(str(row.get("selected_retrieval") or "") for row in scoped)
        ),
        "selected_graph_strategy_counts": dict(
            Counter(str(row.get("selected_graph_strategy") or "") for row in scoped)
        ),
        "query_type_counts": dict(query_type_counts),
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run only the query router over CQ JSONL and save routing decisions.",
    )
    parser.add_argument("--queries", type=Path, default=_default_queries_path())
    parser.add_argument("--output", type=Path, default=Path("data/eval/results/cq_routing_results.jsonl"))
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--max-queries", type=int, default=None)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--graph-mode", choices=["hybrid", "graph", "auto"], default="auto")
    parser.add_argument(
        "--graph-strategy",
        choices=["kg", "query_graph", "combined", "auto"],
        default="auto",
    )
    return parser.parse_args()


def _default_queries_path() -> Path:
    candidates = [
        Path("data/eval/inputs/search_answer_test_queries.jsonl"),
        Path("data/ontology-large/cq/search_answer_test_queries.jsonl"),
        Path("data/ontology/cq/search_answer_test_queries.jsonl"),
    ]
    for path in candidates:
        if path.exists():
            return path
    return candidates[0]


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _completed_keys(path: Path) -> set[tuple[str, int, str, str]]:
    if not path.exists():
        return set()
    keys: set[tuple[str, int, str, str]] = set()
    for row in _read_jsonl(path):
        if row.get("status") != "ok":
            continue
        keys.add(
            _result_key(
                row.get("query_id"),
                int(row.get("query_index") or -1),
                str(row.get("graph_mode") or ""),
                str(row.get("graph_strategy") or ""),
            )
        )
    return keys


def _result_key(
    query_id: Any,
    query_index: int,
    graph_mode: str,
    graph_strategy: str,
) -> tuple[str, int, str, str]:
    return str(query_id or ""), query_index, graph_mode, graph_strategy


if __name__ == "__main__":
    main()
