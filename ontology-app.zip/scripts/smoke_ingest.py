from __future__ import annotations

import argparse
import asyncio
import inspect
import json
from collections.abc import Callable, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from qdrant_client import models

from app.core.config import Settings, get_settings, resolve_default_json_path
from app.services.chunking import chunk_document
from app.services.chunking_profiles import apply_ingest_overrides
from app.services.embeddings import GpuDenseEmbedder, KiwiBm25SparseEmbedder, build_embed_text
from app.services.input_loader import load_parse_result
from app.services.qdrant_store import QdrantStore
from app.services.schemas import ChildChunk, ChunkingResult, DocumentMeta, EmbeddedChunk, RawElement, chunk_to_payload


@dataclass(frozen=True)
class SmokeIngestResult:
    input_path: str
    retrieval_profile: str | None
    source_document_key: str
    smoke_document_key: str
    collection: str
    qdrant: str
    total_elements: int
    total_parent_chunks: int
    total_child_chunks: int
    tested_child_chunks: int
    dense_vector_size: int
    sparse_vectors: int
    upsert_result: dict[str, Any]
    verified_current_points: int | None
    verified_page_range: list[int]
    skipped_qdrant: bool


async def run_smoke_ingest(
    *,
    input_path: str | Path | None = None,
    limit: int = 20,
    key_suffix: str | None = None,
    retrieval_profile: str | None = None,
    skip_qdrant: bool = False,
    verify: bool = True,
    settings: Settings | None = None,
    loader: Callable[[Path], tuple[list[RawElement], DocumentMeta]] = load_parse_result,
    chunker: Callable[[list[RawElement], DocumentMeta, Settings], ChunkingResult] = chunk_document,
    dense_embedder_factory: Callable[..., Any] = GpuDenseEmbedder,
    sparse_embedder_factory: Callable[..., Any] = KiwiBm25SparseEmbedder,
    store_factory: Callable[..., Any] = QdrantStore,
) -> SmokeIngestResult:
    if limit <= 0:
        raise ValueError("limit must be positive")
    suffix = (key_suffix or f"smoke-{limit}").strip().lstrip(":")
    if not suffix:
        raise ValueError("key_suffix must not be empty")

    settings = apply_ingest_overrides(settings or get_settings(), retrieval_profile=retrieval_profile)
    resolved_input_path = Path(input_path) if input_path else resolve_default_json_path(settings)
    elements, meta = loader(resolved_input_path)
    chunked = chunker(elements, meta, settings)
    chunks = chunked.children[:limit]
    if len(chunks) < limit:
        raise ValueError(f"requested {limit} chunks, but only {len(chunks)} chunks are available")

    dense_vectors, sparse_vectors = await _embed_chunks(
        chunks,
        settings=settings,
        dense_embedder_factory=dense_embedder_factory,
        sparse_embedder_factory=sparse_embedder_factory,
    )
    dense_vector_size = len(dense_vectors[0]) if dense_vectors else 0
    smoke_document_key = f"{meta.document_key}:{suffix}"
    embedded = _build_embedded_chunks(
        chunks,
        dense_vectors=dense_vectors,
        sparse_vectors=sparse_vectors,
        meta=meta,
        document_key=smoke_document_key,
        collection_name=settings.qdrant.collection_name,
        transform_version=f"{settings.chunking.profile}:{suffix}",
    )

    upsert_result: dict[str, Any]
    verified_current_points: int | None = None
    if skip_qdrant:
        upsert_result = {"skipped": True, "reason": "skip_qdrant requested"}
    else:
        store = store_factory(settings=settings, dense_vector_size=dense_vector_size)
        try:
            await _maybe_await(store.ensure_collection())
            upsert_result = await _maybe_await(store.upsert_document(smoke_document_key, embedded))
            if verify:
                verified_current_points = await _count_current_points(
                    store,
                    settings=settings,
                    document_key=smoke_document_key,
                    limit=limit,
                )
        finally:
            await _close(store)

    return SmokeIngestResult(
        input_path=str(resolved_input_path),
        retrieval_profile=retrieval_profile,
        source_document_key=meta.document_key,
        smoke_document_key=smoke_document_key,
        collection=settings.qdrant.collection_name,
        qdrant=f"{settings.qdrant.host}:{settings.qdrant.port}",
        total_elements=len(elements),
        total_parent_chunks=len(chunked.parents),
        total_child_chunks=len(chunked.children),
        tested_child_chunks=len(chunks),
        dense_vector_size=dense_vector_size,
        sparse_vectors=len(sparse_vectors),
        upsert_result=upsert_result,
        verified_current_points=verified_current_points,
        verified_page_range=_page_range(chunks),
        skipped_qdrant=skip_qdrant,
    )


async def _embed_chunks(
    chunks: Sequence[ChildChunk],
    *,
    settings: Settings,
    dense_embedder_factory: Callable[..., Any],
    sparse_embedder_factory: Callable[..., Any],
) -> tuple[list[list[float]], list[Any]]:
    embed_texts = [build_embed_text(chunk) for chunk in chunks]
    dense_embedder = dense_embedder_factory(
        base_url=settings.embedding.base_url,
        model=settings.embedding.dense_model_name,
        timeout=settings.embedding.timeout,
    )
    sparse_embedder = sparse_embedder_factory(model_name=settings.embedding.sparse_model_name)
    try:
        dense_vectors = await _maybe_await(dense_embedder.embed_many(embed_texts))
        sparse_vectors = await _maybe_await(sparse_embedder.embed_many(embed_texts))
    finally:
        await _close(dense_embedder)
        await _close(sparse_embedder)
    return [list(vector) for vector in dense_vectors], list(sparse_vectors)


def _build_embedded_chunks(
    chunks: Sequence[ChildChunk],
    *,
    dense_vectors: Sequence[Sequence[float]],
    sparse_vectors: Sequence[Any],
    meta: DocumentMeta,
    document_key: str | None = None,
    collection_name: str | None = None,
    transform_version: str,
) -> list[EmbeddedChunk]:
    return [
        EmbeddedChunk(
            chunk_id=chunk.chunk_id,
            payload=chunk_to_payload(
                chunk,
                meta,
                transform_version=transform_version,
                collection_name=collection_name,
                chunking_profile=transform_version,
                document_key=document_key,
            ),
            dense_vector=list(dense_vector),
            sparse_vector=_sparse_dict(sparse_vector),
            chunk=chunk,
        )
        for chunk, dense_vector, sparse_vector in zip(chunks, dense_vectors, sparse_vectors, strict=True)
    ]


async def _count_current_points(
    store: Any,
    *,
    settings: Settings,
    document_key: str,
    limit: int,
) -> int:
    custom_counter = getattr(store, "count_current_points", None)
    if custom_counter:
        return int(
            await _maybe_await(
                custom_counter(
                    document_key=document_key,
                    limit=limit,
                )
            )
        )

    response = await store.client.scroll(
        collection_name=settings.qdrant.collection_name,
        scroll_filter=models.Filter(
            must=[
                models.FieldCondition(key="document_key", match=models.MatchValue(value=document_key)),
                models.FieldCondition(key="ingest_status", match=models.MatchValue(value="current")),
            ]
        ),
        limit=limit + 1,
        with_payload=False,
        with_vectors=False,
    )
    points = response[0] if isinstance(response, tuple) else getattr(response, "points", [])
    return len(points)


def _sparse_dict(value: Any) -> dict[str, list[int] | list[float]]:
    if isinstance(value, dict):
        return {
            "indices": [int(index) for index in value.get("indices", [])],
            "values": [float(weight) for weight in value.get("values", [])],
        }
    return {
        "indices": [int(index) for index in getattr(value, "indices", [])],
        "values": [float(weight) for weight in getattr(value, "values", [])],
    }


def _page_range(chunks: Sequence[ChildChunk]) -> list[int]:
    page_numbers = [page for chunk in chunks for page in chunk.page_numbers]
    if not page_numbers:
        return []
    return [min(page_numbers), max(page_numbers)]


async def _maybe_await(value: Any) -> Any:
    if inspect.isawaitable(value):
        return await value
    return value


async def _close(value: Any) -> None:
    close = getattr(value, "close", None)
    if not close:
        return
    await _maybe_await(close())


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a safe partial JSON-to-Qdrant ingest with a smoke-test document key suffix."
    )
    parser.add_argument("--input-path", type=Path, default=None, help="PDF extraction JSON path. Defaults to settings.")
    parser.add_argument("--limit", type=int, default=20, help="Number of child chunks to embed and upsert.")
    parser.add_argument(
        "--key-suffix",
        default=None,
        help="Document key suffix. Defaults to smoke-{limit}. The leading colon is optional.",
    )
    parser.add_argument(
        "--retrieval-profile",
        default=None,
        help="Configured retrieval profile to select Qdrant collection and chunking settings, e.g. large or small.",
    )
    parser.add_argument("--skip-qdrant", action="store_true", help="Run load/chunk/embed only and skip Qdrant upsert.")
    parser.add_argument("--no-verify", action="store_true", help="Skip Qdrant current point count verification.")
    return parser


def main() -> None:
    args = _parser().parse_args()
    result = asyncio.run(
        run_smoke_ingest(
            input_path=args.input_path,
            limit=args.limit,
            key_suffix=args.key_suffix,
            retrieval_profile=args.retrieval_profile,
            skip_qdrant=args.skip_qdrant,
            verify=not args.no_verify,
        )
    )
    print(json.dumps(asdict(result), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
