from __future__ import annotations

import argparse
import json
from pathlib import Path

from app.core.config import get_settings
from app.services.ontology import build_ontology_artifacts


def main() -> None:
    parser = argparse.ArgumentParser(description="Build Phase2 ontology CQ artifacts.")
    parser.add_argument("--source-dir", type=Path, default=None, help="CQ markdown source directory.")
    parser.add_argument("--output-root", type=Path, default=None, help="Output artifact root.")
    parser.add_argument("--version", default=None, help="Ontology version.")
    args = parser.parse_args()

    settings = get_settings()
    result = build_ontology_artifacts(
        source_dir=args.source_dir or settings.ontology.cq_source_dir,
        output_root=args.output_root or settings.ontology.artifact_root,
        version=args.version or settings.ontology.version,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
