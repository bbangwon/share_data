from __future__ import annotations

import argparse
import json
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


def main() -> None:
    args = _parse_args()
    args.eval_mode, args.graph_mode, args.graph_strategy = _resolve_eval_args(args)
    rows = _read_jsonl(args.queries)
    selected = rows[args.offset :]
    if args.max_queries is not None:
        selected = selected[: args.max_queries]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    progress_output = args.progress_output or _default_progress_path(args.output)
    progress_output.parent.mkdir(parents=True, exist_ok=True)
    if args.overwrite and args.output.exists():
        args.output.unlink()
    if args.overwrite and progress_output.exists():
        progress_output.unlink()
    completed_keys = _completed_keys(args.output)
    mode_name = args.eval_mode
    pending_rows = [
        (index, row)
        for index, row in enumerate(selected, start=args.offset)
        if _result_key(
            query_id=row.get("query_id"),
            query_index=index,
            retrieval_profile=args.retrieval_profile,
            graph_mode=args.graph_mode,
            graph_strategy=args.graph_strategy,
            kg_expansion_mode=_requested_kg_expansion_mode(args),
        )
        not in completed_keys
    ]
    total_selected = len(selected)
    skipped_count = total_selected - len(pending_rows)
    run_started = time.perf_counter()
    ok_count = 0
    error_count = 0
    completed_this_run = 0
    duration_sum_ms = 0.0
    _write_eval_progress(
        progress_output,
        _eval_progress_payload(
            status="running",
            args=args,
            output=args.output,
            total_selected=total_selected,
            skipped_count=skipped_count,
            pending_count=len(pending_rows),
            completed_this_run=completed_this_run,
            ok_count=ok_count,
            error_count=error_count,
            duration_sum_ms=duration_sum_ms,
            run_started=run_started,
            last_result=None,
        ),
    )
    print(
        "[start] "
        f"mode={mode_name} profile={args.retrieval_profile} "
        f"selected={total_selected} already_done={skipped_count} pending={len(pending_rows)} "
        f"output={args.output} progress={progress_output}"
    )

    with args.output.open("a", encoding="utf-8") as output:
        for run_number, (index, row) in enumerate(pending_rows, start=1):
            key = _result_key(
                query_id=row.get("query_id"),
                query_index=index,
                retrieval_profile=args.retrieval_profile,
                graph_mode=args.graph_mode,
                graph_strategy=args.graph_strategy,
                kg_expansion_mode=_requested_kg_expansion_mode(args),
            )
            started = time.perf_counter()
            payload = {
                "query": row["query"],
                "retrieval_profile": args.retrieval_profile,
                "limit": args.limit,
                "dense_limit": args.dense_limit,
                "sparse_limit": args.sparse_limit,
                "graph_mode": args.graph_mode,
                "graph_strategy": args.graph_strategy,
                "max_context_chars": args.max_context_chars,
                "include_search": args.include_search,
            }
            if args.kg_expansion_mode is not None:
                payload["kg_expansion_mode"] = args.kg_expansion_mode
            if args.rerank is not None:
                payload["rerank"] = args.rerank
            if args.hybrid_rerank is not None:
                payload["hybrid_rerank"] = args.hybrid_rerank
            if args.post_graph_rerank is not None:
                payload["post_graph_rerank"] = args.post_graph_rerank
            result: dict[str, Any]
            try:
                response = _post_json(args.base_url.rstrip("/") + "/answer", payload, timeout=args.timeout)
                duration_ms = _duration_ms(started)
                timings = _timings_from_response(response, total_duration_ms=duration_ms)
                graph_details = _graph_expand_details(response)
                result = {
                    "status": "ok",
                    "mode": mode_name,
                    "eval_mode": args.eval_mode,
                    "query_index": index,
                    "query_id": row.get("query_id"),
                    "query": row["query"],
                    "priority": row.get("priority"),
                    "category": row.get("category"),
                    "expected_classes": row.get("expected_classes", []),
                    "expected_relations": row.get("expected_relations", []),
                    "retrieval_profile": args.retrieval_profile,
                    "graph_mode": args.graph_mode,
                    "graph_strategy": args.graph_strategy,
                    "kg_expansion_mode": response.get("kg_expansion_mode") or args.kg_expansion_mode or "default",
                    "requested_kg_expansion_mode": args.kg_expansion_mode,
                    "hybrid_rerank": response.get("hybrid_rerank"),
                    "post_graph_rerank": response.get("post_graph_rerank"),
                    "use_graph": args.graph_mode == "graph",
                    "routing": _routing_from_response(response),
                    "graph_activated": _graph_activated(response),
                    "selected_graph_strategy": response.get("selected_graph_strategy"),
                    "query_graph_activated": bool(response.get("query_graph_activated")),
                    "post_graph_rerank_applied": bool(response.get("post_graph_rerank_applied")),
                    "graph_candidate_count": int(graph_details.get("graph_candidate_count") or 0),
                    "kg_candidate_count": int(graph_details.get("kg_candidate_count") or 0),
                    "legacy_candidate_count": int(graph_details.get("legacy_candidate_count") or 0),
                    "query_guided_candidate_count": int(graph_details.get("query_guided_candidate_count") or 0),
                    "query_extraction_status": graph_details.get("query_extraction_status"),
                    "query_entities": graph_details.get("query_entities", []),
                    "query_relation_types": graph_details.get("query_relation_types", []),
                    "query_intent": graph_details.get("query_intent"),
                    "query_graph_candidate_count": int(graph_details.get("query_graph_candidate_count") or 0),
                    "request": payload,
                    "duration_ms": duration_ms,
                    "timings": timings,
                    "answer": response.get("answer"),
                    "collection_name": response.get("collection_name"),
                    "contexts": _compact_contexts(response.get("contexts", [])),
                    "search_results": _compact_search_results(response),
                }
                if args.full_response:
                    result["response"] = response
                completed_keys.add(key)
            except Exception as exc:
                duration_ms = _duration_ms(started)
                result = {
                    "status": "error",
                    "mode": mode_name,
                    "eval_mode": args.eval_mode,
                    "query_index": index,
                    "query_id": row.get("query_id"),
                    "query": row.get("query"),
                    "retrieval_profile": args.retrieval_profile,
                    "graph_mode": args.graph_mode,
                    "graph_strategy": args.graph_strategy,
                    "kg_expansion_mode": args.kg_expansion_mode or "default",
                    "requested_kg_expansion_mode": args.kg_expansion_mode,
                    "hybrid_rerank": _effective_bool(args.hybrid_rerank, args.rerank),
                    "post_graph_rerank": _effective_bool(args.post_graph_rerank, args.rerank),
                    "use_graph": args.graph_mode == "graph",
                    "request": payload,
                    "duration_ms": duration_ms,
                    "timings": {
                        "total_duration_ms": duration_ms,
                    },
                    "error": str(exc),
                }
            output.write(json.dumps(result, ensure_ascii=False) + "\n")
            output.flush()
            completed_this_run += 1
            duration_sum_ms += float(result.get("duration_ms") or 0.0)
            if result["status"] == "ok":
                ok_count += 1
            else:
                error_count += 1
            _write_eval_progress(
                progress_output,
                _eval_progress_payload(
                    status="running",
                    args=args,
                    output=args.output,
                    total_selected=total_selected,
                    skipped_count=skipped_count,
                    pending_count=len(pending_rows),
                    completed_this_run=completed_this_run,
                    ok_count=ok_count,
                    error_count=error_count,
                    duration_sum_ms=duration_sum_ms,
                    run_started=run_started,
                    last_result=result,
                ),
            )
            timings = result.get("timings") if isinstance(result.get("timings"), dict) else {}
            print(
                f"[{result['status']}] 총 {len(pending_rows)}개 중 {run_number}번째 질문 완료 "
                f"({result.get('query_id') or index}) "
                f"vector={_format_ms(timings.get('vector_search_duration_ms'))} "
                f"routing={_format_ms(timings.get('routing_duration_ms'))} "
                f"graph={_format_ms(timings.get('graph_search_duration_ms'))} "
                f"strategy={result.get('selected_graph_strategy') or args.graph_strategy} "
                f"kg_mode={result.get('kg_expansion_mode')} "
                f"graph_candidates={result.get('graph_candidate_count', 0)} "
                f"answer={_format_ms(timings.get('answer_generation_duration_ms'))} "
                f"total={_format_ms(timings.get('total_duration_ms') or result.get('duration_ms'))}"
            )
            if result["status"] == "error" and args.stop_on_error:
                raise SystemExit(1)
    activation_summary = _activation_summary(
        args.output,
        retrieval_profile=args.retrieval_profile,
        graph_mode=args.graph_mode,
        graph_strategy=args.graph_strategy,
        kg_expansion_mode=args.kg_expansion_mode,
    )
    _write_eval_progress(
        progress_output,
        _eval_progress_payload(
            status="completed_with_errors" if error_count else "completed",
            args=args,
            output=args.output,
            total_selected=total_selected,
            skipped_count=skipped_count,
            pending_count=len(pending_rows),
            completed_this_run=completed_this_run,
            ok_count=ok_count,
            error_count=error_count,
            duration_sum_ms=duration_sum_ms,
            run_started=run_started,
            last_result=None,
            activation_summary=activation_summary,
        ),
    )
    print(
        "[done] "
        f"mode={mode_name} total={len(pending_rows)} skipped={skipped_count} "
        f"graph_activated={activation_summary['activated']}/{activation_summary['ok']} "
        f"activation_rate={activation_summary['rate']:.1%} "
        f"query_graph_activated={activation_summary['query_graph_activated']}/{activation_summary['ok']} "
        f"post_graph_rerank={activation_summary['post_graph_rerank_applied']}/{activation_summary['ok']} "
        f"avg_total={_format_ms(activation_summary['avg_total_duration_ms'])} output={args.output}"
    )


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run CQ queries through the /answer API.")
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--queries", type=Path, default=_default_queries_path())
    parser.add_argument("--output", type=Path, default=Path("data/eval/results/cq_answer_results.jsonl"))
    parser.add_argument("--progress-output", type=Path, default=None, help="진행상황 JSON 파일 경로입니다. 생략하면 output 경로 뒤에 .progress.json을 붙입니다.")
    parser.add_argument("--retrieval-profile", choices=["large", "small"], default="large")
    parser.add_argument("--eval-mode", choices=["hybrid", "kg", "query_graph", "combined", "auto"], default=None)
    parser.add_argument("--graph-mode", choices=["hybrid", "graph", "auto"], default=None)
    parser.add_argument("--graph-strategy", choices=["kg", "query_graph", "combined", "auto"], default="kg")
    parser.add_argument("--kg-expansion-mode", choices=["legacy", "query_guided"], default=None, help="생략하면 API 서버의 search.kg_expansion_mode_default를 사용합니다.")
    parser.add_argument("--use-graph", action="store_true", help="하위 호환 alias입니다. --graph-mode graph와 같습니다.")
    parser.add_argument("--max-queries", type=int, default=None)
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--dense-limit", type=int, default=None)
    parser.add_argument("--sparse-limit", type=int, default=None)
    parser.add_argument("--max-context-chars", type=int, default=12000)
    parser.add_argument("--timeout", type=float, default=600.0)
    parser.add_argument("--overwrite", action="store_true", help="기존 output 파일을 지우고 처음부터 실행합니다.")
    parser.add_argument("--full-response", action="store_true", help="compact 저장값 외에 /answer 원본 응답 전체를 함께 저장합니다.")
    parser.add_argument("--stop-on-error", action="store_true", help="오류가 발생하면 다음 CQ로 넘어가지 않고 종료합니다.")
    parser.add_argument("--rerank", action="store_true", dest="rerank", help="하위 호환용 전체 rerank 스위치를 명시적으로 켭니다.")
    parser.add_argument("--no-rerank", action="store_false", dest="rerank", help="하위 호환용 전체 rerank 스위치를 명시적으로 끕니다.")
    parser.add_argument("--hybrid-rerank", action="store_true", dest="hybrid_rerank", help="Hybrid Search 직후 rerank를 명시적으로 켭니다.")
    parser.add_argument("--no-hybrid-rerank", action="store_false", dest="hybrid_rerank", help="Hybrid Search 직후 rerank를 끕니다.")
    parser.add_argument("--post-graph-rerank", action="store_true", dest="post_graph_rerank", help="Graph 후보 병합 후 rerank를 명시적으로 켭니다.")
    parser.add_argument("--no-post-graph-rerank", action="store_false", dest="post_graph_rerank", help="Graph 후보 병합 후 rerank를 끕니다.")
    parser.add_argument("--no-search", action="store_false", dest="include_search")
    parser.set_defaults(rerank=None, include_search=True, hybrid_rerank=None, post_graph_rerank=None)
    return parser.parse_args()


def _default_queries_path() -> Path:
    candidates = [
        Path("data/eval/inputs/search_answer_test_queries.jsonl"),
        Path("data/ontology-large/cq/search_answer_test_queries.jsonl"),
        Path("data/ontology/cq/search_answer_test_queries.jsonl"),
    ]
    for path in candidates:
        if path.exists():
            return path
    return candidates[0]


def _resolve_eval_args(args: argparse.Namespace) -> tuple[str, str, str]:
    if args.eval_mode is not None:
        mapping = {
            "hybrid": ("hybrid", "kg"),
            "kg": ("graph", "kg"),
            "query_graph": ("graph", "query_graph"),
            "combined": ("graph", "combined"),
            "auto": ("auto", "auto"),
        }
        graph_mode, graph_strategy = mapping[args.eval_mode]
        return args.eval_mode, graph_mode, graph_strategy
    graph_mode = _resolve_graph_mode_arg(args)
    graph_strategy = args.graph_strategy
    if graph_mode == "hybrid":
        eval_mode = "hybrid"
    elif graph_mode == "auto" and graph_strategy == "auto":
        eval_mode = "auto"
    elif graph_mode == "graph" and graph_strategy in {"kg", "query_graph", "combined"}:
        eval_mode = graph_strategy
    else:
        eval_mode = f"{graph_mode}:{graph_strategy}"
    return eval_mode, graph_mode, graph_strategy


def _resolve_graph_mode_arg(args: argparse.Namespace) -> str:
    if args.use_graph and args.graph_mode is not None and args.graph_mode != "graph":
        raise SystemExit("--use-graph cannot be combined with --graph-mode other than graph")
    if args.graph_mode is not None:
        return args.graph_mode
    return "graph" if args.use_graph else "hybrid"


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _post_json(url: str, payload: dict[str, Any], *, timeout: float) -> dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            content = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc
    return json.loads(content)


def _completed_keys(path: Path) -> set[tuple[str, str, str, str]]:
    if not path.exists():
        return set()
    keys: set[tuple[str, str, str, str]] = set()
    with path.open("r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get("status") != "ok":
                continue
            keys.add(
                _result_key(
                    query_id=row.get("query_id"),
                    query_index=row.get("query_index"),
                    retrieval_profile=str(row.get("retrieval_profile") or ""),
                    graph_mode=_row_graph_mode(row),
                    graph_strategy=_row_graph_strategy(row),
                    kg_expansion_mode=_row_requested_kg_expansion_mode(row),
                )
            )
    return keys


def _result_key(
    *,
    query_id: object,
    query_index: object,
    retrieval_profile: str,
    graph_mode: str,
    graph_strategy: str,
    kg_expansion_mode: str,
) -> tuple[str, str, str, str]:
    query_key = str(query_id or query_index)
    return retrieval_profile, graph_mode, f"{graph_strategy}:{kg_expansion_mode}", query_key


def _row_graph_mode(row: dict[str, Any]) -> str:
    value = row.get("graph_mode")
    if value in {"hybrid", "graph", "auto"}:
        return str(value)
    return "graph" if bool(row.get("use_graph")) else "hybrid"


def _row_graph_strategy(row: dict[str, Any]) -> str:
    value = row.get("graph_strategy")
    if value in {"kg", "query_graph", "combined", "auto"}:
        return str(value)
    return "kg"


def _row_kg_expansion_mode(row: dict[str, Any]) -> str:
    value = row.get("kg_expansion_mode")
    if value in {"legacy", "query_guided"}:
        return str(value)
    return "legacy"


def _row_requested_kg_expansion_mode(row: dict[str, Any]) -> str:
    value = row.get("requested_kg_expansion_mode")
    if value in {"legacy", "query_guided"}:
        return str(value)
    if value is None and "requested_kg_expansion_mode" in row:
        return "default"
    return _row_kg_expansion_mode(row)


def _requested_kg_expansion_mode(args: argparse.Namespace) -> str:
    return args.kg_expansion_mode or "default"


def _compact_contexts(contexts: Any) -> list[dict[str, Any]]:
    if not isinstance(contexts, list):
        return []
    compact: list[dict[str, Any]] = []
    for index, item in enumerate(contexts, start=1):
        if not isinstance(item, dict):
            continue
        compact.append(
            {
                "rank": index,
                "source_id": item.get("source_id"),
                "file": item.get("file"),
                "page_numbers": item.get("page_numbers"),
                "section_path": item.get("section_path"),
                "section_title": item.get("section_title"),
                "section_level": item.get("section_level"),
                "chunk_id": item.get("chunk_id"),
                "context_text": item.get("context_text") or item.get("text"),
            }
        )
    return compact


def _compact_search_results(response: dict[str, Any]) -> list[dict[str, Any]]:
    search = response.get("search")
    if not isinstance(search, dict):
        return []
    results = search.get("results")
    if not isinstance(results, list):
        return []
    compact: list[dict[str, Any]] = []
    for rank, item in enumerate(results, start=1):
        if not isinstance(item, dict):
            continue
        compact.append(
            {
                "rank": rank,
                "id": item.get("id"),
                "score": item.get("score"),
                "rerank_score": item.get("rerank_score"),
                "quality_score": item.get("quality_score"),
                "retrieval_sources": item.get("retrieval_sources", []),
                "graph_score": item.get("graph_score"),
                "graph_entities": item.get("graph_entities", []),
                "graph_reasons": item.get("graph_reasons", []),
                "graph_paths": item.get("graph_paths", []),
                "query_graph_score": item.get("query_graph_score"),
                "synthetic_queries": item.get("synthetic_queries", []),
                "query_graph_paths": item.get("query_graph_paths", []),
                "document_key": item.get("document_key"),
                "file": item.get("file"),
                "page_numbers": item.get("page_numbers"),
                "section_path": item.get("section_path"),
                "section_title": item.get("section_title"),
                "section_level": item.get("section_level"),
                "chunk_id": item.get("chunk_id"),
                "context_source": item.get("context_source"),
                "context_expanded": item.get("context_expanded"),
                "context_neighbor_chunk_ids": item.get("context_neighbor_chunk_ids", []),
                "text": item.get("text"),
                "context_text": item.get("context_text"),
            }
        )
    return compact


def _timings_from_response(response: dict[str, Any], *, total_duration_ms: float) -> dict[str, Any]:
    trace = []
    search = response.get("search")
    if isinstance(search, dict) and isinstance(search.get("trace"), list):
        trace = search["trace"]
    durations_by_node = {
        str(item.get("node")): float(item.get("duration_ms") or 0.0)
        for item in trace
        if isinstance(item, dict)
    }
    graph_duration_ms = durations_by_node.get("graph_expand", 0.0)
    routing_duration_ms = durations_by_node.get("route_query", 0.0)
    search_duration_ms = round(sum(durations_by_node.values()), 2)
    vector_nodes = [
        "embed_query",
        "hybrid_search",
        "rerank",
        "chunk_eval",
        "apply_quality_penalty",
        "finalize",
    ]
    vector_search_duration_ms = round(
        sum(durations_by_node.get(node, 0.0) for node in vector_nodes),
        2,
    )
    answer_generation_duration_ms = round(
        max(0.0, total_duration_ms - search_duration_ms),
        2,
    )
    return {
        "total_duration_ms": total_duration_ms,
        "search_duration_ms": search_duration_ms,
        "vector_search_duration_ms": vector_search_duration_ms,
        "routing_duration_ms": round(routing_duration_ms, 2),
        "graph_search_duration_ms": round(graph_duration_ms, 2),
        "answer_generation_duration_ms": answer_generation_duration_ms,
        "trace_durations_by_node": durations_by_node,
    }


def _routing_from_response(response: dict[str, Any]) -> dict[str, Any]:
    routing = response.get("routing")
    if isinstance(routing, dict):
        return routing
    search = response.get("search")
    if isinstance(search, dict) and isinstance(search.get("routing"), dict):
        return search["routing"]
    return {}


def _graph_expand_details(response: dict[str, Any]) -> dict[str, Any]:
    search = response.get("search")
    if not isinstance(search, dict):
        return {}
    trace = search.get("trace")
    if not isinstance(trace, list):
        return {}
    for item in trace:
        if isinstance(item, dict) and item.get("node") == "graph_expand":
            details = item.get("details")
            return details if isinstance(details, dict) else {}
    return {}


def _graph_activated(response: dict[str, Any]) -> bool:
    routing = _routing_from_response(response)
    if "graph_activated" in routing:
        return bool(routing["graph_activated"])
    return routing.get("selected_retrieval") == "hybrid_graph"


def _effective_bool(value: bool | None, fallback: bool | None) -> bool | None:
    if value is not None:
        return value
    return fallback


def _default_progress_path(output: Path) -> Path:
    return Path(f"{output}.progress.json")


def _eval_progress_payload(
    *,
    status: str,
    args: argparse.Namespace,
    output: Path,
    total_selected: int,
    skipped_count: int,
    pending_count: int,
    completed_this_run: int,
    ok_count: int,
    error_count: int,
    duration_sum_ms: float,
    run_started: float,
    last_result: dict[str, Any] | None,
    activation_summary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    total_completed = skipped_count + completed_this_run
    remaining_this_run = max(0, pending_count - completed_this_run)
    average_ms = round(duration_sum_ms / completed_this_run, 2) if completed_this_run else None
    return {
        "status": status,
        "eval_mode": args.eval_mode,
        "retrieval_profile": args.retrieval_profile,
        "graph_mode": args.graph_mode,
        "graph_strategy": args.graph_strategy,
        "kg_expansion_mode": args.kg_expansion_mode,
        "output": str(output),
        "total_selected_count": total_selected,
        "already_done_count": skipped_count,
        "pending_at_start_count": pending_count,
        "completed_this_run_count": completed_this_run,
        "ok_this_run_count": ok_count,
        "error_this_run_count": error_count,
        "total_completed_count": total_completed,
        "remaining_this_run_count": remaining_this_run,
        "percent_complete_total": round((total_completed / total_selected) * 100, 2) if total_selected else 100.0,
        "percent_complete_this_run": round((completed_this_run / pending_count) * 100, 2) if pending_count else 100.0,
        "average_query_duration_ms": average_ms,
        "estimated_remaining_ms": round(average_ms * remaining_this_run, 2) if average_ms is not None else None,
        "elapsed_ms": _duration_ms(run_started),
        "updated_at": _now_iso(),
        "last_result": _compact_progress_result(last_result),
        "activation_summary": activation_summary or {},
    }


def _compact_progress_result(result: dict[str, Any] | None) -> dict[str, Any] | None:
    if not result:
        return None
    return {
        "status": result.get("status"),
        "query_index": result.get("query_index"),
        "query_id": result.get("query_id"),
        "duration_ms": result.get("duration_ms"),
        "graph_candidate_count": result.get("graph_candidate_count"),
        "selected_graph_strategy": result.get("selected_graph_strategy"),
        "error": result.get("error"),
    }


def _write_eval_progress(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def _activation_summary(
    path: Path,
    *,
    retrieval_profile: str,
    graph_mode: str,
    graph_strategy: str,
    kg_expansion_mode: str | None,
) -> dict[str, Any]:
    ok = 0
    activated = 0
    query_graph_activated = 0
    post_graph_rerank_applied = 0
    total_duration_sum = 0.0
    if not path.exists():
        return {
            "ok": 0,
            "activated": 0,
            "query_graph_activated": 0,
            "post_graph_rerank_applied": 0,
            "rate": 0.0,
            "avg_total_duration_ms": 0.0,
        }
    with path.open("r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get("status") != "ok":
                continue
            if str(row.get("retrieval_profile") or "") != retrieval_profile:
                continue
            if _row_graph_mode(row) != graph_mode:
                continue
            if _row_graph_strategy(row) != graph_strategy:
                continue
            if kg_expansion_mode is not None and _row_kg_expansion_mode(row) != kg_expansion_mode:
                continue
            if kg_expansion_mode is None and _row_requested_kg_expansion_mode(row) != "default":
                continue
            ok += 1
            if row.get("graph_activated"):
                activated += 1
            if row.get("query_graph_activated"):
                query_graph_activated += 1
            if row.get("post_graph_rerank_applied"):
                post_graph_rerank_applied += 1
            timings = row.get("timings") if isinstance(row.get("timings"), dict) else {}
            total_duration_sum += float(timings.get("total_duration_ms") or row.get("duration_ms") or 0.0)
    return {
        "ok": ok,
        "activated": activated,
        "query_graph_activated": query_graph_activated,
        "post_graph_rerank_applied": post_graph_rerank_applied,
        "rate": (activated / ok) if ok else 0.0,
        "avg_total_duration_ms": (total_duration_sum / ok) if ok else 0.0,
    }


def _duration_ms(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 2)


def _format_ms(value: object) -> str:
    if value is None:
        return "-"
    try:
        milliseconds = float(value)
    except (TypeError, ValueError):
        return "-"
    if milliseconds >= 1000:
        return f"{milliseconds / 1000:.1f}s"
    return f"{milliseconds:.0f}ms"


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


if __name__ == "__main__":
    main()
