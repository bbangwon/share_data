#!/usr/bin/env sh
set -eu

: "${WORKERS:=${WEB_CONCURRENCY:-2}}"
: "${BIND:=0.0.0.0:8000}"
: "${TIMEOUT:=0}"
: "${GRACEFUL_TIMEOUT:=300}"
: "${KEEP_ALIVE:=5}"
: "${LOG_LEVEL:=info}"
: "${MAX_REQUESTS:=0}"
: "${MAX_REQUESTS_JITTER:=0}"

exec gunicorn \
  --workers "${WORKERS}" \
  --worker-class uvicorn_worker.UvicornWorker \
  --bind "${BIND}" \
  --timeout "${TIMEOUT}" \
  --graceful-timeout "${GRACEFUL_TIMEOUT}" \
  --keep-alive "${KEEP_ALIVE}" \
  --max-requests "${MAX_REQUESTS}" \
  --max-requests-jitter "${MAX_REQUESTS_JITTER}" \
  --log-level "${LOG_LEVEL}" \
  --access-logfile - \
  --error-logfile - \
  app.main:app \
  "$@"
