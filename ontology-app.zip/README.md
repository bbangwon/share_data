# Production GraphRAG Platform

FastAPI + LangGraph 기반 HybridRAG 서비스입니다.

현재 제공 기능:

- PDF 추출 JSON 로드 → 청킹 → dense/sparse embedding → Qdrant 적재
- 사용자 질의 embedding → Qdrant dense/sparse hybrid search → 선택적 rerank → 선택적 chunk-eval 후처리
- Phase2 Ontology Layer 기초 산출물 생성: CQ 정규화, 초기 온톨로지 스키마, 검토 리포트

GraphRAG는 아직 검색을 대체하지 않습니다. 이후 KG 생성과 Neo4j 그래프 탐색 노드는 현재 LangGraph 흐름 뒤에 증분으로 붙일 수 있도록 분리되어 있습니다.

## Git 태그 요약

- `v0.1`: Ontology/KG 기반 graph retrieval 파이프라인 기준점입니다.
- `v0.2`: Query Routing 기반 graph expansion 제어가 추가된 기준점입니다.
- `v0.3`: Query-Centric GraphRAG와 query graph 계층이 추가된 기준점입니다.
- `v0.4`: Evidence-chain graph context와 `/search` prompt-preview 응답이 반영된 최신 기준점입니다.
- `v0.5`: Query-guided KG 확장, eval job API/볼륨 구조, Qdrant-Neo4j 공통 `chunk_uid`가 반영된 기준점입니다.

## 실행

로컬 개발 서버:

```bash
uv run uvicorn app.main:app --reload
```

컨테이너 운영 서버는 `Dockerfile`과 `start_app.sh`를 사용합니다. 이미지는 `python:3.11-slim` 기반이며, 기본 실행 방식은 Gunicorn + Uvicorn worker입니다.

```bash
docker build -t graphrag-was:latest .

docker run -d \
  --name graphrag-was \
  -p 8000:8000 \
  -e APP_ENV=prod \
  -e WORKERS=2 \
  -e TIMEOUT=0 \
  -v /opt/graphrag-was/configs:/app/configs:ro \
  -v /opt/graphrag-was/data:/app/data \
  -v /opt/graphrag-was/outputs:/app/outputs \
  -v /opt/graphrag-was/logs:/app/logs \
  graphrag-was:latest
```

컨테이너 이미지에는 운영 TOML을 포함하지 않고, `/app/configs` 볼륨 마운트로 주입합니다. 로그는 `/app/logs/app.log`에 기록되며 기본 설정에서는 날짜 단위로 회전하고 14일이 지난 파일은 순차적으로 삭제됩니다.

오프라인 Rocky 9.6 서버 배포와 로그 볼륨 구성 절차는 `docs/docker_offline_ko.md`에 정리되어 있습니다.

기본 런타임 전제:

- Qdrant: `localhost:16333`
- Dense 임베딩 엔드포인트: `http://localhost:18080/v1/embeddings`
- 재정렬 엔드포인트: `http://localhost:18080/v1/rerank`
- Chunk-eval 엔드포인트: 비활성화가 기본값이며, 사용할 경우 `<base_url>/v1/chunk-eval`
- 컬렉션: `graphrag-was-local`

설정은 `configs/*.toml`을 Dynaconf로 읽고, `app/core/config.py`의 Pydantic `Settings` 모델로 검증합니다. 개발 환경은 `.env`의 `APP_ENV=dev`와 `configs/settings.dev.toml`을 사용합니다.

각 설정 파일의 역할과 항목별 의미는 `docs/configuration_ko.md`에 정리되어 있습니다.

로컬 PC 전용 값은 예제 파일을 복사해서 사용합니다.

```bash
cp configs/example.settings.toml configs/90_local.toml
cp configs/.example.secrets.toml configs/.secrets.dev.toml
cp .env.example .env
```

`.env`의 `APP_ENV`로 환경을 선택하고, 환경 변수는 double underscore로 nested 설정을 덮어씁니다. 예를 들어 `APP_QDRANT__HOST`, `APP_QDRANT__PORT`, `APP_EMBEDDING__BASE_URL`, `APP_RERANK__ENABLED`, `APP_CHUNK_EVAL__ENABLED`를 사용할 수 있습니다.

## Phase2 Ontology Layer

현재 Phase2 구현은 검색 방식을 바꾸지 않습니다. 사용자가 준비한 CQ 후보 마크다운을 표준 CQ와 최소 온톨로지 스키마로 정규화하고, 이후 Neo4j KG 생성과 Qdrant 메타데이터 보강이 재사용할 수 있는 산출물을 저장합니다.

입력 자료:

- `data/ontology_cq/llm_instruction_info.md`: CQ 생성을 위해 LLM에 전달한 지시 내용
- `data/ontology_cq/chatgpt_cq.md`: ChatGPT가 생성한 CQ 후보
- `data/ontology_cq/claude_cq.md`: Claude가 생성한 CQ 후보
- `data/ontology_cq/gemini_cq.md`: Gemini가 생성한 CQ 후보

생성 산출물:

- `data/ontology/cq/canonical_cq.jsonl`: 중복 제거 및 표준화된 CQ 목록
- `data/ontology/cq/canonical_cq.json`: 같은 CQ 목록의 JSON 배열 형식
- `data/ontology/cq/phase2_reference_cq.md`: Phase2 설계에 참고한 CQ 전체 목록
- `data/ontology/cq/search_answer_test_queries.jsonl`: `/search`, `/answer` 테스트에 바로 쓸 query 목록
- `data/ontology/schema/ontology_schema_v0.1.json`: 초기 모듈형 온톨로지 스키마
- `data/ontology/schema/graph_schema_v0.1.json`: Neo4j graph schema 초안
- `data/ontology/schema/cq_schema_mapping.jsonl`: CQ별 class/relation 매핑 중간 산출물
- `data/ontology/schema/schema_generation_trace.json`: CQ 입력 통계, class/relation 사용량, schema 생성 정책
- `data/ontology/reports/cq_review.md`: CQ 개수, 우선순위, 주요 CQ 검토 리포트

그래프 스키마 설명은 `docs/graph_schema_v0.1.md`, 온톨로지 스키마 설명은 `docs/ontology_schema_v0.1.md`에 있습니다.

CQ/스키마 산출물만 직접 다시 만들려면 CLI를 사용합니다.

```bash
uv run python -m scripts.build_ontology_cq
```

다른 경로를 지정하려면:

```bash
uv run python -m scripts.build_ontology_cq \
  --source-dir data/ontology_cq \
  --output-root data/ontology \
  --version ontology-v0.1
```

설정은 `[dev.ontology]`, `[prod.ontology]`에서 관리합니다. 개발 환경은 기본적으로 `enabled=true`이며, 운영 환경은 검색 기준선에 영향을 주지 않도록 `enabled=false`입니다.

```toml
[dev.ontology]
enabled = true
version = "ontology-v0.1"
cq_source_dir = "data/ontology_cq"
artifact_root = "data/ontology"
kg_upsert_enabled = false
qdrant_enrichment_enabled = false
```

`/ingest` 실행 시 `ontology.enabled=true`이면 `upsert_qdrant` 뒤에 `build_ontology_layer` 노드가 실행됩니다. 이 노드는 Qdrant 검색 payload를 바꾸지 않고 `data/ontology/` 산출물과 해당 ingest artifact 폴더의 `ontology_result.json`만 저장합니다.

Qdrant에는 이미 필요한 문서가 적재되어 있고 온톨로지 산출물만 다시 만들고 싶다면 아래처럼 실행합니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": true,
    "skip_existing_qdrant": true,
    "force_steps": ["build_ontology_layer"]
  }'
```

Neo4j write는 `ontology.kg_upsert_enabled`, Qdrant metadata enrichment는 `ontology.qdrant_enrichment_enabled`, 검색 시 graph expansion은 `graph_mode`와 `query_routing.*` 설정 뒤에 있습니다. 문제가 있으면 각각의 flag 또는 요청 파라미터로 되돌릴 수 있습니다.

### Neo4j KG 생성 및 그래프 검색

실제 그래프 검색을 사용하려면 먼저 Neo4j에 KG를 적재해야 합니다. small/large처럼 Qdrant 컬렉션과 Neo4j 컨테이너를 같이 바꿔 테스트할 때는 `retrieval_profile`을 사용합니다. profile 매핑은 `configs/settings.dev.toml`의 `[dev.retrieval_profiles.profiles.*]`에 있습니다.

먼저 로컬 설정이나 환경변수에서 Neo4j upsert를 명시적으로 켭니다. Neo4j 비밀번호는 `configs/.secrets.dev.toml`에서 관리합니다.

```bash
APP_ONTOLOGY__KG_EXTRACTION_ENABLED=true
APP_ONTOLOGY__KG_EXTRACTION_MODE=hybrid
APP_ONTOLOGY__KG_UPSERT_ENABLED=true
```

large 기준 Qdrant 컬렉션과 large Neo4j 컨테이너에 KG를 생성하려면:

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "retrieval_profile": "large",
    "resume": true,
    "skip_qdrant": true,
    "force_steps": ["build_ontology_layer"],
    "kg": {
      "extraction_mode": "hybrid"
    }
  }'
```

small 기준 Qdrant 컬렉션과 small Neo4j 컨테이너에 KG를 생성하려면:

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "retrieval_profile": "small",
    "resume": true,
    "skip_qdrant": true,
    "force_steps": ["build_ontology_layer"],
    "kg": {
      "extraction_mode": "hybrid"
    }
  }'
```

이 요청은 profile에 맞는 `collection_name`, `chunking_mode`, `neo4j_uri`, `ontology_artifact_root`를 함께 적용합니다. `load_document`, `chunk_document`, `embed_chunks`의 기존 산출물을 재사용할 수 있고, `upsert_qdrant`는 `skip_qdrant=true`로 건너뜁니다. `kg.extraction_mode=hybrid`이면 `prompts/ontology/entity_extraction.yaml`, `prompts/ontology/relation_extraction.yaml`을 LLM에 연결해 entity/relation을 추출하고, LLM 호출이나 JSON 검증이 실패한 chunk만 규칙 기반 추출로 fallback합니다. 실행 결과로 profile별 ontology artifact root 아래에 KG 추출 산출물이 저장되고, `ontology.kg_upsert_enabled=true`이면 해당 Neo4j 컨테이너에 `Chunk`, `Entity`, `OntologyClass`, `OntologyModule`, `CompetencyQuestion` 노드와 `MENTIONS`, `INSTANCE_OF`, 일부 도메인 관계가 적재됩니다.

LLM 기반 KG 추출은 청크 단위로 중간 저장됩니다. 같은 profile/document/chunking 기준으로 재실행하면 이미 성공한 청크는 다시 LLM을 호출하지 않고 `chunk_cache`를 재사용합니다. 전체 재시도는 보통 `resume=true`와 `force_steps=["build_ontology_layer"]`를 함께 사용합니다.

긴 실행을 초반 일부 청크로만 검증하려면 `kg.chunk_offset`, `kg.chunk_limit`을 사용합니다. 이 값은 Qdrant 적재 범위를 줄이지 않고, `build_ontology_layer`의 KG 추출 대상 청크만 제한합니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "retrieval_profile": "large",
    "resume": true,
    "skip_qdrant": true,
    "force_steps": ["build_ontology_layer"],
    "kg": {
      "extraction_mode": "hybrid",
      "chunk_offset": 0,
      "chunk_limit": 20
    }
  }'
```

진척률은 profile별 ontology artifact root에서 확인하거나 API로 조회합니다.

```bash
curl 'http://127.0.0.1:8000/ingest/kg-progress?retrieval_profile=large'
```

응답에는 전체 청크 수, 선택된 청크 수, 완료/재사용/실패 청크 수, 평균 처리 시간, 누적 실행 시간, 예상 잔여 시간이 포함됩니다. 청크별 성공/재사용/실패 이벤트와 작업 시간은 `kg_extraction_events.jsonl`에 한 줄씩 저장됩니다.

같은 profile의 Neo4j 그래프를 완전히 지우고 다시 만들려면 Qdrant는 건드리지 않고 graph scope만 reset합니다. `confirm_retrieval_profile`은 실수 방지를 위해 `retrieval_profile`과 정확히 같아야 합니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "retrieval_profile": "large",
    "resume": true,
    "skip_qdrant": true,
    "force_steps": ["build_ontology_layer"],
    "kg": {
      "extraction_mode": "hybrid"
    },
    "reset": {
      "neo4j_graph": true,
      "confirm_retrieval_profile": "large"
    }
  }'
```

KG 추출 산출물:

- `data/ontology-large/kg/chunks.jsonl`
- `data/ontology-large/kg/entities.jsonl`
- `data/ontology-large/kg/mentions.jsonl`
- `data/ontology-large/kg/relations.jsonl`
- `data/ontology-large/kg/kg_extraction_summary.json`
- `data/ontology-large/kg/kg_extraction_review.md`

### Query Graph 생성

v0.3 Query-Centric GraphRAG는 chunk에서 synthetic question-answer를 만들고 별도 query graph layer로 저장합니다. 원본 Qdrant chunk 컬렉션은 수정하지 않고, synthetic query는 `<profile collection>-qcg` Qdrant 컬렉션과 Neo4j `SyntheticQuery` 노드로 저장됩니다.

초기에는 작은 구간부터 실행합니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "retrieval_profile": "large",
    "resume": true,
    "skip_qdrant": true,
    "force_steps": ["build_query_graph_layer"],
    "query_graph": {
      "enabled": true,
      "chunk_offset": 0,
      "chunk_limit": 20
    }
  }'
```

진척률은 API로 확인합니다.

```bash
curl 'http://127.0.0.1:8000/ingest/query-graph-progress?retrieval_profile=large'
```

`progress.json`에는 선택된 청크 수, 완료/성공/실패/재사용 청크 수, 진행률, 평균 청크 처리 시간, 예상 잔여 시간이 저장됩니다. `resume=true`로 재실행하면 `chunk_cache`에 `completed`로 저장된 청크는 LLM을 다시 호출하지 않고 스킵합니다. 이전 실행에서 `failed`로 끝난 청크 cache는 성공 결과가 아니므로 다음 실행에서 다시 시도합니다.

같은 profile의 query graph만 삭제하고 다시 만들려면 `query_graph.reset_scope=true`와 확인용 profile을 함께 보냅니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "retrieval_profile": "large",
    "resume": true,
    "skip_qdrant": true,
    "force_steps": ["build_query_graph_layer"],
    "query_graph": {
      "enabled": true,
      "reset_scope": true,
      "confirm_retrieval_profile": "large",
      "chunk_offset": 0,
      "chunk_limit": 20
    }
  }'
```

Query graph 산출물:

- `data/ontology-large/query_graph/progress.json`
- `data/ontology-large/query_graph/query_graph_events.jsonl`
- `data/ontology-large/query_graph/synthetic_queries.jsonl`
- `data/ontology-large/query_graph/query_graph_edges.jsonl`
- `data/ontology-large/query_graph/query_graph_review.md`
- `data/ontology-large/query_graph/chunk_cache/<graph_dataset_hash>/*.json`

`synthetic_queries.jsonl`은 chunk 처리 직후에도 append 저장되며, 전체 노드가 끝나면 cache 기준으로 한 번 더 정리되어 최종 파일로 덮어씁니다.
- `data/ontology-large/kg/chunk_cache/<graph_dataset_hash>/*.json`

small profile은 같은 파일 구조를 `data/ontology-small/kg/` 아래에 저장합니다.

그래프 검색은 기본값이 꺼져 있습니다. v0.2부터는 `graph_mode`로 그래프 확장을 제어합니다. 기존 `use_graph`도 하위 호환을 위해 유지되며, `use_graph=false`는 `graph_mode=hybrid`, `use_graph=true`는 `graph_mode=graph`로 매핑됩니다.

기존 HybridRAG만 사용:

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "보건위생과 직원입니다. 청색비상 발생 시 어디 반에 편성되고 주요 임무는 무엇인가요?",
    "retrieval_profile": "large",
    "limit": 5,
    "graph_mode": "hybrid"
  }'
```

HybridRAG + Neo4j graph expansion 사용:

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "보건위생과 직원입니다. 청색비상 발생 시 어디 반에 편성되고 주요 임무는 무엇인가요?",
    "retrieval_profile": "large",
    "limit": 5,
    "graph_mode": "graph"
  }'
```

Query Router가 자동으로 그래프 필요 여부를 판단하게 하려면 `graph_mode=auto`를 사용합니다.

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "청색비상에서 보건위생과는 어떤 협업반과 연결되고 어떤 역할을 담당하나요?",
    "retrieval_profile": "large",
    "limit": 5,
    "graph_mode": "auto"
  }'
```

`/answer`도 같은 `graph_mode` 파라미터를 받습니다. `graph_mode=graph`는 그래프 사용만 강제하고 질의 분류는 유지하므로, `graph_strategy=auto`를 함께 쓰면 질의 타입에 따라 `kg`, `query_graph`, `combined` 중 하나가 선택됩니다. graph expansion은 Qdrant 검색을 대체하지 않고, Qdrant 결과의 seed chunk와 같은 엔티티를 공유하거나 1-hop 관계로 연결된 Neo4j chunk를 추가 후보로 가져와 `routing`, `retrieval_sources`, `graph_score`, `graph_entities`, `graph_reasons`, `graph_paths`를 응답에 남깁니다.

v0.3 Query-Centric GraphRAG를 사용하려면 `graph_strategy=query_graph` 또는 `combined`를 추가합니다. `combined`는 query graph로 관련 chunk cluster를 먼저 찾고, 그 결과와 기존 HybridRAG seed를 KG 확장의 seed로 함께 사용합니다. 이 기능도 기존 HybridRAG 검색 이후에만 실행됩니다.

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "청색비상 이후 주민 보호 조치는 어떤 순서로 이어지나요?",
    "retrieval_profile": "large",
    "limit": 5,
    "graph_mode": "graph",
    "graph_strategy": "query_graph"
  }'
```

v0.4 비교용 evidence-chain API는 일반 `/search`, `/answer` 흐름과 분리해 graph 연결 근거가 포함된 프롬프트 context를 확인할 수 있도록 별도 경로로 제공합니다.

- `POST /search/graph-enhanced`
- `POST /answer/graph-enhanced`

추가 파라미터:

| 파라미터 | 기본값 | 설명 |
| --- | --- | --- |
| `include_evidence_chains` | `true` | 그래프 확장 chunk가 어떤 entity/relation/query graph 경로로 연결되었는지 구조화된 chain을 프롬프트 context에 포함합니다. |
| `relation_allowlist` | `null` | KG relation traversal에 사용할 관계 타입 목록입니다. 생략하면 query router가 분류한 질의 타입에 맞춰 자동 allowlist를 사용합니다. 알 수 없는 관계 타입은 400 에러입니다. |
| `evidence_chain_limit` | `5` | 결과 chunk별로 반환할 최대 evidence chain 개수입니다. |

예시:

```bash
curl -X POST http://127.0.0.1:8000/search/graph-enhanced \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "보건위생과와 의료지원반은 어떤 관계이고 어떤 근거 청크들이 연결되나요?",
    "retrieval_profile": "large",
    "limit": 5,
    "graph_mode": "graph",
    "graph_strategy": "combined",
    "include_evidence_chains": true,
    "relation_allowlist": ["ASSIGNED_TO", "RESPONSIBLE_FOR", "REQUIRES_COOPERATION_WITH"],
    "evidence_chain_limit": 5
  }'
```

`/search/graph-enhanced` 응답의 `prompt`에는 `<evidence_chains>` 요약이 포함될 수 있습니다. `/answer/graph-enhanced`는 같은 chain 요약을 답변 생성 context에 짧게 포함해 LLM이 왜 해당 chunk가 같이 선택됐는지 확인할 수 있게 합니다.

## API 사용 방법

Swagger UI는 아래 주소에서 확인할 수 있습니다.

```text
http://127.0.0.1:8000/docs
```

### Health Check

```bash
curl "http://127.0.0.1:8000/health?retrieval_profile=large"
```

정상 응답:

```json
{
  "status": "ok",
  "app": {"status": "ok"},
  "retrieval_profile": "large",
  "collection_name": "ontology-radiation-safety-action-manual-large",
  "neo4j_database": "neo4j",
  "checks": {
    "qdrant": {
      "status": "ok",
      "host": "qdrant-host",
      "port": 6333,
      "collection_name": "ontology-radiation-safety-action-manual-large",
      "collection_exists": true,
      "collections": [
        "ontology-radiation-safety-action-manual-large",
        "ontology-radiation-safety-action-manual-large-qcg"
      ],
      "collection_count": 2,
      "duration_ms": 12.34
    },
    "neo4j": {
      "status": "ok",
      "uri": "bolt://neo4j-host:7687",
      "database": "neo4j",
      "query_ok": true,
      "connected": true,
      "duration_ms": 8.9
    }
  }
}
```

`/health`는 앱 상태, Qdrant 컬렉션 목록, 선택 컬렉션 존재 여부, Neo4j 연결 상태를 한 번에 확인합니다. `retrieval_profile`을 지정하면 해당 profile의 Qdrant collection과 Neo4j 접속 정보로 확인합니다. `retrieval_profile`과 `collection_name`을 모두 생략하면 `search.default_retrieval_profile`을 사용합니다.

기존 호환을 위해 `/health/dependencies`, `/health/ready`도 같은 결과를 반환합니다.

```bash
curl "http://127.0.0.1:8000/health/dependencies?retrieval_profile=large"
curl "http://127.0.0.1:8000/health/ready?retrieval_profile=large"
```

정상 연결이면 HTTP 200과 `status: "ok"`를 반환합니다. Qdrant collection이 없거나 Neo4j 접속에 실패하면 HTTP 503과 함께 실패한 dependency의 `error`, `detail`, `duration_ms`를 반환합니다. Qdrant 서버 연결과 collection 목록만 확인하고 선택 collection 존재 여부 검사는 제외하려면 `check_collection=false`를 붙입니다.

### JSON 문서 적재

기본 JSON 파일을 적재하려면 `/ingest`를 호출합니다. `input_path`를 생략하면 설정의 `runtime.default_json_dirs` 순서대로 JSON 파일을 찾습니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": true
  }'
```

특정 JSON 파일을 지정하려면:

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "input_path": "data/json/manual.json",
    "resume": true
  }'
```

처음부터 전체 과정을 다시 실행하려면 `resume=false`를 사용합니다. 이 경우 기존 중간 산출물을 재사용하지 않고 JSON 로드, 청킹, 임베딩, Qdrant upsert를 다시 수행합니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": false,
    "skip_qdrant": false,
    "skip_existing_qdrant": false
  }'
```

이미 성공한 중간 산출물은 재사용하되 특정 단계만 다시 실행하려면 `force_steps`를 사용합니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": true,
    "force_steps": ["chunk_document", "embed_chunks", "upsert_qdrant"]
  }'
```

Qdrant 적재 없이 JSON 로드, 청킹, 임베딩, 중간 산출물 저장까지만 확인하려면:

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": false,
    "skip_qdrant": true
  }'
```

Qdrant에 같은 `document_key`의 current 문서가 이미 있으면 upsert를 건너뛰려면:

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": true,
    "skip_existing_qdrant": true
  }'
```

Qdrant 컬렉션을 완전히 초기화한 뒤 새로 적재하려면 `reset.qdrant_collection=true`를 사용합니다. 이 요청은 컬렉션 전체를 삭제 후 재생성하므로, 실수 방지를 위해 최종 사용 컬렉션명을 `reset.confirm_collection_name`에 정확히 입력해야 합니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": false,
    "reset": {
      "qdrant_collection": true,
      "confirm_collection_name": "ontology-radiation-safety-action-manual"
    },
    "skip_qdrant": false
  }'
```

컬렉션 초기화만 다시 실행하고, 이미 저장된 청크/임베딩 산출물을 재사용해 재적재하려면:

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": true,
    "force_steps": ["reset_qdrant_collection", "upsert_qdrant"],
    "reset": {
      "qdrant_collection": true,
      "confirm_collection_name": "ontology-radiation-safety-action-manual"
    }
  }'
```

청킹 방식과 컬렉션명을 요청별로 선택할 수도 있습니다. `chunking_mode=small`은 첫 번째 커밋의 작은 `text` 청크 방식에 가깝게 child 병합과 parent 보정을 끈 방식이고, `chunking_mode=large`는 현재 튜닝된 큰 `text` 청크와 2000자 이하 `parent_text` 방식을 사용합니다.

현재 기본 chunking profile은 `251013-manual-json-v2`입니다. v2부터 `section_path`는 `"Ⅰ. 총칙 > 1. 목적 > 1) 초기 대응"`처럼 heading stack 기반 계층형 문자열로 저장되고, 디버깅용 `section_title`, `section_level`도 Qdrant payload와 Neo4j `Chunk`에 함께 들어갑니다. 기존 v1 적재본에는 자동 반영되지 않으므로 이 값을 확인하려면 컬렉션과 graph scope를 reset한 뒤 재적재해야 합니다.

작은 `text` 청크 방식으로 별도 컬렉션을 생성하려면:

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "chunking_mode": "small",
    "collection_name": "ontology-radiation-safety-action-manual-small",
    "ontology_artifact_root": "data/ontology-small",
    "resume": false,
    "reset": {
      "qdrant_collection": true,
      "confirm_collection_name": "ontology-radiation-safety-action-manual-small"
    }
  }'
```

큰 `text` 청크 방식으로 별도 컬렉션을 생성하려면:

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "chunking_mode": "large",
    "collection_name": "ontology-radiation-safety-action-manual-large",
    "ontology_artifact_root": "data/ontology-large",
    "resume": false,
    "reset": {
      "qdrant_collection": true,
      "confirm_collection_name": "ontology-radiation-safety-action-manual-large"
    }
  }'
```

`chunking_mode`와 `collection_name`이 다르면 ingest 중간 산출물 경로도 별도로 분리됩니다. 따라서 small 컬렉션의 `chunks.json`, `embedded_chunks.json`이 large 컬렉션 적재에 재사용되는 일을 피할 수 있습니다. `retrieval_profile` 없이 직접 `chunking_mode + collection_name`을 지정하는 경우에는 KG/CQ 산출물 경로가 기본 `data/ontology`에 섞이지 않도록 `ontology_artifact_root`도 함께 지정합니다.

`/ingest` 요청 파라미터:

| 파라미터 | 기본값 | 설명 |
| --- | --- | --- |
| `input_path` | `null` | 적재할 PDF 추출 JSON 파일 경로입니다. 생략하면 `runtime.default_json_dirs`에서 첫 JSON을 사용합니다. |
| `resume` | `true` | 완료된 단계의 산출물이 있으면 재사용합니다. 실패 후 재시도할 때 보통 `true`를 사용합니다. |
| `force_steps` | `[]` | `resume=true`여도 다시 실행할 단계 목록입니다. 가능한 값은 `load_document`, `chunk_document`, `embed_chunks`, `reset_qdrant_collection`, `upsert_qdrant`, `build_ontology_layer`, `build_query_graph_layer`입니다. |
| `skip_qdrant` | `false` | Qdrant upsert를 건너뜁니다. 적재 전 산출물 검증에 사용합니다. |
| `skip_existing_qdrant` | `false` | Qdrant에 같은 `document_key`의 current 문서가 있으면 upsert를 건너뜁니다. |
| `chunking_mode` | `null` | 요청별 청킹 방식입니다. `small`은 작은 `text` 청크 방식, `large`는 현재 튜닝된 큰 `text` 청크 방식입니다. 생략하면 TOML 설정을 그대로 사용합니다. |
| `collection_name` | `null` | 요청별 Qdrant 컬렉션명입니다. 생략하면 설정의 `qdrant.collection_name`을 사용합니다. |
| `ontology_artifact_root` | `null` | 요청별 ontology/KG 산출물 저장 루트입니다. `retrieval_profile` 없이 `collection_name + chunking_mode`를 직접 지정할 때 `data/ontology-large`, `data/ontology-small`처럼 분리하려고 사용합니다. |
| `retrieval_profile` | `null` | Qdrant 컬렉션명, 청킹 방식, Neo4j URI, ontology 산출물 경로를 함께 선택하는 설정 profile입니다. `large`, `small`처럼 비교 실험 단위를 고를 때 사용합니다. 이 값을 쓰면 `chunking_mode`, `collection_name`, `ontology_artifact_root`를 함께 보내지 않습니다. |
| `kg` | `{}` | KG 생성 관련 옵션을 묶은 객체입니다. 생략하면 TOML의 기본 KG 설정과 전체 청크를 사용합니다. |
| `kg.extraction_mode` | `null` | KG 생성 방식입니다. `rule_based`, `llm`, `hybrid` 중 하나이며 생략하면 TOML의 `ontology.kg_extraction_mode`를 사용합니다. |
| `kg.chunk_offset` | `0` | KG entity/relation 추출을 시작할 child chunk offset입니다. 긴 LLM 추출을 일부 구간만 검증하거나 중간 구간부터 실행할 때 사용합니다. |
| `query_graph` | `{}` | Query-Centric GraphRAG용 synthetic query graph 생성 옵션입니다. |
| `query_graph.enabled` | `false` | 요청 단위로 query graph 생성과 저장을 켭니다. |
| `query_graph.chunk_offset` | `null` | query graph 생성을 시작할 child chunk offset입니다. |
| `query_graph.chunk_limit` | `null` | query graph 생성에서 처리할 최대 child chunk 수입니다. |
| `query_graph.reset_scope` | `false` | 현재 retrieval profile의 query graph scope만 삭제 후 재생성합니다. |
| `kg.chunk_limit` | `null` | KG entity/relation 추출에서 처리할 최대 child chunk 수입니다. `null`이면 전체 청크를 처리합니다. |
| `reset` | `{}` | 컬렉션 초기화 같은 파괴적 작업 옵션을 묶은 객체입니다. |
| `reset.qdrant_collection` | `false` | Qdrant 컬렉션을 삭제 후 재생성합니다. 컬렉션 전체 데이터가 삭제되는 파괴적 작업입니다. |
| `reset.confirm_collection_name` | `null` | 컬렉션 초기화 확인용 컬렉션명입니다. `reset.qdrant_collection=true`일 때 `collection_name` override까지 반영된 최종 컬렉션명과 정확히 일치해야 합니다. |
| `reset.neo4j_graph` | `false` | 현재 `retrieval_profile`의 Neo4j graph scope만 삭제 후 재생성합니다. Qdrant는 건드리지 않습니다. |
| `reset.confirm_retrieval_profile` | `null` | Neo4j graph reset 확인용 profile 이름입니다. `reset.neo4j_graph=true`일 때 `retrieval_profile`과 정확히 같아야 합니다. |

일반 적재는 같은 `document_key`의 기존 point만 교체하며 컬렉션의 다른 문서는 유지합니다. 컬렉션 전체를 비우려면 반드시 `reset.qdrant_collection=true`를 명시해야 합니다.

### 청킹 크기 조정

현재 기본 청킹은 PDF layout element를 바로 검색 단위로 쓰지 않고, 인접한 짧은 text leaf를 child chunk로 병합합니다. 또한 parent chunk가 너무 짧으면 인접 parent와 병합해 `parent_text`가 LLM 컨텍스트로 쓸 만큼 충분해지도록 보정합니다.

```toml
[dev.chunking]
child_min_chars = 250
child_target_chars = 600
child_char_max = 1400
parent_min_chars = 500
parent_target_chars = 1400
parent_char_max = 2000
```

- `child_min_chars`: text child chunk가 최소한 확보하려는 글자 수입니다. 현재 문서 기준 검색 정밀도를 유지하기 위해 250자로 둡니다.
- `child_target_chars`: 가능하면 이 정도 크기까지 인접 leaf를 병합합니다. 현재 문서 기준 child 중앙값이 약 550자대로 형성됩니다.
- `child_char_max`: child chunk의 절대 최대 크기입니다.
- `parent_min_chars`: parent chunk가 너무 짧을 때 인접 parent와 병합하는 기준입니다.
- `parent_target_chars`: parent chunk가 가능하면 목표로 삼는 크기입니다. 현재 문서 기준 `parent_text` 평균이 1400자대에 가깝게 형성되도록 1400자로 둡니다.
- `parent_char_max`: parent chunk의 절대 최대 크기입니다. 현재 설정에서는 `parent_text`가 2000자를 넘지 않습니다.

이 설정을 바꾸면 Qdrant에 저장되는 embedding 단위가 달라집니다. 변경 후에는 `force_steps=["chunk_document", "embed_chunks", "upsert_qdrant"]`로 재청킹, 재임베딩, 재적재를 실행해야 합니다.

```bash
curl -X POST http://127.0.0.1:8000/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "resume": true,
    "force_steps": ["chunk_document", "embed_chunks", "upsert_qdrant"]
  }'
```

### Qdrant 검색

현재 `/search`는 답변 생성 API가 아니라 근거 청크 검색 API입니다. 다만 검색 결과가 실제 답변 생성 프롬프트에 어떻게 들어가는지 바로 확인할 수 있도록 `prompt`를 반환합니다. `only_prompt=false`로 요청하면 `search_type`, `search_result`, `empty_prompt`, `prompt`, `total_duration_ms`를 함께 반환합니다. Neo4j graph expansion은 `graph_mode=graph|auto`에서만 검색 흐름에 추가되며, 실제 LLM answer generation은 `/answer`에서만 실행됩니다.

검색은 LangGraph로 아래 순서로 실행됩니다.

```text
query
→ route_query
→ embed_query
→ hybrid_search
→ rerank
→ chunk_eval
→ apply_quality_penalty
→ graph_expand
→ finalize
→ results
```

- `route_query`: `graph_mode`를 해석하고 `auto`일 때 graph expansion 필요 여부를 판단합니다.
- `embed_query`: 사용자 질의를 dense embedding과 Kiwi BM25 sparse vector로 변환합니다.
- `hybrid_search`: Qdrant dense/sparse prefetch를 수행하고 DBSF fusion으로 후보를 합칩니다.
- `rerank`: `rerank=true`이고 설정의 `rerank.enabled=true`이면 reranker로 후보를 재정렬합니다.
- `chunk_eval`: `chunk_eval.enabled=true`일 때만 외부 `/v1/chunk-eval` 서비스에 재정렬된 후보 목록을 보내 추가 평가를 수행합니다. 기본값은 비활성화입니다.
- `apply_quality_penalty`: 검색된 원본 `text`가 너무 짧은 후보에 점수 패널티를 적용해 최종 순위를 보정합니다.
- `graph_expand`: routing 결과가 `hybrid_graph`이면 Neo4j에서 공유 엔티티, query entity, 1-hop entity relation 기반 후보를 추가합니다.
- `finalize`: 최종 `limit`만큼 결과를 잘라 API 응답 형태로 변환합니다. 검색된 원본 청크 `text`는 그대로 두고, 짧은 청크에는 `parent_text`, 앞뒤 청크, 페이지 텍스트 순으로 LLM 컨텍스트용 `context_text`를 별도로 붙입니다.

짧은 청크 컨텍스트 보강은 `result_context` 설정으로 제어합니다. 기본값은 활성화입니다.

```toml
[dev.result_context]
enabled = true
min_chars = 120
max_chars = 3000
use_parent_text = true
use_neighbor_text = true
neighbor_window = 1
use_page_text = true
```

- `enabled`: 짧은 결과 표시 문맥 확장 여부입니다.
- `min_chars`: 이 글자 수보다 짧은 결과만 확장 대상이 됩니다.
- `max_chars`: 보강된 컨텍스트 텍스트의 최대 길이입니다.
- `use_parent_text`: Qdrant payload의 `parent_text`를 우선 사용합니다.
- `use_neighbor_text`: `parent_text`도 짧으면 Qdrant에서 같은 `parent_id`의 앞뒤 child chunk를 조회해 붙입니다.
- `neighbor_window`: 앞뒤로 몇 개의 child chunk를 붙일지 정합니다. `1`이면 이전 1개, 현재 chunk, 다음 1개를 합칩니다.
- `use_page_text`: `parent_text`와 앞뒤 청크도 부족하면 `parse_result_path`와 `page_numbers`로 원본 JSON의 페이지 텍스트를 읽어 fallback으로 사용합니다.

내부 검색 결과의 `text`는 항상 실제 검색된 원본 청크입니다. `/search` 응답의 `search_result[].context_text`는 LLM에 넘기기 위한 보강 문맥이며, 상세 출처인 `context_expanded`, `context_source`, `context_neighbor_chunk_ids`는 `/answer` 요청에서 `include_search=true`로 원본 검색 결과를 함께 받을 때 확인할 수 있습니다.

짧은 `text` 검색 패널티는 `search` 설정으로 제어합니다. 기본값은 활성화입니다.

```toml
[dev.search]
default_retrieval_profile = "large"
hybrid_rerank_default = true
post_graph_rerank_default = true
short_text_penalty_enabled = true
short_text_min_chars = 120
short_text_penalty_floor = 0.70
```

- `default_retrieval_profile`: `/search`, `/answer` 요청에서 `retrieval_profile`과 `collection_name`을 모두 생략했을 때 사용할 profile입니다. 현재 기본값은 `large`입니다.
- `hybrid_rerank_default`: API 요청에서 `rerank`, `hybrid_rerank`를 모두 생략했을 때 Hybrid Search 직후 rerank를 수행할지 정합니다.
- `post_graph_rerank_default`: API 요청에서 `rerank`, `post_graph_rerank`를 모두 생략했을 때 graph 후보 병합 후 2차 rerank를 수행할지 정합니다.
- `short_text_penalty_enabled`: 짧은 검색 청크의 최종 순위 패널티 여부입니다.
- `short_text_min_chars`: 이 글자 수보다 짧은 `text`를 패널티 대상으로 봅니다.
- `short_text_penalty_floor`: 패널티 multiplier의 하한입니다. 실제 multiplier는 `max(short_text_penalty_floor, text_chars / short_text_min_chars)`로 계산하므로, 기준에 약간 못 미치는 청크는 약하게, 매우 짧은 청크는 더 강하게 내려갑니다.

이 패널티는 Qdrant payload나 `text`, `parent_text`를 수정하지 않습니다. `rerank_score`가 있으면 그 값을 기준으로, 없으면 Qdrant `score`를 기준으로 `quality_score`를 계산하고 최종 정렬에 사용합니다. 패널티 적용 여부는 `/answer` 요청에서 `include_search=true`를 사용해 내부 검색 결과의 `quality_penalty_reason=short_text` 값을 보면 확인할 수 있습니다.

`chunk_eval`은 API 요청 파라미터가 아니라 서버 설정으로 켜고 끕니다. 기본 Hybrid Search와 rerank 결과를 바꾸지 않도록 기본값은 `false`입니다.

```toml
[dev.chunk_eval]
enabled = true
base_url = "http://localhost:18080"
timeout = 60.0
```

환경변수로 켜려면:

```bash
APP_CHUNK_EVAL__ENABLED=true
APP_CHUNK_EVAL__BASE_URL=http://localhost:18080
```

요청 payload는 내부적으로 아래 형태로 전송됩니다.

```json
{
  "queries": ["방사능 누출 초기 대응 절차는?"],
  "documents": [[{"id": "point-id", "payload": {"text": "검색 후보 청크"}}]]
}
```

응답도 `documents`를 같은 2중 배열 구조로 반환해야 합니다. chunk-eval 서비스가 실패하거나 응답 구조가 맞지 않으면 검색 그래프는 기존 rerank 결과로 fallback하며, `trace`의 `chunk_eval` 노드에 `fallback` 또는 `skipped` 상태가 남습니다.

기본 검색:

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "방사능 누출 초기 대응 절차는?",
    "limit": 5
  }'
```

특정 컬렉션에서 검색하려면 `collection_name`을 지정합니다. small/large 방식으로 만든 컬렉션을 비교할 때 이 값을 바꿔 같은 질의를 보내면 됩니다.

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "방사능 누출 초기 대응 절차는?",
    "collection_name": "ontology-radiation-safety-action-manual-large",
    "limit": 5
  }'
```

rerank 없이 Qdrant hybrid fusion 결과만 확인하려면 아래처럼 요청합니다. 단, 서버 설정에서 `chunk_eval.enabled=true`로 켜둔 경우에는 chunk-eval 후처리가 추가로 실행될 수 있으므로 순수 Qdrant 결과 확인 시에는 `chunk_eval.enabled=false`를 사용하세요.

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "주민 보호 조치는 무엇인가요?",
    "limit": 5,
    "rerank": false
  }'
```

dense/sparse 후보 개수를 직접 조정하려면:

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "방사능 누출 상황 보고 절차",
    "dense_limit": 50,
    "sparse_limit": 50,
    "limit": 10
  }'
```

특정 문서만 대상으로 검색하려면 `document_key`를 지정합니다.

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "초기 상황판단 회의는 언제 하나요?",
    "document_key": "(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정 251013)",
    "limit": 5
  }'
```

`/search` 요청 파라미터:

| 파라미터 | 기본값 | 설명 |
| --- | --- | --- |
| `query` | 필수 | 원본 사용자 질의입니다. `query_complete`가 비어 있으면 dense/sparse query embedding과 query routing에 사용됩니다. |
| `query_complete` | `null` | 질의 확장 API를 통해 생성된 정제 질의입니다. 값이 있으면 `query`보다 우선해서 검색 실행, query routing, 답변 생성 질문으로 사용됩니다. |
| `limit` | `settings.search.final_limit` | 최종 반환 결과 개수입니다. |
| `dense_limit` | `settings.search.dense_limit` | Qdrant dense vector prefetch 후보 개수입니다. |
| `sparse_limit` | `settings.search.sparse_limit` | Qdrant sparse vector prefetch 후보 개수입니다. |
| `rerank` | `null` | 하위 호환용 전체 rerank 스위치입니다. 새 요청에서는 `hybrid_rerank`, `post_graph_rerank`를 각각 사용하는 것을 권장합니다. 이 값까지 생략하면 toml 기본값을 따릅니다. |
| `hybrid_rerank` | `null` | Qdrant Hybrid Search 직후 후보를 reranker로 재정렬할지 여부입니다. 생략하면 `rerank` 요청값을 따르고, `rerank`도 생략하면 `settings.search.hybrid_rerank_default`를 따릅니다. |
| `post_graph_rerank` | `null` | KG/query graph 후보를 병합한 뒤 2차 rerank를 수행할지 여부입니다. 생략하면 `rerank` 요청값을 따르고, `rerank`도 생략하면 `settings.search.post_graph_rerank_default`를 따릅니다. |
| `graph_mode` | `null` | `hybrid`, `graph`, `auto` 중 하나입니다. `hybrid`는 그래프를 끄고, `graph`는 강제로 켜며, `auto`는 Query Router가 질의 유형에 따라 graph expansion 여부를 결정합니다. |
| `graph_strategy` | `kg` | `kg`, `query_graph`, `combined`, `auto` 중 하나입니다. `graph_mode`가 그래프를 켰을 때 KG expansion, Query Graph expansion, query_graph→KG 2단계 조합, 또는 질의 타입 기반 자동 선택 중 무엇을 사용할지 결정합니다. |
| `kg_expansion_mode` | `settings.search.kg_expansion_mode_default` | `legacy`, `query_guided` 중 하나입니다. 생략하면 TOML 기본값을 사용하고, 요청값이 있으면 요청값이 우선합니다. |
| `only_prompt` | `settings.search.only_prompt_default` | `true`이면 `prompt`만 반환하고, `false`이면 검색 결과 요약과 전체 수행시간을 포함한 전체 응답을 반환합니다. |
| `use_graph` | `null` | 하위 호환용 파라미터입니다. `true`는 `graph_mode=graph`, `false`는 `graph_mode=hybrid`로 매핑됩니다. 새 요청에서는 `graph_mode`를 권장합니다. |
| `document_key` | `null` | 특정 문서 안에서만 검색할 때 사용하는 필터입니다. |
| `collection_name` | `null` | 검색 대상 Qdrant 컬렉션명입니다. 이 값을 보내면 `search.default_retrieval_profile`은 적용되지 않습니다. |
| `retrieval_profile` | `settings.search.default_retrieval_profile` | Qdrant 컬렉션과 Neo4j URI를 함께 선택하는 설정 profile입니다. `retrieval_profile`과 `collection_name`을 모두 생략하면 toml의 기본 profile을 사용합니다. 현재 기본값은 `large`입니다. |

응답 예시:

```json
{
  "query": "방사능 누출 초기 대응 절차는?",
  "search_type": "hybrid",
  "search_result": [
    {
      "rank": 1,
      "id": "child:0:3",
      "filename": "(사회재난-17) ... .pdf",
      "page": [12],
      "context_text": "LLM에 넘길 보강 문맥"
    }
  ],
  "empty_prompt": "당신은 ...\\n질문:\\n{query}\\n\\n검색된 참고자료:\\n{context}",
  "prompt": "당신은 ...\\n질문:\\n방사능 누출 초기 대응 절차는?\\n\\n검색된 참고자료:\\n<sources>...</sources>",
  "total_duration_ms": 123.45
}
```

내부 검색 workflow의 상세 `routing`, `trace`, 원본 `results`가 필요하면 `/answer` 요청에 `include_search=true`를 사용합니다.

실제 retrieve 테스트는 아래 순서로 진행하는 것을 권장합니다.

1. Qdrant 적재 여부를 먼저 확인합니다. `/search`는 Qdrant에 적재된 chunk만 반환합니다.
2. `rerank=false`로 Qdrant hybrid retrieval 자체가 동작하는지 확인합니다.

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "방사능 누출 초기 대응 절차는?",
    "limit": 5,
    "rerank": false
  }'
```

3. 결과가 나오면 `rerank=true`로 재정렬까지 확인합니다. 그래프 후보 병합 후 2차 rerank만 별도로 끄고 싶으면 `post_graph_rerank=false`를 사용합니다.

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "방사능 누출 초기 대응 절차는?",
    "limit": 5,
    "rerank": true,
    "post_graph_rerank": false
  }'
```

4. 결과가 너무 적거나 관련성이 낮으면 `dense_limit`, `sparse_limit`을 늘려 후보 pool을 키웁니다.

```bash
curl -X POST http://127.0.0.1:8000/search \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "방사능 누출 초기 대응 절차는?",
    "dense_limit": 80,
    "sparse_limit": 80,
    "limit": 10,
    "rerank": false
  }'
```

### 개발용 답변 생성

운영 기준 검색 API는 `/search`입니다. 현재 `/search`는 내부 검색 결과를 그대로 노출하지 않고, 최종 검색 결과가 답변 프롬프트에 어떤 형태로 들어가는지 확인할 수 있도록 `search_type`, `search_result`, `empty_prompt`, `prompt`를 반환합니다. `search_type`은 `hybrid`, `kg`, `query_graph`, `combined` 중 하나입니다. 개발 단계에서 실제 LLM 답변까지 확인하려면 `/answer`를 사용합니다. `/answer`는 기존 `SearchWorkflow`를 그대로 실행한 뒤, 그 응답의 `context_text`와 출처 메타데이터를 프롬프트 컨텍스트로 가공해 답변을 생성합니다.

KG 확장의 요청 기본값은 `configs/settings.*.toml`의 `search.kg_expansion_mode_default`로 정합니다. 현재 기본값은 기존 방식인 `legacy`입니다. 이 모드는 HybridRAG 상위 chunk를 seed로 삼아 공유 entity, query term entity, 1-hop entity relation을 탐색하며 LLM 기반 사용자 질의 추출을 수행하지 않습니다. 비교 실험이 필요하면 요청에 `kg_expansion_mode="query_guided"`를 명시하거나 TOML 기본값을 `query_guided`로 바꿉니다. 이 모드는 KG 확장 직전에 `prompts/kg_query_extraction.yaml`로 사용자 질의의 entity, relation type 후보, intent, constraints를 추출하고, 실패 시 rule-based fallback을 사용합니다. 추출값은 Neo4j traversal 힌트일 뿐 답변 근거로 직접 사용하지 않습니다.

답변 생성 프롬프트는 `prompts/answer_generation.yaml`에 있습니다. 코드는 `langchain_core.prompts.load_prompt`로 이 YAML을 읽습니다. 프롬프트에는 검색 결과별 `chunk_id` 기반 source `id`, `파일이름`, `페이지`, `section_path`, `context_text`만 XML로 전달합니다. 그래프 강화 답변에서는 `include_evidence_chains=true`일 때 짧은 `<evidence_chains>` 요약만 추가합니다. 점수, routing, trace 같은 디버깅 값은 프롬프트에 넣지 않고 `/answer`의 `include_search=true` 응답에서 확인합니다.

메인 Qdrant chunk collection은 재적재 후 payload에 Neo4j `Chunk`와 같은 `chunk_uid`를 저장합니다. `chunk_uid`는 `document_key + collection_name + chunking_profile + chunk_id`로 결정되므로, Qdrant point id처럼 재적재 버전에 따라 바뀌지 않습니다.

답변 본문에서 사용한 근거는 `[자료 N]`으로 표시하도록 하고, 답변 마지막의 `참고자료` 섹션에는 실제 사용한 자료의 `파일이름`과 `페이지`만 출력하도록 구성했습니다. 모델이 본문에 `[자료 N]`을 표시했지만 `참고자료` 섹션을 누락한 경우에는 서버가 인용된 자료만 골라 마지막에 보강합니다.

LLM 설정은 `configs/settings.dev.toml`의 `[dev.llm]`을 사용합니다.

```toml
[dev.llm]
base_url = "http://localhost:8080/v1"
model_name = "hcx-seed-32b-q4"
timeout = 300.0
temperature = 0.0
```

요청 예시:

```bash
curl -X POST http://127.0.0.1:8000/answer \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "방사능 누출 초기 대응 절차는?",
    "retrieval_profile": "large",
    "limit": 5,
    "rerank": true,
    "max_context_chars": 12000,
    "include_search": true
  }'
```

`/answer` 요청은 `/search`의 모든 파라미터를 그대로 받으며, 아래 파라미터만 추가됩니다.

| 파라미터 | 기본값 | 설명 |
| --- | --- | --- |
| `max_context_chars` | `12000` | LLM 프롬프트에 넣을 검색 근거 컨텍스트 최대 문자 수입니다. |
| `include_search` | `true` | 내부 search 결과를 응답에 함께 포함할지 여부입니다. 디버깅 단계에서는 `true`를 권장합니다. |

응답에는 `answer`, `contexts`, 선택적으로 `search`가 포함됩니다. 답변은 검색 근거 안에서만 생성하도록 프롬프트를 구성합니다.

CQ 목록으로 `/answer`를 반복 호출하려면 개발용 스크립트를 사용합니다. 평가 입력 JSONL은 `data/eval/inputs/`, 평가 결과와 진행률 파일은 `data/eval/results/`, API job 메타데이터는 `data/eval/jobs/`로 분리해 관리합니다. 컨테이너 운영에서는 `data/eval/inputs`를 read-only 볼륨으로 주입하고, `data/eval/results`, `data/eval/jobs`를 write 볼륨으로 분리하는 구성을 권장합니다.

스크립트 기본 입력은 `data/eval/inputs/search_answer_test_queries.jsonl`을 먼저 찾고, 없으면 기존 ontology CQ 산출물(`data/ontology-large/cq/search_answer_test_queries.jsonl`, `data/ontology/cq/search_answer_test_queries.jsonl`)을 fallback으로 사용합니다. 결과는 JSONL로 저장됩니다. 스크립트는 query마다 한 줄씩 즉시 append 저장하며, 재실행 시 같은 `retrieval_profile + graph_mode + graph_strategy + query_id` 조합의 성공 결과는 건너뜁니다. 실패 row는 성공으로 간주하지 않으므로 다음 실행에서 다시 시도합니다. 콘솔에는 `총 N개 중 K번째 질문 완료` 형식과 함께 routing, vector search, graph search, graph strategy, graph candidate count, answer generation, total 시간을 출력합니다. JSONL에도 같은 값이 `timings`, `routing`, `graph_activated`, `selected_graph_strategy`, `graph_candidate_count`, `kg_candidate_count`, `query_graph_candidate_count`, `hybrid_rerank`, `post_graph_rerank`, `post_graph_rerank_applied`로 저장됩니다.

진행률은 기본적으로 `<output>.progress.json`에 atomic write로 저장됩니다. 예를 들어 `--output data/eval/results/cq_answer_large_hybrid.jsonl`이면 `data/eval/results/cq_answer_large_hybrid.jsonl.progress.json`에서 전체 선택 질문 수, 이미 완료된 질문 수, 이번 실행 완료/성공/실패 수, 진행률, 평균 질문 처리 시간, 예상 잔여 시간을 확인할 수 있습니다. 경로를 직접 지정하려면 `--progress-output`을 사용합니다.

```bash
uv run python scripts/run_cq_answer_eval.py \
  --retrieval-profile large \
  --eval-mode hybrid \
  --max-queries 5 \
  --output data/eval/results/cq_answer_large_hybrid.jsonl
```

평가 모드는 `--eval-mode hybrid|kg|query_graph|combined|auto`로 고정하는 것을 권장합니다.

- `hybrid`: `graph_mode=hybrid`, `graph_strategy=kg`
- `kg`: `graph_mode=graph`, `graph_strategy=kg`
- `query_graph`: `graph_mode=graph`, `graph_strategy=query_graph`
- `combined`: `graph_mode=graph`, `graph_strategy=combined`
- `auto`: `graph_mode=auto`, `graph_strategy=auto`

기존 `--graph-mode`, `--graph-strategy`, `--use-graph`도 하위 호환 옵션으로 유지되지만, `--eval-mode`가 있으면 `--eval-mode`가 우선합니다.

```bash
uv run python scripts/run_cq_answer_eval.py \
  --retrieval-profile large \
  --eval-mode query_graph \
  --max-queries 5 \
  --output data/eval/results/cq_answer_large_query_graph.jsonl
```

Query Router 자동 판단 결과를 평가하려면 `--eval-mode auto`를 사용합니다.

```bash
uv run python scripts/run_cq_answer_eval.py \
  --retrieval-profile large \
  --eval-mode auto \
  --max-queries 5 \
  --output data/eval/results/cq_answer_large_auto.jsonl
```

KG legacy와 query-guided 방식을 비교하려면 같은 `--eval-mode kg` 또는 `--eval-mode combined` 요청에 `--kg-expansion-mode`만 바꿔 실행합니다. 성공 row skip 기준에도 이 값이 포함되므로 같은 output 파일 안에서도 두 모드를 분리해 재개할 수 있습니다.

```bash
uv run python scripts/run_cq_answer_eval.py \
  --retrieval-profile large \
  --eval-mode kg \
  --kg-expansion-mode query_guided \
  --max-queries 5 \
  --output data/eval/results/cq_answer_large_kg_query_guided.jsonl
```

전체 CQ를 처음부터 다시 실행하려면 `--max-queries`를 생략하고 필요 시 `--overwrite`를 붙입니다. 기본 저장값은 `answer`, 최종 `search_results`, 답변 context를 포함하는 compact JSONL입니다. `/answer` 원본 응답 전체가 필요하면 `--full-response`를 추가합니다.

같은 평가를 CLI 대신 API로 시작할 수도 있습니다. `POST /eval/answer-jobs`는 서버 내부에서 백그라운드 평가 작업을 만들고 즉시 `job_id`를 반환합니다. 질문은 body의 `queries` 배열로 직접 보내거나, 서버 로컬 JSONL 경로를 `queries_path`로 지정할 수 있습니다. 상대 경로 `queries_path`는 기본적으로 `eval.input_dir` 아래에서 찾고, 상대 경로 `output_path`, `progress_output`은 기본적으로 `eval.output_dir` 아래에 저장합니다. 결과는 질문마다 `output_path`에 JSONL로 즉시 append 저장되며, 진행률은 `progress_output`에 저장됩니다.

```bash
curl -X POST http://127.0.0.1:8000/eval/answer-jobs \
  -H 'Content-Type: application/json' \
  -d '{
    "queries_path": "user_questions.jsonl",
    "output_path": "user_questions_hybrid.jsonl",
    "progress_output": "user_questions_hybrid.progress.json",
    "retrieval_profile": "large",
    "eval_mode": "hybrid",
    "limit": 5
  }'
```

응답 예시:

```json
{
  "job_id": "7f9a1c2d3e4f",
  "status": "started",
  "output_path": "/workspace/data/eval/results/user_questions_hybrid.jsonl",
  "progress_path": "/workspace/data/eval/results/user_questions_hybrid.progress.json",
  "progress_url": "/eval/answer-jobs/7f9a1c2d3e4f"
}
```

진행률과 결과는 아래처럼 확인합니다.

```bash
curl http://127.0.0.1:8000/eval/answer-jobs/7f9a1c2d3e4f
curl 'http://127.0.0.1:8000/eval/answer-jobs/7f9a1c2d3e4f/results?limit=30'
```

이 API는 개발/평가 편의 기능입니다. 여러 gunicorn worker로 운영할 경우 작업 실행은 요청을 받은 worker에서 진행되지만, 진행률과 결과는 파일로 저장되므로 `progress_url` 조회는 다른 worker에서도 동작합니다. 서버가 재시작되면 실행 중인 작업은 중단되며, 같은 `output_path`로 다시 시작하면 이미 성공한 row는 건너뜁니다.

컨테이너에서 외부 평가 파일을 주입하는 예시는 아래와 같습니다.

```bash
docker run --rm -p 8000:8000 \
  -v /host/configs:/app/configs:ro \
  -v /host/eval-inputs:/app/data/eval/inputs:ro \
  -v /host/eval-results:/app/data/eval/results \
  -v /host/eval-jobs:/app/data/eval/jobs \
  graph-was
```

## 개발용 일부 적재 테스트

Qdrant에 일부 청크만 별도 document key로 적재해 청킹/임베딩/upsert를 빠르게 검증할 때는 개발용 CLI를 사용합니다. KG 추출만 일부 청크로 제한하는 경우에는 `/ingest`의 `kg.chunk_offset`, `kg.chunk_limit`을 사용합니다.

```bash
uv run python -m scripts.smoke_ingest --limit 20
```

기본적으로 Qdrant `document_key`는 `원본문서키:smoke-20`처럼 suffix가 붙어 원본 적재본과 분리됩니다. suffix를 직접 지정할 수도 있습니다.

```bash
uv run python -m scripts.smoke_ingest --limit 20 --key-suffix smoke-20
```

Qdrant upsert 없이 JSON 로드, 청킹, 임베딩까지만 확인하려면:

```bash
uv run python -m scripts.smoke_ingest --limit 20 --skip-qdrant
```

small/large profile 기준으로 일부 적재를 확인하려면:

```bash
uv run python -m scripts.smoke_ingest --limit 20 --retrieval-profile large
uv run python -m scripts.smoke_ingest --limit 20 --retrieval-profile small
```

## 체크포인트

적재 중간 산출물은 `data/work/<document-key>-<hash>/` 아래에 저장됩니다.

- `raw_document.json`
- `chunks.json`
- `parents.jsonl`
- `chunks.jsonl`
- `chunk_preview.json`
- `chunk_preview.jsonl`
- `embedded_chunks.json`
- `embedded_chunk_preview.jsonl`
- `embedding_timings.jsonl`
- `reset_qdrant_result.json`
- `upsert_result.json`
- `ontology_result.json`
- `checkpoint.json`
- `checkpoint_events.jsonl`
- `summary.json`

실패 후 같은 요청을 `{"resume": true}`로 재실행하면 완료된 단계 산출물을 재사용합니다. 특정 단계를 다시 실행하려면 `force_steps`에 `load_document`, `chunk_document`, `embed_chunks`, `reset_qdrant_collection`, `upsert_qdrant`, `build_ontology_layer`, `build_query_graph_layer` 중 하나를 넣습니다.

`summary.json`에는 노드별 trace와 `total_node_duration_ms`가 저장됩니다. `embedding_timings.jsonl`에는 청크별 dense/sparse embedding batch 시간과 청크 단위 추정 시간이 저장됩니다.

## 코드 구조

FastAPI와 LangGraph 계층은 분리되어 있습니다.

```text
app/
  main.py               # FastAPI 앱 생성과 v1 라우터 등록
  core/
    config.py           # Dynaconf TOML 로드 + Pydantic Settings 검증
    dependencies.py     # 공통 Depends 의존성
  api/
    deps.py             # 엔드포인트 의존성 재노출
    v1/
      router.py         # v1 라우터 통합
      endpoints/
        health.py       # GET /health
        ingest.py       # POST /ingest
        search.py       # POST /search
        answer.py       # POST /answer
        eval.py         # POST /eval/answer-jobs
  schemas/
    ingest.py           # IngestRequest
    search.py           # SearchRequest
    answer.py           # AnswerRequest
    eval.py             # 평가 job 요청/응답 schema
  services/
    answer_generation.py # 개발용 답변 생성
    chunk_eval.py       # 선택적 chunk-eval 후처리 클라이언트
    chunking.py         # 청킹
    embeddings.py       # dense/sparse embedding
    input_loader.py     # PDF 추출 JSON 로더
    qdrant_store.py     # Qdrant 적재
    rerank.py           # rerank
    query_routing.py    # graph_mode=auto query routing
    query_graph.py      # Query-Centric GraphRAG synthetic query graph
    result_context.py   # 짧은 검색 결과의 LLM 컨텍스트 보강
    ontology/           # Phase2 CQ 정규화와 초기 ontology schema 산출
    graph/
      common/           # 체크포인트/trace 공통 유틸
      ingest/
        state.py        # IngestState
        nodes.py        # load/chunk/embed/upsert/ontology/finalize 노드
        workflow.py     # StateGraph 빌드 + compile()
      search/
        state.py        # SearchState
        nodes.py        # embed_query/hybrid_search/rerank/chunk_eval/finalize 노드
        workflow.py     # StateGraph 빌드 + compile()
configs/
  settings.dev.toml     # 개발 환경 설정
  settings.prod.toml    # 운영 환경 설정
  example.settings.toml # 로컬 override 예제
  .example.secrets.toml # 로컬 secret 예제
data/
  eval/
    inputs/             # 평가 질문 JSONL 볼륨 마운트 지점
    results/            # 평가 결과 JSONL과 progress JSON 저장 지점
    jobs/               # 평가 API job 메타데이터 저장 지점
```

도메인 기능은 `app/services/`에 두어 FastAPI 라우터나 LangGraph 그래프 정의에 비즈니스 로직이 섞이지 않도록 했습니다.

## 문서 언어 기준

사용자 실행 안내 문서는 한글로 작성합니다.

- `README.md`
- `docs/architecture_ko.md`
- `docs/configuration_ko.md`
- `docs/graph_schema_v0.1.md`
- `docs/ontology_schema_v0.1.md`

Codex와 리뷰어가 작업 기준으로 반복 참조하는 핵심 문서는 영어로 유지합니다.

- `AGENTS.md`
- `ROADMAP.md`
- `docs/architecture.md`
- `docs/adr/*.md`
- `docs/glossary.md`
- `docs/evaluation_strategy.md`
- `docs/phase2_ontology_plan.md`
- `docs/query_routing.md`
- `docs/query_graph.md`
- `docs/production_checklist.md`
