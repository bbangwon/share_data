ls
pwd
exit
