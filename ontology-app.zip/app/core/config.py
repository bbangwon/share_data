from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

from dynaconf import Dynaconf
from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator

BASE_DIR = Path(__file__).resolve().parents[2]
CONFIG_DIR = BASE_DIR / "configs"


def _settings_files() -> list[str]:
    if not CONFIG_DIR.exists():
        return []
    visible_files = sorted(
        path
        for path in CONFIG_DIR.glob("*.toml")
        if path.is_file()
        and not path.name.startswith(".")
        and "example" not in path.name.lower()
    )
    base_files = [path for path in visible_files if path.name.startswith("settings.")]
    local_files = [path for path in visible_files if path not in base_files]
    secret_files = sorted(path for path in CONFIG_DIR.glob(".*.toml") if path.is_file())
    return [str(path) for path in [*base_files, *local_files, *secret_files]]


_dynaconf_settings = Dynaconf(
    envvar_prefix="APP",
    settings_files=_settings_files(),
    environments=True,
    load_dotenv=True,
    env_switcher="APP_ENV",
    merge_enabled=True,
)


class RuntimeConfig(BaseModel):
    artifact_root: Path
    persist_embeddings: bool = True
    default_json_dirs: tuple[Path, ...]

    @field_validator("artifact_root")
    @classmethod
    def resolve_artifact_root(cls, value: Path) -> Path:
        return _resolve_project_path(value)

    @field_validator("default_json_dirs")
    @classmethod
    def resolve_default_json_dirs(cls, value: tuple[Path, ...]) -> tuple[Path, ...]:
        return tuple(_resolve_project_path(path) for path in value)


class QdrantConfig(BaseModel):
    host: str
    port: int
    timeout: float
    collection_name: str
    dense_name: str
    sparse_name: str
    dense_vector_size: int | None = None
    upload_batch_size: int
    upload_max_retries: int

    def model_post_init(self, __context: Any) -> None:
        if self.upload_max_retries < 0:
            raise ValueError("qdrant.upload_max_retries must be non-negative")


class EmbeddingConfig(BaseModel):
    base_url: str
    timeout: float
    dense_model_name: str
    dense_concurrency: int
    sparse_model_name: str
    sparse_concurrency: int

    def model_post_init(self, __context: Any) -> None:
        if self.dense_concurrency <= 0:
            raise ValueError("embedding.dense_concurrency must be positive")
        if self.sparse_concurrency <= 0:
            raise ValueError("embedding.sparse_concurrency must be positive")


class RerankConfig(BaseModel):
    enabled: bool
    base_url: str
    model_name: str
    timeout: float
    top_n: int

    def model_post_init(self, __context: Any) -> None:
        if self.top_n <= 0:
            raise ValueError("rerank.top_n must be positive")


class ChunkEvalConfig(BaseModel):
    enabled: bool = False
    base_url: str = ""
    timeout: float = 60.0

    def model_post_init(self, __context: Any) -> None:
        if self.timeout <= 0:
            raise ValueError("chunk_eval.timeout must be positive")
        if self.enabled and not self.base_url:
            raise ValueError("chunk_eval.base_url is required when chunk_eval.enabled=true")


class ChunkingConfig(BaseModel):
    child_char_max: int
    child_token_cap: int
    child_min_chars: int | None = None
    child_target_chars: int | None = None
    parent_char_max: int
    parent_min_chars: int | None = None
    parent_target_chars: int | None = None
    min_leaf_chars: int
    profile: str
    ignore_categories: tuple[str, ...] = Field(default_factory=tuple)

    def model_post_init(self, __context: Any) -> None:
        if self.child_min_chars is None:
            self.child_min_chars = min(250, self.child_char_max)
        if self.child_target_chars is None:
            self.child_target_chars = min(max(self.child_min_chars, 600), self.child_char_max)
        if self.parent_min_chars is None:
            self.parent_min_chars = min(900, self.parent_char_max)
        if self.parent_target_chars is None:
            self.parent_target_chars = min(max(self.parent_min_chars, 1400), self.parent_char_max)

        if self.child_char_max <= 0:
            raise ValueError("chunking.child_char_max must be positive")
        if self.child_token_cap <= 0:
            raise ValueError("chunking.child_token_cap must be positive")
        if self.child_min_chars < 0:
            raise ValueError("chunking.child_min_chars must be non-negative")
        if self.child_target_chars <= 0:
            raise ValueError("chunking.child_target_chars must be positive")
        if self.child_target_chars > self.child_char_max:
            raise ValueError("chunking.child_target_chars must be less than or equal to child_char_max")
        if self.child_min_chars > self.child_char_max:
            raise ValueError("chunking.child_min_chars must be less than or equal to child_char_max")
        if self.parent_char_max <= 0:
            raise ValueError("chunking.parent_char_max must be positive")
        if self.parent_min_chars < 0:
            raise ValueError("chunking.parent_min_chars must be non-negative")
        if self.parent_min_chars > self.parent_char_max:
            raise ValueError("chunking.parent_min_chars must be less than or equal to parent_char_max")
        if self.parent_target_chars <= 0:
            raise ValueError("chunking.parent_target_chars must be positive")
        if self.parent_target_chars > self.parent_char_max:
            raise ValueError("chunking.parent_target_chars must be less than or equal to parent_char_max")


class SearchConfig(BaseModel):
    dense_limit: int
    sparse_limit: int
    final_limit: int
    default_retrieval_profile: str | None = None
    only_prompt_default: bool = True
    hybrid_rerank_default: bool = True
    post_graph_rerank_default: bool = True
    kg_expansion_mode_default: Literal["legacy", "query_guided"] = "legacy"
    short_text_penalty_enabled: bool = True
    short_text_min_chars: int = 120
    short_text_penalty_floor: float = 0.70

    def model_post_init(self, __context: Any) -> None:
        if self.dense_limit <= 0:
            raise ValueError("search.dense_limit must be positive")
        if self.sparse_limit <= 0:
            raise ValueError("search.sparse_limit must be positive")
        if self.final_limit <= 0:
            raise ValueError("search.final_limit must be positive")
        if self.short_text_min_chars < 0:
            raise ValueError("search.short_text_min_chars must be non-negative")
        if not 0 < self.short_text_penalty_floor <= 1:
            raise ValueError("search.short_text_penalty_floor must be greater than 0 and less than or equal to 1")


class EvalConfig(BaseModel):
    input_dir: Path = Path("data/eval/inputs")
    output_dir: Path = Path("data/eval/results")
    job_dir: Path = Path("data/eval/jobs")

    @field_validator("input_dir", "output_dir", "job_dir")
    @classmethod
    def resolve_paths(cls, value: Path) -> Path:
        return _resolve_project_path(value)


class LoggingConfig(BaseModel):
    level: str = "INFO"
    directory: Path = Path("logs")
    filename: str = "app.log"
    retention_days: int = 14
    console_enabled: bool = True
    file_enabled: bool = True

    @field_validator("directory")
    @classmethod
    def resolve_directory(cls, value: Path) -> Path:
        return _resolve_project_path(value)

    def model_post_init(self, __context: Any) -> None:
        allowed_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        self.level = self.level.upper()
        if self.level not in allowed_levels:
            raise ValueError(f"logging.level must be one of {sorted(allowed_levels)}")
        if not self.filename:
            raise ValueError("logging.filename must not be empty")
        if self.retention_days <= 0:
            raise ValueError("logging.retention_days must be positive")


class ResultContextConfig(BaseModel):
    enabled: bool = True
    min_chars: int = 120
    max_chars: int = 3000
    use_parent_text: bool = True
    use_neighbor_text: bool = True
    neighbor_window: int = 1
    use_page_text: bool = True

    def model_post_init(self, __context: Any) -> None:
        if self.min_chars < 0:
            raise ValueError("result_context.min_chars must be non-negative")
        if self.max_chars <= 0:
            raise ValueError("result_context.max_chars must be positive")
        if self.neighbor_window < 0:
            raise ValueError("result_context.neighbor_window must be non-negative")


class LLMConfig(BaseModel):
    base_url: str | None = None
    model_name: str | None = None
    timeout: float | None = None
    temperature: float = 0.0
    api_key: SecretStr = SecretStr("no-key")

    def model_post_init(self, __context: Any) -> None:
        if self.temperature < 0:
            raise ValueError("llm.temperature must be non-negative")


class OntologyConfig(BaseModel):
    enabled: bool = False
    version: str = "ontology-v0.1"
    cq_source_dir: Path = Path("data/ontology_cq")
    artifact_root: Path = Path("data/ontology")
    kg_extraction_enabled: bool = False
    kg_extraction_mode: Literal["rule_based", "llm", "hybrid"] = "rule_based"
    kg_llm_concurrency: int = 1
    kg_llm_max_chunk_chars: int = 3500
    kg_llm_confidence_threshold: float = 0.5
    kg_upsert_enabled: bool = False
    qdrant_enrichment_enabled: bool = False
    graph_search_enabled: bool = False
    graph_search_limit: int = 5
    graph_search_seed_limit: int = 5

    @field_validator("cq_source_dir", "artifact_root")
    @classmethod
    def resolve_paths(cls, value: Path) -> Path:
        return _resolve_project_path(value)

    def model_post_init(self, __context: Any) -> None:
        if self.kg_llm_concurrency <= 0:
            raise ValueError("ontology.kg_llm_concurrency must be positive")
        if self.kg_llm_max_chunk_chars <= 0:
            raise ValueError("ontology.kg_llm_max_chunk_chars must be positive")
        if not 0 <= self.kg_llm_confidence_threshold <= 1:
            raise ValueError("ontology.kg_llm_confidence_threshold must be between 0 and 1")
        if self.graph_search_limit <= 0:
            raise ValueError("ontology.graph_search_limit must be positive")
        if self.graph_search_seed_limit <= 0:
            raise ValueError("ontology.graph_search_seed_limit must be positive")


class QueryRoutingConfig(BaseModel):
    enabled: bool = False
    graph_activation_threshold: float = 0.70
    llm_enabled: bool = False
    llm_confidence_threshold: float = 0.60
    llm_prompt_path: Path = Path("prompts/query_routing.yaml")

    @field_validator("llm_prompt_path")
    @classmethod
    def resolve_llm_prompt_path(cls, value: Path) -> Path:
        return _resolve_project_path(value)

    def model_post_init(self, __context: Any) -> None:
        if not 0 <= self.graph_activation_threshold <= 1:
            raise ValueError("query_routing.graph_activation_threshold must be between 0 and 1")
        if not 0 <= self.llm_confidence_threshold <= 1:
            raise ValueError("query_routing.llm_confidence_threshold must be between 0 and 1")


class KGQueryExtractionConfig(BaseModel):
    enabled: bool = True
    mode: Literal["llm", "rule_based"] = "llm"
    timeout: float | None = None
    temperature: float = 0.0
    fallback_to_rule_based: bool = True
    prompt_path: Path = Path("prompts/kg_query_extraction.yaml")

    @field_validator("prompt_path")
    @classmethod
    def resolve_prompt_path(cls, value: Path) -> Path:
        return _resolve_project_path(value)

    def model_post_init(self, __context: Any) -> None:
        if self.timeout is not None and self.timeout <= 0:
            raise ValueError("kg_query_extraction.timeout must be positive when provided")
        if self.temperature < 0:
            raise ValueError("kg_query_extraction.temperature must be non-negative")


class QueryGraphConfig(BaseModel):
    enabled: bool = False
    generation_enabled: bool = False
    upsert_enabled: bool = False
    questions_per_chunk: int = 3
    chunk_offset: int = 0
    chunk_limit: int | None = None
    quality_similarity_threshold: float = 0.55
    quality_top_ratio: float = 0.5
    neighbor_depth: int = 1
    neighbor_top_k: int = 5
    retrieval_query_limit: int = 20
    retrieval_chunk_limit: int = 10
    qdrant_collection_suffix: str = "-qcg"
    llm_prompt_path: Path = Path("prompts/query_graph_generation.yaml")
    max_chunk_chars: int = 2500

    @field_validator("llm_prompt_path")
    @classmethod
    def resolve_llm_prompt_path(cls, value: Path) -> Path:
        return _resolve_project_path(value)

    def model_post_init(self, __context: Any) -> None:
        if self.questions_per_chunk <= 0:
            raise ValueError("query_graph.questions_per_chunk must be positive")
        if self.chunk_offset < 0:
            raise ValueError("query_graph.chunk_offset must be greater than or equal to 0")
        if self.chunk_limit is not None and self.chunk_limit <= 0:
            raise ValueError("query_graph.chunk_limit must be positive when provided")
        if not 0 <= self.quality_similarity_threshold <= 1:
            raise ValueError("query_graph.quality_similarity_threshold must be between 0 and 1")
        if not 0 < self.quality_top_ratio <= 1:
            raise ValueError("query_graph.quality_top_ratio must be greater than 0 and less than or equal to 1")
        if self.neighbor_depth != 1:
            raise ValueError("query_graph.neighbor_depth must be 1 in v0.3")
        if self.neighbor_top_k <= 0:
            raise ValueError("query_graph.neighbor_top_k must be positive")
        if self.retrieval_query_limit <= 0:
            raise ValueError("query_graph.retrieval_query_limit must be positive")
        if self.retrieval_chunk_limit <= 0:
            raise ValueError("query_graph.retrieval_chunk_limit must be positive")
        if not self.qdrant_collection_suffix:
            raise ValueError("query_graph.qdrant_collection_suffix must not be empty")
        if self.max_chunk_chars <= 0:
            raise ValueError("query_graph.max_chunk_chars must be positive")


class Neo4jConfig(BaseModel):
    uri: str | None = None
    username: str | None = None
    password: SecretStr | None = None
    database: str | None = None
    connection_timeout: float = 30.0
    connection_write_timeout: float = 30.0
    connection_acquisition_timeout: float = 60.0
    max_transaction_retry_time: float = 30.0
    max_connection_lifetime: float = 3600.0
    max_connection_pool_size: int = 100
    liveness_check_timeout: float | None = None
    keep_alive: bool = True
    fetch_size: int = 1000

    def model_post_init(self, __context: Any) -> None:
        for key in (
            "connection_timeout",
            "connection_write_timeout",
            "connection_acquisition_timeout",
            "max_transaction_retry_time",
            "max_connection_lifetime",
        ):
            if getattr(self, key) <= 0:
                raise ValueError(f"neo4j.{key} must be positive")
        if self.max_connection_pool_size <= 0:
            raise ValueError("neo4j.max_connection_pool_size must be positive")
        if self.liveness_check_timeout is not None and self.liveness_check_timeout <= 0:
            raise ValueError("neo4j.liveness_check_timeout must be positive when provided")
        if self.fetch_size <= 0:
            raise ValueError("neo4j.fetch_size must be positive")


class RetrievalProfileConfig(BaseModel):
    collection_name: str
    chunking_mode: Literal["small", "large"] | None = None
    neo4j_uri: str | None = None
    neo4j_username: str | None = None
    neo4j_database: str | None = None
    ontology_artifact_root: Path | None = None

    @field_validator("ontology_artifact_root")
    @classmethod
    def resolve_ontology_artifact_root(cls, value: Path | None) -> Path | None:
        if value is None:
            return None
        return _resolve_project_path(value)


class RetrievalProfilesConfig(BaseModel):
    profiles: dict[str, RetrievalProfileConfig] = Field(default_factory=dict)


class Settings(BaseModel):
    """Validated application settings loaded by Dynaconf."""

    model_config = ConfigDict(extra="forbid")

    runtime: RuntimeConfig
    qdrant: QdrantConfig
    embedding: EmbeddingConfig
    rerank: RerankConfig
    chunk_eval: ChunkEvalConfig = Field(default_factory=ChunkEvalConfig)
    chunking: ChunkingConfig
    search: SearchConfig
    eval: EvalConfig = Field(default_factory=EvalConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    result_context: ResultContextConfig = Field(default_factory=ResultContextConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    ontology: OntologyConfig = Field(default_factory=OntologyConfig)
    query_routing: QueryRoutingConfig = Field(default_factory=QueryRoutingConfig)
    kg_query_extraction: KGQueryExtractionConfig = Field(default_factory=KGQueryExtractionConfig)
    query_graph: QueryGraphConfig = Field(default_factory=QueryGraphConfig)
    neo4j: Neo4jConfig = Field(default_factory=Neo4jConfig)
    retrieval_profiles: RetrievalProfilesConfig = Field(default_factory=RetrievalProfilesConfig)

    @classmethod
    def load(cls) -> "Settings":
        raw = _normalize_keys(_dynaconf_settings.as_dict())
        allowed = {key: raw[key] for key in cls.model_fields if key in raw}
        return cls.model_validate(allowed)


def _normalize_keys(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key).lower(): _normalize_keys(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_normalize_keys(item) for item in value]
    return value


def _resolve_project_path(value: Path) -> Path:
    return value if value.is_absolute() else BASE_DIR / value


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings.load()


def clear_settings_cache() -> None:
    get_settings.cache_clear()


def resolve_default_json_path(settings: Settings) -> Path:
    for directory in settings.runtime.default_json_dirs:
        if not directory.exists():
            continue
        matches = sorted(directory.glob("*.json"))
        if matches:
            return matches[0]
    searched = ", ".join(str(path) for path in settings.runtime.default_json_dirs)
    raise FileNotFoundError(f"No JSON input file found in: {searched}")
