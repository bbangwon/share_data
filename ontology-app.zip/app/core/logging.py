from __future__ import annotations

import logging
import sys
from logging.handlers import TimedRotatingFileHandler

from app.core.config import Settings

try:
    from concurrent_log_handler import ConcurrentTimedRotatingFileHandler
except ImportError:  # pragma: no cover - dependency is installed in production image.
    ConcurrentTimedRotatingFileHandler = None  # type: ignore[assignment]

_CONFIGURED = False


def configure_logging(settings: Settings) -> None:
    """Configure console and daily rotating file logs."""

    global _CONFIGURED
    if _CONFIGURED:
        return

    log_config = settings.logging
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s [%(name)s] %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )
    handlers: list[logging.Handler] = []

    if log_config.console_enabled:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        handlers.append(console_handler)

    if log_config.file_enabled:
        log_config.directory.mkdir(parents=True, exist_ok=True)
        log_file = log_config.directory / log_config.filename
        if ConcurrentTimedRotatingFileHandler is not None:
            file_handler = ConcurrentTimedRotatingFileHandler(
                filename=log_file,
                when="midnight",
                interval=1,
                backupCount=log_config.retention_days,
                encoding="utf-8",
                lock_file_directory=str(log_config.directory),
            )
        else:
            file_handler = TimedRotatingFileHandler(
                filename=log_file,
                when="midnight",
                interval=1,
                backupCount=log_config.retention_days,
                encoding="utf-8",
            )
        file_handler.suffix = "%Y-%m-%d"
        file_handler.setFormatter(formatter)
        handlers.append(file_handler)

    root_logger = logging.getLogger()
    root_logger.setLevel(log_config.level)
    root_logger.handlers.clear()
    for handler in handlers:
        handler.setLevel(log_config.level)
        root_logger.addHandler(handler)

    for logger_name in ("uvicorn", "uvicorn.error", "gunicorn", "gunicorn.error"):
        logging.getLogger(logger_name).setLevel(log_config.level)

    _CONFIGURED = True
