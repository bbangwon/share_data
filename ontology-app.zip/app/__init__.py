"""GraphRAG WAS application package."""
