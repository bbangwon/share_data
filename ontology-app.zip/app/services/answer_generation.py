from __future__ import annotations

import inspect
import re
import warnings
from functools import lru_cache
from html import escape
from pathlib import Path
from typing import Any

from langchain_core.prompts import load_prompt
from langchain_openai import ChatOpenAI

from app.core.config import Settings

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ANSWER_PROMPT_PATH = PROJECT_ROOT / "prompts" / "answer_generation.yaml"
ANSWER_GRAPH_PROMPT_PATH = PROJECT_ROOT / "prompts" / "answer_graph_generation.yaml"


class AnswerGenerationService:
    def __init__(self, settings: Settings, *, llm: Any | None = None) -> None:
        self.settings = settings
        self.llm = llm

    async def generate(
        self,
        *,
        query: str,
        search_response: dict[str, Any],
        max_context_chars: int,
        include_evidence_chains: bool = False,
    ) -> dict[str, Any]:
        context_blocks = build_context_blocks(
            search_response,
            max_context_chars=max_context_chars,
            include_evidence_chains=include_evidence_chains,
        )
        prompt = build_answer_prompt(
            query=query,
            context_blocks=context_blocks,
            include_evidence_chains=include_evidence_chains,
        )
        llm = self.llm or self._build_llm()
        response = llm.ainvoke(prompt) if hasattr(llm, "ainvoke") else llm.invoke(prompt)
        message = await response if inspect.isawaitable(response) else response
        answer = ensure_reference_footer(_message_content(message), context_blocks)
        return {
            "answer": answer,
            "context_count": len(context_blocks),
            "contexts": context_blocks,
        }

    def _build_llm(self) -> ChatOpenAI:
        if not self.settings.llm.base_url:
            raise ValueError("llm.base_url is required for /answer")
        if not self.settings.llm.model_name:
            raise ValueError("llm.model_name is required for /answer")
        return ChatOpenAI(
            model=self.settings.llm.model_name,
            base_url=self.settings.llm.base_url,
            timeout=self.settings.llm.timeout,
            temperature=self.settings.llm.temperature,
            api_key=self.settings.llm.api_key.get_secret_value(),
        )


def build_context_blocks(
    search_response: dict[str, Any],
    *,
    max_context_chars: int,
    include_evidence_chains: bool = False,
) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    remaining = max_context_chars
    for search_rank, result in enumerate(search_response.get("results") or [], start=1):
        if remaining <= 0:
            break
        text = _result_context_text(result)
        if not text:
            continue
        if len(text) > remaining:
            text = text[:remaining]
        payload = _result_payload(result)
        page_numbers = _result_pages(result, payload)
        file_name = _result_file_name(result, payload)
        index = len(blocks) + 1
        block = {
            "index": index,
            "search_rank": search_rank,
            "document_key": result.get("document_key") or payload.get("document_key"),
            "file": file_name,
            "doc_name": payload.get("doc_name"),
            "chunk_id": result.get("chunk_id") or payload.get("chunk_id"),
            "page_numbers": page_numbers,
            "page_display": _format_pages(page_numbers),
            "section_path": result.get("section_path") or payload.get("section_path"),
            "section_title": result.get("section_title") or payload.get("section_title"),
            "section_level": result.get("section_level") or payload.get("section_level"),
            "context_source": result.get("context_source") or payload.get("context_source"),
            "context_expanded": bool(result.get("context_expanded")),
            "context_neighbor_chunk_ids": result.get("context_neighbor_chunk_ids") or [],
            "score": result.get("score"),
            "rerank_score": result.get("rerank_score"),
            "quality_score": result.get("quality_score"),
            "quality_penalty": result.get("quality_penalty"),
            "retrieval_sources": result.get("retrieval_sources") or [],
            "graph_entities": result.get("graph_entities") or [],
            "graph_reasons": result.get("graph_reasons") or [],
            "graph_paths": result.get("graph_paths") or [],
            "query_graph_score": result.get("query_graph_score"),
            "synthetic_queries": result.get("synthetic_queries") or [],
            "query_graph_paths": result.get("query_graph_paths") or [],
            "reference": _format_reference(file_name, page_numbers),
            "source_element_types": payload.get("source_element_types") or [],
            "context_text": text,
            "text": text,
        }
        if include_evidence_chains:
            evidence_chains = result.get("evidence_chains") or payload.get("evidence_chains") or []
            block["evidence_chains"] = evidence_chains
            block["relation_types_used"] = result.get("relation_types_used") or payload.get("relation_types_used") or []
            block["connected_chunk_ids"] = result.get("connected_chunk_ids") or payload.get("connected_chunk_ids") or []
        blocks.append(block)
        remaining -= len(text)
    return blocks


def build_answer_prompt(
    *,
    query: str,
    context_blocks: list[dict[str, Any]],
    include_evidence_chains: bool = False,
) -> Any:
    prompt = _load_answer_graph_prompt() if include_evidence_chains else _load_answer_prompt()
    return prompt.format_prompt(
        query=query,
        context=format_context_for_prompt(context_blocks),
    )


def build_prompt_preview(
    *,
    query: str,
    search_response: dict[str, Any],
    include_evidence_chains: bool = False,
    max_context_chars: int | None = None,
) -> dict[str, Any]:
    context_blocks = build_context_blocks(
        search_response,
        max_context_chars=max_context_chars or _full_context_char_budget(search_response),
        include_evidence_chains=include_evidence_chains,
    )
    prompt = build_answer_prompt(
        query=query,
        context_blocks=context_blocks,
        include_evidence_chains=include_evidence_chains,
    )
    return {
        "context_blocks": context_blocks,
        "empty_prompt": get_answer_prompt_template(include_evidence_chains=include_evidence_chains),
        "prompt": prompt.to_string(),
    }


def get_answer_prompt_template(*, include_evidence_chains: bool = False) -> str:
    prompt = _load_answer_graph_prompt() if include_evidence_chains else _load_answer_prompt()
    template = getattr(prompt, "template", None)
    if isinstance(template, str):
        return template
    return prompt.format_prompt(query="{query}", context="{context}").to_string()


@lru_cache
def _load_answer_prompt() -> Any:
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            category=DeprecationWarning,
            message=r".*load_prompt.*",
        )
        return load_prompt(ANSWER_PROMPT_PATH)


@lru_cache
def _load_answer_graph_prompt() -> Any:
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            category=DeprecationWarning,
            message=r".*load_prompt.*",
        )
        return load_prompt(ANSWER_GRAPH_PROMPT_PATH)


def format_context_for_prompt(context_blocks: list[dict[str, Any]]) -> str:
    if not context_blocks:
        return "<sources />"
    return "<sources>\n" + "\n\n".join(_format_context_block(block) for block in context_blocks) + "\n</sources>"


def _format_context_block(block: dict[str, Any]) -> str:
    index = block["index"]
    lines = [
        (
            f'  <source index="{_xml_attr(index)}" '
            f'id="{_xml_attr(block.get("chunk_id") or "-")}">'
        ),
        "    <reference>",
        f"      <filename>{_xml_text(_context_filename(block))}</filename>",
        f"      <page>{_xml_text(_context_page(block))}</page>",
        "    </reference>",
        f"    <section_path>{_xml_text(block.get('section_path') or '-')}</section_path>",
    ]
    if block.get("evidence_chains"):
        lines.append("    <evidence_chains>")
        for chain in block["evidence_chains"][:2]:
            lines.append(
                f'      <chain type="{_xml_attr(chain.get("chain_type") or "graph_path")}">'
                f"{_xml_text(_format_evidence_chain(chain))}</chain>"
            )
        lines.append("    </evidence_chains>")
    context_text = str(block.get("context_text") or block.get("text") or "").strip()
    lines.extend(
        [
            f"    <context_text>{_xml_text(context_text)}</context_text>",
            "  </source>",
        ]
    )
    return "\n".join(lines)


def ensure_reference_footer(answer: str, context_blocks: list[dict[str, Any]]) -> str:
    if not answer or _has_reference_section(answer):
        return answer
    cited_indexes = _cited_context_indexes(answer)
    if not cited_indexes:
        return answer
    block_by_index = {int(block["index"]): block for block in context_blocks}
    references = [
        f"- [자료 {index}] {block_by_index[index]['reference']}"
        for index in cited_indexes
        if index in block_by_index
    ]
    if not references:
        return answer
    return f"{answer.rstrip()}\n\n참고자료:\n" + "\n".join(references)


def _format_evidence_chain(chain: dict[str, Any]) -> str:
    chain_type = str(chain.get("chain_type") or "graph_path")
    path_text = str(chain.get("path_text") or "").strip()
    if path_text:
        return f"{chain_type}: {path_text}"
    synthetic_queries = chain.get("synthetic_queries") or []
    if synthetic_queries:
        return f"{chain_type}: " + " -> ".join(str(item) for item in synthetic_queries[:2])
    source = chain.get("source_chunk_id") or "-"
    target = chain.get("target_chunk_id") or "-"
    return f"{chain_type}: {source} -> {target}"


def _context_filename(block: dict[str, Any]) -> str:
    for value in (block.get("file"), block.get("doc_name")):
        text = str(value or "").strip()
        if text:
            return text
    reference = str(block.get("reference") or "").strip()
    match = re.search(r"파일이름:\s*(.*?)(?:,\s*페이지:|$)", reference)
    return match.group(1).strip() if match and match.group(1).strip() else "-"


def _context_page(block: dict[str, Any]) -> str:
    page_display = str(block.get("page_display") or "").strip()
    if page_display:
        return page_display
    pages = block.get("page_numbers")
    if isinstance(pages, list):
        return _format_pages(_normalize_pages(pages))
    reference = str(block.get("reference") or "").strip()
    match = re.search(r"페이지:\s*(.+)$", reference)
    return match.group(1).strip() if match and match.group(1).strip() else "-"


_INVALID_XML_CHARS_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _xml_clean(value: Any) -> str:
    return _INVALID_XML_CHARS_RE.sub("", str(value or "").strip())


def _xml_text(value: Any) -> str:
    return escape(_xml_clean(value), quote=False)


def _xml_attr(value: Any) -> str:
    return escape(_xml_clean(value), quote=True)


def _result_context_text(result: dict[str, Any]) -> str:
    return str(result.get("context_text") or result.get("text") or "").strip()


def _full_context_char_budget(search_response: dict[str, Any]) -> int:
    total_chars = 0
    for result in search_response.get("results") or []:
        if isinstance(result, dict):
            total_chars += len(_result_context_text(result))
    return max(total_chars, 1)


def _result_payload(result: dict[str, Any]) -> dict[str, Any]:
    payload = result.get("payload") or {}
    return payload if isinstance(payload, dict) else {}


def _result_file_name(result: dict[str, Any], payload: dict[str, Any]) -> str:
    for value in (
        result.get("file"),
        payload.get("file"),
        payload.get("doc_name"),
        result.get("document_key"),
        payload.get("document_key"),
    ):
        text = str(value or "").strip()
        if text:
            return text
    return "-"


def _result_pages(result: dict[str, Any], payload: dict[str, Any]) -> list[int]:
    raw_pages = result.get("page_numbers") or payload.get("page_numbers") or []
    pages = _normalize_pages(raw_pages)
    if pages:
        return pages
    page_start = _coerce_int(payload.get("page_start"))
    page_end = _coerce_int(payload.get("page_end"))
    if page_start is None and page_end is None:
        return []
    if page_start is None:
        return [page_end] if page_end is not None else []
    if page_end is None:
        return [page_start]
    if page_end < page_start:
        return [page_start]
    return list(range(page_start, page_end + 1))


def _normalize_pages(value: Any) -> list[int]:
    if isinstance(value, int):
        return [value]
    if not isinstance(value, list):
        return []
    pages: list[int] = []
    for item in value:
        page = _coerce_int(item)
        if page is not None and page not in pages:
            pages.append(page)
    return pages


def _format_pages(pages: list[int]) -> str:
    if not pages:
        return "-"
    sorted_pages = sorted(dict.fromkeys(pages))
    ranges: list[str] = []
    start = prev = sorted_pages[0]
    for page in sorted_pages[1:]:
        if page == prev + 1:
            prev = page
            continue
        ranges.append(str(start) if start == prev else f"{start}-{prev}")
        start = prev = page
    ranges.append(str(start) if start == prev else f"{start}-{prev}")
    return ", ".join(ranges)


def _format_reference(file_name: str, pages: list[int]) -> str:
    return f"파일이름: {file_name or '-'}, 페이지: {_format_pages(pages)}"


def _format_scores(block: dict[str, Any]) -> str:
    parts = []
    for key, label in (
        ("quality_score", "quality"),
        ("rerank_score", "rerank"),
        ("score", "qdrant"),
        ("quality_penalty", "penalty"),
    ):
        value = block.get(key)
        if value is None:
            continue
        parts.append(f"{label}={_format_float(value)}")
    return ", ".join(parts) if parts else "-"


def _format_float(value: Any) -> str:
    try:
        return f"{float(value):.4f}"
    except (TypeError, ValueError):
        return str(value)


def _coerce_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _has_reference_section(answer: str) -> bool:
    return bool(re.search(r"(?m)^#{0,3}\s*(참고자료|출처)\s*:?\s*$", answer))


def _cited_context_indexes(answer: str) -> list[int]:
    indexes: list[int] = []
    for match in re.finditer(r"\[(?:자료|근거)?\s*(\d+)\]", answer):
        index = int(match.group(1))
        if index not in indexes:
            indexes.append(index)
    return indexes


def _message_content(message: Any) -> str:
    content = getattr(message, "content", message)
    if isinstance(content, list):
        return "\n".join(_content_part_text(part) for part in content if _content_part_text(part)).strip()
    return str(content).strip()


def _content_part_text(part: Any) -> str:
    if isinstance(part, dict):
        return str(part.get("text") or part.get("content") or "").strip()
    return str(part).strip()
