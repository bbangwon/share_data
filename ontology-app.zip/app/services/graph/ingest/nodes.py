from __future__ import annotations

import asyncio
import hashlib
import inspect
import time
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from app.core.config import Settings
from app.services.chunking import chunk_document
from app.services.chunking_profiles import build_artifact_key
from app.services.embeddings import (
    GpuDenseEmbedder,
    KiwiBm25SparseEmbedder,
    build_embed_text,
)
from app.services.graph.common.artifacts import ArtifactStore
from app.services.graph.common.tracing import append_trace
from app.services.graph.ingest.state import IngestState
from app.services.input_loader import derive_document_key, load_parse_result
from app.services.ontology import build_initial_schema, build_kg_artifacts, build_ontology_artifacts, canonicalize_cqs, parse_cq_sources
from app.services.ontology.extraction import build_graph_dataset_key, build_kg_extraction
from app.services.ontology.llm_extraction import OntologyLLMExtractor
from app.services.ontology.neo4j_store import Neo4jOntologyStore
from app.services.qdrant_store import QdrantStore
from app.services.query_graph import QueryGraphBuilder
from app.services.schemas import (
    ChildChunk,
    DocumentMeta,
    EmbeddedChunk,
    RawElement,
    chunk_to_payload,
)


class IngestNodes:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.artifacts = ArtifactStore(settings.runtime.artifact_root)

    async def load_document(self, state: IngestState) -> IngestState:
        """PDF 추출 JSON 파일을 로드하고 LangGraph 상태에 문서 메타데이터와 원본 요소 목록을 저장합니다.

        요청별 컬렉션명과 청킹 프로파일을 반영해 artifact key를 만들고,
        resume 가능한 경우 저장된 raw_document 산출물을 재사용합니다.
        """
        step = "load_document"
        started = time.perf_counter()
        input_path = Path(state["input_path"])
        document_key = derive_document_key(input_path)
        collection_name = _state_collection_name(state, self.settings)
        chunking_profile = _state_chunking_profile(state, self.settings)
        _log_ingest_step(
            step,
            "started",
            document_key=document_key,
            collection_name=collection_name,
            retrieval_profile=state.get("retrieval_profile"),
        )
        artifact_key = build_artifact_key(
            document_key=document_key,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
        )
        artifact_dir = self.artifacts.document_dir(artifact_key)
        try:
            if self._can_resume(state, step, "raw_document.json", artifact_key):
                payload = self.artifacts.load(artifact_key, "raw_document.json")
                meta = DocumentMeta.model_validate(payload["meta"])
                elements = [
                    RawElement.model_validate(item) for item in payload["elements"]
                ]
                status = "resumed"
            else:
                elements, meta = load_parse_result(input_path)
                self.artifacts.save(
                    artifact_key,
                    "raw_document.json",
                    {
                        "meta": meta.model_dump(mode="json"),
                        "elements": [
                            element.model_dump(mode="json") for element in elements
                        ],
                    },
                )
                status = "completed"
            self.artifacts.update_checkpoint(
                artifact_key,
                step=step,
                status=status,
                details={
                    "document_key": meta.document_key,
                    "collection_name": collection_name,
                    "retrieval_profile": state.get("retrieval_profile"),
                    "chunking_profile": chunking_profile,
                    "input_path": str(input_path),
                    "element_count": len(elements),
                },
            )
            _log_ingest_step(
                step,
                status,
                document_key=meta.document_key,
                element_count=len(elements),
            )
            return {
                **state,
                "document_key": meta.document_key,
                "artifact_key": artifact_key,
                "artifact_dir": str(artifact_dir),
                "meta": meta,
                "elements": elements,
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status=status,
                    started=started,
                    details={"element_count": len(elements)},
                ),
            }
        except Exception as exc:
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status="failed", details={"document_key": document_key, "error": str(exc)}
            )
            raise

    async def chunk_document(self, state: IngestState) -> IngestState:
        """로드된 문서 요소를 parent/child chunk로 변환하고 중간 산출물을 저장합니다.

        현재 설정의 청킹 프로파일(small/large 또는 TOML 기본값)에 따라 검색 단위 child chunk와
        LLM 컨텍스트용 parent chunk를 만들며, chunks.json/jsonl과 preview 파일을 남깁니다.
        """
        step = "chunk_document"
        started = time.perf_counter()
        document_key = state["document_key"]
        artifact_key = state.get("artifact_key") or document_key
        collection_name = _state_collection_name(state, self.settings)
        chunking_profile = _state_chunking_profile(state, self.settings)
        _log_ingest_step(
            step,
            "started",
            document_key=document_key,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
        )
        try:
            if self._can_resume(state, step, "chunks.json", artifact_key):
                payload = self.artifacts.load(artifact_key, "chunks.json")
                chunks = [ChildChunk.model_validate(item) for item in payload["chunks"]]
                status = "resumed"
            else:
                chunking_started = time.perf_counter()
                result = chunk_document(state["elements"], state["meta"], self.settings)
                chunking_duration_ms = _duration_ms(chunking_started)
                chunks = result.children
                self.artifacts.save_jsonl(
                    artifact_key,
                    "parents.jsonl",
                    (parent.model_dump(mode="json") for parent in result.parents),
                )
                self.artifacts.save_jsonl(
                    artifact_key,
                    "chunks.jsonl",
                    (
                        {
                            "chunk_index": index,
                            **chunk.model_dump(mode="json"),
                        }
                        for index, chunk in enumerate(chunks)
                    ),
                )
                self.artifacts.save(
                    artifact_key,
                    "chunks.json",
                    {
                        "document_key": document_key,
                        "artifact_key": artifact_key,
                        "collection_name": collection_name,
                        "retrieval_profile": state.get("retrieval_profile"),
                        "chunking_mode": state.get("chunking_mode"),
                        "chunking_profile": chunking_profile,
                        "total_chunks": len(chunks),
                        "parents": [
                            parent.model_dump(mode="json") for parent in result.parents
                        ],
                        "chunks": [chunk.model_dump(mode="json") for chunk in chunks],
                    },
                )
                preview_rows = [
                    {
                        "chunk_index": index,
                        "chunk_id": chunk.chunk_id,
                        "page_numbers": chunk.page_numbers,
                        "section_path": chunk.section_path,
                        "char_count": chunk.char_count,
                        "token_count": chunk.token_count,
                        "embed_text": build_embed_text(chunk),
                    }
                    for index, chunk in enumerate(chunks)
                ]
                self.artifacts.save_jsonl(artifact_key, "chunk_preview.jsonl", preview_rows)
                self.artifacts.save(
                    artifact_key,
                    "chunk_preview.json",
                    {
                        "document_key": document_key,
                        "artifact_key": artifact_key,
                        "collection_name": collection_name,
                        "chunking_mode": state.get("chunking_mode"),
                        "chunking_profile": chunking_profile,
                        "total_chunks": len(chunks),
                        "chunking_duration_ms": chunking_duration_ms,
                        "chunks": preview_rows,
                    },
                )
                status = "completed"
            self.artifacts.update_checkpoint(
                artifact_key,
                step=step,
                status=status,
                details={
                    "document_key": document_key,
                    "collection_name": collection_name,
                    "retrieval_profile": state.get("retrieval_profile"),
                    "chunking_profile": chunking_profile,
                    "chunk_count": len(chunks),
                    "artifacts": ["parents.jsonl", "chunks.json", "chunks.jsonl", "chunk_preview.json", "chunk_preview.jsonl"],
                },
            )
            _log_ingest_step(
                step,
                status,
                document_key=document_key,
                chunk_count=len(chunks),
            )
            return {
                **state,
                "chunks": chunks,
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status=status,
                    started=started,
                    details={"chunk_count": len(chunks)},
                ),
            }
        except Exception as exc:
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status="failed", details={"document_key": document_key, "error": str(exc)}
            )
            raise

    async def embed_chunks(self, state: IngestState) -> IngestState:
        """생성된 child chunk에 dense embedding과 sparse vector를 생성합니다.

        embedding 입력 텍스트를 구성한 뒤 dense/sparse embedder를 실행하고,
        Qdrant 적재용 payload와 벡터 및 청크별 임베딩 시간 산출물을 저장합니다.
        """
        step = "embed_chunks"
        started = time.perf_counter()
        document_key = state["document_key"]
        artifact_key = state.get("artifact_key") or document_key
        collection_name = _state_collection_name(state, self.settings)
        chunking_profile = _state_chunking_profile(state, self.settings)
        _log_ingest_step(
            step,
            "started",
            document_key=document_key,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
            chunk_count=len(state.get("chunks") or []),
        )
        try:
            if self._can_resume(state, step, "embedded_chunks.json", artifact_key):
                payload = self.artifacts.load(artifact_key, "embedded_chunks.json")
                embedded = [
                    EmbeddedChunk.model_validate(item)
                    for item in payload["embedded_chunks"]
                ]
                dense_vector_size = int(payload["dense_vector_size"])
                status = "resumed"
            else:
                chunks = state["chunks"]
                embed_texts = [build_embed_text(chunk) for chunk in chunks]
                dense_embedder = GpuDenseEmbedder(
                    base_url=self.settings.embedding.base_url,
                    model=self.settings.embedding.dense_model_name,
                    timeout=self.settings.embedding.timeout,
                )
                sparse_embedder = KiwiBm25SparseEmbedder(
                    model_name=self.settings.embedding.sparse_model_name
                )
                try:
                    dense_started = time.perf_counter()
                    dense_vectors, dense_timings = await _embed_many_with_timings(
                        dense_embedder,
                        embed_texts,
                        concurrency=self.settings.embedding.dense_concurrency,
                        label="dense",
                    )
                    dense_duration_ms = _duration_ms(dense_started)
                    sparse_started = time.perf_counter()
                    sparse_vectors, sparse_timings = await _embed_many_with_timings(
                        sparse_embedder,
                        embed_texts,
                        concurrency=self.settings.embedding.sparse_concurrency,
                        label="sparse",
                    )
                    sparse_duration_ms = _duration_ms(sparse_started)
                finally:
                    await dense_embedder.close()
                    await sparse_embedder.close()
                dense_vector_size = len(dense_vectors[0]) if dense_vectors else 0
                embedded = _build_embedded_chunks(
                    chunks,
                    dense_vectors,
                    sparse_vectors,
                    state["meta"],
                    collection_name=collection_name,
                    chunking_profile=chunking_profile,
                )
                embedding_timing_rows = _embedding_timing_rows(chunks, dense_timings, sparse_timings)
                self.artifacts.save_jsonl(artifact_key, "embedding_timings.jsonl", embedding_timing_rows)
                self.artifacts.save_jsonl(
                    artifact_key,
                    "embedded_chunk_preview.jsonl",
                    (
                        {
                            "chunk_index": index,
                            "chunk_id": item.chunk_id,
                            "dense_vector_size": len(item.dense_vector),
                            "sparse_vector_size": len(item.sparse_vector.get("indices", [])),
                            "page_numbers": item.chunk.page_numbers,
                        }
                        for index, item in enumerate(embedded)
                    ),
                )
                if self.settings.runtime.persist_embeddings:
                    self.artifacts.save(
                        artifact_key,
                        "embedded_chunks.json",
                        {
                            "document_key": document_key,
                            "artifact_key": artifact_key,
                            "collection_name": collection_name,
                            "retrieval_profile": state.get("retrieval_profile"),
                            "chunking_mode": state.get("chunking_mode"),
                            "chunking_profile": chunking_profile,
                            "dense_vector_size": dense_vector_size,
                            "embedded_chunks": [
                                item.model_dump(mode="json") for item in embedded
                            ],
                        },
                    )
                status = "completed"
            details = {
                "document_key": document_key,
                "collection_name": collection_name,
                "retrieval_profile": state.get("retrieval_profile"),
                "chunking_profile": chunking_profile,
                "embedded_count": len(embedded),
                "dense_vector_size": dense_vector_size,
                "artifacts": ["embedded_chunks.json", "embedded_chunk_preview.jsonl", "embedding_timings.jsonl"],
            }
            if status == "completed":
                details["dense_embedding_duration_ms"] = dense_duration_ms
                details["sparse_embedding_duration_ms"] = sparse_duration_ms
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status=status, details=details
            )
            _log_ingest_step(
                step,
                status,
                document_key=document_key,
                embedded_count=len(embedded),
                dense_vector_size=dense_vector_size,
            )
            return {
                **state,
                "embedded_chunks": embedded,
                "dense_vector_size": dense_vector_size,
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status=status,
                    started=started,
                    details=details,
                ),
            }
        except Exception as exc:
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status="failed", details={"document_key": document_key, "error": str(exc)}
            )
            raise

    async def upsert_qdrant(self, state: IngestState) -> IngestState:
        """임베딩된 chunk를 현재 설정의 Qdrant 컬렉션에 적재합니다.

        컬렉션을 보장한 뒤 같은 document_key의 현재 버전을 교체하고,
        skip_qdrant 또는 skip_existing_qdrant 옵션이 있으면 요청된 정책에 따라 적재를 건너뜁니다.
        """
        step = "upsert_qdrant"
        started = time.perf_counter()
        document_key = state["document_key"]
        artifact_key = state.get("artifact_key") or document_key
        collection_name = _state_collection_name(state, self.settings)
        _log_ingest_step(
            step,
            "started",
            document_key=document_key,
            collection_name=collection_name,
            embedded_count=len(state.get("embedded_chunks") or []),
        )
        try:
            if state.get("skip_qdrant"):
                result = {
                    "skipped": True,
                    "reason": "skip_qdrant requested",
                    "collection_name": collection_name,
                }
                status = "skipped"
            elif not state.get("reset_qdrant_collection") and self._can_resume(state, step, "upsert_result.json", artifact_key):
                result = self.artifacts.load(artifact_key, "upsert_result.json")
                status = "resumed"
            else:
                store = QdrantStore(
                    settings=self.settings, dense_vector_size=state["dense_vector_size"]
                )
                try:
                    await store.ensure_collection()
                    if state.get(
                        "skip_existing_qdrant"
                    ) and await store.has_current_document(document_key):
                        result = {
                            "skipped": True,
                            "reason": "current document already exists in Qdrant",
                            "collection_name": store.collection_name,
                        }
                        status = "skipped"
                    else:
                        result = await store.upsert_document(
                            document_key, state["embedded_chunks"]
                        )
                        result["collection_name"] = store.collection_name
                        status = "completed"
                finally:
                    await store.close()
                self.artifacts.save(artifact_key, "upsert_result.json", result)
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status=status, details={"document_key": document_key, **result}
            )
            _log_ingest_step(
                step,
                status,
                document_key=document_key,
                collection_name=result.get("collection_name") or collection_name,
                points=result.get("point_count") or result.get("upserted_count"),
            )
            return {
                **state,
                "upsert_result": result,
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status=status,
                    started=started,
                    details=result,
                ),
            }
        except Exception as exc:
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status="failed", details={"document_key": document_key, "error": str(exc)}
            )
            raise

    async def reset_qdrant_collection(self, state: IngestState) -> IngestState:
        """명시적으로 확인된 경우 Qdrant 컬렉션을 삭제 후 재생성합니다.

        reset_qdrant_collection 요청이 없으면 건너뛰며, 실행 시에는 현재 요청에서 확정된
        컬렉션명과 벡터 설정으로 새 컬렉션과 payload index를 준비합니다.
        """
        step = "reset_qdrant_collection"
        started = time.perf_counter()
        document_key = state["document_key"]
        artifact_key = state.get("artifact_key") or document_key
        collection_name = _state_collection_name(state, self.settings)
        _log_ingest_step(
            step,
            "started",
            document_key=document_key,
            collection_name=collection_name,
            requested=bool(state.get("reset_qdrant_collection")),
        )
        try:
            if not state.get("reset_qdrant_collection"):
                result = {
                    "skipped": True,
                    "reason": "reset_qdrant_collection not requested",
                    "collection_name": collection_name,
                }
                status = "skipped"
            elif state.get("skip_qdrant"):
                raise ValueError("reset_qdrant_collection cannot be used with skip_qdrant=true")
            elif self._can_resume(state, step, "reset_qdrant_result.json", artifact_key):
                result = self.artifacts.load(artifact_key, "reset_qdrant_result.json")
                status = "resumed"
            else:
                store = QdrantStore(
                    settings=self.settings, dense_vector_size=state["dense_vector_size"]
                )
                try:
                    result = await store.recreate_collection()
                    status = "completed"
                finally:
                    await store.close()
                self.artifacts.save(artifact_key, "reset_qdrant_result.json", result)
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status=status, details={"document_key": document_key, **result}
            )
            _log_ingest_step(
                step,
                status,
                document_key=document_key,
                collection_name=result.get("collection_name") or collection_name,
            )
            return {
                **state,
                "reset_qdrant_result": result,
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status=status,
                    started=started,
                    details=result,
                ),
            }
        except Exception as exc:
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status="failed", details={"document_key": document_key, "error": str(exc)}
            )
            raise

    async def build_ontology_layer(self, state: IngestState) -> IngestState:
        """Phase2 Ontology Layer의 CQ와 초기 스키마 산출물을 생성합니다.

        현재 단계에서는 graph traversal을 검색 흐름에 연결하지 않습니다. 대신 사용자가 제공한
        `data/ontology_cq` 마크다운 자료를 canonical CQ와 최소 모듈형 ontology schema로 정규화하고,
        이후 Neo4j KG 생성 및 Qdrant metadata enrichment가 재사용할 산출물을 저장합니다.
        """
        step = "build_ontology_layer"
        started = time.perf_counter()
        document_key = state["document_key"]
        artifact_key = state.get("artifact_key") or document_key
        _log_ingest_step(
            step,
            "started",
            document_key=document_key,
            kg_extraction_mode=state.get("kg_extraction_mode") or self.settings.ontology.kg_extraction_mode,
            kg_chunk_offset=state.get("kg_chunk_offset", 0),
            kg_chunk_limit=state.get("kg_chunk_limit"),
        )
        try:
            if not self.settings.ontology.enabled:
                result = {
                    "skipped": True,
                    "reason": "ontology.enabled=false",
                    "version": self.settings.ontology.version,
                }
                status = "skipped"
            elif self._can_resume(state, step, "ontology_result.json", artifact_key):
                result = self.artifacts.load(artifact_key, "ontology_result.json")
                status = "resumed"
            else:
                result = build_ontology_artifacts(
                    source_dir=self.settings.ontology.cq_source_dir,
                    output_root=self.settings.ontology.artifact_root,
                    version=self.settings.ontology.version,
                )
                if self.settings.ontology.kg_extraction_enabled:
                    kg_result = await self._build_kg_layer(state)
                else:
                    kg_result = {
                        "skipped": True,
                        "reason": "ontology.kg_extraction_enabled=false",
                    }
                result = {
                    **result,
                    "kg_result": kg_result,
                    "kg_upsert_enabled": self.settings.ontology.kg_upsert_enabled,
                    "qdrant_enrichment_enabled": self.settings.ontology.qdrant_enrichment_enabled,
                    "graph_traversal_enabled": False,
                    "document_key": document_key,
                    "artifact_key": artifact_key,
                }
                self.artifacts.save(artifact_key, "ontology_result.json", result)
                status = "completed"
            self.artifacts.update_checkpoint(
                artifact_key,
                step=step,
                status=status,
                details={"document_key": document_key, **result},
            )
            kg_result = result.get("kg_result") if isinstance(result, dict) else {}
            _log_ingest_step(
                step,
                status,
                document_key=document_key,
                kg_extraction_mode=(kg_result or {}).get("kg_extraction_mode"),
                selected_chunk_count=(kg_result or {}).get("selected_chunk_count"),
            )
            return {
                **state,
                "ontology_result": result,
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status=status,
                    started=started,
                    details=result,
                ),
            }
        except Exception as exc:
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status="failed", details={"document_key": document_key, "error": str(exc)}
            )
            raise

    async def build_query_graph_layer(self, state: IngestState) -> IngestState:
        """Query-Centric GraphRAG용 synthetic query graph 산출물과 저장소 레이어를 생성합니다.

        기존 chunk/embedding 산출물을 재사용하고, 요청별 offset/limit 및 cache를 활용해 긴 LLM
        생성 작업을 중간부터 재개할 수 있게 합니다. 생성된 query graph는 Qdrant 원본 chunk 컬렉션과
        Neo4j KG를 대체하지 않고 별도 augmentation layer로만 저장합니다.
        """
        step = "build_query_graph_layer"
        started = time.perf_counter()
        document_key = state["document_key"]
        artifact_key = state.get("artifact_key") or document_key
        _log_ingest_step(
            step,
            "started",
            document_key=document_key,
            enabled=bool(state.get("query_graph_enabled")) or self.settings.query_graph.enabled,
            chunk_offset=state.get("query_graph_chunk_offset"),
            chunk_limit=state.get("query_graph_chunk_limit"),
        )
        try:
            query_graph_enabled = bool(state.get("query_graph_enabled")) or self.settings.query_graph.enabled
            if not query_graph_enabled:
                result = {
                    "skipped": True,
                    "reason": "query_graph.enabled=false",
                }
                status = "skipped"
            elif self._can_resume(state, step, "query_graph_result.json", artifact_key):
                result = self.artifacts.load(artifact_key, "query_graph_result.json")
                status = "resumed"
            else:
                collection_name = _state_collection_name(state, self.settings)
                chunking_profile = _state_chunking_profile(state, self.settings)
                graph_dataset_key = build_graph_dataset_key(
                    document_key=state["meta"].document_key,
                    collection_name=collection_name,
                    chunking_profile=chunking_profile,
                )
                request_generation = state.get("query_graph_generation_enabled")
                request_upsert = state.get("query_graph_upsert_enabled")
                generation_enabled = (
                    bool(request_generation)
                    if request_generation is not None
                    else bool(state.get("query_graph_enabled")) or self.settings.query_graph.generation_enabled
                )
                upsert_enabled = (
                    bool(request_upsert)
                    if request_upsert is not None
                    else bool(state.get("query_graph_enabled")) or self.settings.query_graph.upsert_enabled
                )
                offset = (
                    int(state["query_graph_chunk_offset"])
                    if state.get("query_graph_chunk_offset") is not None
                    else self.settings.query_graph.chunk_offset
                )
                limit = (
                    int(state["query_graph_chunk_limit"])
                    if state.get("query_graph_chunk_limit") is not None
                    else self.settings.query_graph.chunk_limit
                )
                result = await QueryGraphBuilder(self.settings).build(
                    chunks=state["chunks"],
                    embedded_chunks=state["embedded_chunks"],
                    meta=state["meta"],
                    collection_name=collection_name,
                    chunking_profile=chunking_profile,
                    graph_dataset_key=graph_dataset_key,
                    output_root=self.settings.ontology.artifact_root,
                    offset=offset,
                    limit=limit,
                    resume=bool(state.get("resume", True)),
                    generation_enabled=generation_enabled,
                    upsert_enabled=upsert_enabled,
                    reset_scope=bool(state.get("reset_query_graph_scope")),
                )
                result = {
                    **result,
                    "document_key": document_key,
                    "artifact_key": artifact_key,
                }
                self.artifacts.save(artifact_key, "query_graph_result.json", result)
                status = "completed"
            self.artifacts.update_checkpoint(
                artifact_key,
                step=step,
                status=status,
                details={"document_key": document_key, **result},
            )
            _log_ingest_step(
                step,
                status,
                document_key=document_key,
                selected_chunk_count=result.get("selected_chunk_count"),
                accepted_record_count=result.get("accepted_record_count"),
            )
            return {
                **state,
                "query_graph_result": result,
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status=status,
                    started=started,
                    details=result,
                ),
            }
        except Exception as exc:
            self.artifacts.update_checkpoint(
                artifact_key, step=step, status="failed", details={"document_key": document_key, "error": str(exc)}
            )
            raise

    async def _build_kg_layer(self, state: IngestState) -> dict[str, Any]:
        schema = build_initial_schema(version=self.settings.ontology.version)
        source_items = parse_cq_sources(self.settings.ontology.cq_source_dir)
        canonical_cqs = canonicalize_cqs(source_items, schema=schema)
        collection_name = _state_collection_name(state, self.settings)
        chunking_profile = _state_chunking_profile(state, self.settings)
        all_chunks = state["chunks"]
        kg_chunk_offset = int(state.get("kg_chunk_offset") or 0)
        kg_chunk_limit = state.get("kg_chunk_limit")
        selected_chunks = _select_kg_chunks(
            all_chunks,
            offset=kg_chunk_offset,
            limit=kg_chunk_limit,
        )
        graph_dataset_key = build_graph_dataset_key(
            document_key=state["meta"].document_key,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
        )
        extraction_mode = state.get("kg_extraction_mode") or self.settings.ontology.kg_extraction_mode
        if extraction_mode == "rule_based":
            extraction = build_kg_extraction(
                chunks=selected_chunks,
                meta=state["meta"],
                schema=schema,
                collection_name=collection_name,
                chunking_profile=chunking_profile,
                graph_dataset_key=graph_dataset_key,
            )
        elif extraction_mode in {"llm", "hybrid"}:
            kg_dir = self.settings.ontology.artifact_root / "kg"
            progress_path = kg_dir / "kg_extraction_progress.json"
            progress_events_path = kg_dir / "kg_extraction_events.jsonl"
            cache_dir = kg_dir / "chunk_cache" / _kg_cache_dir_name(graph_dataset_key)
            extraction = await OntologyLLMExtractor(self.settings).extract(
                chunks=selected_chunks,
                meta=state["meta"],
                schema=schema,
                collection_name=collection_name,
                chunking_profile=chunking_profile,
                graph_dataset_key=graph_dataset_key,
                mode=extraction_mode,
                cache_dir=cache_dir,
                progress_path=progress_path,
                progress_events_path=progress_events_path,
                resume=bool(state.get("resume", True)),
                total_source_chunk_count=len(all_chunks),
                selected_offset=kg_chunk_offset,
                selected_limit=kg_chunk_limit,
            )
        else:
            raise ValueError(f"unsupported ontology.kg_extraction_mode: {extraction_mode!r}")
        extraction, kg_result = build_kg_artifacts(
            chunks=selected_chunks,
            meta=state["meta"],
            schema=schema,
            output_root=self.settings.ontology.artifact_root,
            extraction=extraction,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
            graph_dataset_key=graph_dataset_key,
        )
        upsert_result: dict[str, Any]
        if self.settings.ontology.kg_upsert_enabled:
            store = Neo4jOntologyStore(self.settings.neo4j)
            try:
                reset_result: dict[str, Any] = {"skipped": True, "reason": "reset.neo4j_graph=false"}
                if state.get("reset_neo4j_graph"):
                    reset_result = await store.reset_graph_scope(
                        document_key=state["meta"].document_key,
                        graph_dataset_key=graph_dataset_key,
                    )
                upsert_result = await store.upsert_kg(
                    schema=schema,
                    canonical_cqs=canonical_cqs,
                    extraction=extraction,
                )
                upsert_result = {
                    **upsert_result,
                    "neo4j_reset": reset_result,
                }
            finally:
                await store.close()
        else:
            upsert_result = {
                "skipped": True,
                "reason": "ontology.kg_upsert_enabled=false",
            }
        return {
            **kg_result,
            "neo4j_upsert": upsert_result,
            "kg_extraction_mode": extraction_mode,
            "graph_dataset_key": graph_dataset_key,
            "total_source_chunk_count": len(all_chunks),
            "selected_chunk_count": len(selected_chunks),
            "kg_chunk_offset": kg_chunk_offset,
            "kg_chunk_limit": kg_chunk_limit,
            "kg_chunk_range": _kg_chunk_range(kg_chunk_offset, len(selected_chunks)),
            "kg_progress_artifact": str(self.settings.ontology.artifact_root / "kg" / "kg_extraction_progress.json"),
            "kg_progress_events_artifact": str(self.settings.ontology.artifact_root / "kg" / "kg_extraction_events.jsonl"),
        }

    async def finalize(self, state: IngestState) -> IngestState:
        """적재 워크플로 실행 결과를 요약하고 최종 checkpoint/summary 산출물을 저장합니다.

        각 노드 trace를 합산해 전체 실행 시간을 남기며, 이후 KG 생성 같은 후속 노드가
        재사용할 수 있는 artifact 위치와 적재 결과를 summary.json에 기록합니다.
        """
        step = "finalize"
        started = time.perf_counter()
        document_key = state["document_key"]
        artifact_key = state.get("artifact_key") or document_key
        trace = append_trace(
            state.get("trace"), node=step, status="completed", started=started
        )
        summary = self.summary({**state, "trace": trace})
        self.artifacts.save(artifact_key, "summary.json", summary)
        self.artifacts.update_checkpoint(
            artifact_key, step=step, status="completed", details=summary
        )
        _log_ingest_step(
            step,
            "completed",
            document_key=document_key,
            total_chunks=summary.get("total_chunks"),
            embedded_chunks=summary.get("embedded_chunks"),
            total_node_duration_ms=summary.get("total_node_duration_ms"),
        )
        return {
            **state,
            "trace": trace,
        }

    def summary(self, state: IngestState) -> dict[str, Any]:
        meta = state.get("meta")
        document_key = state.get("document_key") or (meta.document_key if meta else "")
        artifact_key = state.get("artifact_key") or document_key
        return {
            "document_key": document_key,
            "artifact_key": artifact_key,
            "collection_name": state.get("collection_name") or self.settings.qdrant.collection_name,
            "retrieval_profile": state.get("retrieval_profile"),
            "chunking_mode": state.get("chunking_mode"),
            "chunking_profile": state.get("chunking_profile") or self.settings.chunking.profile,
            "kg_extraction_mode": state.get("kg_extraction_mode") or self.settings.ontology.kg_extraction_mode,
            "kg_chunk_offset": state.get("kg_chunk_offset", 0),
            "kg_chunk_limit": state.get("kg_chunk_limit"),
            "query_graph_enabled": state.get("query_graph_enabled", False),
            "query_graph_chunk_offset": state.get("query_graph_chunk_offset"),
            "query_graph_chunk_limit": state.get("query_graph_chunk_limit"),
            "ontology_artifact_root": str(self.settings.ontology.artifact_root),
            "input_path": state.get("input_path"),
            "artifact_dir": state.get("artifact_dir")
            or str(self.artifacts.document_dir(artifact_key)),
            "total_elements": len(state.get("elements") or []),
            "total_chunks": len(state.get("chunks") or []),
            "embedded_chunks": len(state.get("embedded_chunks") or []),
            "dense_vector_size": state.get("dense_vector_size"),
            "reset_qdrant_result": state.get("reset_qdrant_result") or {},
            "upsert_result": state.get("upsert_result") or {},
            "ontology_result": state.get("ontology_result") or {},
            "query_graph_result": state.get("query_graph_result") or {},
            "total_node_duration_ms": _total_trace_duration_ms(state.get("trace") or []),
            "trace": state.get("trace") or [],
        }

    def _can_resume(
        self, state: IngestState, step: str, artifact_name: str, document_key: str
    ) -> bool:
        return (
            bool(state.get("resume", True))
            and step not in set(state.get("force_steps", []))
            and self.artifacts.exists(document_key, artifact_name)
        )


async def _embed_many(
    embedder: Any, texts: Sequence[str], *, concurrency: int
) -> list[Any]:
    if not texts:
        return []
    concurrency = max(1, concurrency)
    if hasattr(embedder, "embed_many"):
        semaphore = asyncio.Semaphore(concurrency)

        async def embed_batch(batch: Sequence[str]) -> list[Any]:
            async with semaphore:
                result = embedder.embed_many(batch)
                if inspect.isawaitable(result):
                    result = await result
                return list(result)

        batches = _batches(texts, concurrency)
        batch_results = await asyncio.gather(*(embed_batch(batch) for batch in batches))
        return [item for batch in batch_results for item in batch]
    if not hasattr(embedder, "embed"):
        raise AttributeError("embedder must expose embed or embed_many")

    semaphore = asyncio.Semaphore(concurrency)

    async def embed_one(text: str) -> Any:
        async with semaphore:
            result = embedder.embed(text)
            if inspect.isawaitable(result):
                return await result
            return result

    return list(await asyncio.gather(*(embed_one(text) for text in texts)))


async def _embed_many_with_timings(
    embedder: Any, texts: Sequence[str], *, concurrency: int, label: str = "embedding"
) -> tuple[list[Any], list[dict[str, Any]]]:
    if not texts:
        return [], []
    concurrency = max(1, concurrency)
    if hasattr(embedder, "embed_many"):
        semaphore = asyncio.Semaphore(concurrency)
        batches = [
            (batch_index, start_index, batch)
            for batch_index, (start_index, batch) in enumerate(_indexed_batches(texts, concurrency))
        ]

        async def embed_batch(batch_index: int, start_index: int, batch: Sequence[str]) -> tuple[int, list[Any], list[dict[str, Any]]]:
            async with semaphore:
                started = time.perf_counter()
                result = embedder.embed_many(batch)
                if inspect.isawaitable(result):
                    result = await result
                duration_ms = _duration_ms(started)
                values = list(result)
                per_item_ms = round(duration_ms / max(1, len(values)), 2)
                timings = [
                    {
                        "chunk_index": start_index + offset,
                        "batch_index": batch_index,
                        "batch_size": len(batch),
                        "batch_duration_ms": duration_ms,
                        "estimated_chunk_duration_ms": per_item_ms,
                    }
                    for offset, _ in enumerate(values)
                ]
                _log_ingest_progress(
                    "embed_chunks",
                    event=f"{label}_batch_completed",
                    completed=min(start_index + len(values), len(texts)),
                    total=len(texts),
                    batch_index=batch_index + 1,
                    batch_count=len(batches),
                    duration_ms=duration_ms,
                )
                return start_index, values, timings

        batch_results = await asyncio.gather(
            *(embed_batch(batch_index, start_index, batch) for batch_index, start_index, batch in batches)
        )
        ordered_results = sorted(batch_results, key=lambda item: item[0])
        vectors = [vector for _, values, _ in ordered_results for vector in values]
        timings = [timing for _, _, items in ordered_results for timing in items]
        return vectors, timings

    if not hasattr(embedder, "embed"):
        raise AttributeError("embedder must expose embed or embed_many")

    semaphore = asyncio.Semaphore(concurrency)

    async def embed_one(index: int, text: str) -> tuple[int, Any, dict[str, Any]]:
        async with semaphore:
            started = time.perf_counter()
            result = embedder.embed(text)
            if inspect.isawaitable(result):
                result = await result
            duration_ms = _duration_ms(started)
            _log_ingest_progress(
                "embed_chunks",
                event=f"{label}_item_completed",
                completed=index + 1,
                total=len(texts),
                chunk_index=index,
                duration_ms=duration_ms,
            )
            return index, result, {
                "chunk_index": index,
                "batch_index": index,
                "batch_size": 1,
                "batch_duration_ms": duration_ms,
                "estimated_chunk_duration_ms": duration_ms,
            }

    item_results = await asyncio.gather(*(embed_one(index, text) for index, text in enumerate(texts)))
    ordered_items = sorted(item_results, key=lambda item: item[0])
    return [value for _, value, _ in ordered_items], [timing for _, _, timing in ordered_items]


def _batches(values: Sequence[str], batch_size: int) -> list[Sequence[str]]:
    return [
        values[index : index + batch_size]
        for index in range(0, len(values), batch_size)
    ]


def _indexed_batches(values: Sequence[str], batch_size: int) -> list[tuple[int, Sequence[str]]]:
    return [
        (index, values[index : index + batch_size])
        for index in range(0, len(values), batch_size)
    ]


def _embedding_timing_rows(
    chunks: Sequence[ChildChunk],
    dense_timings: Sequence[dict[str, Any]],
    sparse_timings: Sequence[dict[str, Any]],
) -> list[dict[str, Any]]:
    dense_by_index = {int(item["chunk_index"]): item for item in dense_timings}
    sparse_by_index = {int(item["chunk_index"]): item for item in sparse_timings}
    rows: list[dict[str, Any]] = []
    for index, chunk in enumerate(chunks):
        dense = dense_by_index.get(index, {})
        sparse = sparse_by_index.get(index, {})
        dense_estimated_ms = float(dense.get("estimated_chunk_duration_ms") or 0)
        sparse_estimated_ms = float(sparse.get("estimated_chunk_duration_ms") or 0)
        rows.append(
            {
                "chunk_index": index,
                "chunk_id": chunk.chunk_id,
                "page_numbers": chunk.page_numbers,
                "char_count": chunk.char_count,
                "token_count": chunk.token_count,
                "dense_batch_index": dense.get("batch_index"),
                "dense_batch_size": dense.get("batch_size"),
                "dense_batch_duration_ms": dense.get("batch_duration_ms"),
                "dense_estimated_chunk_duration_ms": dense.get("estimated_chunk_duration_ms"),
                "sparse_batch_index": sparse.get("batch_index"),
                "sparse_batch_size": sparse.get("batch_size"),
                "sparse_batch_duration_ms": sparse.get("batch_duration_ms"),
                "sparse_estimated_chunk_duration_ms": sparse.get("estimated_chunk_duration_ms"),
                "estimated_total_chunk_embedding_ms": round(dense_estimated_ms + sparse_estimated_ms, 2),
            }
        )
    return rows


def _state_collection_name(state: IngestState, settings: Settings) -> str:
    return state.get("collection_name") or settings.qdrant.collection_name


def _state_chunking_profile(state: IngestState, settings: Settings) -> str:
    return state.get("chunking_profile") or settings.chunking.profile


def _select_kg_chunks(
    chunks: Sequence[ChildChunk],
    *,
    offset: int,
    limit: int | None,
) -> list[ChildChunk]:
    if offset < 0:
        raise ValueError("kg_chunk_offset must be greater than or equal to 0")
    if limit is not None and limit <= 0:
        raise ValueError("kg_chunk_limit must be greater than 0 when provided")
    total = len(chunks)
    if offset >= total and total > 0:
        raise ValueError(
            f"kg_chunk_offset={offset} is outside the available chunk range 0..{total - 1}"
        )
    end = None if limit is None else offset + limit
    return list(chunks[offset:end])


def _kg_chunk_range(offset: int, selected_count: int) -> dict[str, int | None]:
    if selected_count <= 0:
        return {
            "start_offset": None,
            "end_offset_inclusive": None,
            "end_offset_exclusive": offset,
        }
    return {
        "start_offset": offset,
        "end_offset_inclusive": offset + selected_count - 1,
        "end_offset_exclusive": offset + selected_count,
    }


def _kg_cache_dir_name(graph_dataset_key: str) -> str:
    digest = hashlib.sha1(graph_dataset_key.encode("utf-8")).hexdigest()[:16]
    return f"{digest}"


def _log_ingest_step(step: str, status: str, **details: Any) -> None:
    _log_ingest_progress(step, event=status, **details)


def _log_ingest_progress(
    step: str,
    *,
    event: str,
    completed: int | None = None,
    total: int | None = None,
    **details: Any,
) -> None:
    parts = [f"[ingest][{step}]", event]
    if completed is not None and total is not None:
        percent = round((completed / total) * 100, 2) if total else 100.0
        parts.append(f"{completed}/{total} ({percent}%)")
    for key, value in details.items():
        if value is None:
            continue
        parts.append(f"{key}={value}")
    print(" ".join(parts), flush=True)


def _duration_ms(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 2)


def _total_trace_duration_ms(trace: Sequence[dict[str, Any]]) -> float:
    return round(sum(float(item.get("duration_ms") or 0) for item in trace), 2)


def _build_embedded_chunks(
    chunks: Sequence[ChildChunk],
    dense_vectors: Sequence[Any],
    sparse_vectors: Sequence[Any],
    meta: DocumentMeta,
    *,
    collection_name: str,
    chunking_profile: str,
) -> list[EmbeddedChunk]:
    embedded: list[EmbeddedChunk] = []
    for chunk, dense_vector, sparse_vector in zip(
        chunks, dense_vectors, sparse_vectors, strict=True
    ):
        embedded.append(
            EmbeddedChunk(
                chunk_id=chunk.chunk_id,
                payload=chunk_to_payload(
                    chunk,
                    meta,
                    transform_version=chunking_profile,
                    collection_name=collection_name,
                    chunking_profile=chunking_profile,
                ),
                dense_vector=list(dense_vector),
                sparse_vector=_sparse_dict(sparse_vector),
                chunk=chunk,
            )
        )
    return embedded


def _sparse_dict(value: Any) -> dict[str, list[int] | list[float]]:
    if isinstance(value, dict):
        return {
            "indices": [int(index) for index in value.get("indices", [])],
            "values": [float(weight) for weight in value.get("values", [])],
        }
    return {
        "indices": [int(index) for index in getattr(value, "indices", [])],
        "values": [float(weight) for weight in getattr(value, "values", [])],
    }
