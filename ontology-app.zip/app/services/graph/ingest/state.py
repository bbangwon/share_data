from __future__ import annotations

from typing import Any, TypedDict

from app.services.schemas import ChildChunk, DocumentMeta, EmbeddedChunk, RawElement


class IngestState(TypedDict, total=False):
    input_path: str
    resume: bool
    force_steps: list[str]
    skip_qdrant: bool
    skip_existing_qdrant: bool
    reset_qdrant_collection: bool
    reset_qdrant_confirm_collection_name: str | None
    reset_neo4j_graph: bool
    reset_neo4j_confirm_retrieval_profile: str | None
    collection_name: str
    retrieval_profile: str | None
    chunking_mode: str | None
    chunking_profile: str
    kg_extraction_mode: str | None
    kg_chunk_offset: int
    kg_chunk_limit: int | None
    query_graph_enabled: bool
    query_graph_generation_enabled: bool | None
    query_graph_upsert_enabled: bool | None
    query_graph_chunk_offset: int | None
    query_graph_chunk_limit: int | None
    reset_query_graph_scope: bool
    reset_query_graph_confirm_retrieval_profile: str | None
    artifact_key: str
    document_key: str
    artifact_dir: str
    meta: DocumentMeta
    elements: list[RawElement]
    chunks: list[ChildChunk]
    embedded_chunks: list[EmbeddedChunk]
    dense_vector_size: int
    reset_qdrant_result: dict[str, Any]
    upsert_result: dict[str, Any]
    ontology_result: dict[str, Any]
    query_graph_result: dict[str, Any]
    trace: list[dict[str, Any]]
