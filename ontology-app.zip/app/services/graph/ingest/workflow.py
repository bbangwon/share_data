from __future__ import annotations

from pathlib import Path
from typing import Any

from langgraph.graph import END, StateGraph

from app.core.config import Settings, get_settings, resolve_default_json_path
from app.services.graph.ingest.nodes import IngestNodes
from app.services.graph.ingest.state import IngestState


class IngestWorkflow:
    """LangGraph orchestration for JSON-to-Qdrant ingest."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.nodes = IngestNodes(self.settings)
        self.graph = self._build_graph()

    async def run(
        self,
        *,
        input_path: str | None = None,
        resume: bool = True,
        force_steps: list[str] | None = None,
        skip_qdrant: bool = False,
        skip_existing_qdrant: bool = False,
        reset_qdrant_collection: bool = False,
        reset_qdrant_confirm_collection_name: str | None = None,
        reset_neo4j_graph: bool = False,
        reset_neo4j_confirm_retrieval_profile: str | None = None,
        chunking_mode: str | None = None,
        retrieval_profile: str | None = None,
        kg_extraction_mode: str | None = None,
        kg_chunk_offset: int = 0,
        kg_chunk_limit: int | None = None,
        query_graph_enabled: bool = False,
        query_graph_generation_enabled: bool | None = None,
        query_graph_upsert_enabled: bool | None = None,
        query_graph_chunk_offset: int | None = None,
        query_graph_chunk_limit: int | None = None,
        reset_query_graph_scope: bool = False,
        reset_query_graph_confirm_retrieval_profile: str | None = None,
    ) -> dict[str, Any]:
        if kg_chunk_offset < 0:
            raise ValueError("kg_chunk_offset must be greater than or equal to 0")
        if kg_chunk_limit is not None and kg_chunk_limit <= 0:
            raise ValueError("kg_chunk_limit must be greater than 0 when provided")
        if (
            reset_qdrant_collection
            and reset_qdrant_confirm_collection_name
            != self.settings.qdrant.collection_name
        ):
            raise ValueError(
                "reset_qdrant_confirm_collection_name must exactly match "
                f"{self.settings.qdrant.collection_name!r}"
            )
        if reset_neo4j_graph:
            if not retrieval_profile:
                raise ValueError("reset_neo4j_graph requires retrieval_profile")
            if reset_neo4j_confirm_retrieval_profile != retrieval_profile:
                raise ValueError(
                    "reset_neo4j_confirm_retrieval_profile must exactly match "
                    f"{retrieval_profile!r}"
                )
        if query_graph_chunk_offset is not None and query_graph_chunk_offset < 0:
            raise ValueError("query_graph_chunk_offset must be greater than or equal to 0")
        if query_graph_chunk_limit is not None and query_graph_chunk_limit <= 0:
            raise ValueError("query_graph_chunk_limit must be greater than 0 when provided")
        if reset_query_graph_scope:
            if not retrieval_profile:
                raise ValueError("reset_query_graph_scope requires retrieval_profile")
            if reset_query_graph_confirm_retrieval_profile != retrieval_profile:
                raise ValueError(
                    "reset_query_graph_confirm_retrieval_profile must exactly match "
                    f"{retrieval_profile!r}"
                )
        resolved_input_path = (
            Path(input_path) if input_path else resolve_default_json_path(self.settings)
        )
        effective_chunking_mode = chunking_mode
        if effective_chunking_mode is None and retrieval_profile:
            profile = self.settings.retrieval_profiles.profiles.get(retrieval_profile)
            if profile is not None:
                effective_chunking_mode = profile.chunking_mode
        initial_state: IngestState = {
            "input_path": str(resolved_input_path),
            "resume": resume,
            "force_steps": force_steps or [],
            "skip_qdrant": skip_qdrant,
            "skip_existing_qdrant": skip_existing_qdrant,
            "reset_qdrant_collection": reset_qdrant_collection,
            "reset_qdrant_confirm_collection_name": reset_qdrant_confirm_collection_name,
            "reset_neo4j_graph": reset_neo4j_graph,
            "reset_neo4j_confirm_retrieval_profile": reset_neo4j_confirm_retrieval_profile,
            "collection_name": self.settings.qdrant.collection_name,
            "retrieval_profile": retrieval_profile,
            "chunking_mode": effective_chunking_mode,
            "chunking_profile": self.settings.chunking.profile,
            "kg_extraction_mode": kg_extraction_mode,
            "kg_chunk_offset": kg_chunk_offset,
            "kg_chunk_limit": kg_chunk_limit,
            "query_graph_enabled": query_graph_enabled,
            "query_graph_generation_enabled": query_graph_generation_enabled,
            "query_graph_upsert_enabled": query_graph_upsert_enabled,
            "query_graph_chunk_offset": query_graph_chunk_offset,
            "query_graph_chunk_limit": query_graph_chunk_limit,
            "reset_query_graph_scope": reset_query_graph_scope,
            "reset_query_graph_confirm_retrieval_profile": reset_query_graph_confirm_retrieval_profile,
            "trace": [],
        }
        final_state = await self.graph.ainvoke(initial_state)
        return self.nodes.summary(final_state)

    def _build_graph(self) -> Any:
        graph = StateGraph(IngestState)
        # 노드 정의
        graph.add_node("load_document", self.nodes.load_document)
        graph.add_node("chunk_document", self.nodes.chunk_document)
        graph.add_node("embed_chunks", self.nodes.embed_chunks)
        graph.add_node("reset_qdrant_collection", self.nodes.reset_qdrant_collection)
        graph.add_node("upsert_qdrant", self.nodes.upsert_qdrant)
        graph.add_node("build_ontology_layer", self.nodes.build_ontology_layer)
        graph.add_node("build_query_graph_layer", self.nodes.build_query_graph_layer)
        graph.add_node("finalize", self.nodes.finalize)

        # 노드 연결
        graph.set_entry_point("load_document")
        graph.add_edge("load_document", "chunk_document")
        graph.add_edge("chunk_document", "embed_chunks")
        graph.add_edge("embed_chunks", "reset_qdrant_collection")
        graph.add_edge("reset_qdrant_collection", "upsert_qdrant")
        graph.add_edge("upsert_qdrant", "build_ontology_layer")
        graph.add_edge("build_ontology_layer", "build_query_graph_layer")
        graph.add_edge("build_query_graph_layer", "finalize")
        graph.add_edge("finalize", END)
        return graph.compile()
