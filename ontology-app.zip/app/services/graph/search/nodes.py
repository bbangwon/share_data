from __future__ import annotations

import inspect
import time
from typing import Any

from qdrant_client import AsyncQdrantClient, models

from app.core.config import Settings
from app.services.chunk_eval import ChunkEvalClient, is_document_groups
from app.services.embeddings import GpuDenseEmbedder, KiwiBm25SparseEmbedder
from app.services.graph.common.tracing import append_trace
from app.services.graph.search.state import SearchState
from app.services.kg_query_extraction import (
    KGQueryExtractionResult,
    KGQueryExtractionService,
)
from app.services.ontology.extraction import build_chunk_uid, build_graph_dataset_key
from app.services.ontology.neo4j_store import Neo4jOntologyStore
from app.services.query_graph import QueryGraphExpansionService
from app.services.query_routing import route_query as route_user_query
from app.services.rerank import GpuReranker, build_rerank_input, rerank_documents
from app.services.result_context import build_result_text_context


class SearchNodes:
    def __init__(
        self, settings: Settings, *, chunk_eval_client: Any | None = None
    ) -> None:
        self.settings = settings
        self.chunk_eval_client = chunk_eval_client

    async def route_query(self, state: SearchState) -> SearchState:
        """사용자 질의의 성격을 분류해 graph expansion 사용 여부를 결정합니다.

        `graph_mode=auto`에서는 규칙 기반 router가 관계형/다중-hop/비교/시간/원인 질의를
        감지해 `use_graph`를 설정합니다. `graph_mode=hybrid|graph`는 기존 수동 제어를 유지합니다.
        """
        step = "route_query"
        started = time.perf_counter()
        decision = await route_user_query(
            query=state["query"],
            graph_mode=state.get("graph_mode") or "hybrid",
            settings=self.settings,
        )
        routing = decision.model_dump(mode="json")
        return {
            **state,
            "routing": routing,
            "use_graph": decision.graph_activated,
            "trace": append_trace(
                state.get("trace"),
                node=step,
                status="completed",
                started=started,
                details=routing,
            ),
        }

    async def embed_query(self, state: SearchState) -> SearchState:
        """사용자 질의를 dense vector와 sparse vector로 변환합니다.

        이후 Qdrant hybrid search에서 사용할 query embedding을 생성하고,
        dense vector 크기 등 관측 정보를 trace에 기록합니다.
        """
        step = "embed_query"
        started = time.perf_counter()
        dense_embedder = GpuDenseEmbedder(
            base_url=self.settings.embedding.base_url,
            model=self.settings.embedding.dense_model_name,
            timeout=self.settings.embedding.timeout,
        )
        sparse_embedder = KiwiBm25SparseEmbedder(
            model_name=self.settings.embedding.sparse_model_name
        )
        try:
            dense_vector = (
                await _maybe_await(dense_embedder.embed_query_many([state["query"]]))
            )[0]
            sparse_vector = (
                await _maybe_await(sparse_embedder.embed_query_many([state["query"]]))
            )[0]
        finally:
            await dense_embedder.close()
            await sparse_embedder.close()
        return {
            **state,
            "dense_vector": dense_vector,
            "sparse_vector": sparse_vector,
            "trace": append_trace(
                state.get("trace"),
                node=step,
                status="completed",
                started=started,
                details={"dense_vector_size": len(dense_vector)},
            ),
        }

    async def hybrid_search(self, state: SearchState) -> SearchState:
        """Qdrant에서 dense/sparse hybrid retrieval을 수행해 후보 chunk를 가져옵니다.

        요청별 collection_name과 document_key 필터를 반영하고, DBSF fusion 결과에서
        current 문서 버전만 남겨 다음 rerank 단계로 전달합니다.
        """
        step = "hybrid_search"
        started = time.perf_counter()
        client = AsyncQdrantClient(
            host=self.settings.qdrant.host,
            port=self.settings.qdrant.port,
            timeout=self.settings.qdrant.timeout,
            check_compatibility=False,
        )
        try:
            query_filter = _build_query_filter(document_key=state.get("document_key"))
            prefetch = [
                models.Prefetch(
                    query=state["dense_vector"],
                    using=self.settings.qdrant.dense_name,
                    filter=query_filter,
                    limit=state["dense_limit"],
                ),
                models.Prefetch(
                    query=_as_sparse_vector(state["sparse_vector"]),
                    using=self.settings.qdrant.sparse_name,
                    filter=query_filter,
                    limit=state["sparse_limit"],
                ),
            ]
            needs_rerank_pool = bool(
                state.get("hybrid_rerank", state.get("rerank", True))
                or state.get("post_graph_rerank", state.get("rerank", True))
            )
            query_limit = (
                state["dense_limit"] + state["sparse_limit"]
                if needs_rerank_pool
                else state["limit"]
            )
            response = await client.query_points(
                collection_name=self.settings.qdrant.collection_name,
                prefetch=prefetch,
                query=models.FusionQuery(fusion=models.Fusion.DBSF),
                query_filter=query_filter,
                limit=query_limit,
                with_payload=True,
                with_vectors=False,
            )
        finally:
            close = getattr(client, "close", None)
            if close:
                result = close()
                if inspect.isawaitable(result):
                    await result
        candidates = _filter_active_document_versions(_response_points(response))
        return {
            **state,
            "candidates": candidates,
            "trace": append_trace(
                state.get("trace"),
                node=step,
                status="completed",
                started=started,
                details={
                    "collection_name": self.settings.qdrant.collection_name,
                    "candidate_count": len(candidates),
                    "query_limit": query_limit,
                    "hybrid_rerank": bool(state.get("hybrid_rerank", state.get("rerank", True))),
                    "post_graph_rerank": bool(state.get("post_graph_rerank", state.get("rerank", True))),
                },
            ),
        }

    async def rerank(self, state: SearchState) -> SearchState:
        """검색 후보를 설정된 reranker로 재정렬합니다.

        rerank가 비활성화되었거나 후보가 없으면 원래 후보 순서를 유지하고,
        활성화된 경우 rerank_score를 붙여 후속 평가/최종화 단계로 전달합니다.
        """
        step = "rerank"
        started = time.perf_counter()
        documents = state.get("candidates") or []
        status = "skipped"
        hybrid_rerank_enabled = bool(state.get("hybrid_rerank", state.get("rerank", True)))
        if self.settings.rerank.enabled and hybrid_rerank_enabled and documents:
            reranker = GpuReranker(
                base_url=self.settings.rerank.base_url,
                model=self.settings.rerank.model_name,
                timeout=self.settings.rerank.timeout,
            )
            inputs = [build_rerank_input(document) for document in documents]
            documents = await rerank_documents(
                state["query"],
                documents,
                reranker=reranker,
                inputs=inputs,
                top_n=min(self.settings.rerank.top_n, len(documents)),
            )
            status = "completed"
        return {
            **state,
            "reranked_candidates": documents,
            "trace": append_trace(
                state.get("trace"),
                node=step,
                status=status,
                started=started,
                details={
                    "candidate_count": len(documents),
                    "hybrid_rerank": hybrid_rerank_enabled,
                    "rerank_service_enabled": self.settings.rerank.enabled,
                },
            ),
        }

    async def chunk_eval(self, state: SearchState) -> SearchState:
        """선택적으로 외부 chunk-eval 서비스에 후보 목록을 보내 추가 평가(Reasoning Selector)를 수행합니다.

        chunk_eval 설정이 꺼져 있거나 외부 응답이 실패/비정상 형태이면 기존 후보 목록으로
        fallback하여 기본 HybridRAG 검색 품질을 보존합니다.
        """
        step = "chunk_eval"
        started = time.perf_counter()
        documents = state.get("reranked_candidates") or state.get("candidates") or []
        evaluated_documents = documents
        status = "skipped"
        details: dict[str, Any] = {"candidate_count": len(documents)}

        if not documents:
            details["reason"] = "no_candidates"
        elif not self.settings.chunk_eval.enabled:
            details["reason"] = "disabled"
        else:
            evaluator = self.chunk_eval_client or ChunkEvalClient(
                base_url=self.settings.chunk_eval.base_url,
                timeout=self.settings.chunk_eval.timeout,
            )
            document_groups = [documents]
            try:
                evaluated = await evaluator.evaluate([state["query"]], document_groups)
                if evaluated is not document_groups and is_document_groups(
                    evaluated, expected_groups=1
                ):
                    evaluated_documents = evaluated[0]
                    status = "completed"
                    details["evaluated_count"] = len(evaluated_documents)
                else:
                    status = "fallback"
                    details["reason"] = "invalid_or_failed_response"
            except Exception as exc:
                status = "fallback"
                details["reason"] = str(exc)

        return {
            **state,
            "evaluated_candidates": evaluated_documents,
            "trace": append_trace(
                state.get("trace"),
                node=step,
                status=status,
                started=started,
                details=details,
            ),
        }

    async def apply_quality_penalty(self, state: SearchState) -> SearchState:
        """너무 짧은 원본 child text 후보에 최종 정렬용 품질 패널티를 적용합니다.

        Qdrant payload나 원본 text는 변경하지 않고, rerank_score 또는 score를 기준으로
        quality_score를 계산해 fragmented chunk가 과도하게 상위에 오르는 것을 완화합니다.
        """
        step = "apply_quality_penalty"
        started = time.perf_counter()
        documents = (
            state.get("evaluated_candidates")
            or state.get("reranked_candidates")
            or state.get("candidates")
            or []
        )
        adjusted, penalized_count = _apply_short_text_penalty(documents, self.settings)
        status = (
            "completed"
            if self.settings.search.short_text_penalty_enabled
            else "skipped"
        )
        return {
            **state,
            "quality_adjusted_candidates": adjusted,
            "trace": append_trace(
                state.get("trace"),
                node=step,
                status=status,
                started=started,
                details={
                    "candidate_count": len(documents),
                    "penalized_count": penalized_count,
                    "short_text_min_chars": self.settings.search.short_text_min_chars,
                    "short_text_penalty_floor": self.settings.search.short_text_penalty_floor,
                },
            ),
        }

    async def finalize(self, state: SearchState) -> SearchState:
        """최종 후보를 API 응답 형태로 변환하고 짧은 결과의 LLM 컨텍스트를 보강합니다.

        원본 검색 청크 text는 그대로 유지하며, 필요한 경우 parent_text, 같은 parent의 앞뒤 child chunk,
        page text 순서로 context_text를 구성해 응답과 trace에 보강 정보를 남깁니다.
        """
        step = "finalize"
        started = time.perf_counter()
        documents = (
            state.get("graph_expanded_candidates")
            or state.get("quality_adjusted_candidates")
            or state.get("evaluated_candidates")
            or state.get("reranked_candidates")
            or state.get("candidates")
            or []
        )
        selected_documents = documents[: state["limit"]]
        selected_documents, context_details = await _attach_neighbor_contexts(
            selected_documents, self.settings
        )
        results = [
            _search_result(document, self.settings) for document in selected_documents
        ]
        return {
            **state,
            "results": results,
            "trace": append_trace(
                state.get("trace"),
                node=step,
                status="completed",
                started=started,
                details={"result_count": len(results), **context_details},
            ),
        }

    async def graph_expand(self, state: SearchState) -> SearchState:
        """Neo4j KG 또는 query graph를 사용해 초기 HybridRAG 후보 주변 chunk를 확장합니다.

        이 노드는 Qdrant 검색을 대체하지 않고, routing 결과가 `hybrid_graph`일 때만
        graph candidate를 추가·융합합니다. 그래프 확장 실패 시 기존 후보로 fallback합니다.
        """
        step = "graph_expand"
        started = time.perf_counter()
        documents = (
            state.get("quality_adjusted_candidates")
            or state.get("evaluated_candidates")
            or state.get("reranked_candidates")
            or state.get("candidates")
            or []
        )
        kg_expansion_mode = str(state.get("kg_expansion_mode") or "legacy")
        if kg_expansion_mode not in {"legacy", "query_guided"}:
            kg_expansion_mode = "legacy"
        kg_query_extraction = KGQueryExtractionResult(status="skipped")
        if not state.get("use_graph"):
            return {
                **state,
                "graph_expanded_candidates": documents,
                "kg_query_extraction": kg_query_extraction.trace_payload(),
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status="skipped",
                    started=started,
                    details={
                        "reason": "use_graph=false",
                        "candidate_count": len(documents),
                        "routing": state.get("routing") or {},
                        "kg_expansion_mode": kg_expansion_mode,
                        **kg_query_extraction.trace_payload(),
                        "post_graph_rerank": bool(state.get("post_graph_rerank", state.get("rerank", True))),
                    },
                ),
            }
        if not documents:
            return {
                **state,
                "graph_expanded_candidates": documents,
                "kg_query_extraction": kg_query_extraction.trace_payload(),
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status="skipped",
                    started=started,
                    details={
                        "reason": "no_candidates",
                        "kg_expansion_mode": kg_expansion_mode,
                        **kg_query_extraction.trace_payload(),
                    },
                ),
            }
        seed_chunk_refs = _seed_chunk_refs(
            documents,
            settings=self.settings,
            limit=self.settings.ontology.graph_search_seed_limit,
        )
        if not seed_chunk_refs:
            return {
                **state,
                "graph_expanded_candidates": documents,
                "kg_query_extraction": kg_query_extraction.trace_payload(),
                "trace": append_trace(
                    state.get("trace"),
                    node=step,
                    status="skipped",
                    started=started,
                    details={
                        "reason": "no_seed_chunk_ids",
                        "candidate_count": len(documents),
                        "kg_expansion_mode": kg_expansion_mode,
                        **kg_query_extraction.trace_payload(),
                    },
                ),
            }
        selected_strategy = _select_graph_strategy(
            state.get("graph_strategy") or "kg",
            routing=state.get("routing") or {},
        )
        rows: list[dict[str, Any]] = []
        errors: list[str] = []
        kg_rows: list[dict[str, Any]] = []
        query_graph_rows: list[dict[str, Any]] = []
        legacy_candidate_count = 0
        query_guided_candidate_count = 0

        # relation_allowlist: 명시 지정이 없으면 질의 타입 기반으로 자동 생성합니다.
        effective_relation_allowlist = list(state.get("relation_allowlist") or [])
        if not state.get("relation_allowlist_explicit"):
            effective_relation_allowlist = _build_auto_relation_allowlist(
                list((state.get("routing") or {}).get("query_types") or [])
            )

        if selected_strategy in {"query_graph", "combined"}:
            try:
                query_graph_rows = await QueryGraphExpansionService(self.settings).expand(
                    dense_vector=state["dense_vector"],
                    sparse_vector=state["sparse_vector"],
                    seed_chunk_refs=seed_chunk_refs,
                    document_key=state.get("document_key"),
                    include_evidence_chains=bool(state.get("include_evidence_chains")),
                    evidence_chain_limit=int(state.get("evidence_chain_limit") or 5),
                )
                rows.extend(query_graph_rows)
            except Exception as exc:
                errors.append(f"query_graph: {exc}")
                if selected_strategy == "query_graph" and state.get("graph_strategy") == "auto":
                    selected_strategy = "kg"
                    try:
                        kg_rows, kg_query_extraction = await self._expand_kg_rows_by_mode(
                            state,
                            seed_chunk_refs,
                            effective_relation_allowlist,
                            kg_expansion_mode=kg_expansion_mode,
                        )
                        if kg_expansion_mode == "query_guided":
                            query_guided_candidate_count = len(kg_rows)
                        else:
                            legacy_candidate_count = len(kg_rows)
                        rows.extend(kg_rows)
                    except Exception as kg_exc:
                        errors.append(f"kg_fallback: {kg_exc}")
            else:
                if not query_graph_rows and selected_strategy == "query_graph" and state.get("graph_strategy") == "auto":
                    selected_strategy = "kg"
                    try:
                        kg_rows, kg_query_extraction = await self._expand_kg_rows_by_mode(
                            state,
                            seed_chunk_refs,
                            effective_relation_allowlist,
                            kg_expansion_mode=kg_expansion_mode,
                        )
                        if kg_expansion_mode == "query_guided":
                            query_guided_candidate_count = len(kg_rows)
                        else:
                            legacy_candidate_count = len(kg_rows)
                        rows.extend(kg_rows)
                    except Exception as kg_exc:
                        errors.append(f"kg_fallback: {kg_exc}")

        if selected_strategy in {"kg", "combined"} and not kg_rows:
            kg_seed_refs = seed_chunk_refs
            if selected_strategy == "combined":
                kg_seed_refs = _merge_seed_refs(
                    seed_chunk_refs,
                    _seed_chunk_refs_from_graph_rows(query_graph_rows),
                    limit=max(
                        self.settings.ontology.graph_search_seed_limit,
                        self.settings.query_graph.retrieval_chunk_limit,
                    ),
                )
            try:
                kg_rows, kg_query_extraction = await self._expand_kg_rows_by_mode(
                    state,
                    kg_seed_refs,
                    effective_relation_allowlist,
                    kg_expansion_mode=kg_expansion_mode,
                )
                if kg_expansion_mode == "query_guided":
                    query_guided_candidate_count = len(kg_rows)
                else:
                    legacy_candidate_count = len(kg_rows)
                rows.extend(kg_rows)
            except Exception as exc:
                errors.append(f"kg: {exc}")

        expanded = _merge_graph_candidates(documents, rows)
        expanded, post_graph_rerank_applied = await self._post_graph_rerank_if_needed(
            query=state["query"],
            documents=expanded,
            graph_row_count=len(rows),
            rerank_enabled=bool(state.get("post_graph_rerank", state.get("rerank", True))),
        )
        status = "completed" if rows else ("fallback" if errors else "skipped")
        details: dict[str, Any] = {
            "seed_chunk_count": len(seed_chunk_refs),
            "graph_candidate_count": len(rows),
            "kg_candidate_count": len(kg_rows),
            "legacy_candidate_count": legacy_candidate_count,
            "query_guided_candidate_count": query_guided_candidate_count,
            "query_graph_candidate_count": len(query_graph_rows),
            "selected_graph_strategy": selected_strategy,
            "requested_graph_strategy": state.get("graph_strategy") or "kg",
            "kg_expansion_mode": kg_expansion_mode,
            **kg_query_extraction.trace_payload(),
            "query_graph_activated": bool(query_graph_rows),
            "post_graph_rerank_applied": post_graph_rerank_applied,
            "hybrid_rerank": bool(state.get("hybrid_rerank", state.get("rerank", True))),
            "post_graph_rerank": bool(state.get("post_graph_rerank", state.get("rerank", True))),
            "graph_search_limit": self.settings.ontology.graph_search_limit,
            "query_graph_retrieval_chunk_limit": self.settings.query_graph.retrieval_chunk_limit,
            "retrieval_profile": state.get("retrieval_profile"),
            "neo4j_database": self.settings.neo4j.database,
            "routing": state.get("routing") or {},
            "errors": errors,
        }
        details["effective_relation_allowlist"] = effective_relation_allowlist
        details["auto_relation_allowlist"] = (
            not bool(state.get("relation_allowlist_explicit"))
        )
        if state.get("include_evidence_chains"):
            details["relation_allowlist"] = state.get("relation_allowlist") or []
            details["evidence_chain_limit"] = int(state.get("evidence_chain_limit") or 5)
        return {
            **state,
            "graph_expanded_candidates": expanded,
            "kg_query_extraction": kg_query_extraction.trace_payload(),
            "selected_graph_strategy": selected_strategy,
            "query_graph_activated": bool(query_graph_rows),
            "post_graph_rerank_applied": post_graph_rerank_applied,
            "trace": append_trace(
                state.get("trace"),
                node=step,
                status=status,
                started=started,
                details={**details, "merged_candidate_count": len(expanded)},
            ),
        }

    async def _expand_kg_rows_by_mode(
        self,
        state: SearchState,
        seed_chunk_refs: list[dict[str, Any]],
        relation_allowlist: list[str] | None = None,
        *,
        kg_expansion_mode: str,
    ) -> tuple[list[dict[str, Any]], KGQueryExtractionResult]:
        effective_relation_allowlist = (
            relation_allowlist
            if relation_allowlist is not None
            else list(state.get("relation_allowlist") or [])
        )
        if kg_expansion_mode != "query_guided":
            rows = await self._expand_kg_rows(state, seed_chunk_refs, effective_relation_allowlist)
            return rows, KGQueryExtractionResult(status="skipped")

        extraction_result = await KGQueryExtractionService(self.settings).extract(
            query=state["query"],
            relation_allowlist=effective_relation_allowlist,
        )
        if extraction_result.status == "failed":
            return [], extraction_result

        store = Neo4jOntologyStore(self.settings.neo4j)
        try:
            rows = await store.expand_query_guided_chunks(
                query=state["query"],
                seed_chunk_refs=seed_chunk_refs,
                document_key=state.get("document_key"),
                limit=self.settings.ontology.graph_search_limit,
                relation_allowlist=effective_relation_allowlist,
                query_entities=extraction_result.extraction.entities,
                query_relation_types=extraction_result.extraction.relation_types,
                query_constraints=extraction_result.extraction.constraints,
                query_intent=extraction_result.extraction.intent,
                include_evidence_chains=bool(state.get("include_evidence_chains")),
                evidence_chain_limit=int(state.get("evidence_chain_limit") or 5),
            )
            return rows, extraction_result
        finally:
            await store.close()

    async def _expand_kg_rows(
        self,
        state: SearchState,
        seed_chunk_refs: list[dict[str, Any]],
        relation_allowlist: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        store = Neo4jOntologyStore(self.settings.neo4j)
        try:
            return await store.expand_chunks(
                query=state["query"],
                seed_chunk_refs=seed_chunk_refs,
                document_key=state.get("document_key"),
                limit=self.settings.ontology.graph_search_limit,
                relation_allowlist=relation_allowlist if relation_allowlist is not None else (state.get("relation_allowlist") or []),
                include_evidence_chains=bool(state.get("include_evidence_chains")),
                evidence_chain_limit=int(state.get("evidence_chain_limit") or 5),
            )
        finally:
            await store.close()

    async def _post_graph_rerank_if_needed(
        self,
        *,
        query: str,
        documents: list[dict[str, Any]],
        graph_row_count: int,
        rerank_enabled: bool,
    ) -> tuple[list[dict[str, Any]], bool]:
        if not graph_row_count or not documents or not rerank_enabled or not self.settings.rerank.enabled:
            return documents, False
        reranker = GpuReranker(
            base_url=self.settings.rerank.base_url,
            model=self.settings.rerank.model_name,
            timeout=self.settings.rerank.timeout,
        )
        inputs = [build_rerank_input(document) for document in documents]
        reranked = await rerank_documents(
            query,
            documents,
            reranker=reranker,
            inputs=inputs,
            top_n=min(self.settings.rerank.top_n, len(documents)),
        )
        return reranked, True


def _build_query_filter(*, document_key: str | None) -> models.Filter | None:
    if not document_key:
        return None
    return models.Filter(
        must=[
            models.FieldCondition(
                key="document_key",
                match=models.MatchValue(value=document_key),
            )
        ]
    )


def _as_sparse_vector(value: Any) -> models.SparseVector:
    if isinstance(value, models.SparseVector):
        return value
    if isinstance(value, dict):
        return models.SparseVector(
            indices=list(value.get("indices") or []),
            values=list(value.get("values") or []),
        )
    return models.SparseVector(
        indices=list(getattr(value, "indices", []) or []),
        values=list(getattr(value, "values", []) or []),
    )


def _response_points(response: Any) -> list[dict[str, Any]]:
    if response is None:
        return []
    if hasattr(response, "model_dump"):
        dumped = response.model_dump()
        points = dumped.get("points", []) if isinstance(dumped, dict) else []
    elif isinstance(response, dict):
        points = response.get("points", [])
    else:
        points = getattr(response, "points", [])

    normalized: list[dict[str, Any]] = []
    for point in points or []:
        if isinstance(point, dict):
            normalized.append(point)
        elif hasattr(point, "model_dump"):
            normalized.append(point.model_dump())
        else:
            normalized.append(
                {
                    "id": getattr(point, "id", None),
                    "score": getattr(point, "score", None),
                    "payload": getattr(point, "payload", None) or {},
                }
            )
    return normalized


def _filter_active_document_versions(
    documents: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    latest_epoch_by_doc: dict[Any, int] = {}
    for document in documents:
        payload = document.get("payload") or {}
        if payload.get("ingest_status") in {"staging", "stale"}:
            continue
        document_key = payload.get("document_key")
        if document_key is None:
            continue
        epoch = _coerce_int(payload.get("ingest_epoch_ns"), default=0)
        latest_epoch_by_doc[document_key] = max(
            latest_epoch_by_doc.get(document_key, 0), epoch
        )

    active: list[dict[str, Any]] = []
    for document in documents:
        payload = document.get("payload") or {}
        if payload.get("ingest_status") in {"staging", "stale"}:
            continue
        document_key = payload.get("document_key")
        if document_key is None:
            active.append(document)
            continue
        if _coerce_int(
            payload.get("ingest_epoch_ns"), default=0
        ) == latest_epoch_by_doc.get(document_key, 0):
            active.append(document)
    return active


def _search_result(document: dict[str, Any], settings: Settings) -> dict[str, Any]:
    payload = document.get("payload") or {}
    context = build_result_text_context(
        payload,
        min_chars=settings.result_context.min_chars
        if settings.result_context.enabled
        else 0,
        max_chars=settings.result_context.max_chars,
        use_parent_text=settings.result_context.enabled
        and settings.result_context.use_parent_text,
        use_neighbor_text=settings.result_context.enabled
        and settings.result_context.use_neighbor_text,
        use_page_text=settings.result_context.enabled
        and settings.result_context.use_page_text,
        ignore_categories=settings.chunking.ignore_categories,
    )
    result = {
        "id": document.get("id"),
        "score": document.get("score"),
        "rerank_score": document.get("rerank_score"),
        "quality_score": document.get("quality_score"),
        "quality_penalty": document.get("quality_penalty"),
        "quality_penalty_reason": document.get("quality_penalty_reason"),
        "document_key": payload.get("document_key"),
        "file": payload.get("file"),
        "chunk_id": payload.get("chunk_id"),
        "page_numbers": payload.get("page_numbers") or [],
        "section_path": payload.get("section_path"),
        "section_title": payload.get("section_title"),
        "section_level": payload.get("section_level"),
        "text": payload.get("text") or "",
        "context_text": context.text,
        "context_source": context.source,
        "context_expanded": context.expanded,
        "context_neighbor_chunk_ids": payload.get("neighbor_chunk_ids") or [],
        "retrieval_sources": document.get("retrieval_sources") or payload.get("retrieval_sources") or ["hybrid"],
        "graph_score": document.get("graph_score") or payload.get("graph_score"),
        "graph_entities": payload.get("graph_entities") or [],
        "graph_reasons": payload.get("graph_reasons") or [],
        "graph_paths": payload.get("graph_paths") or [],
        "query_graph_score": document.get("query_graph_score") or payload.get("query_graph_score"),
        "synthetic_queries": payload.get("synthetic_queries") or [],
        "query_graph_paths": payload.get("query_graph_paths") or [],
        "payload": payload,
    }
    evidence_chains = payload.get("evidence_chains") or []
    if evidence_chains:
        result["evidence_chains"] = evidence_chains
        result["relation_types_used"] = payload.get("relation_types_used") or []
        result["connected_chunk_ids"] = payload.get("connected_chunk_ids") or []
    return result


def _seed_chunk_refs(
    documents: list[dict[str, Any]],
    *,
    settings: Settings,
    limit: int,
) -> list[dict[str, str]]:
    refs: list[dict[str, str]] = []
    seen: set[str] = set()
    for document in documents:
        payload = document.get("payload") or {}
        chunk_id = str(payload.get("chunk_id") or "").strip()
        document_key = str(payload.get("document_key") or "").strip()
        chunking_profile = str(payload.get("transform_version") or settings.chunking.profile).strip()
        if not chunk_id or not document_key or not chunking_profile:
            continue
        graph_dataset_key = str(
            payload.get("graph_dataset_key")
            or build_graph_dataset_key(
                document_key=document_key,
                collection_name=settings.qdrant.collection_name,
                chunking_profile=chunking_profile,
            )
        )
        chunk_uid = str(
            payload.get("chunk_uid")
            or build_chunk_uid(graph_dataset_key=graph_dataset_key, chunk_id=chunk_id)
        )
        if chunk_uid and chunk_uid not in seen:
            seen.add(chunk_uid)
            refs.append(
                {
                    "chunk_uid": chunk_uid,
                    "chunk_id": chunk_id,
                    "document_key": document_key,
                    "graph_dataset_key": graph_dataset_key,
                }
            )
        if len(refs) >= limit:
            break
    return refs


def _seed_chunk_refs_from_graph_rows(rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    refs: list[dict[str, str]] = []
    for row in rows:
        payload = row.get("payload") or {}
        chunk_uid = str(payload.get("chunk_uid") or "").strip()
        chunk_id = str(payload.get("chunk_id") or "").strip()
        graph_dataset_key = str(payload.get("graph_dataset_key") or "").strip()
        document_key = str(payload.get("document_key") or "").strip()
        if not chunk_uid or not chunk_id or not graph_dataset_key:
            continue
        refs.append(
            {
                "chunk_uid": chunk_uid,
                "chunk_id": chunk_id,
                "document_key": document_key,
                "graph_dataset_key": graph_dataset_key,
            }
        )
    return refs


def _merge_seed_refs(
    *groups: list[dict[str, str]],
    limit: int,
) -> list[dict[str, str]]:
    refs: list[dict[str, str]] = []
    seen: set[str] = set()
    for group in groups:
        for ref in group:
            key = str(ref.get("chunk_uid") or ref.get("chunk_id") or "").strip()
            if not key or key in seen:
                continue
            seen.add(key)
            refs.append(ref)
            if len(refs) >= limit:
                return refs
    return refs


def _merge_graph_candidates(
    documents: list[dict[str, Any]],
    graph_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    for document in documents:
        payload = document.get("payload") or {}
        chunk_key = _candidate_key(payload, document.get("id"))
        if not chunk_key:
            continue
        merged[chunk_key] = {
            **document,
            "retrieval_sources": _dedupe([*(document.get("retrieval_sources") or []), "hybrid"]),
        }
        order.append(chunk_key)

    for row in graph_rows:
        graph_document = _graph_document(row)
        payload = graph_document.get("payload") or {}
        chunk_key = _candidate_key(payload, None)
        if not chunk_key:
            continue
        existing = merged.get(chunk_key)
        if existing is None:
            merged[chunk_key] = graph_document
            order.append(chunk_key)
            continue
        existing_payload = existing.get("payload") or {}
        graph_payload = graph_document.get("payload") or {}
        graph_score = max(float(existing.get("graph_score") or 0), float(graph_document.get("graph_score") or 0))
        existing["graph_score"] = graph_score
        existing["quality_score"] = max(float(existing.get("quality_score") or existing.get("rerank_score") or existing.get("score") or 0), graph_score)
        existing["retrieval_sources"] = _dedupe(
            [*(existing.get("retrieval_sources") or []), *(graph_document.get("retrieval_sources") or ["graph"])]
        )
        merged_payload = {
            **existing_payload,
            "graph_score": graph_score,
            "query_graph_score": max(float(existing_payload.get("query_graph_score") or 0), float(graph_payload.get("query_graph_score") or 0)),
            "graph_entities": _dedupe([*(existing_payload.get("graph_entities") or []), *(graph_payload.get("graph_entities") or [])]),
            "graph_reasons": _dedupe([*(existing_payload.get("graph_reasons") or []), *(graph_payload.get("graph_reasons") or [])]),
            "graph_paths": _dedupe([*(existing_payload.get("graph_paths") or []), *(graph_payload.get("graph_paths") or [])]),
            "synthetic_queries": _dedupe([*(existing_payload.get("synthetic_queries") or []), *(graph_payload.get("synthetic_queries") or [])]),
            "query_graph_paths": _dedupe([*(existing_payload.get("query_graph_paths") or []), *(graph_payload.get("query_graph_paths") or [])]),
            "retrieval_sources": existing["retrieval_sources"],
        }
        evidence_chains = _dedupe_chains([*(existing_payload.get("evidence_chains") or []), *(graph_payload.get("evidence_chains") or [])])
        if evidence_chains:
            merged_payload["evidence_chains"] = evidence_chains
            merged_payload["relation_types_used"] = _dedupe([*(existing_payload.get("relation_types_used") or []), *(graph_payload.get("relation_types_used") or [])])
            merged_payload["connected_chunk_ids"] = _dedupe([*(existing_payload.get("connected_chunk_ids") or []), *(graph_payload.get("connected_chunk_ids") or [])])
        existing["payload"] = merged_payload

    return sorted(
        merged.values(),
        key=lambda item: float(item.get("quality_score") or item.get("rerank_score") or item.get("score") or item.get("graph_score") or 0),
        reverse=True,
    )


def _graph_document(row: dict[str, Any]) -> dict[str, Any]:
    payload = dict(row.get("payload") or {})
    graph_score = float(row.get("graph_score") or 0.0)
    retrieval_source = "query_graph" if row.get("query_graph_score") is not None else "graph"
    payload.update(
        {
            "chunk_type": "child",
            "graph_score": graph_score,
            "graph_entities": row.get("graph_entities") or [],
            "graph_reasons": row.get("graph_reasons") or [],
            "graph_paths": row.get("graph_paths") or [],
            "query_graph_score": row.get("query_graph_score"),
            "synthetic_queries": row.get("synthetic_queries") or [],
            "query_graph_paths": row.get("query_graph_paths") or [],
            "retrieval_sources": [retrieval_source],
        }
    )
    evidence_chains = row.get("evidence_chains") or []
    if evidence_chains:
        payload["evidence_chains"] = evidence_chains
        payload["relation_types_used"] = row.get("relation_types_used") or _relation_types_from_chains(evidence_chains)
        payload["connected_chunk_ids"] = row.get("connected_chunk_ids") or _connected_chunk_ids_from_chains(evidence_chains)
    return {
        "id": f"graph:{payload.get('chunk_uid') or payload.get('chunk_id')}",
        "score": None,
        "rerank_score": None,
        "quality_score": graph_score,
        "quality_penalty": 1.0,
        "quality_penalty_reason": None,
        "graph_score": graph_score,
        "query_graph_score": row.get("query_graph_score"),
        "retrieval_sources": [retrieval_source],
        "payload": payload,
    }


def _candidate_key(payload: dict[str, Any], fallback_id: Any) -> str:
    if payload.get("chunk_uid"):
        return str(payload["chunk_uid"])
    document_key = str(payload.get("document_key") or "")
    chunk_id = str(payload.get("chunk_id") or fallback_id or "")
    if document_key and chunk_id:
        return f"{document_key}:{chunk_id}"
    return chunk_id


def _dedupe(values: list[Any]) -> list[Any]:
    result: list[Any] = []
    for value in values:
        if value not in result:
            result.append(value)
    return result


def _dedupe_chains(values: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, dict):
            continue
        key = str(
            value.get("path_text")
            or (
                value.get("chain_type"),
                value.get("source_chunk_id"),
                value.get("target_chunk_id"),
                value.get("synthetic_queries"),
            )
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result


def _relation_types_from_chains(chains: list[dict[str, Any]]) -> list[str]:
    relation_types: list[str] = []
    for chain in chains:
        for relation in chain.get("relations") or []:
            relation_type = relation.get("type") if isinstance(relation, dict) else None
            if relation_type and relation_type not in relation_types:
                relation_types.append(str(relation_type))
    return relation_types


def _connected_chunk_ids_from_chains(chains: list[dict[str, Any]]) -> list[str]:
    chunk_ids: list[str] = []
    for chain in chains:
        for key in ("source_chunk_id", "target_chunk_id"):
            chunk_id = str(chain.get(key) or "").strip()
            if chunk_id and chunk_id not in chunk_ids:
                chunk_ids.append(chunk_id)
    return chunk_ids


_DEFAULT_KG_RELATION_ALLOWLIST: tuple[str, ...] = (
    "ASSIGNED_TO",
    "RESPONSIBLE_FOR",
    "SUPPORTS",
    "ACTIVATED_AT",
    "APPLIES_TO",
    "LOCATED_IN",
    "USES_TRANSPORT",
    "HAS_CONTACT",
    "PRECEDES",
    "REQUIRES_COOPERATION_WITH",
    "HAS_CRITERIA",
    "REPORTS_TO",
    "COMMUNICATES_VIA",
    "MONITORS",
    "OPERATES",
    "REFERENCES",
    "BELONGS_TO",
    "RELATED_TO",
)


_QUERY_TYPE_RELATION_MAP: dict[str, list[str]] = {
    # 조직·협업·보고 관계 질의
    "relationship": ["RESPONSIBLE_FOR", "ASSIGNED_TO", "SUPPORTS", "REPORTS_TO", "REQUIRES_COOPERATION_WITH"],
    # 집계 질의: 적용 대상·기준·수단을 모아야 함
    "aggregation":  ["APPLIES_TO", "HAS_CRITERIA", "USES_TRANSPORT", "ACTIVATED_AT"],
    # 순서·시점 질의: 선후 관계와 단계 활성화
    "temporal":     ["PRECEDES", "ACTIVATED_AT"],
    # 원인·근거 질의: 기준 보유와 단계 활성화
    "causal":       ["HAS_CRITERIA", "ACTIVATED_AT"],
    # 비교·다중 hop은 넓게 보되, 구조 관계까지 전체 순회하지 않도록 도메인 관계로 제한합니다.
    "comparison":   ["RESPONSIBLE_FOR", "ASSIGNED_TO", "SUPPORTS", "APPLIES_TO", "HAS_CRITERIA", "PRECEDES", "ACTIVATED_AT", "REQUIRES_COOPERATION_WITH"],
    "multi_hop":    ["RESPONSIBLE_FOR", "ASSIGNED_TO", "SUPPORTS", "REPORTS_TO", "REQUIRES_COOPERATION_WITH", "APPLIES_TO", "HAS_CRITERIA", "PRECEDES", "ACTIVATED_AT", "RELATED_TO"],
    "semantic":     ["REFERENCES", "RELATED_TO", "APPLIES_TO", "HAS_CRITERIA"],
    "factual":      ["REFERENCES", "RELATED_TO"],
}


def _build_auto_relation_allowlist(query_types: list[str]) -> list[str]:
    """질의 타입 기반 KG 탐색 relation_allowlist 자동 생성.

    빈 리스트가 Neo4j에서 전체 관계 타입 순회를 의미하므로, 자동 정책은 항상
    하나 이상의 도메인 관계 allowlist를 반환합니다.
    """
    result: list[str] = []
    for qt in query_types:
        rels = _QUERY_TYPE_RELATION_MAP.get(qt, [])
        for rel in rels:
            if rel not in result:
                result.append(rel)
    if result:
        return result
    return list(_DEFAULT_KG_RELATION_ALLOWLIST)


def _select_graph_strategy(requested: str, *, routing: dict[str, Any]) -> str:
    if requested in {"kg", "query_graph", "combined"}:
        return requested
    if requested != "auto":
        return "kg"
    # auto 모드: 질의 타입 기반으로 최적 전략 선택
    query_types = set(routing.get("query_types") or [])
    # 다중 hop·비교 질의 → 두 레이어 모두 탐색해 커버리지 극대화
    if query_types.intersection({"multi_hop", "comparison"}):
        return "combined"
    # 시간·인과 질의 → synthetic Q&A 의미 유사도 기반 탐색이 유리
    if query_types.intersection({"temporal", "causal"}):
        return "query_graph"
    # 관계·집계 질의 → 엔티티-관계 그래프 직접 순회
    if query_types.intersection({"relationship", "aggregation"}):
        return "kg"
    return "kg"


async def _attach_neighbor_contexts(
    documents: list[dict[str, Any]],
    settings: Settings,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if not documents:
        return documents, {
            "neighbor_context_status": "skipped",
            "neighbor_context_count": 0,
        }
    if not _neighbor_context_enabled(settings):
        return documents, {
            "neighbor_context_status": "disabled",
            "neighbor_context_count": 0,
        }
    if not any(
        _needs_neighbor_context(document.get("payload") or {}, settings)
        for document in documents
    ):
        return documents, {
            "neighbor_context_status": "not_needed",
            "neighbor_context_count": 0,
        }

    client = AsyncQdrantClient(
        host=settings.qdrant.host,
        port=settings.qdrant.port,
        timeout=settings.qdrant.timeout,
        check_compatibility=False,
    )
    augmented: list[dict[str, Any]] = []
    attached_count = 0
    try:
        for document in documents:
            next_document, attached = await _attach_neighbor_context(
                client, document, settings
            )
            augmented.append(next_document)
            if attached:
                attached_count += 1
    except Exception as exc:
        return documents, {
            "neighbor_context_status": "fallback",
            "neighbor_context_count": 0,
            "neighbor_context_reason": str(exc),
        }
    finally:
        close = getattr(client, "close", None)
        if close:
            result = close()
            if inspect.isawaitable(result):
                await result

    return augmented, {
        "neighbor_context_status": "completed",
        "neighbor_context_count": attached_count,
        "neighbor_window": settings.result_context.neighbor_window,
    }


async def _attach_neighbor_context(
    client: AsyncQdrantClient,
    document: dict[str, Any],
    settings: Settings,
) -> tuple[dict[str, Any], bool]:
    payload = document.get("payload") or {}
    if not _needs_neighbor_context(payload, settings):
        return document, False

    document_key = _payload_text(payload, "document_key")
    parent_id = _payload_text(payload, "parent_id")
    child_idx = _payload_int(payload, "child_idx")
    if not document_key or not parent_id or child_idx is None:
        return document, False

    window = settings.result_context.neighbor_window
    must_conditions: list[Any] = [
        models.FieldCondition(
            key="document_key", match=models.MatchValue(value=document_key)
        ),
        models.FieldCondition(
            key="parent_id", match=models.MatchValue(value=parent_id)
        ),
        models.FieldCondition(
            key="ingest_status", match=models.MatchValue(value="current")
        ),
        models.FieldCondition(
            key="child_idx",
            range=models.Range(gte=child_idx - window, lte=child_idx + window),
        ),
    ]
    ingest_epoch_ns = _payload_int(payload, "ingest_epoch_ns")
    if ingest_epoch_ns is not None:
        must_conditions.append(
            models.FieldCondition(
                key="ingest_epoch_ns", match=models.MatchValue(value=ingest_epoch_ns)
            )
        )

    response = await client.scroll(
        collection_name=settings.qdrant.collection_name,
        scroll_filter=models.Filter(must=must_conditions),
        limit=(window * 2) + 1,
        with_payload=True,
        with_vectors=False,
    )
    points = (
        response[0] if isinstance(response, tuple) else getattr(response, "points", [])
    )
    neighbor_payloads = [_point_payload(point) for point in points]
    if not neighbor_payloads:
        return document, False

    neighbor_text, neighbor_chunk_ids = _build_neighbor_text(
        neighbor_payloads,
        fallback_payload=payload,
        max_chars=settings.result_context.max_chars,
    )
    if len(neighbor_text) <= len(_payload_text(payload, "text")):
        return document, False

    next_payload = {
        **payload,
        "neighbor_text": neighbor_text,
        "neighbor_chunk_ids": neighbor_chunk_ids,
        "neighbor_window": window,
    }
    return {**document, "payload": next_payload}, True


def _neighbor_context_enabled(settings: Settings) -> bool:
    return (
        settings.result_context.enabled
        and settings.result_context.use_neighbor_text
        and settings.result_context.neighbor_window > 0
        and settings.result_context.max_chars > 0
    )


def _needs_neighbor_context(payload: dict[str, Any], settings: Settings) -> bool:
    original_text = _payload_text(payload, "text")
    if len(original_text) >= settings.result_context.min_chars:
        return False
    if settings.result_context.use_parent_text:
        parent_text = _payload_text(payload, "parent_text")
        if len(parent_text) >= settings.result_context.min_chars and len(
            parent_text
        ) > len(original_text):
            return False
    neighbor_text = _payload_text(payload, "neighbor_text")
    if len(neighbor_text) >= settings.result_context.min_chars and len(
        neighbor_text
    ) > len(original_text):
        return False
    return True


def _build_neighbor_text(
    payloads: list[dict[str, Any]],
    *,
    fallback_payload: dict[str, Any],
    max_chars: int,
) -> tuple[str, list[str]]:
    ordered = sorted(
        [*payloads, fallback_payload],
        key=lambda item: _payload_int(item, "child_idx") or 0,
    )
    parts: list[str] = []
    chunk_ids: list[str] = []
    seen_chunks: set[str] = set()
    seen_texts: set[str] = set()
    for payload in ordered:
        text = _payload_text(payload, "text")
        if not text or text in seen_texts:
            continue
        chunk_id = _payload_text(payload, "chunk_id")
        dedupe_key = chunk_id or text
        if dedupe_key in seen_chunks:
            continue
        parts.append(text)
        seen_texts.add(text)
        seen_chunks.add(dedupe_key)
        if chunk_id:
            chunk_ids.append(chunk_id)
    return "\n\n".join(parts).strip()[:max_chars], chunk_ids


def _point_payload(point: Any) -> dict[str, Any]:
    if isinstance(point, dict):
        return dict(point.get("payload") or {})
    if hasattr(point, "model_dump"):
        dumped = point.model_dump()
        return dict(dumped.get("payload") or {})
    return dict(getattr(point, "payload", None) or {})


def _payload_text(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if value is None:
        return ""
    return str(value).strip()


def _payload_int(payload: dict[str, Any], key: str) -> int | None:
    try:
        return int(payload.get(key))
    except (TypeError, ValueError):
        return None


def _apply_short_text_penalty(
    documents: list[dict[str, Any]],
    settings: Settings,
) -> tuple[list[dict[str, Any]], int]:
    if not documents:
        return documents, 0
    if (
        not settings.search.short_text_penalty_enabled
        or settings.search.short_text_min_chars <= 0
    ):
        return [
            _strip_internal_quality_fields(
                _with_quality_score(document, index, len(documents), penalty=1.0)
            )
            for index, document in enumerate(documents)
        ], 0

    adjusted: list[dict[str, Any]] = []
    penalized_count = 0
    for index, document in enumerate(documents):
        payload = document.get("payload") or {}
        text_chars = len(str(payload.get("text") or ""))
        penalty = 1.0
        reason = None
        if text_chars < settings.search.short_text_min_chars:
            observed_ratio = (
                text_chars / settings.search.short_text_min_chars
                if settings.search.short_text_min_chars
                else 1.0
            )
            penalty = max(settings.search.short_text_penalty_floor, observed_ratio)
            reason = "short_text"
            penalized_count += 1
        adjusted.append(
            _with_quality_score(
                document, index, len(documents), penalty=penalty, reason=reason
            )
        )

    adjusted.sort(
        key=lambda document: (
            float(document.get("quality_score") or 0.0),
            -int(document.get("_quality_original_rank") or 0),
        ),
        reverse=True,
    )
    return [
        _strip_internal_quality_fields(document) for document in adjusted
    ], penalized_count


def _with_quality_score(
    document: dict[str, Any],
    index: int,
    total: int,
    *,
    penalty: float,
    reason: str | None = None,
) -> dict[str, Any]:
    base_score = _document_base_score(document)
    if base_score is None:
        base_score = float(total - index)
    quality_score = _apply_score_penalty(base_score, penalty)
    return {
        **document,
        "quality_score": quality_score,
        "quality_penalty": penalty,
        "quality_penalty_reason": reason,
        "_quality_original_rank": index,
    }


def _document_base_score(document: dict[str, Any]) -> float | None:
    for key in ("rerank_score", "score"):
        value = document.get(key)
        try:
            if value is not None:
                return float(value)
        except (TypeError, ValueError):
            continue
    return None


def _apply_score_penalty(score: float, penalty: float) -> float:
    if penalty >= 1:
        return score
    if score < 0:
        return score / penalty
    return score * penalty


def _strip_internal_quality_fields(document: dict[str, Any]) -> dict[str, Any]:
    if "_quality_original_rank" not in document:
        return document
    result = dict(document)
    result.pop("_quality_original_rank", None)
    return result


def _coerce_int(value: Any, *, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


async def _maybe_await(value: Any) -> Any:
    if inspect.isawaitable(value):
        return await value
    return value
