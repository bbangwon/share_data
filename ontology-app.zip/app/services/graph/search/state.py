from __future__ import annotations

from typing import Any, TypedDict


class SearchState(TypedDict, total=False):
    query: str
    limit: int
    dense_limit: int
    sparse_limit: int
    rerank: bool
    hybrid_rerank: bool
    post_graph_rerank: bool
    graph_mode: str
    graph_strategy: str
    kg_expansion_mode: str
    use_graph: bool
    include_evidence_chains: bool
    relation_allowlist: list[str]
    relation_allowlist_explicit: bool
    evidence_chain_limit: int
    graph_context_version: str | None
    document_key: str | None
    retrieval_profile: str | None
    routing: dict[str, Any]
    kg_query_extraction: dict[str, Any]
    dense_vector: list[float]
    sparse_vector: dict[str, list[int] | list[float]]
    candidates: list[dict[str, Any]]
    reranked_candidates: list[dict[str, Any]]
    evaluated_candidates: list[dict[str, Any]]
    quality_adjusted_candidates: list[dict[str, Any]]
    graph_expanded_candidates: list[dict[str, Any]]
    results: list[dict[str, Any]]
    selected_graph_strategy: str
    query_graph_activated: bool
    post_graph_rerank_applied: bool
    trace: list[dict[str, Any]]
