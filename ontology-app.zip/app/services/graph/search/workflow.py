from __future__ import annotations

from typing import Any

from langgraph.graph import END, StateGraph

from app.core.config import Settings, get_settings
from app.services.graph.search.nodes import SearchNodes
from app.services.graph.search.state import SearchState
from app.services.query_routing import GraphMode, resolve_graph_mode

GraphStrategy = str


class SearchWorkflow:
    """LangGraph orchestration for Qdrant hybrid retrieval."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.nodes = SearchNodes(self.settings)
        self.graph = self._build_graph()

    async def run(
        self,
        *,
        query: str,
        limit: int | None = None,
        dense_limit: int | None = None,
        sparse_limit: int | None = None,
        rerank: bool | None = None,
        hybrid_rerank: bool | None = None,
        post_graph_rerank: bool | None = None,
        use_graph: bool | None = None,
        graph_mode: GraphMode | None = None,
        graph_strategy: GraphStrategy = "kg",
        kg_expansion_mode: str | None = None,
        include_evidence_chains: bool = False,
        relation_allowlist: list[str] | None = None,
        evidence_chain_limit: int = 5,
        graph_context_version: str | None = None,
        document_key: str | None = None,
        retrieval_profile: str | None = None,
    ) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("query must not be empty")
        if graph_strategy not in {"kg", "query_graph", "combined", "auto"}:
            raise ValueError("graph_strategy must be one of kg, query_graph, combined, auto")
        resolved_kg_expansion_mode = (
            self.settings.search.kg_expansion_mode_default
            if kg_expansion_mode is None
            else kg_expansion_mode
        )
        if resolved_kg_expansion_mode not in {"legacy", "query_guided"}:
            raise ValueError("kg_expansion_mode must be one of legacy, query_guided")
        resolved_graph_mode = resolve_graph_mode(
            graph_mode=graph_mode,
            use_graph=use_graph,
            graph_search_enabled=self.settings.ontology.graph_search_enabled,
            query_routing_enabled=self.settings.query_routing.enabled,
        )
        hybrid_default = self.settings.search.hybrid_rerank_default if rerank is None else rerank
        post_graph_default = self.settings.search.post_graph_rerank_default if rerank is None else rerank
        resolved_hybrid_rerank = hybrid_default if hybrid_rerank is None else hybrid_rerank
        resolved_post_graph_rerank = (
            post_graph_default if post_graph_rerank is None else post_graph_rerank
        )
        initial_state: SearchState = {
            "query": query,
            "limit": limit or self.settings.search.final_limit,
            "dense_limit": dense_limit or self.settings.search.dense_limit,
            "sparse_limit": sparse_limit or self.settings.search.sparse_limit,
            "rerank": resolved_hybrid_rerank,
            "hybrid_rerank": resolved_hybrid_rerank,
            "post_graph_rerank": resolved_post_graph_rerank,
            "graph_mode": resolved_graph_mode,
            "graph_strategy": graph_strategy,
            "kg_expansion_mode": resolved_kg_expansion_mode,
            "use_graph": False,
            "include_evidence_chains": include_evidence_chains,
            "relation_allowlist": relation_allowlist or [],
            "relation_allowlist_explicit": relation_allowlist is not None,
            "evidence_chain_limit": max(1, evidence_chain_limit),
            "graph_context_version": graph_context_version,
            "document_key": document_key,
            "retrieval_profile": retrieval_profile,
            "trace": [],
        }
        final_state = await self.graph.ainvoke(initial_state)
        results = final_state.get("results") or []
        if include_evidence_chains:
            results = [_with_enhanced_graph_fields(result) for result in results]
        response = {
            "query": query,
            "collection_name": self.settings.qdrant.collection_name,
            "retrieval_profile": retrieval_profile,
            "hybrid_rerank": resolved_hybrid_rerank,
            "post_graph_rerank": resolved_post_graph_rerank,
            "routing": final_state.get("routing") or {},
            "kg_expansion_mode": resolved_kg_expansion_mode,
            "kg_query_extraction": final_state.get("kg_query_extraction") or {},
            "selected_graph_strategy": final_state.get("selected_graph_strategy") or graph_strategy,
            "query_graph_activated": bool(final_state.get("query_graph_activated")),
            "post_graph_rerank_applied": bool(final_state.get("post_graph_rerank_applied")),
            "total": len(results),
            "results": results,
            "trace": final_state.get("trace") or [],
        }
        if include_evidence_chains and graph_context_version:
            response["graph_context_version"] = graph_context_version
        return response

    def _build_graph(self) -> Any:
        graph = StateGraph(SearchState)
        # 노드 정의
        graph.add_node("route_query", self.nodes.route_query)
        graph.add_node("embed_query", self.nodes.embed_query)
        graph.add_node("hybrid_search", self.nodes.hybrid_search)
        graph.add_node("rerank", self.nodes.rerank)
        graph.add_node("chunk_eval", self.nodes.chunk_eval)
        graph.add_node("apply_quality_penalty", self.nodes.apply_quality_penalty)
        graph.add_node("graph_expand", self.nodes.graph_expand)
        graph.add_node("finalize", self.nodes.finalize)

        # 노드 연결
        graph.set_entry_point("route_query")
        graph.add_edge("route_query", "embed_query")
        graph.add_edge("embed_query", "hybrid_search")
        graph.add_edge("hybrid_search", "rerank")
        graph.add_edge("rerank", "chunk_eval")
        graph.add_edge("chunk_eval", "apply_quality_penalty")
        graph.add_edge("apply_quality_penalty", "graph_expand")
        graph.add_edge("graph_expand", "finalize")
        graph.add_edge("finalize", END)
        return graph.compile()


def _with_enhanced_graph_fields(result: dict[str, Any]) -> dict[str, Any]:
    payload = result.get("payload") if isinstance(result.get("payload"), dict) else {}
    evidence_chains = result.get("evidence_chains") or payload.get("evidence_chains") or []
    relation_types = result.get("relation_types_used") or payload.get("relation_types_used") or []
    connected_chunk_ids = result.get("connected_chunk_ids") or payload.get("connected_chunk_ids") or []
    next_result = {
        **result,
        "evidence_chains": evidence_chains,
        "relation_types_used": relation_types,
        "connected_chunk_ids": connected_chunk_ids,
    }
    if isinstance(payload, dict):
        next_result["payload"] = {
            **payload,
            "evidence_chains": evidence_chains,
            "relation_types_used": relation_types,
            "connected_chunk_ids": connected_chunk_ids,
        }
    return next_result
