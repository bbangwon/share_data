from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from collections.abc import Iterable
from pathlib import Path
from typing import Any


class ArtifactStore:
    def __init__(self, root: Path) -> None:
        self.root = root

    def document_dir(self, document_key: str) -> Path:
        digest = hashlib.sha1(document_key.encode("utf-8")).hexdigest()[:12]
        safe_prefix = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in document_key)[:80]
        path = self.root / f"{safe_prefix}-{digest}"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def exists(self, document_key: str, name: str) -> bool:
        return (self.document_dir(document_key) / name).exists()

    def load(self, document_key: str, name: str) -> dict[str, Any]:
        path = self.document_dir(document_key) / name
        return json.loads(path.read_text(encoding="utf-8"))

    def save(self, document_key: str, name: str, payload: dict[str, Any]) -> Path:
        path = self.document_dir(document_key) / name
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def save_jsonl(self, document_key: str, name: str, rows: Iterable[dict[str, Any]]) -> Path:
        path = self.document_dir(document_key) / name
        lines = [json.dumps(row, ensure_ascii=False) for row in rows]
        path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
        return path

    def append_jsonl(self, document_key: str, name: str, row: dict[str, Any]) -> Path:
        path = self.document_dir(document_key) / name
        with path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(row, ensure_ascii=False))
            file.write("\n")
        return path

    def update_checkpoint(
        self,
        document_key: str,
        *,
        step: str,
        status: str,
        details: dict[str, Any] | None = None,
    ) -> Path:
        updated_at = datetime.now(UTC).isoformat()
        event = {
            "step": step,
            "status": status,
            "updated_at": updated_at,
            "details": details or {},
        }
        path = self.document_dir(document_key) / "checkpoint.json"
        previous = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        steps = dict(previous.get("steps") or {})
        steps[step] = event
        history = [*(previous.get("history") or []), event]
        payload = {
            "document_key": document_key,
            "step": step,
            "status": status,
            "updated_at": updated_at,
            "details": details or {},
            "steps": steps,
            "history": history,
        }
        self.append_jsonl(document_key, "checkpoint_events.jsonl", {"document_key": document_key, **event})
        return self.save(document_key, "checkpoint.json", payload)
