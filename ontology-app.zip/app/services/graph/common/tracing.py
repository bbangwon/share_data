from __future__ import annotations

import time
from typing import Any


def append_trace(
    trace: list[dict[str, Any]] | None,
    *,
    node: str,
    status: str,
    started: float,
    details: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    next_trace = list(trace or [])
    next_trace.append(
        {
            "node": node,
            "status": status,
            "duration_ms": round((time.perf_counter() - started) * 1000, 2),
            "details": details or {},
        }
    )
    return next_trace
