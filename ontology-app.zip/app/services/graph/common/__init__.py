"""Shared graph utilities."""
