from __future__ import annotations

import asyncio
from collections.abc import Iterable, Sequence
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import httpx
from fastembed import SparseTextEmbedding
from kiwipiepy import Kiwi

SparseVectorDict = dict[str, list[int] | list[float]]


def build_embed_text(chunk: Any) -> str:
    parts = [
        getattr(chunk, "contextual_prefix", None),
        getattr(chunk, "metadata_prefix", None),
        getattr(chunk, "boost_keywords", None),
        getattr(chunk, "text", None),
    ]
    return "\n".join(str(part) for part in parts if part)


class GpuDenseEmbedder:
    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        timeout: float = 60,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._owns_client = client is None
        self.client = client or httpx.AsyncClient(timeout=timeout)

    async def embed(self, text: str) -> list[float]:
        return (await self.embed_many([text]))[0]

    async def embed_many(self, texts: Sequence[str]) -> list[list[float]]:
        if not texts:
            return []
        response = await self.client.post(
            f"{self.base_url}/v1/embeddings",
            json={"model": self.model, "input": list(texts)},
        )
        response.raise_for_status()
        data = response.json().get("data", [])
        if len(data) != len(texts):
            raise ValueError(
                f"embedding response count mismatch: expected {len(texts)}, got {len(data)}"
            )

        ordered: list[list[float] | None] = [None] * len(texts)
        for position, item in enumerate(data):
            try:
                index = int(item.get("index", position))
            except (AttributeError, TypeError, ValueError):
                raise ValueError(
                    f"invalid embedding response index: {item!r}"
                ) from None
            if index < 0 or index >= len(texts) or ordered[index] is not None:
                raise ValueError(f"invalid embedding response index: {index!r}")
            ordered[index] = list(item["embedding"])
        if any(vector is None for vector in ordered):
            raise ValueError("embedding response missing one or more indexes")
        return [vector for vector in ordered if vector is not None]

    async def embed_query_many(self, queries: Sequence[str]) -> list[list[float]]:
        return await self.embed_many(queries)

    async def close(self) -> None:
        if self._owns_client:
            await self.client.aclose()


class KiwiBm25SparseEmbedder:
    TOKEN_TAGS = {"NNG", "NNP", "SN", "SL"}

    def __init__(
        self,
        *,
        tokenizer: Any | None = None,
        model: Any | None = None,
        model_name: str = "Qdrant/bm25",
    ) -> None:
        self.tokenizer = tokenizer or Kiwi()
        self.model = model or SparseTextEmbedding(model_name=model_name)
        self._executor = ThreadPoolExecutor(max_workers=1)

    def tokenize(self, text: str) -> list[str]:
        tokens: list[str] = []
        for token in self.tokenizer.tokenize(text or ""):
            form = getattr(token, "form", "")
            tag = getattr(token, "tag", "")
            if not form:
                continue
            if tag in self.TOKEN_TAGS:
                tokens.append(str(form).lower() if tag == "SL" else str(form))
        return tokens

    def preprocess(self, text: str) -> str:
        return " ".join(self.tokenize(text))

    async def embed(self, text: str) -> SparseVectorDict:
        return (await self.embed_many([text]))[0]

    async def embed_many(self, texts: Sequence[str]) -> list[SparseVectorDict]:
        return await self._embed_with("embed", texts)

    async def query_embed(self, text: str) -> SparseVectorDict:
        return (await self.embed_query_many([text]))[0]

    async def embed_query_many(self, queries: Sequence[str]) -> list[SparseVectorDict]:
        return await self._embed_with("query_embed", queries)

    async def _embed_with(
        self, method_name: str, texts: Sequence[str]
    ) -> list[SparseVectorDict]:
        if not texts:
            return []
        loop = asyncio.get_running_loop()
        embeddings = await loop.run_in_executor(
            self._executor, self._embed_sync, method_name, list(texts)
        )
        return [self._to_sparse_dict(embedding) for embedding in embeddings]

    def _embed_sync(self, method_name: str, texts: list[str]) -> list[Any]:
        preprocessed = [self.preprocess(text) for text in texts]
        method = getattr(self.model, method_name)
        return list(method(preprocessed))

    async def close(self) -> None:
        self._executor.shutdown(wait=True)

    @staticmethod
    def _to_sparse_dict(embedding: Any) -> SparseVectorDict:
        if hasattr(embedding, "as_object"):
            raw = embedding.as_object()
            return {
                "indices": _as_list(raw.get("indices", []), int),
                "values": _as_list(raw.get("values", []), float),
            }
        if hasattr(embedding, "indices") and hasattr(embedding, "values"):
            return {
                "indices": _as_list(embedding.indices, int),
                "values": _as_list(embedding.values, float),
            }
        if hasattr(embedding, "as_dict"):
            raw_dict = embedding.as_dict()
            return {
                "indices": [int(index) for index in raw_dict.keys()],
                "values": [float(value) for value in raw_dict.values()],
            }
        if isinstance(embedding, dict):
            return {
                "indices": _as_list(embedding.get("indices", []), int),
                "values": _as_list(embedding.get("values", []), float),
            }
        raise TypeError(f"Unsupported sparse embedding shape: {type(embedding)!r}")


def _as_list(values: Iterable[Any], item_type: type) -> list[Any]:
    if hasattr(values, "tolist"):
        values = values.tolist()
    return [item_type(value) for value in values]
