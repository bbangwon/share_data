from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from app.services.ontology.cq import CanonicalCQ, CQSourceItem, canonicalize_cqs, parse_cq_sources
from app.services.ontology.extraction import KGExtractionResult, build_kg_extraction
from app.services.ontology.schema import OntologySchema, build_initial_schema
from app.services.schemas import ChildChunk, DocumentMeta


def build_ontology_artifacts(
    *,
    source_dir: Path,
    output_root: Path,
    version: str = "ontology-v0.1",
) -> dict[str, Any]:
    """CQ 후보 파일을 표준 CQ와 초기 온톨로지 스키마 산출물로 변환합니다."""
    if not source_dir.exists():
        raise FileNotFoundError(f"Ontology CQ source directory does not exist: {source_dir}")
    source_items = parse_cq_sources(source_dir)
    schema = build_initial_schema(version=version)
    canonical_cqs = canonicalize_cqs(source_items, schema=schema)

    cq_dir = output_root / "cq"
    schema_dir = output_root / "schema"
    report_dir = output_root / "reports"
    for directory in (cq_dir, schema_dir, report_dir):
        directory.mkdir(parents=True, exist_ok=True)

    canonical_jsonl = cq_dir / "canonical_cq.jsonl"
    canonical_json = cq_dir / "canonical_cq.json"
    reference_cq_md = cq_dir / "phase2_reference_cq.md"
    test_queries_jsonl = cq_dir / "search_answer_test_queries.jsonl"
    schema_json = schema_dir / "ontology_schema_v0.1.json"
    graph_schema_json = schema_dir / "graph_schema_v0.1.json"
    cq_schema_mapping_jsonl = schema_dir / "cq_schema_mapping.jsonl"
    schema_generation_trace_json = schema_dir / "schema_generation_trace.json"
    review_md = report_dir / "cq_review.md"

    _write_jsonl(canonical_jsonl, [item.model_dump(mode="json") for item in canonical_cqs])
    _write_json(
        canonical_json,
        {
            "version": version,
            "source_dir": _display_path(source_dir),
            "source_count": len(source_items),
            "canonical_count": len(canonical_cqs),
            "items": [item.model_dump(mode="json") for item in canonical_cqs],
        },
    )
    _write_json(schema_json, schema.model_dump(mode="json"))
    reference_cq_md.write_text(_build_reference_cq_markdown(canonical_cqs, source_dir, version), encoding="utf-8")
    _write_jsonl(test_queries_jsonl, _build_test_query_rows(canonical_cqs))
    _write_json(graph_schema_json, _build_graph_schema(schema, version))
    _write_jsonl(cq_schema_mapping_jsonl, _build_cq_schema_mapping_rows(canonical_cqs))
    _write_json(
        schema_generation_trace_json,
        _build_schema_generation_trace(
            source_items=source_items,
            canonical_cqs=canonical_cqs,
            schema=schema,
            source_dir=source_dir,
            output_root=output_root,
        ),
    )
    review_md.write_text(_build_review_markdown(canonical_cqs, schema), encoding="utf-8")

    return {
        "version": version,
        "source_dir": _display_path(source_dir),
        "output_root": _display_path(output_root),
        "source_count": len(source_items),
        "canonical_count": len(canonical_cqs),
        "schema_class_count": len(schema.classes),
        "schema_relation_count": len(schema.relations),
        "artifacts": {
            "canonical_cq_jsonl": str(canonical_jsonl),
            "canonical_cq_json": str(canonical_json),
            "phase2_reference_cq_markdown": str(reference_cq_md),
            "search_answer_test_queries_jsonl": str(test_queries_jsonl),
            "ontology_schema_json": str(schema_json),
            "graph_schema_json": str(graph_schema_json),
            "cq_schema_mapping_jsonl": str(cq_schema_mapping_jsonl),
            "schema_generation_trace_json": str(schema_generation_trace_json),
            "cq_review_markdown": str(review_md),
        },
    }


def _write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
        encoding="utf-8",
    )


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def build_kg_artifacts(
    *,
    chunks: list[ChildChunk],
    meta: DocumentMeta,
    schema: OntologySchema,
    output_root: Path,
    extraction: KGExtractionResult | None = None,
    collection_name: str = "default",
    chunking_profile: str = "default",
    graph_dataset_key: str | None = None,
) -> tuple[KGExtractionResult, dict[str, Any]]:
    """청크 기반 KG 후보를 추출하고 검토 가능한 중간 산출물을 저장합니다."""
    if extraction is None:
        extraction = build_kg_extraction(
            chunks=chunks,
            meta=meta,
            schema=schema,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
            graph_dataset_key=graph_dataset_key,
        )
    kg_dir = output_root / "kg"
    kg_dir.mkdir(parents=True, exist_ok=True)
    chunks_jsonl = kg_dir / "chunks.jsonl"
    entities_jsonl = kg_dir / "entities.jsonl"
    mentions_jsonl = kg_dir / "mentions.jsonl"
    relations_jsonl = kg_dir / "relations.jsonl"
    summary_json = kg_dir / "kg_extraction_summary.json"
    review_md = kg_dir / "kg_extraction_review.md"

    _write_jsonl(chunks_jsonl, [item.model_dump(mode="json") for item in extraction.chunks])
    _write_jsonl(entities_jsonl, [item.model_dump(mode="json") for item in extraction.entities])
    _write_jsonl(mentions_jsonl, [item.model_dump(mode="json") for item in extraction.mentions])
    _write_jsonl(relations_jsonl, [item.model_dump(mode="json") for item in extraction.relations])
    _write_json(summary_json, extraction.summary)
    review_md.write_text(_build_kg_review_markdown(extraction), encoding="utf-8")

    result = {
        **extraction.summary,
        "artifacts": {
            "kg_chunks_jsonl": str(chunks_jsonl),
            "kg_entities_jsonl": str(entities_jsonl),
            "kg_mentions_jsonl": str(mentions_jsonl),
            "kg_relations_jsonl": str(relations_jsonl),
            "kg_extraction_summary_json": str(summary_json),
            "kg_extraction_review_markdown": str(review_md),
        },
    }
    return extraction, result


def _display_path(path: Path) -> str:
    resolved = path.resolve()
    try:
        return str(resolved.relative_to(Path.cwd().resolve()))
    except ValueError:
        return str(resolved)


def _build_kg_review_markdown(extraction: KGExtractionResult) -> str:
    lines = [
        "# Phase2 KG Extraction Review",
        "",
        f"- Document key: `{extraction.document_key}`",
        f"- Graph dataset key: `{extraction.summary.get('graph_dataset_key', '-')}`",
        f"- Extraction policy: `{extraction.summary.get('extraction_policy', '-')}`",
        f"- Chunk count: `{len(extraction.chunks)}`",
        f"- Entity count: `{len(extraction.entities)}`",
        f"- Mention count: `{len(extraction.mentions)}`",
        f"- Relation count: `{len(extraction.relations)}`",
        f"- LLM chunk count: `{extraction.summary.get('llm_chunk_count', 0)}`",
        f"- LLM failed chunk count: `{extraction.summary.get('llm_failed_chunk_count', 0)}`",
        f"- Fallback chunk count: `{extraction.summary.get('fallback_chunk_count', 0)}`",
        "",
        "## Class Counts",
        "",
    ]
    for class_name, count in extraction.summary.get("class_counts", {}).items():
        lines.append(f"- `{class_name}`: {count}")
    lines.extend(["", "## Relation Counts", ""])
    for relation_name, count in extraction.summary.get("relation_counts", {}).items():
        lines.append(f"- `{relation_name}`: {count}")
    lines.extend(["", "## Sample Entities", ""])
    for entity in extraction.entities[:30]:
        lines.append(f"- `{entity.class_name}` {entity.name} ({entity.mention_count})")
    lines.extend(["", "## Sample Relations", ""])
    entity_by_id = {entity.entity_id: entity for entity in extraction.entities}
    for relation in extraction.relations[:30]:
        source = entity_by_id.get(relation.source_entity_id)
        target = entity_by_id.get(relation.target_entity_id)
        lines.append(
            f"- `{relation.relation_type}` "
            f"{source.name if source else relation.source_entity_id} -> "
            f"{target.name if target else relation.target_entity_id} "
            f"(chunk={relation.chunk_id}, pages={relation.page_numbers})"
        )
    fallback_reasons = extraction.summary.get("fallback_reasons") or {}
    if fallback_reasons:
        lines.extend(["", "## LLM Fallback Reasons", ""])
        for chunk_id, reason in list(fallback_reasons.items())[:30]:
            lines.append(f"- `{chunk_id}`: {reason}")
    lines.append("")
    return "\n".join(lines)


def _build_reference_cq_markdown(cqs: list[CanonicalCQ], source_dir: Path, version: str) -> str:
    priority_order = {"high": 0, "medium": 1, "low": 2}
    grouped: dict[str, list[CanonicalCQ]] = defaultdict(list)
    for cq in cqs:
        grouped[cq.priority].append(cq)

    lines = [
        "# Phase2 Reference CQs",
        "",
        "이 파일은 Phase2 온톨로지 스키마 설계에 참고한 canonical CQ 모음입니다.",
        "검색 및 답변 생성 테스트 쿼리로도 사용할 수 있습니다.",
        "",
        f"- Ontology version: `{version}`",
        f"- Source directory: `{_display_path(source_dir)}`",
        f"- Canonical CQ count: `{len(cqs)}`",
        "- Source files: `chatgpt_cq.md`, `claude_cq.md`, `gemini_cq.md`",
        "",
    ]
    for priority in sorted(grouped, key=lambda value: priority_order.get(value, 99)):
        lines.extend(["", f"## {priority.title()} Priority", ""])
        for cq in grouped[priority]:
            lines.append(f"### {cq.cq_id}")
            lines.append("")
            lines.append(cq.question)
            lines.append("")
            lines.append(f"- Category: {cq.category}")
            lines.append(f"- Required classes: {', '.join(cq.required_classes) or '-'}")
            lines.append(f"- Required relations: {', '.join(cq.required_relations) or '-'}")
            lines.append(f"- Expected evidence: {', '.join(cq.expected_evidence_types) or '-'}")
            lines.append(f"- Source count: {cq.source_count}")
            lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _build_test_query_rows(cqs: list[CanonicalCQ]) -> list[dict[str, Any]]:
    return [
        {
            "query_id": cq.cq_id,
            "query": cq.question,
            "priority": cq.priority,
            "category": cq.category,
            "expected_classes": cq.required_classes,
            "expected_relations": cq.required_relations,
            "expected_evidence_types": cq.expected_evidence_types,
            "recommended_endpoints": ["/search", "/answer"],
            "source_count": cq.source_count,
        }
        for cq in cqs
    ]


def _build_cq_schema_mapping_rows(cqs: list[CanonicalCQ]) -> list[dict[str, Any]]:
    return [
        {
            "cq_id": cq.cq_id,
            "question": cq.question,
            "priority": cq.priority,
            "category": cq.category,
            "required_classes": cq.required_classes,
            "required_relations": cq.required_relations,
            "expected_evidence_types": cq.expected_evidence_types,
        }
        for cq in cqs
    ]


def _build_graph_schema(schema: OntologySchema, version: str) -> dict[str, Any]:
    return {
        "version": version,
        "name": "radiation_safety_action_manual_graph_schema",
        "description": "Phase2 Neo4j graph schema materialized from Qdrant chunks and ontology extraction results.",
        "retrieval_policy": {
            "graph_traversal_enabled": "request_gated",
            "initial_retrieval": "Qdrant hybrid retrieval remains the production baseline.",
            "activation_phase": "Graph traversal runs only when search/answer requests set graph_mode=graph or graph_mode=auto activates routing.",
        },
        "node_labels": [
            {
                "label": "Chunk",
                "key": "chunk_uid",
                "description": "Qdrant retrieval unit mirrored as graph evidence with document/profile namespace.",
                "properties": [
                    "chunk_uid",
                    "chunk_id",
                    "graph_dataset_key",
                    "collection_name",
                    "chunking_profile",
                    "document_key",
                    "file",
                    "page_numbers",
                    "section_path",
                    "section_title",
                    "section_level",
                    "text",
                    "parent_id",
                    "child_idx",
                ],
            },
            {
                "label": "Entity",
                "key": "entity_id",
                "description": "Canonical entity extracted from chunk evidence.",
                "properties": ["entity_id", "name", "normalized_name", "aliases", "class_name", "confidence"],
                "secondary_labels": [item.name for item in schema.classes],
            },
            {
                "label": "OntologyClass",
                "key": "name",
                "description": "Ontology class definition.",
                "properties": ["name", "label_ko", "module", "description", "examples"],
            },
            {
                "label": "OntologyModule",
                "key": "name",
                "description": "Bounded-context ontology module.",
                "properties": ["name", "label_ko", "description", "priority"],
            },
            {
                "label": "CompetencyQuestion",
                "key": "cq_id",
                "description": "Canonical CQ used to validate ontology coverage and retrieval tests.",
                "properties": ["cq_id", "question", "priority", "category", "expected_evidence_types"],
            },
            {
                "label": "SyntheticQuery",
                "key": "query_id",
                "description": "Query-Centric GraphRAG question-answer node generated from source chunks in v0.3.",
                "properties": [
                    "query_id",
                    "graph_dataset_key",
                    "chunk_uid",
                    "question",
                    "answer",
                    "quality_score",
                ],
            },
        ],
        "relationship_types": [
            {
                "type": relation.name,
                "label_ko": relation.label_ko,
                "start_labels": relation.domain,
                "end_labels": relation.range,
                "description": relation.description,
            }
            for relation in schema.relations
        ] + [
            {
                "type": "GENERATED_FROM",
                "label_ko": "생성근거",
                "start_labels": ["SyntheticQuery"],
                "end_labels": ["Chunk"],
                "description": "Synthetic query가 어떤 source chunk에서 생성되었는지 나타냅니다.",
            },
            {
                "type": "MENTIONS_ENTITY",
                "label_ko": "질문엔티티언급",
                "start_labels": ["SyntheticQuery"],
                "end_labels": ["Entity"],
                "description": "Synthetic query가 source chunk의 엔티티와 연결됩니다.",
            },
            {
                "type": "SIMILAR_TO",
                "label_ko": "유사질문",
                "start_labels": ["SyntheticQuery"],
                "end_labels": ["SyntheticQuery"],
                "description": "Synthetic query 사이의 embedding 기반 유사 관계입니다.",
            },
        ],
        "constraints": [
            "Chunk.chunk_uid IS UNIQUE",
            "Entity.entity_id IS UNIQUE",
            "OntologyClass.name IS UNIQUE",
            "OntologyModule.name IS UNIQUE",
            "CompetencyQuestion.cq_id IS UNIQUE",
            "SyntheticQuery.query_id IS UNIQUE",
        ],
        "indexes": [
            "Chunk(graph_dataset_key, document_key, chunk_id)",
            "SyntheticQuery(graph_dataset_key, chunk_uid)",
            "Chunk(page_numbers)",
            "Entity(normalized_name)",
            "Entity(class_name)",
            "CompetencyQuestion(priority)",
            "CompetencyQuestion(category)",
        ],
        "materialization_order": [
            "OntologyModule",
            "OntologyClass",
            "Chunk",
            "CompetencyQuestion",
            "Entity",
            "domain relationships",
            "SyntheticQuery",
            "query graph relationships",
        ],
        "planned_not_materialized": [
            {
                "label": "EntityCandidate",
                "description": "LLM/raw candidate audit node. Current implementation writes candidates to JSONL artifacts instead of Neo4j.",
            },
            {
                "label": "RelationCandidate",
                "description": "LLM/raw relation candidate audit node. Current implementation writes accepted relations to Neo4j and review artifacts.",
            },
        ],
    }


def _build_schema_generation_trace(
    *,
    source_items: list[CQSourceItem],
    canonical_cqs: list[CanonicalCQ],
    schema: OntologySchema,
    source_dir: Path,
    output_root: Path,
) -> dict[str, Any]:
    class_usage = Counter(class_name for cq in canonical_cqs for class_name in cq.required_classes)
    relation_usage = Counter(relation_name for cq in canonical_cqs for relation_name in cq.required_relations)
    module_by_class = {item.name: item.module for item in schema.classes}
    module_usage: Counter[str] = Counter()
    for class_name, count in class_usage.items():
        if class_name in module_by_class:
            module_usage[module_by_class[class_name]] += count
    schema_class_names = [item.name for item in schema.classes]
    schema_relation_names = [item.name for item in schema.relations]
    return {
        "version": schema.version,
        "source_dir": _display_path(source_dir),
        "output_root": _display_path(output_root),
        "source_files": sorted({item.source_file for item in source_items}),
        "source_model_counts": dict(sorted(Counter(item.source_model for item in source_items).items())),
        "source_count": len(source_items),
        "canonical_count": len(canonical_cqs),
        "priority_counts": dict(sorted(Counter(cq.priority for cq in canonical_cqs).items())),
        "category_counts": dict(sorted(Counter(cq.category for cq in canonical_cqs).items())),
        "class_usage_counts": dict(sorted(class_usage.items())),
        "relation_usage_counts": dict(sorted(relation_usage.items())),
        "module_usage_counts": dict(sorted(module_usage.items())),
        "schema_class_count": len(schema.classes),
        "schema_relation_count": len(schema.relations),
        "schema_module_count": len(schema.modules),
        "classes_without_current_cq_usage": sorted(set(schema_class_names) - set(class_usage)),
        "relations_without_current_cq_usage": sorted(set(schema_relation_names) - set(relation_usage)),
        "generation_policy": [
            "Use CQ seeds as requirements, not as generated answers.",
            "Keep Chunk, Entity, OntologyClass, CompetencyQuestion, and OntologyModule separate.",
            "Prefer minimal bounded-context modules over a monolithic ontology.",
            "Do not enable graph traversal during Phase2.",
            "Require chunk/page evidence for future entity and relation extraction.",
        ],
    }


def _build_review_markdown(cqs: list[CanonicalCQ], schema: OntologySchema) -> str:
    priority_counts: dict[str, int] = {}
    category_counts: dict[str, int] = {}
    for cq in cqs:
        priority_counts[cq.priority] = priority_counts.get(cq.priority, 0) + 1
        category_counts[cq.category] = category_counts.get(cq.category, 0) + 1

    lines = [
        "# Phase2 Canonical CQ Review",
        "",
        f"- Ontology version: `{schema.version}`",
        f"- Canonical CQ count: `{len(cqs)}`",
        f"- Ontology class count: `{len(schema.classes)}`",
        f"- Ontology relation count: `{len(schema.relations)}`",
        "",
        "## Priority Counts",
        "",
    ]
    for priority, count in sorted(priority_counts.items()):
        lines.append(f"- `{priority}`: {count}")
    lines.extend(["", "## Category Counts", ""])
    for category, count in sorted(category_counts.items()):
        lines.append(f"- {category}: {count}")
    lines.extend(["", "## High Priority CQs", ""])
    for cq in [item for item in cqs if item.priority == "high"][:30]:
        lines.append(f"- `{cq.cq_id}` {cq.question}")
        lines.append(f"  - classes: {', '.join(cq.required_classes) or '-'}")
        lines.append(f"  - relations: {', '.join(cq.required_relations) or '-'}")
    lines.append("")
    return "\n".join(lines)
