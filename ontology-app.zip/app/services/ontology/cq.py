from __future__ import annotations

import re
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from app.services.ontology.schema import OntologySchema, build_initial_schema


class CQSourceItem(BaseModel):
    source_file: str
    source_model: str
    source_id: str | None = None
    question: str
    category: str | None = None
    required_classes: list[str] = Field(default_factory=list)
    required_relations: list[str] = Field(default_factory=list)
    raw_required_elements: str | None = None


class CanonicalCQ(BaseModel):
    cq_id: str
    question: str
    category: str
    priority: str
    source_count: int
    sources: list[dict[str, Any]]
    required_classes: list[str] = Field(default_factory=list)
    required_relations: list[str] = Field(default_factory=list)
    expected_evidence_types: list[str] = Field(default_factory=list)
    notes: str | None = None


_TABLE_ROW_RE = re.compile(r"^\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|")
_CHATGPT_CQ_RE = re.compile(r"^\|\s*(CQ-\d+)\s*\|\s*(.+?)\s*\|\s*(.*?)\s*\|")
_CLAUDE_CQ_RE = re.compile(r"^\*\*CQ-(\d+)\.\*\*\s*(.+)$")
_NUMBERED_BOLD_RE = re.compile(r"^\s*(\d+)\.\s+\*\*(.+?)\*\*\s*$")
_NUMBERED_RE = re.compile(r"^\s*(\d+)\.\s+(.+?)\s*$")
_HEADING_RE = re.compile(r"^#{2,4}\s+(.+?)\s*$")
_CODE_TERM_RE = re.compile(r"`([^`]+)`")
_MARKDOWN_BOLD_RE = re.compile(r"\*\*(.*?)\*\*")
_PUNCT_RE = re.compile(r"[\s\W_]+", re.UNICODE)

_HIGH_PRIORITY_PATTERNS = (
    "직원입니다",
    "담당자 연락처",
    "담당 임무",
    "어느 협업반",
    "어디 반",
    "소개 절차",
    "부산경찰청",
    "해군작전사령부",
    "임시긴급열차",
    "사회복지시설",
)

_CLASS_KEYWORDS: tuple[tuple[str, str], ...] = (
    ("비상", "EmergencyLevel"),
    ("위기경보", "EmergencyLevel"),
    ("단계", "EmergencyLevel"),
    ("발령", "ActivationCriteria"),
    ("기준", "ActivationCriteria"),
    ("부서", "Department"),
    ("담당관", "Department"),
    ("협업반", "CooperationTeam"),
    ("실무반", "CooperationTeam"),
    ("대책본부", "EmergencyHQ"),
    ("지휘센터", "EmergencyHQ"),
    ("기관", "ExternalAgency"),
    ("경찰", "ExternalAgency"),
    ("교육청", "ExternalAgency"),
    ("해경", "ExternalAgency"),
    ("군부대", "MilitaryUnit"),
    ("사단", "MilitaryUnit"),
    ("작전사령부", "MilitaryUnit"),
    ("해군", "MilitaryUnit"),
    ("육군", "MilitaryUnit"),
    ("공군", "MilitaryUnit"),
    ("임무", "Task"),
    ("업무", "Task"),
    ("역할", "Role"),
    ("조치", "Action"),
    ("절차", "Procedure"),
    ("주민", "ResidentGroup"),
    ("취약", "VulnerableGroup"),
    ("대피", "ProtectiveAction"),
    ("소개", "ProtectiveAction"),
    ("구호", "ReliefSupport"),
    ("PAZ", "EmergencyPlanningZone"),
    ("UPZ", "EmergencyPlanningZone"),
    ("구역", "EmergencyPlanningZone"),
    ("시설", "Facility"),
    ("구호소", "Shelter"),
    ("집결지", "AssemblyPoint"),
    ("버스", "Bus"),
    ("선박", "Vessel"),
    ("철도", "RailTransport"),
    ("열차", "RailTransport"),
    ("철도역", "Station"),
    ("역사", "Station"),
    ("월내역", "Station"),
    ("항만", "Port"),
    ("항구", "Port"),
    ("선착장", "Port"),
    ("연락처", "ContactPoint"),
    ("핫라인", "ContactPoint"),
    ("재난문자", "CommunicationChannel"),
    ("통신망", "CommunicationChannel"),
    ("시스템", "InformationSystem"),
    ("방사선", "RadiationMonitoring"),
    ("탐지", "RadiationMonitoring"),
    ("감시", "RadiationMonitoring"),
    ("오염", "ContaminatedArea"),
    ("제염", "Decontamination"),
    ("의료", "EmergencyMedicalCare"),
    ("진료", "EmergencyMedicalCare"),
)

_RELATION_KEYWORDS: tuple[tuple[str, str], ...] = (
    ("편성", "ASSIGNED_TO"),
    ("배속", "ASSIGNED_TO"),
    ("소속", "BELONGS_TO"),
    ("담당", "RESPONSIBLE_FOR"),
    ("수행", "RESPONSIBLE_FOR"),
    ("주관", "RESPONSIBLE_FOR"),
    ("지원", "SUPPORTS"),
    ("협조", "REQUIRES_COOPERATION_WITH"),
    ("발령", "ACTIVATED_AT"),
    ("단계", "ACTIVATED_AT"),
    ("적용", "APPLIES_TO"),
    ("대상", "APPLIES_TO"),
    ("위치", "LOCATED_IN"),
    ("어디", "LOCATED_IN"),
    ("수단", "USES_TRANSPORT"),
    ("이용", "USES_TRANSPORT"),
    ("연락처", "HAS_CONTACT"),
    ("보고", "REPORTS_TO"),
    ("전파", "COMMUNICATES_VIA"),
    ("통신", "COMMUNICATES_VIA"),
    ("순서", "PRECEDES"),
    ("절차", "PRECEDES"),
    ("기준", "HAS_CRITERIA"),
    ("탐지", "MONITORS"),
    ("감시", "MONITORS"),
    ("운영", "OPERATES"),
)


def parse_cq_sources(source_dir: Path) -> list[CQSourceItem]:
    """`data/ontology_cq` 마크다운 파일에서 CQ 후보를 추출합니다."""
    if not source_dir.exists():
        return []
    items: list[CQSourceItem] = []
    for path in sorted(source_dir.glob("*.md")):
        if path.name == "llm_instruction_info.md":
            continue
        items.extend(parse_cq_markdown(path))
    return items


def parse_cq_markdown(path: Path) -> list[CQSourceItem]:
    source_model = _source_model(path)
    items: list[CQSourceItem] = []
    current_category: str | None = None
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        heading_match = _HEADING_RE.match(line)
        if heading_match:
            current_category = _clean_category(heading_match.group(1))
            continue

        item = _parse_chatgpt_row(path, source_model, current_category, line)
        if item:
            items.append(item)
            continue

        item = _parse_claude_line(path, source_model, current_category, line)
        if item:
            items.append(item)
            continue

        item = _parse_numbered_line(path, source_model, current_category, line)
        if item:
            items.append(item)
    return items


def canonicalize_cqs(
    source_items: list[CQSourceItem],
    *,
    schema: OntologySchema | None = None,
    similarity_threshold: float = 0.92,
) -> list[CanonicalCQ]:
    """여러 LLM이 생성한 CQ 후보를 중복 제거하고 표준 CQ 목록으로 변환합니다."""
    schema = schema or build_initial_schema()
    class_names = {item.name for item in schema.classes}
    relation_names = {item.name for item in schema.relations}
    groups: list[list[CQSourceItem]] = []
    group_keys: list[str] = []

    for item in source_items:
        key = _normalize_question_key(item.question)
        matched_index = _find_group_index(key, group_keys, similarity_threshold=similarity_threshold)
        if matched_index is None:
            groups.append([item])
            group_keys.append(key)
        else:
            groups[matched_index].append(item)

    canonical: list[CanonicalCQ] = []
    for index, group in enumerate(groups, start=1):
        representative = _representative_question(group)
        category = _representative_category(group)
        required_classes = _dedupe(
            [
                *_collect_items(group, "required_classes"),
                *_infer_classes(representative),
            ]
        )
        required_relations = _dedupe(
            [
                *_collect_items(group, "required_relations"),
                *_infer_relations(representative),
            ]
        )
        required_classes = [name for name in required_classes if name in class_names]
        required_relations = [name for name in required_relations if name in relation_names]
        canonical.append(
            CanonicalCQ(
                cq_id=f"CQ-{index:04d}",
                question=representative,
                category=category,
                priority=_priority(representative, required_classes, required_relations),
                source_count=len(group),
                sources=[
                    {
                        "source_file": item.source_file,
                        "source_model": item.source_model,
                        "source_id": item.source_id,
                        "category": item.category,
                    }
                    for item in group
                ],
                required_classes=required_classes,
                required_relations=required_relations,
                expected_evidence_types=_expected_evidence_types(required_classes, required_relations),
            )
        )
    return canonical


def summarize_cq_sources(source_items: list[CQSourceItem], canonical: list[CanonicalCQ]) -> dict[str, Any]:
    source_counts = Counter(item.source_model for item in source_items)
    priority_counts = Counter(item.priority for item in canonical)  # type: ignore[attr-defined]
    category_counts = Counter(item.category for item in canonical)
    return {
        "source_count": len(source_items),
        "canonical_count": len(canonical),
        "source_models": dict(source_counts),
        "categories": dict(category_counts),
        "priorities": dict(priority_counts),
    }


def _parse_chatgpt_row(path: Path, source_model: str, category: str | None, line: str) -> CQSourceItem | None:
    match = _CHATGPT_CQ_RE.match(line)
    if not match:
        table_match = _TABLE_ROW_RE.match(line)
        if not table_match:
            return None
        first = table_match.group(1).strip()
        if first in {"ID", "---:"} or not first.startswith("CQ-"):
            return None
        match = table_match
    source_id = match.group(1).strip()
    question = _clean_question(match.group(2))
    raw_elements = match.group(3).strip() if len(match.groups()) >= 3 else ""
    if not _looks_like_question(question):
        return None
    return CQSourceItem(
        source_file=path.name,
        source_model=source_model,
        source_id=source_id,
        question=question,
        category=category,
        raw_required_elements=raw_elements or None,
        required_classes=_classes_from_raw_elements(raw_elements),
        required_relations=_relations_from_raw_elements(raw_elements),
    )


def _parse_claude_line(path: Path, source_model: str, category: str | None, line: str) -> CQSourceItem | None:
    match = _CLAUDE_CQ_RE.match(line)
    if not match:
        return None
    question = _clean_question(match.group(2))
    if not _looks_like_question(question):
        return None
    return CQSourceItem(
        source_file=path.name,
        source_model=source_model,
        source_id=f"CQ-{int(match.group(1)):02d}",
        question=question,
        category=category,
        required_classes=_infer_classes(question),
        required_relations=_infer_relations(question),
    )


def _parse_numbered_line(path: Path, source_model: str, category: str | None, line: str) -> CQSourceItem | None:
    match = _NUMBERED_BOLD_RE.match(line) or _NUMBERED_RE.match(line)
    if not match:
        return None
    question = _clean_question(match.group(2))
    if not _looks_like_question(question):
        return None
    return CQSourceItem(
        source_file=path.name,
        source_model=source_model,
        source_id=f"CQ-{int(match.group(1)):02d}",
        question=question,
        category=category,
        required_classes=_infer_classes(question),
        required_relations=_infer_relations(question),
    )


def _classes_from_raw_elements(text: str) -> list[str]:
    terms = _CODE_TERM_RE.findall(text)
    if terms:
        return [term for term in terms if term and term[0].isupper()]
    return _infer_classes(text)


def _relations_from_raw_elements(text: str) -> list[str]:
    terms = _CODE_TERM_RE.findall(text)
    return [term for term in terms if term.isupper()] or _infer_relations(text)


def _infer_classes(question: str) -> list[str]:
    return _dedupe([class_name for keyword, class_name in _CLASS_KEYWORDS if keyword in question])


def _infer_relations(question: str) -> list[str]:
    return _dedupe([relation_name for keyword, relation_name in _RELATION_KEYWORDS if keyword in question])


def _expected_evidence_types(classes: list[str], relations: list[str]) -> list[str]:
    evidence: list[str] = ["chunk_text", "page_numbers"]
    if {"ContactPoint", "ContactRole"} & set(classes):
        evidence.append("contact_table")
    if {"Department", "CooperationTeam", "ExternalAgency", "MilitaryUnit"} & set(classes):
        evidence.append("organization_table")
    if {"Procedure", "ProcedureStep", "PRECEDES"} & set(classes + relations):
        evidence.append("procedure_sequence")
    if {"EmergencyPlanningZone", "AdministrativeArea", "Facility", "AssemblyPoint"} & set(classes):
        evidence.append("location_metadata")
    return _dedupe(evidence)


def _priority(question: str, classes: list[str], relations: list[str]) -> str:
    if any(pattern in question for pattern in _HIGH_PRIORITY_PATTERNS):
        return "high"
    if "ContactPoint" in classes or "HAS_CONTACT" in relations:
        return "high"
    if {"Department", "CooperationTeam", "Task"} <= set(classes):
        return "high"
    if len(classes) >= 4 or len(relations) >= 3:
        return "medium"
    return "low"


def _find_group_index(key: str, group_keys: list[str], *, similarity_threshold: float) -> int | None:
    for index, group_key in enumerate(group_keys):
        if key == group_key:
            return index
        if SequenceMatcher(None, key, group_key).ratio() >= similarity_threshold:
            return index
    return None


def _representative_question(group: list[CQSourceItem]) -> str:
    ordered = sorted(group, key=lambda item: (0 if item.source_model == "chatgpt" else 1, -len(item.question)))
    return ordered[0].question


def _representative_category(group: list[CQSourceItem]) -> str:
    counts = Counter(item.category for item in group if item.category)
    if counts:
        return counts.most_common(1)[0][0] or "기타"
    question = group[0].question
    if any(keyword in question for keyword in ("부서", "협업반", "기관", "경찰청", "해군", "육군", "공군")):
        return "조직·역할"
    if any(keyword in question for keyword in ("대피", "소개", "구호소", "집결지", "PAZ", "UPZ")):
        return "주민보호"
    if any(keyword in question for keyword in ("연락처", "보고", "전파", "통신", "재난문자")):
        return "연락망·보고"
    return "기타"


def _collect_items(group: list[CQSourceItem], field_name: str) -> list[str]:
    values: list[str] = []
    for item in group:
        values.extend(getattr(item, field_name))
    return values


def _normalize_question_key(question: str) -> str:
    return _PUNCT_RE.sub("", question).lower()


def _clean_question(text: str) -> str:
    text = _MARKDOWN_BOLD_RE.sub(r"\1", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"<br\s*/?>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip(" -|")


def _clean_category(text: str) -> str:
    text = _clean_question(text)
    text = re.sub(r"^[🏛🚶💊🚧]+\s*", "", text)
    return text.strip()


def _looks_like_question(text: str) -> bool:
    if len(text) < 10:
        return False
    return text.endswith("?") or text.endswith("요?") or text.endswith("가?") or "무엇" in text or "어떻게" in text


def _source_model(path: Path) -> str:
    stem = path.stem.lower()
    for name in ("chatgpt", "claude", "gemini"):
        if name in stem:
            return name
    return stem


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result
