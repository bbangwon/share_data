from __future__ import annotations

import inspect
import re
from typing import Any

from neo4j import AsyncGraphDatabase

from app.core.config import Neo4jConfig
from app.services.kg_query_extraction import (
    normalize_query_entity_terms,
    relation_types_for_intent,
)
from app.services.ontology.cq import CanonicalCQ
from app.services.ontology.extraction import KGExtractionResult
from app.services.ontology.schema import OntologySchema


class Neo4jOntologyStore:
    def __init__(self, config: Neo4jConfig) -> None:
        if not config.uri:
            raise ValueError("neo4j.uri is required when ontology.kg_upsert_enabled=true")
        if not config.username:
            raise ValueError("neo4j.username is required when ontology.kg_upsert_enabled=true")
        if config.password is None:
            raise ValueError("neo4j.password is required when ontology.kg_upsert_enabled=true")
        self.database = config.database or "neo4j"
        self.driver = AsyncGraphDatabase.driver(
            config.uri,
            auth=(config.username, config.password.get_secret_value()),
            connection_timeout=config.connection_timeout,
            connection_write_timeout=config.connection_write_timeout,
            connection_acquisition_timeout=config.connection_acquisition_timeout,
            max_transaction_retry_time=config.max_transaction_retry_time,
            max_connection_lifetime=config.max_connection_lifetime,
            max_connection_pool_size=config.max_connection_pool_size,
            liveness_check_timeout=config.liveness_check_timeout,
            keep_alive=config.keep_alive,
            fetch_size=config.fetch_size,
        )

    async def close(self) -> None:
        result = self.driver.close()
        if inspect.isawaitable(result):
            await result

    async def verify_connectivity(self) -> None:
        await self.driver.verify_connectivity()

    async def upsert_kg(
        self,
        *,
        schema: OntologySchema,
        canonical_cqs: list[CanonicalCQ],
        extraction: KGExtractionResult,
    ) -> dict[str, Any]:
        await self.verify_connectivity()
        async with self.driver.session(database=self.database) as session:
            await self._ensure_constraints(session)
            await session.execute_write(_upsert_modules, [item.model_dump(mode="json") for item in schema.modules])
            await session.execute_write(_upsert_classes, [item.model_dump(mode="json") for item in schema.classes])
            await session.execute_write(_upsert_cqs, [item.model_dump(mode="json") for item in canonical_cqs])
            await session.execute_write(_upsert_chunks, [item.model_dump(mode="json") for item in extraction.chunks])
            await session.execute_write(_upsert_entities, [item.model_dump(mode="json") for item in extraction.entities])
            await session.execute_write(_upsert_mentions, [item.model_dump(mode="json") for item in extraction.mentions])
            await session.execute_write(_upsert_instance_of, [item.model_dump(mode="json") for item in extraction.entities])
            await session.execute_write(_upsert_domain_relations, [item.model_dump(mode="json") for item in extraction.relations])
        return {
            "database": self.database,
            "chunk_count": len(extraction.chunks),
            "entity_count": len(extraction.entities),
            "mention_count": len(extraction.mentions),
            "relation_count": len(extraction.relations),
            "cq_count": len(canonical_cqs),
            "schema_class_count": len(schema.classes),
            "schema_module_count": len(schema.modules),
        }

    async def reset_graph_scope(self, *, document_key: str, graph_dataset_key: str) -> dict[str, Any]:
        await self.verify_connectivity()
        async with self.driver.session(database=self.database) as session:
            await self._ensure_constraints(session)
            reset_result = await session.execute_write(
                _reset_graph_scope,
                document_key,
                graph_dataset_key,
            )
            orphan_candidate_entity_ids = reset_result.pop("orphan_candidate_entity_ids", [])
            orphan_result = await session.execute_write(
                _delete_orphan_entities,
                orphan_candidate_entity_ids,
            )
        return {
            "database": self.database,
            "document_key": document_key,
            "graph_dataset_key": graph_dataset_key,
            **reset_result,
            **orphan_result,
        }

    async def expand_chunks(
        self,
        *,
        query: str,
        seed_chunk_refs: list[dict[str, Any]],
        document_key: str | None,
        limit: int,
        relation_allowlist: list[str] | None = None,
        include_evidence_chains: bool = False,
        evidence_chain_limit: int = 5,
    ) -> list[dict[str, Any]]:
        if not seed_chunk_refs and not query.strip():
            return []
        terms = _query_terms(query)
        graph_dataset_keys = sorted(
            {
                str(ref.get("graph_dataset_key"))
                for ref in seed_chunk_refs
                if ref.get("graph_dataset_key")
            }
        )
        seed_chunk_uids = [
            str(ref.get("chunk_uid"))
            for ref in seed_chunk_refs
            if ref.get("chunk_uid")
        ]
        async with self.driver.session(database=self.database) as session:
            rows = await session.execute_read(
                _expand_chunks,
                seed_chunk_uids,
                graph_dataset_keys,
                terms,
                document_key,
                max(1, limit),
                relation_allowlist or [],
                include_evidence_chains,
                max(1, evidence_chain_limit),
            )
        return rows

    async def expand_query_guided_chunks(
        self,
        *,
        query: str,
        seed_chunk_refs: list[dict[str, Any]],
        document_key: str | None,
        limit: int,
        relation_allowlist: list[str] | None = None,
        query_entities: list[str] | None = None,
        query_relation_types: list[str] | None = None,
        query_constraints: dict[str, Any] | None = None,
        query_intent: str | None = None,
        include_evidence_chains: bool = False,
        evidence_chain_limit: int = 5,
    ) -> list[dict[str, Any]]:
        if not seed_chunk_refs and not (query_entities or query.strip()):
            return []
        graph_dataset_keys = sorted(
            {
                str(ref.get("graph_dataset_key"))
                for ref in seed_chunk_refs
                if ref.get("graph_dataset_key")
            }
        )
        seed_chunk_uids = [
            str(ref.get("chunk_uid"))
            for ref in seed_chunk_refs
            if ref.get("chunk_uid")
        ]
        relation_allowlist = relation_allowlist or []
        query_relation_types = _effective_query_relation_types(
            query_relation_types=query_relation_types or [],
            relation_allowlist=relation_allowlist,
        )
        query_entity_terms = normalize_query_entity_terms(query_entities or []) or _query_terms(query)
        constraint_pages = _constraint_pages(query_constraints or {})
        async with self.driver.session(database=self.database) as session:
            rows = await session.execute_read(
                _expand_query_guided_chunks,
                seed_chunk_uids,
                graph_dataset_keys,
                query_entity_terms,
                query_relation_types,
                relation_allowlist,
                relation_types_for_intent(query_intent),
                constraint_pages,
                document_key,
                max(1, limit),
                include_evidence_chains,
                max(1, evidence_chain_limit),
            )
        return rows

    async def reset_query_graph_scope(self, *, graph_dataset_key: str) -> dict[str, Any]:
        await self.verify_connectivity()
        async with self.driver.session(database=self.database) as session:
            await self._ensure_constraints(session)
            result = await session.execute_write(
                _reset_query_graph_scope,
                graph_dataset_key,
            )
        return {"database": self.database, "graph_dataset_key": graph_dataset_key, **result}

    async def upsert_query_graph(
        self,
        *,
        records: list[Any],
        edges: list[Any],
    ) -> dict[str, Any]:
        await self.verify_connectivity()
        record_rows = [_model_row(record) for record in records if getattr(record, "accepted", False)]
        edge_rows = [_model_row(edge) for edge in edges]
        async with self.driver.session(database=self.database) as session:
            await self._ensure_constraints(session)
            await session.execute_write(_upsert_synthetic_queries, record_rows)
            await session.execute_write(_upsert_query_graph_edges, edge_rows)
        return {
            "database": self.database,
            "synthetic_query_count": len(record_rows),
            "query_graph_edge_count": len(edge_rows),
        }

    async def expand_query_graph_chunks(
        self,
        *,
        query_rows: list[dict[str, Any]],
        graph_dataset_keys: list[str],
        document_key: str | None,
        neighbor_top_k: int,
        limit: int,
        include_evidence_chains: bool = False,
        evidence_chain_limit: int = 5,
    ) -> list[dict[str, Any]]:
        if not query_rows:
            return []
        async with self.driver.session(database=self.database) as session:
            rows = await session.execute_read(
                _expand_query_graph_chunks,
                query_rows,
                graph_dataset_keys,
                document_key,
                max(1, neighbor_top_k),
                max(1, limit),
                include_evidence_chains,
                max(1, evidence_chain_limit),
            )
        return rows

    async def _ensure_constraints(self, session: Any) -> None:
        for statement in _CONSTRAINTS:
            await session.run(statement)


_CONSTRAINTS = (
    "DROP CONSTRAINT chunk_id_unique IF EXISTS",
    "CREATE CONSTRAINT chunk_uid_unique IF NOT EXISTS FOR (n:Chunk) REQUIRE n.chunk_uid IS UNIQUE",
    "CREATE INDEX chunk_scope_lookup IF NOT EXISTS FOR (n:Chunk) ON (n.graph_dataset_key, n.document_key, n.chunk_id)",
    "CREATE CONSTRAINT entity_id_unique IF NOT EXISTS FOR (n:Entity) REQUIRE n.entity_id IS UNIQUE",
    "CREATE CONSTRAINT synthetic_query_id_unique IF NOT EXISTS FOR (n:SyntheticQuery) REQUIRE n.query_id IS UNIQUE",
    "CREATE INDEX synthetic_query_scope_lookup IF NOT EXISTS FOR (n:SyntheticQuery) ON (n.graph_dataset_key, n.chunk_uid)",
    "CREATE CONSTRAINT ontology_class_name_unique IF NOT EXISTS FOR (n:OntologyClass) REQUIRE n.name IS UNIQUE",
    "CREATE CONSTRAINT ontology_module_name_unique IF NOT EXISTS FOR (n:OntologyModule) REQUIRE n.name IS UNIQUE",
    "CREATE CONSTRAINT cq_id_unique IF NOT EXISTS FOR (n:CompetencyQuestion) REQUIRE n.cq_id IS UNIQUE",
)


async def _upsert_modules(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MERGE (m:OntologyModule {name: row.name})
        SET m.label_ko = row.label_ko,
            m.description = row.description,
            m.priority = row.priority,
            m.classes = row.classes
        """,
        rows=rows,
    )


async def _upsert_classes(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MERGE (c:OntologyClass {name: row.name})
        SET c.label_ko = row.label_ko,
            c.module = row.module,
            c.description = row.description,
            c.examples = row.examples
        WITH c, row
        MATCH (m:OntologyModule {name: row.module})
        MERGE (c)-[:BELONGS_TO]->(m)
        """,
        rows=rows,
    )


async def _upsert_cqs(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MERGE (cq:CompetencyQuestion {cq_id: row.cq_id})
        SET cq.question = row.question,
            cq.priority = row.priority,
            cq.category = row.category,
            cq.expected_evidence_types = row.expected_evidence_types,
            cq.required_classes = row.required_classes,
            cq.required_relations = row.required_relations,
            cq.source_count = row.source_count
        """,
        rows=rows,
    )


async def _upsert_chunks(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MERGE (chunk:Chunk {chunk_uid: row.chunk_uid})
        SET chunk.chunk_id = row.chunk_id,
            chunk.graph_dataset_key = row.graph_dataset_key,
            chunk.collection_name = row.collection_name,
            chunk.chunking_profile = row.chunking_profile,
            chunk.document_key = row.document_key,
            chunk.file = row.file,
            chunk.doc_name = row.doc_name,
            chunk.page_numbers = row.page_numbers,
            chunk.section_path = row.section_path,
            chunk.section_title = row.section_title,
            chunk.section_level = row.section_level,
            chunk.text = row.text,
            chunk.parent_text = row.parent_text,
            chunk.parent_id = row.parent_id,
            chunk.parent_idx = row.parent_idx,
            chunk.child_idx = row.child_idx
        """,
        rows=rows,
    )


async def _upsert_entities(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MERGE (entity:Entity {entity_id: row.entity_id})
        SET entity.name = row.name,
            entity.normalized_name = row.normalized_name,
            entity.class_name = row.class_name,
            entity.aliases = row.aliases,
            entity.mention_count = row.mention_count
        """,
        rows=rows,
    )
    grouped: dict[str, list[str]] = {}
    for row in rows:
        class_name = row.get("class_name")
        entity_id = row.get("entity_id")
        if class_name and entity_id and _safe_label(class_name):
            grouped.setdefault(class_name, []).append(entity_id)
    for class_name, entity_ids in grouped.items():
        await tx.run(
            f"""
            MATCH (entity:Entity)
            WHERE entity.entity_id IN $entity_ids
            SET entity:{class_name}
            """,
            entity_ids=entity_ids,
        )


async def _upsert_mentions(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MATCH (chunk:Chunk {chunk_uid: row.chunk_uid})
        MATCH (entity:Entity {entity_id: row.entity_id})
        MERGE (chunk)-[r:MENTIONS]->(entity)
        SET r.evidence_text = row.evidence_text,
            r.page_numbers = row.page_numbers
        """,
        rows=rows,
    )


async def _upsert_instance_of(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MATCH (entity:Entity {entity_id: row.entity_id})
        MATCH (class:OntologyClass {name: row.class_name})
        MERGE (entity)-[:INSTANCE_OF]->(class)
        """,
        rows=rows,
    )


async def _upsert_domain_relations(tx: Any, rows: list[dict[str, Any]]) -> None:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        relation_type = row.get("relation_type")
        if relation_type and _safe_relation_type(relation_type):
            grouped.setdefault(relation_type, []).append(row)
    for relation_type, relation_rows in grouped.items():
        await tx.run(
            f"""
            UNWIND $rows AS row
            MATCH (source:Entity {{entity_id: row.source_entity_id}})
            MATCH (target:Entity {{entity_id: row.target_entity_id}})
            MATCH (chunk:Chunk {{chunk_uid: row.chunk_uid}})
            MERGE (source)-[r:{relation_type} {{relation_id: row.relation_id}}]->(target)
            SET r.chunk_uid = row.chunk_uid,
                r.chunk_id = row.chunk_id,
                r.evidence_text = row.evidence_text,
                r.page_numbers = row.page_numbers,
                r.confidence = row.confidence
            """,
            rows=relation_rows,
        )


async def _upsert_synthetic_queries(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MATCH (chunk:Chunk {chunk_uid: row.chunk_uid})
        MERGE (query:SyntheticQuery {query_id: row.query_id})
        SET query.graph_dataset_key = row.graph_dataset_key,
            query.document_key = row.document_key,
            query.collection_name = row.collection_name,
            query.chunking_profile = row.chunking_profile,
            query.chunk_uid = row.chunk_uid,
            query.chunk_id = row.chunk_id,
            query.question = row.question,
            query.answer = row.answer,
            query.page_numbers = row.page_numbers,
            query.section_path = row.section_path,
            query.quality_score = row.quality_score
        MERGE (query)-[generated:GENERATED_FROM]->(chunk)
        SET generated.quality_score = row.quality_score
        WITH query, chunk
        OPTIONAL MATCH (chunk)-[:MENTIONS]->(entity:Entity)
        WITH query, collect(DISTINCT entity) AS entities
        FOREACH (entity IN entities | MERGE (query)-[:MENTIONS_ENTITY]->(entity))
        """,
        rows=rows,
    )


async def _upsert_query_graph_edges(tx: Any, rows: list[dict[str, Any]]) -> None:
    await tx.run(
        """
        UNWIND $rows AS row
        MATCH (source:SyntheticQuery {query_id: row.source_query_id})
        MATCH (target:SyntheticQuery {query_id: row.target_query_id})
        MERGE (source)-[rel:SIMILAR_TO {edge_id: row.edge_id}]->(target)
        SET rel.graph_dataset_key = row.graph_dataset_key,
            rel.similarity = row.similarity
        """,
        rows=rows,
    )


async def _reset_query_graph_scope(tx: Any, graph_dataset_key: str) -> dict[str, int]:
    result = await tx.run(
        """
        MATCH (query:SyntheticQuery {graph_dataset_key: $graph_dataset_key})
        WITH collect(query) AS queries
        WITH queries, size(queries) AS deleted_synthetic_query_count
        UNWIND queries AS query
        DETACH DELETE query
        RETURN deleted_synthetic_query_count
        """,
        graph_dataset_key=graph_dataset_key,
    )
    record = await result.single()
    if record is None:
        return {"deleted_synthetic_query_count": 0}
    return {"deleted_synthetic_query_count": int(record.get("deleted_synthetic_query_count") or 0)}


async def _reset_graph_scope(tx: Any, document_key: str, graph_dataset_key: str) -> dict[str, Any]:
    candidate_result = await tx.run(
        """
        MATCH (chunk:Chunk {document_key: $document_key, graph_dataset_key: $graph_dataset_key})
              -[:MENTIONS]->(entity:Entity)
        RETURN collect(DISTINCT entity.entity_id) AS entity_ids
        """,
        document_key=document_key,
        graph_dataset_key=graph_dataset_key,
    )
    candidate_record = await candidate_result.single()
    orphan_candidate_entity_ids = []
    if candidate_record is not None:
        orphan_candidate_entity_ids = [
            str(entity_id)
            for entity_id in candidate_record.get("entity_ids", [])
            if entity_id
        ]

    result = await tx.run(
        """
        MATCH (chunk:Chunk {document_key: $document_key, graph_dataset_key: $graph_dataset_key})
        WITH collect(chunk) AS chunks
        WITH chunks, [chunk IN chunks | chunk.chunk_uid] AS chunk_uids
        CALL {
            WITH chunk_uids
            MATCH (:Entity)-[rel]->(:Entity)
            WHERE rel.chunk_uid IN chunk_uids
            WITH collect(rel) AS relations
            FOREACH (rel IN relations | DELETE rel)
            RETURN size(relations) AS deleted_domain_relation_count
        }
        WITH chunks, deleted_domain_relation_count, size(chunks) AS deleted_chunk_count
        UNWIND chunks AS chunk
        DETACH DELETE chunk
        RETURN deleted_chunk_count, deleted_domain_relation_count
        """,
        document_key=document_key,
        graph_dataset_key=graph_dataset_key,
    )
    record = await result.single()
    if record is None:
        return {
            "deleted_chunk_count": 0,
            "deleted_domain_relation_count": 0,
            "orphan_candidate_entity_count": len(orphan_candidate_entity_ids),
            "orphan_candidate_entity_ids": orphan_candidate_entity_ids,
        }
    return {
        "deleted_chunk_count": int(record.get("deleted_chunk_count") or 0),
        "deleted_domain_relation_count": int(record.get("deleted_domain_relation_count") or 0),
        "orphan_candidate_entity_count": len(orphan_candidate_entity_ids),
        "orphan_candidate_entity_ids": orphan_candidate_entity_ids,
    }


async def _delete_orphan_entities(tx: Any, candidate_entity_ids: list[str]) -> dict[str, int]:
    if not candidate_entity_ids:
        return {"deleted_orphan_entity_count": 0}
    result = await tx.run(
        """
        MATCH (entity:Entity)
        WHERE entity.entity_id IN $candidate_entity_ids
          AND NOT EXISTS {
            MATCH (:Chunk)-[:MENTIONS]->(entity)
        }
        WITH collect(entity) AS entities
        FOREACH (entity IN entities | DETACH DELETE entity)
        RETURN size(entities) AS deleted_orphan_entity_count
        """,
        candidate_entity_ids=candidate_entity_ids,
    )
    record = await result.single()
    if record is None:
        return {"deleted_orphan_entity_count": 0}
    return {"deleted_orphan_entity_count": int(record.get("deleted_orphan_entity_count") or 0)}


async def _expand_chunks(
    tx: Any,
    seed_chunk_uids: list[str],
    graph_dataset_keys: list[str],
    terms: list[str],
    document_key: str | None,
    limit: int,
    relation_allowlist: list[str] | None = None,
    include_evidence_chains: bool = False,
    evidence_chain_limit: int = 5,
) -> list[dict[str, Any]]:
    relation_allowlist = relation_allowlist or []
    shared_result = await tx.run(
        """
        MATCH (seed:Chunk)-[:MENTIONS]->(entity:Entity)<-[:MENTIONS]-(chunk:Chunk)
        WHERE seed.chunk_uid IN $seed_chunk_uids
          AND (size($graph_dataset_keys) = 0 OR chunk.graph_dataset_key IN $graph_dataset_keys)
          AND ($document_key IS NULL OR chunk.document_key = $document_key)
        WITH chunk,
             collect(DISTINCT entity.name) AS entities,
             count(DISTINCT entity) AS entity_count,
             collect(DISTINCT {
                 chain_type: 'shared_entity',
                 source_chunk_uid: seed.chunk_uid,
                 source_chunk_id: seed.chunk_id,
                 target_chunk_uid: chunk.chunk_uid,
                 target_chunk_id: chunk.chunk_id,
                 entities: [entity.name],
                 relations: [
                     {type: 'MENTIONS', source: seed.chunk_id, target: entity.name, evidence_text: null, page_numbers: seed.page_numbers},
                     {type: 'MENTIONS', source: chunk.chunk_id, target: entity.name, evidence_text: null, page_numbers: chunk.page_numbers}
                 ],
                 path_text: seed.chunk_id + ' -[MENTIONS]- ' + entity.name + ' -[MENTIONS]- ' + chunk.chunk_id,
                 score: 0.70
             })[..$evidence_chain_limit] AS evidence_chains
        RETURN chunk {
            .chunk_uid,
            .chunk_id,
            .graph_dataset_key,
            .collection_name,
            .chunking_profile,
            .document_key,
            .file,
            .doc_name,
            .page_numbers,
            .section_path,
            .section_title,
            .section_level,
            .text,
            .parent_text,
            .parent_id,
            .parent_idx,
            .child_idx
        } AS payload,
        entities AS graph_entities,
        ['shared_entity'] AS graph_reasons,
        [] AS graph_paths,
        CASE WHEN $include_evidence_chains THEN evidence_chains ELSE [] END AS evidence_chains,
        0.70 + (0.03 * entity_count) AS graph_score
        ORDER BY graph_score DESC, size(entities) DESC
        LIMIT $limit
        """,
        seed_chunk_uids=seed_chunk_uids,
        graph_dataset_keys=graph_dataset_keys,
        document_key=document_key,
        limit=limit,
        include_evidence_chains=include_evidence_chains,
        evidence_chain_limit=evidence_chain_limit,
    )
    rows = await _records_to_dicts(shared_result)

    relation_result = await tx.run(
        """
        MATCH (seed:Chunk)-[:MENTIONS]->(entity:Entity)-[rel]-(related:Entity)<-[:MENTIONS]-(chunk:Chunk)
        WHERE seed.chunk_uid IN $seed_chunk_uids
          AND (size($graph_dataset_keys) = 0 OR chunk.graph_dataset_key IN $graph_dataset_keys)
          AND ($document_key IS NULL OR chunk.document_key = $document_key)
          AND (size($relation_allowlist) = 0 OR type(rel) IN $relation_allowlist)
        WITH chunk,
             collect(DISTINCT entity.name) + collect(DISTINCT related.name) AS all_entities,
             collect(DISTINCT entity.name + ' -[' + type(rel) + ']- ' + related.name) AS paths,
             count(DISTINCT rel) AS relation_count,
             collect(DISTINCT type(rel)) AS relation_types,
             collect(DISTINCT {
                 chain_type: 'entity_relation',
                 source_chunk_uid: seed.chunk_uid,
                 source_chunk_id: seed.chunk_id,
                 target_chunk_uid: chunk.chunk_uid,
                 target_chunk_id: chunk.chunk_id,
                 entities: [entity.name, related.name],
                 relations: [
                     {type: type(rel), source: entity.name, target: related.name, evidence_text: rel.evidence_text, page_numbers: rel.page_numbers}
                 ],
                 path_text: seed.chunk_id + ' -[MENTIONS]- ' + entity.name + ' -[' + type(rel) + ']- ' + related.name + ' -[MENTIONS]- ' + chunk.chunk_id,
                 score: 0.74
             })[..$evidence_chain_limit] AS evidence_chains
        WITH chunk, [entity IN all_entities WHERE entity IS NOT NULL] AS entities, paths, relation_count, relation_types, evidence_chains
        RETURN chunk {
            .chunk_uid,
            .chunk_id,
            .graph_dataset_key,
            .collection_name,
            .chunking_profile,
            .document_key,
            .file,
            .doc_name,
            .page_numbers,
            .section_path,
            .section_title,
            .section_level,
            .text,
            .parent_text,
            .parent_id,
            .parent_idx,
            .child_idx
        } AS payload,
        entities AS graph_entities,
        ['entity_relation'] AS graph_reasons,
        paths AS graph_paths,
        relation_types AS relation_types_used,
        CASE WHEN $include_evidence_chains THEN evidence_chains ELSE [] END AS evidence_chains,
        0.74 + (0.04 * relation_count) AS graph_score
        ORDER BY graph_score DESC, size(paths) DESC
        LIMIT $limit
        """,
        seed_chunk_uids=seed_chunk_uids,
        graph_dataset_keys=graph_dataset_keys,
        document_key=document_key,
        limit=limit,
        relation_allowlist=relation_allowlist,
        include_evidence_chains=include_evidence_chains,
        evidence_chain_limit=evidence_chain_limit,
    )
    rows.extend(await _records_to_dicts(relation_result))

    term_result = await tx.run(
        """
        MATCH (entity:Entity)<-[:MENTIONS]-(chunk:Chunk)
        WHERE size($terms) > 0
          AND (size($graph_dataset_keys) = 0 OR chunk.graph_dataset_key IN $graph_dataset_keys)
          AND ($document_key IS NULL OR chunk.document_key = $document_key)
          AND any(term IN $terms WHERE toLower(entity.name) CONTAINS term OR entity.normalized_name CONTAINS term)
        WITH chunk, collect(DISTINCT entity.name) AS entities, count(DISTINCT entity) AS entity_count
        RETURN chunk {
            .chunk_uid,
            .chunk_id,
            .graph_dataset_key,
            .collection_name,
            .chunking_profile,
            .document_key,
            .file,
            .doc_name,
            .page_numbers,
            .section_path,
            .section_title,
            .section_level,
            .text,
            .parent_text,
            .parent_id,
            .parent_idx,
            .child_idx
        } AS payload,
        entities AS graph_entities,
        ['query_entity'] AS graph_reasons,
        [] AS graph_paths,
        [] AS evidence_chains,
        0.78 + (0.04 * entity_count) AS graph_score
        ORDER BY graph_score DESC, size(entities) DESC
        LIMIT $limit
        """,
        terms=terms,
        graph_dataset_keys=graph_dataset_keys,
        document_key=document_key,
        limit=limit,
    )
    rows.extend(await _records_to_dicts(term_result))
    term_relation_result = await tx.run(
        """
        MATCH (entity:Entity)-[rel]-(related:Entity)<-[:MENTIONS]-(chunk:Chunk)
        WHERE size($terms) > 0
          AND (size($graph_dataset_keys) = 0 OR chunk.graph_dataset_key IN $graph_dataset_keys)
          AND ($document_key IS NULL OR chunk.document_key = $document_key)
          AND (size($relation_allowlist) = 0 OR type(rel) IN $relation_allowlist)
          AND any(term IN $terms WHERE toLower(entity.name) CONTAINS term OR entity.normalized_name CONTAINS term)
        WITH chunk,
             collect(DISTINCT entity.name) + collect(DISTINCT related.name) AS all_entities,
             collect(DISTINCT entity.name + ' -[' + type(rel) + ']- ' + related.name) AS paths,
             count(DISTINCT rel) AS relation_count,
             collect(DISTINCT type(rel)) AS relation_types,
             collect(DISTINCT {
                 chain_type: 'query_entity_relation',
                 source_chunk_uid: null,
                 source_chunk_id: null,
                 target_chunk_uid: chunk.chunk_uid,
                 target_chunk_id: chunk.chunk_id,
                 entities: [entity.name, related.name],
                 relations: [
                     {type: type(rel), source: entity.name, target: related.name, evidence_text: rel.evidence_text, page_numbers: rel.page_numbers}
                 ],
                 path_text: entity.name + ' -[' + type(rel) + ']- ' + related.name + ' -[MENTIONS]- ' + chunk.chunk_id,
                 score: 0.76
             })[..$evidence_chain_limit] AS evidence_chains
        WITH chunk, [entity IN all_entities WHERE entity IS NOT NULL] AS entities, paths, relation_count, relation_types, evidence_chains
        RETURN chunk {
            .chunk_uid,
            .chunk_id,
            .graph_dataset_key,
            .collection_name,
            .chunking_profile,
            .document_key,
            .file,
            .doc_name,
            .page_numbers,
            .section_path,
            .section_title,
            .section_level,
            .text,
            .parent_text,
            .parent_id,
            .parent_idx,
            .child_idx
        } AS payload,
        entities AS graph_entities,
        ['query_entity_relation'] AS graph_reasons,
        paths AS graph_paths,
        relation_types AS relation_types_used,
        CASE WHEN $include_evidence_chains THEN evidence_chains ELSE [] END AS evidence_chains,
        0.76 + (0.04 * relation_count) AS graph_score
        ORDER BY graph_score DESC, size(paths) DESC
        LIMIT $limit
        """,
        terms=terms,
        graph_dataset_keys=graph_dataset_keys,
        document_key=document_key,
        limit=limit,
        relation_allowlist=relation_allowlist,
        include_evidence_chains=include_evidence_chains,
        evidence_chain_limit=evidence_chain_limit,
    )
    rows.extend(await _records_to_dicts(term_relation_result))
    return _merge_graph_rows(rows, limit=limit)


async def _expand_query_guided_chunks(
    tx: Any,
    seed_chunk_uids: list[str],
    graph_dataset_keys: list[str],
    query_entity_terms: list[str],
    query_relation_types: list[str],
    relation_allowlist: list[str],
    intent_relation_types: list[str],
    constraint_pages: list[int],
    document_key: str | None,
    limit: int,
    include_evidence_chains: bool = False,
    evidence_chain_limit: int = 5,
) -> list[dict[str, Any]]:
    relation_result = await tx.run(
        """
        MATCH (entity:Entity)-[rel]-(related:Entity)<-[:MENTIONS]-(chunk:Chunk)
        WHERE size($query_entity_terms) > 0
          AND (size($graph_dataset_keys) = 0 OR chunk.graph_dataset_key IN $graph_dataset_keys)
          AND ($document_key IS NULL OR chunk.document_key = $document_key)
          AND (size($constraint_pages) = 0 OR any(page IN chunk.page_numbers WHERE page IN $constraint_pages))
          AND (size($query_relation_types) = 0 OR type(rel) IN $query_relation_types)
          AND (size($relation_allowlist) = 0 OR type(rel) IN $relation_allowlist)
          AND any(term IN $query_entity_terms WHERE
              toLower(entity.name) CONTAINS term
              OR toLower(coalesce(entity.normalized_name, '')) CONTAINS term
              OR any(alias IN coalesce(entity.aliases, []) WHERE toLower(alias) CONTAINS term)
              OR toLower(related.name) CONTAINS term
              OR toLower(coalesce(related.normalized_name, '')) CONTAINS term
              OR any(alias IN coalesce(related.aliases, []) WHERE toLower(alias) CONTAINS term)
          )
        OPTIONAL MATCH (seed:Chunk)-[:MENTIONS]->(seedEntity:Entity)
        WHERE seed.chunk_uid IN $seed_chunk_uids
          AND seedEntity.entity_id IN [entity.entity_id, related.entity_id]
        WITH chunk, entity, related, rel,
             collect(DISTINCT seed)[0] AS seed,
             count(DISTINCT seed) AS seed_path_count
        WITH chunk,
             collect(DISTINCT entity.name) + collect(DISTINCT related.name) AS all_entities,
             collect(DISTINCT entity.name + ' -[' + type(rel) + ']- ' + related.name) AS paths,
             count(DISTINCT rel) AS relation_count,
             collect(DISTINCT type(rel)) AS relation_types,
             sum(seed_path_count) AS seed_path_count,
             sum(CASE WHEN type(rel) IN $intent_relation_types THEN 1 ELSE 0 END) AS intent_match_count,
             collect(DISTINCT {
                 chain_type: 'query_guided_entity_relation',
                 source_chunk_uid: CASE WHEN seed IS NULL THEN null ELSE seed.chunk_uid END,
                 source_chunk_id: CASE WHEN seed IS NULL THEN null ELSE seed.chunk_id END,
                 target_chunk_uid: chunk.chunk_uid,
                 target_chunk_id: chunk.chunk_id,
                 entities: [entity.name, related.name],
                 relations: [
                     {type: type(rel), source: entity.name, target: related.name, evidence_text: rel.evidence_text, page_numbers: rel.page_numbers}
                 ],
                 path_text: CASE
                     WHEN seed IS NULL THEN entity.name + ' -[' + type(rel) + ']- ' + related.name + ' -[MENTIONS]- ' + chunk.chunk_id
                     ELSE seed.chunk_id + ' -[MENTIONS]- ' + entity.name + ' -[' + type(rel) + ']- ' + related.name + ' -[MENTIONS]- ' + chunk.chunk_id
                 END,
                 score: 0.82
             })[..$evidence_chain_limit] AS evidence_chains
        WITH chunk, [entity IN all_entities WHERE entity IS NOT NULL] AS entities, paths,
             relation_count, relation_types, seed_path_count, intent_match_count, evidence_chains
        RETURN chunk {
            .chunk_uid,
            .chunk_id,
            .graph_dataset_key,
            .collection_name,
            .chunking_profile,
            .document_key,
            .file,
            .doc_name,
            .page_numbers,
            .section_path,
            .section_title,
            .section_level,
            .text,
            .parent_text,
            .parent_id,
            .parent_idx,
            .child_idx
        } AS payload,
        entities AS graph_entities,
        ['query_guided_entity_relation'] AS graph_reasons,
        paths AS graph_paths,
        relation_types AS relation_types_used,
        CASE WHEN $include_evidence_chains THEN evidence_chains ELSE [] END AS evidence_chains,
        0.82 + (0.06 * relation_count) + (0.04 * seed_path_count) + (0.04 * intent_match_count) AS graph_score
        ORDER BY graph_score DESC, size(paths) DESC
        LIMIT $limit
        """,
        seed_chunk_uids=seed_chunk_uids,
        graph_dataset_keys=graph_dataset_keys,
        query_entity_terms=query_entity_terms,
        query_relation_types=query_relation_types,
        relation_allowlist=relation_allowlist,
        intent_relation_types=intent_relation_types,
        constraint_pages=constraint_pages,
        document_key=document_key,
        limit=limit,
        include_evidence_chains=include_evidence_chains,
        evidence_chain_limit=evidence_chain_limit,
    )
    rows = await _records_to_dicts(relation_result)

    entity_result = await tx.run(
        """
        MATCH (entity:Entity)<-[:MENTIONS]-(chunk:Chunk)
        WHERE size($query_entity_terms) > 0
          AND (size($graph_dataset_keys) = 0 OR chunk.graph_dataset_key IN $graph_dataset_keys)
          AND ($document_key IS NULL OR chunk.document_key = $document_key)
          AND (size($constraint_pages) = 0 OR any(page IN chunk.page_numbers WHERE page IN $constraint_pages))
          AND any(term IN $query_entity_terms WHERE
              toLower(entity.name) CONTAINS term
              OR toLower(coalesce(entity.normalized_name, '')) CONTAINS term
              OR any(alias IN coalesce(entity.aliases, []) WHERE toLower(alias) CONTAINS term)
          )
        OPTIONAL MATCH (seed:Chunk)-[:MENTIONS]->(entity)
        WHERE seed.chunk_uid IN $seed_chunk_uids
        WITH chunk,
             collect(DISTINCT entity.name) AS entities,
             count(DISTINCT entity) AS entity_count,
             count(DISTINCT seed) AS seed_path_count,
             collect(DISTINCT {
                 chain_type: 'query_guided_entity',
                 source_chunk_uid: CASE WHEN seed IS NULL THEN null ELSE seed.chunk_uid END,
                 source_chunk_id: CASE WHEN seed IS NULL THEN null ELSE seed.chunk_id END,
                 target_chunk_uid: chunk.chunk_uid,
                 target_chunk_id: chunk.chunk_id,
                 entities: [entity.name],
                 relations: [
                     {type: 'MENTIONS', source: chunk.chunk_id, target: entity.name, evidence_text: null, page_numbers: chunk.page_numbers}
                 ],
                 path_text: CASE
                     WHEN seed IS NULL THEN entity.name + ' -[MENTIONS]- ' + chunk.chunk_id
                     ELSE seed.chunk_id + ' -[MENTIONS]- ' + entity.name + ' -[MENTIONS]- ' + chunk.chunk_id
                 END,
                 score: 0.72
             })[..$evidence_chain_limit] AS evidence_chains
        RETURN chunk {
            .chunk_uid,
            .chunk_id,
            .graph_dataset_key,
            .collection_name,
            .chunking_profile,
            .document_key,
            .file,
            .doc_name,
            .page_numbers,
            .section_path,
            .section_title,
            .section_level,
            .text,
            .parent_text,
            .parent_id,
            .parent_idx,
            .child_idx
        } AS payload,
        entities AS graph_entities,
        ['query_guided_entity'] AS graph_reasons,
        [] AS graph_paths,
        [] AS relation_types_used,
        CASE WHEN $include_evidence_chains THEN evidence_chains ELSE [] END AS evidence_chains,
        0.72 + (0.05 * entity_count) + (0.03 * seed_path_count) AS graph_score
        ORDER BY graph_score DESC, size(entities) DESC
        LIMIT $limit
        """,
        seed_chunk_uids=seed_chunk_uids,
        graph_dataset_keys=graph_dataset_keys,
        query_entity_terms=query_entity_terms,
        constraint_pages=constraint_pages,
        document_key=document_key,
        limit=limit,
        include_evidence_chains=include_evidence_chains,
        evidence_chain_limit=evidence_chain_limit,
    )
    rows.extend(await _records_to_dicts(entity_result))
    return _merge_graph_rows(rows, limit=limit)


async def _expand_query_graph_chunks(
    tx: Any,
    query_rows: list[dict[str, Any]],
    graph_dataset_keys: list[str],
    document_key: str | None,
    neighbor_top_k: int,
    limit: int,
    include_evidence_chains: bool = False,
    evidence_chain_limit: int = 5,
) -> list[dict[str, Any]]:
    direct_result = await tx.run(
        """
        UNWIND $query_rows AS row
        MATCH (query:SyntheticQuery {query_id: row.query_id})-[:GENERATED_FROM]->(chunk:Chunk)
        WHERE (size($graph_dataset_keys) = 0 OR chunk.graph_dataset_key IN $graph_dataset_keys)
          AND ($document_key IS NULL OR chunk.document_key = $document_key)
        RETURN chunk {
            .chunk_uid,
            .chunk_id,
            .graph_dataset_key,
            .collection_name,
            .chunking_profile,
            .document_key,
            .file,
            .doc_name,
            .page_numbers,
            .section_path,
            .section_title,
            .section_level,
            .text,
            .parent_text,
            .parent_id,
            .parent_idx,
            .child_idx
        } AS payload,
        [query.question] AS synthetic_queries,
        ['synthetic_query'] AS graph_reasons,
        [query.question + ' -> ' + chunk.chunk_id] AS query_graph_paths,
        CASE WHEN $include_evidence_chains THEN [{
            chain_type: 'synthetic_query',
            source_chunk_uid: null,
            source_chunk_id: null,
            target_chunk_uid: chunk.chunk_uid,
            target_chunk_id: chunk.chunk_id,
            synthetic_queries: [query.question],
            entities: [],
            relations: [{type: 'GENERATED_FROM', source: query.query_id, target: chunk.chunk_id, evidence_text: query.answer, page_numbers: query.page_numbers}],
            path_text: query.question + ' -> ' + chunk.chunk_id,
            score: row.score
        }] ELSE [] END AS evidence_chains,
        row.score AS query_graph_score,
        row.score AS graph_score
        ORDER BY graph_score DESC
        LIMIT $limit
        """,
        query_rows=query_rows,
        graph_dataset_keys=graph_dataset_keys,
        document_key=document_key,
        limit=limit,
        include_evidence_chains=include_evidence_chains,
    )
    rows = await _records_to_dicts(direct_result)

    neighbor_result = await tx.run(
        """
        UNWIND $query_rows AS row
        MATCH (query:SyntheticQuery {query_id: row.query_id})-[similar:SIMILAR_TO]-(neighbor:SyntheticQuery)
        WHERE (size($graph_dataset_keys) = 0 OR neighbor.graph_dataset_key IN $graph_dataset_keys)
        WITH row, query, similar, neighbor
        ORDER BY row.query_id, similar.similarity DESC
        WITH row, query, collect({node: neighbor, similarity: similar.similarity})[..$neighbor_top_k] AS neighbors
        UNWIND neighbors AS item
        WITH row, query, item.node AS neighbor, item.similarity AS similarity
        MATCH (neighbor)-[:GENERATED_FROM]->(chunk:Chunk)
        WHERE (size($graph_dataset_keys) = 0 OR chunk.graph_dataset_key IN $graph_dataset_keys)
          AND ($document_key IS NULL OR chunk.document_key = $document_key)
        WITH row, query, neighbor, similarity, chunk,
             (coalesce(row.score, 0.0) * 0.75 + coalesce(similarity, 0.0) * 0.25) AS graph_score
        RETURN chunk {
            .chunk_uid,
            .chunk_id,
            .graph_dataset_key,
            .collection_name,
            .chunking_profile,
            .document_key,
            .file,
            .doc_name,
            .page_numbers,
            .section_path,
            .section_title,
            .section_level,
            .text,
            .parent_text,
            .parent_id,
            .parent_idx,
            .child_idx
        } AS payload,
        [query.question, neighbor.question] AS synthetic_queries,
        ['query_graph_neighbor'] AS graph_reasons,
        [query.question + ' -[SIMILAR_TO ' + toString(round(similarity * 1000) / 1000.0) + ']- ' + neighbor.question + ' -> ' + chunk.chunk_id] AS query_graph_paths,
        CASE WHEN $include_evidence_chains THEN [{
            chain_type: 'query_graph_neighbor',
            source_chunk_uid: null,
            source_chunk_id: null,
            target_chunk_uid: chunk.chunk_uid,
            target_chunk_id: chunk.chunk_id,
            synthetic_queries: [query.question, neighbor.question],
            entities: [],
            relations: [
                {type: 'SIMILAR_TO', source: query.query_id, target: neighbor.query_id, evidence_text: null, page_numbers: []},
                {type: 'GENERATED_FROM', source: neighbor.query_id, target: chunk.chunk_id, evidence_text: neighbor.answer, page_numbers: neighbor.page_numbers}
            ],
            path_text: query.question + ' -[SIMILAR_TO ' + toString(round(similarity * 1000) / 1000.0) + ']- ' + neighbor.question + ' -> ' + chunk.chunk_id,
            score: graph_score
        }] ELSE [] END AS evidence_chains,
        graph_score AS query_graph_score,
        graph_score AS graph_score
        ORDER BY graph_score DESC
        LIMIT $limit
        """,
        query_rows=query_rows,
        graph_dataset_keys=graph_dataset_keys,
        document_key=document_key,
        neighbor_top_k=neighbor_top_k,
        limit=limit,
        include_evidence_chains=include_evidence_chains,
    )
    rows.extend(await _records_to_dicts(neighbor_result))
    return _merge_query_graph_rows(rows, limit=limit)


async def _records_to_dicts(result: Any) -> list[dict[str, Any]]:
    return [dict(record) async for record in result]


def _merge_graph_rows(rows: list[dict[str, Any]], *, limit: int) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for row in rows:
        payload = row.get("payload") or {}
        chunk_key = payload.get("chunk_uid") or payload.get("chunk_id")
        if not chunk_key:
            continue
        previous = merged.get(chunk_key)
        if previous is None:
            merged[chunk_key] = row
            continue
        previous["graph_score"] = max(float(previous.get("graph_score") or 0), float(row.get("graph_score") or 0))
        previous["graph_entities"] = sorted({*(previous.get("graph_entities") or []), *(row.get("graph_entities") or [])})
        previous["graph_reasons"] = sorted({*(previous.get("graph_reasons") or []), *(row.get("graph_reasons") or [])})
        previous["graph_paths"] = sorted({*(previous.get("graph_paths") or []), *(row.get("graph_paths") or [])})
        previous["relation_types_used"] = sorted({*(previous.get("relation_types_used") or []), *(row.get("relation_types_used") or [])})
        previous["evidence_chains"] = _dedupe_evidence_chains([*(previous.get("evidence_chains") or []), *(row.get("evidence_chains") or [])])
    return sorted(
        merged.values(),
        key=lambda item: (float(item.get("graph_score") or 0), len(item.get("graph_entities") or [])),
        reverse=True,
    )[:limit]


def _merge_query_graph_rows(rows: list[dict[str, Any]], *, limit: int) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for row in rows:
        payload = row.get("payload") or {}
        chunk_key = payload.get("chunk_uid") or payload.get("chunk_id")
        if not chunk_key:
            continue
        previous = merged.get(chunk_key)
        if previous is None:
            merged[chunk_key] = row
            continue
        previous["graph_score"] = max(float(previous.get("graph_score") or 0), float(row.get("graph_score") or 0))
        previous["query_graph_score"] = max(float(previous.get("query_graph_score") or 0), float(row.get("query_graph_score") or 0))
        previous["synthetic_queries"] = sorted({*(previous.get("synthetic_queries") or []), *(row.get("synthetic_queries") or [])})
        previous["graph_reasons"] = sorted({*(previous.get("graph_reasons") or []), *(row.get("graph_reasons") or [])})
        previous["query_graph_paths"] = sorted({*(previous.get("query_graph_paths") or []), *(row.get("query_graph_paths") or [])})
        previous["evidence_chains"] = _dedupe_evidence_chains([*(previous.get("evidence_chains") or []), *(row.get("evidence_chains") or [])])
    return sorted(
        merged.values(),
        key=lambda item: float(item.get("graph_score") or item.get("query_graph_score") or 0),
        reverse=True,
    )[:limit]


def _query_terms(query: str) -> list[str]:
    terms: list[str] = []
    for term in re.findall(r"[가-힣A-Za-z0-9]{2,}", query.lower()):
        normalized = re.sub(r"[\s\W_]+", "", term)
        if len(normalized) >= 2 and normalized not in terms:
            terms.append(normalized)
    return terms[:12]


def _effective_query_relation_types(
    *,
    query_relation_types: list[str],
    relation_allowlist: list[str],
) -> list[str]:
    relation_allowlist = relation_allowlist or []
    query_relation_types = [str(item).upper() for item in query_relation_types or []]
    if relation_allowlist:
        return [
            item
            for item in query_relation_types
            if item in relation_allowlist
        ] or list(relation_allowlist)
    return query_relation_types


def _constraint_pages(constraints: dict[str, Any]) -> list[int]:
    raw_pages = constraints.get("pages") if isinstance(constraints, dict) else None
    if raw_pages is None:
        return []
    if not isinstance(raw_pages, list):
        raw_pages = [raw_pages]
    pages: list[int] = []
    for page in raw_pages:
        try:
            value = int(page)
        except (TypeError, ValueError):
            continue
        if value > 0 and value not in pages:
            pages.append(value)
    return pages


def _dedupe_evidence_chains(chains: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for chain in chains:
        if not isinstance(chain, dict):
            continue
        key = str(
            chain.get("path_text")
            or (
                chain.get("chain_type"),
                chain.get("source_chunk_id"),
                chain.get("target_chunk_id"),
                chain.get("synthetic_queries"),
            )
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(chain)
    return result


def _safe_relation_type(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Z][A-Z0-9_]*", value or ""))


def _safe_label(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Z][A-Za-z0-9_]*", value or ""))


def _model_row(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json", exclude={"dense_vector", "sparse_vector"})
    if isinstance(value, dict):
        return dict(value)
    raise TypeError(f"Unsupported Neo4j row value: {type(value)!r}")
