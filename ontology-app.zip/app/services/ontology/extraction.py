from __future__ import annotations

import re
import uuid
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, Field

from app.services.chunk_identity import build_chunk_uid, build_graph_dataset_key
from app.services.ontology.schema import OntologySchema
from app.services.schemas import ChildChunk, DocumentMeta


class ChunkNode(BaseModel):
    chunk_uid: str
    chunk_id: str
    graph_dataset_key: str
    collection_name: str
    chunking_profile: str
    document_key: str
    file: str
    doc_name: str | None = None
    page_numbers: list[int] = Field(default_factory=list)
    section_path: str | None = None
    section_title: str | None = None
    section_level: int | None = None
    text: str
    parent_text: str
    parent_id: str
    parent_idx: int
    child_idx: int


class EntityNode(BaseModel):
    entity_id: str
    name: str
    normalized_name: str
    class_name: str
    aliases: list[str] = Field(default_factory=list)
    mention_count: int = 0


class MentionEdge(BaseModel):
    chunk_uid: str
    chunk_id: str
    entity_id: str
    evidence_text: str
    page_numbers: list[int] = Field(default_factory=list)


class DomainRelation(BaseModel):
    relation_id: str
    relation_type: str
    source_entity_id: str
    target_entity_id: str
    chunk_uid: str
    chunk_id: str
    evidence_text: str
    page_numbers: list[int] = Field(default_factory=list)
    confidence: float = 0.5


class KGExtractionResult(BaseModel):
    document_key: str
    chunks: list[ChunkNode]
    entities: list[EntityNode]
    mentions: list[MentionEdge]
    relations: list[DomainRelation]
    summary: dict[str, Any]


@dataclass(frozen=True)
class _EntityCandidate:
    name: str
    class_name: str
    evidence_text: str
    page_numbers: tuple[int, ...] = field(default_factory=tuple)


_EMERGENCY_LEVELS = ("이상상태", "백색비상", "청색비상", "적색비상")
_PROTECTIVE_ACTIONS = ("옥내대피", "소개", "강제대피", "대피", "갑상샘 방호 약품", "구호")
_ZONES = ("PAZ", "UPZ", "방사선비상계획구역", "오염구역")
_TRANSPORT_TERMS = ("버스", "선박", "함정", "철도", "열차", "임시긴급열차", "광역전철")
_FACILITY_TERMS = ("구호소", "집결지", "병원", "학교", "노인요양원", "장애인시설", "사회복지시설", "항만", "선착장")
_DEPARTMENT_TERMS = (
    "원자력안전과",
    "보건위생과",
    "복지정책과",
    "자연재난과",
    "교통혁신과",
    "대중교통과",
    "철도시설과",
    "자치행정과",
    "공보담당관",
    "미디어담당관",
    "건설행정과",
    "도로계획과",
    "도시공공디자인과",
    "푸른숲도시과",
)
_EXTERNAL_AGENCY_TERMS = (
    "부산경찰청",
    "부산소방재난본부",
    "부산광역시교육청",
    "한국철도공사",
    "한국철도공사 부산경남본부",
    "고리원자력본부",
    "새울원자력본부",
    "기장군",
    "부산해양경찰서",
    "원자력안전위원회",
)
_MILITARY_TERMS = (
    "해군작전사령부",
    "육군 제53보병사단",
    "공군작전사령부",
    "육군",
    "해군",
    "공군",
)
_TEAM_TERMS = (
    "재난상황관리반",
    "긴급생활안정지원반",
    "긴급통신지원반",
    "시설응급복구반",
    "에너지기능복구반",
    "재난자원지원반",
    "교통대책반",
    "의료및방역서비스지원반",
    "재난수습홍보반",
    "자원봉사관리반",
    "사회질서유지반",
    "수색구조구급반",
)
_STATION_TERMS = ("월내역", "좌천역", "기장역", "신해운대역", "부전역")
_PORT_TERMS = ("부산항", "장안항", "대변항", "월내항", "선착장", "항만")
_ORG_SUFFIX_RE = re.compile(
    r"([가-힣A-Za-z0-9·()]{2,15}(?:과|담당관|경찰청|교육청|사령부))"
)
_TEAM_RE = re.compile(r"([가-힣A-Za-z0-9·() ]{2,35}(?:협업반|실무반|대책본부|지휘센터))")
_PHONE_RE = re.compile(r"(?:\d{2,4}[-)]\s?\d{3,4}[-]\d{4}|\d{2,4}-\d{3,4}-\d{4})")
_LINE_SPLIT_RE = re.compile(r"[\n\r]+")
_TASK_MARKERS = ("임무", "업무", "조치", "절차", "대책", "운영", "지원", "보고", "전파", "통제")
_STOP_ORG_NAMES = {
    "구호소",
    "방사능",
    "방사선",
    "현장",
    "주민",
    "대책",
    "비상",
    "지원",
    "관리",
    "책임과",
    "대응과",
    "매뉴얼과",
    "조치과",
    "업무과",
}

_RELATION_RULES: tuple[tuple[str, tuple[str, ...], tuple[str, ...], tuple[str, ...]], ...] = (
    ("ASSIGNED_TO", ("편성", "배속", "소속"), ("Department", "ExternalAgency", "MilitaryUnit"), ("CooperationTeam",)),
    (
        "RESPONSIBLE_FOR",
        ("담당", "수행", "주관"),
        ("Department", "ExternalAgency", "MilitaryUnit", "CooperationTeam"),
        ("Task", "Action", "Procedure"),
    ),
    (
        "SUPPORTS",
        ("지원", "협조"),
        ("Department", "ExternalAgency", "MilitaryUnit", "CooperationTeam"),
        ("Task", "Action", "Department", "ExternalAgency", "MilitaryUnit", "CooperationTeam"),
    ),
    ("ACTIVATED_AT", ("청색비상", "적색비상", "백색비상", "이상상태", "단계"), ("Task", "Action", "Procedure", "ProtectiveAction"), ("EmergencyLevel",)),
    ("APPLIES_TO", ("대상", "적용", "주민", "시설"), ("ProtectiveAction", "Procedure"), ("ResidentGroup", "VulnerableGroup", "EmergencyPlanningZone", "Facility", "VulnerableFacility")),
    ("LOCATED_IN", ("위치", "구역", "지역"), ("Facility", "Shelter", "AssemblyPoint", "Station", "Port"), ("AdministrativeArea", "EmergencyPlanningZone")),
    ("USES_TRANSPORT", ("수단", "이용", "운행", "수송", "소개"), ("EvacuationOrder", "Procedure", "ProtectiveAction"), ("TransportMode", "Bus", "Vessel", "RailTransport")),
    ("HAS_CONTACT", ("연락처", "전화", "핫라인", "담당자"), ("Department", "ExternalAgency", "MilitaryUnit", "CooperationAgency"), ("ContactPoint",)),
    ("PRECEDES", ("순서", "절차", "후", "이후", "전"), ("Procedure", "ProcedureStep", "Action"), ("Procedure", "ProcedureStep", "Action")),
    ("REQUIRES_COOPERATION_WITH", ("협조", "요청", "연계"), ("Task", "Action", "Procedure"), ("Department", "ExternalAgency", "MilitaryUnit", "CooperationAgency")),
    ("HAS_CRITERIA", ("기준", "조건", "발령"), ("EmergencyLevel", "ProtectiveAction"), ("ActivationCriteria",)),
    ("REPORTS_TO", ("보고", "상황보고"), ("Department", "ExternalAgency", "CooperationTeam"), ("EmergencyHQ", "ExternalAgency")),
    ("COMMUNICATES_VIA", ("전파", "통보", "재난문자", "통신"), ("Department", "ExternalAgency", "Action"), ("CommunicationChannel", "InformationSystem")),
    ("MONITORS", ("탐지", "감시", "측정"), ("Department", "ExternalAgency", "MilitaryUnit", "JointMonitoringCenter"), ("ContaminatedArea", "AdministrativeArea", "EmergencyPlanningZone")),
    ("OPERATES", ("운영", "가동", "편성"), ("Department", "ExternalAgency", "CooperationTeam"), ("Shelter", "Facility", "InformationSystem", "JointMonitoringCenter", "RailTransport")),
)


def build_kg_extraction(
    *,
    chunks: list[ChildChunk],
    meta: DocumentMeta,
    schema: OntologySchema,
    collection_name: str = "default",
    chunking_profile: str = "default",
    graph_dataset_key: str | None = None,
) -> KGExtractionResult:
    """청크에서 증거 기반 KG 후보를 결정적으로 추출합니다.

    이 함수는 LLM을 호출하지 않고 매뉴얼 도메인에 맞춘 보수적 규칙만 사용합니다.
    모든 엔티티와 관계 후보는 chunk_id, page_numbers, evidence_text를 함께 보존합니다.
    """
    graph_dataset_key = graph_dataset_key or build_graph_dataset_key(
        document_key=meta.document_key,
        collection_name=collection_name,
        chunking_profile=chunking_profile,
    )
    class_names = {item.name for item in schema.classes}
    relation_names = {item.name for item in schema.relations}
    chunk_nodes = [
        build_chunk_node(
            chunk,
            meta,
            graph_dataset_key=graph_dataset_key,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
        )
        for chunk in chunks
    ]
    chunk_node_by_id = {chunk_node.chunk_id: chunk_node for chunk_node in chunk_nodes}
    entity_by_id: dict[str, EntityNode] = {}
    mention_keys: set[tuple[str, str]] = set()
    mentions: list[MentionEdge] = []
    relation_keys: set[tuple[str, str, str, str]] = set()
    relations: list[DomainRelation] = []

    for chunk in chunks:
        chunk_node = chunk_node_by_id[chunk.chunk_id]
        candidates = [candidate for candidate in _extract_entities(chunk) if candidate.class_name in class_names]
        entities_for_chunk: list[EntityNode] = []
        for candidate in candidates:
            entity_id = build_entity_id(candidate.class_name, candidate.name)
            entity = entity_by_id.get(entity_id)
            if entity is None:
                entity = EntityNode(
                    entity_id=entity_id,
                    name=candidate.name,
                    normalized_name=_normalize_name(candidate.name),
                    class_name=candidate.class_name,
                    aliases=[],
                    mention_count=0,
                )
                entity_by_id[entity_id] = entity
            entity.mention_count += 1
            entities_for_chunk.append(entity)
            mention_key = (chunk_node.chunk_uid, entity.entity_id)
            if mention_key not in mention_keys:
                mentions.append(
                    MentionEdge(
                        chunk_uid=chunk_node.chunk_uid,
                        chunk_id=chunk.chunk_id,
                        entity_id=entity.entity_id,
                        evidence_text=candidate.evidence_text,
                        page_numbers=chunk.page_numbers,
                    )
                )
                mention_keys.add(mention_key)
        relations.extend(
            _extract_relations(
                chunk=chunk,
                chunk_uid=chunk_node.chunk_uid,
                entities=entities_for_chunk,
                relation_names=relation_names,
                relation_keys=relation_keys,
            )
        )

    class_counts = Counter(entity.class_name for entity in entity_by_id.values())
    relation_counts = Counter(relation.relation_type for relation in relations)
    return KGExtractionResult(
        document_key=meta.document_key,
        chunks=chunk_nodes,
        entities=sorted(entity_by_id.values(), key=lambda item: (item.class_name, item.normalized_name)),
        mentions=mentions,
        relations=relations,
        summary={
            "document_key": meta.document_key,
            "chunk_count": len(chunk_nodes),
            "entity_count": len(entity_by_id),
            "mention_count": len(mentions),
            "relation_count": len(relations),
            "class_counts": dict(sorted(class_counts.items())),
            "relation_counts": dict(sorted(relation_counts.items())),
            "extraction_policy": "deterministic_rule_based_v0.1",
            "graph_dataset_key": graph_dataset_key,
            "collection_name": collection_name,
            "chunking_profile": chunking_profile,
        },
    )


def build_entity_id(class_name: str, name: str) -> str:
    return "ent:" + uuid.uuid5(uuid.NAMESPACE_URL, f"graphrag-was:{class_name}:{_normalize_name(name)}").hex


def build_relation_id(relation_type: str, source_id: str, target_id: str, chunk_uid: str) -> str:
    return "rel:" + uuid.uuid5(
        uuid.NAMESPACE_URL,
        f"graphrag-was:{relation_type}:{source_id}:{target_id}:{chunk_uid}",
    ).hex


def build_chunk_node(
    chunk: ChildChunk,
    meta: DocumentMeta,
    *,
    graph_dataset_key: str,
    collection_name: str,
    chunking_profile: str,
) -> ChunkNode:
    return ChunkNode(
        chunk_uid=build_chunk_uid(graph_dataset_key=graph_dataset_key, chunk_id=chunk.chunk_id),
        chunk_id=chunk.chunk_id,
        graph_dataset_key=graph_dataset_key,
        collection_name=collection_name,
        chunking_profile=chunking_profile,
        document_key=meta.document_key,
        file=meta.file,
        doc_name=meta.doc_name,
        page_numbers=chunk.page_numbers,
        section_path=chunk.section_path,
        section_title=chunk.section_title,
        section_level=chunk.section_level,
        text=chunk.text,
        parent_text=chunk.parent_text,
        parent_id=chunk.parent_id,
        parent_idx=chunk.parent_idx,
        child_idx=chunk.child_idx,
    )


def _extract_entities(chunk: ChildChunk) -> list[_EntityCandidate]:
    text = _clean_text(chunk.text)
    candidates: list[_EntityCandidate] = []
    candidates.extend(_literal_entities(text, _EMERGENCY_LEVELS, "EmergencyLevel", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _PROTECTIVE_ACTIONS, "ProtectiveAction", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _ZONES, "EmergencyPlanningZone", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _TRANSPORT_TERMS, "TransportMode", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _FACILITY_TERMS, "Facility", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _DEPARTMENT_TERMS, "Department", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _EXTERNAL_AGENCY_TERMS, "ExternalAgency", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _MILITARY_TERMS, "MilitaryUnit", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _TEAM_TERMS, "CooperationTeam", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _STATION_TERMS, "Station", chunk.page_numbers))
    candidates.extend(_literal_entities(text, _PORT_TERMS, "Port", chunk.page_numbers))
    candidates.extend(_regex_entities(text, _TEAM_RE, "CooperationTeam", chunk.page_numbers))
    candidates.extend(_regex_entities(text, _ORG_SUFFIX_RE, "Department", chunk.page_numbers))
    candidates.extend(_regex_entities(text, _PHONE_RE, "ContactPoint", chunk.page_numbers))
    candidates.extend(_task_entities(text, chunk.page_numbers))
    return _dedupe_candidates(_specialize_entities(candidates))


def _literal_entities(
    text: str,
    terms: tuple[str, ...],
    class_name: str,
    page_numbers: list[int],
) -> list[_EntityCandidate]:
    return [
        _EntityCandidate(
            name=term,
            class_name=class_name,
            evidence_text=_evidence(text, term),
            page_numbers=tuple(page_numbers),
        )
        for term in terms
        if term in text
    ]


def _regex_entities(
    text: str,
    pattern: re.Pattern[str],
    class_name: str,
    page_numbers: list[int],
) -> list[_EntityCandidate]:
    candidates: list[_EntityCandidate] = []
    for match in pattern.finditer(text):
        name = match.group(1) if match.groups() else match.group(0)
        name = name.strip(" -:()[]")
        if len(name) < 2 or name in _STOP_ORG_NAMES:
            continue
        candidates.append(
            _EntityCandidate(
                name=name,
                class_name=class_name,
                evidence_text=_evidence(text, name),
                page_numbers=tuple(page_numbers),
            )
        )
    return candidates


def _task_entities(text: str, page_numbers: list[int]) -> list[_EntityCandidate]:
    candidates: list[_EntityCandidate] = []
    for line in _LINE_SPLIT_RE.split(text):
        normalized = line.strip(" -•·\t")
        if "<table" in normalized or normalized.count("|") >= 4:
            continue
        if len(normalized) < 8 or not any(marker in normalized for marker in _TASK_MARKERS):
            continue
        if len(normalized) > 120:
            normalized = normalized[:120].rsplit(" ", 1)[0].strip() or normalized[:120]
        class_name = "Procedure" if "절차" in normalized else "Action" if "조치" in normalized else "Task"
        candidates.append(
            _EntityCandidate(
                name=normalized,
                class_name=class_name,
                evidence_text=normalized,
                page_numbers=tuple(page_numbers),
            )
        )
        if len(candidates) >= 4:
            break
    return candidates


def _specialize_entities(candidates: list[_EntityCandidate]) -> list[_EntityCandidate]:
    specialized: list[_EntityCandidate] = []
    for candidate in candidates:
        class_name = candidate.class_name
        name = candidate.name
        if class_name == "Department":
            if any(term in name for term in ("경찰", "교육청", "공사", "공단", "해경", "센터", "본부")):
                class_name = "ExternalAgency"
            if any(term in name for term in ("사령부", "사단", "부대", "해군", "육군", "공군")):
                class_name = "MilitaryUnit"
        elif class_name == "Facility":
            if any(term in name for term in ("요양원", "장애인시설", "사회복지시설")):
                class_name = "VulnerableFacility"
            elif name == "구호소":
                class_name = "Shelter"
            elif name == "집결지":
                class_name = "AssemblyPoint"
            elif any(term in name for term in ("항", "항만", "선착장")):
                class_name = "Port"
        elif class_name == "TransportMode":
            if any(term in name for term in ("선박", "함정")):
                class_name = "Vessel"
            elif "버스" in name:
                class_name = "Bus"
            elif any(term in name for term in ("철도", "열차", "전철")):
                class_name = "RailTransport"
        specialized.append(
            _EntityCandidate(
                name=name,
                class_name=class_name,
                evidence_text=candidate.evidence_text,
                page_numbers=candidate.page_numbers,
            )
        )
    return specialized


def _dedupe_candidates(candidates: list[_EntityCandidate]) -> list[_EntityCandidate]:
    seen: set[tuple[str, str]] = set()
    result: list[_EntityCandidate] = []
    for candidate in candidates:
        key = (candidate.class_name, _normalize_name(candidate.name))
        if key in seen:
            continue
        seen.add(key)
        result.append(candidate)
    return result


def _extract_relations(
    *,
    chunk: ChildChunk,
    chunk_uid: str,
    entities: list[EntityNode],
    relation_names: set[str],
    relation_keys: set[tuple[str, str, str, str]],
) -> list[DomainRelation]:
    relations: list[DomainRelation] = []
    text = _clean_text(chunk.text)
    by_class: dict[str, list[EntityNode]] = {}
    for entity in entities:
        by_class.setdefault(entity.class_name, []).append(entity)

    for relation_type, keywords, source_classes, target_classes in _RELATION_RULES:
        if relation_type not in relation_names or not any(keyword in text for keyword in keywords):
            continue
        sources = [entity for class_name in source_classes for entity in by_class.get(class_name, [])]
        targets = [entity for class_name in target_classes for entity in by_class.get(class_name, [])]
        rule_count = 0
        for source in sources[:4]:
            for target in targets[:4]:
                if rule_count >= 4:
                    break
                if source.entity_id == target.entity_id:
                    continue
                evidence = _find_relation_evidence(chunk.text, source.name, target.name, keywords)
                if evidence is None:
                    continue
                key = (relation_type, source.entity_id, target.entity_id, chunk_uid)
                if key in relation_keys:
                    continue
                relation_keys.add(key)
                relations.append(
                    DomainRelation(
                        relation_id=build_relation_id(relation_type, source.entity_id, target.entity_id, chunk_uid),
                        relation_type=relation_type,
                        source_entity_id=source.entity_id,
                        target_entity_id=target.entity_id,
                        chunk_uid=chunk_uid,
                        chunk_id=chunk.chunk_id,
                        evidence_text=evidence,
                        page_numbers=chunk.page_numbers,
                        confidence=0.6,
                    )
                )
                rule_count += 1
                if len(relations) >= 12:
                    return relations
            if rule_count >= 4:
                break
    return relations


def _entity_id(class_name: str, name: str) -> str:
    return build_entity_id(class_name, name)


def _relation_id(relation_type: str, source_id: str, target_id: str, chunk_id: str) -> str:
    return build_relation_id(relation_type, source_id, target_id, chunk_id)


def _normalize_name(value: str) -> str:
    return re.sub(r"[\s\W_]+", "", value).lower()


def _clean_text(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def _evidence(text: str, term: str, *, window: int = 80) -> str:
    index = text.find(term)
    if index < 0:
        return text[: window * 2].strip()
    start = max(0, index - window)
    end = min(len(text), index + len(term) + window)
    return text[start:end].strip()


def _relation_evidence(text: str, source_name: str, target_name: str, keywords: tuple[str, ...]) -> str:
    anchors = [source_name, target_name, *keywords]
    positions = [text.find(anchor) for anchor in anchors if anchor and text.find(anchor) >= 0]
    if not positions:
        return text[:200].strip()
    center = min(positions)
    return text[max(0, center - 100) : min(len(text), center + 220)].strip()


def _find_relation_evidence(
    text: str,
    source_name: str,
    target_name: str,
    keywords: tuple[str, ...],
    *,
    window: int = 180,
) -> str | None:
    for unit in _relation_units(text):
        if (
            source_name in unit
            and target_name in unit
            and any(keyword in unit for keyword in keywords)
        ):
            return unit[:320].strip()

    cleaned = _clean_text(text)
    anchors = [source_name, target_name]
    keyword_positions = [cleaned.find(keyword) for keyword in keywords if cleaned.find(keyword) >= 0]
    positions = [cleaned.find(anchor) for anchor in anchors if cleaned.find(anchor) >= 0]
    if len(positions) < 2 or not keyword_positions:
        return None
    all_positions = [*positions, min(keyword_positions)]
    if max(all_positions) - min(all_positions) > window:
        return None
    center = min(all_positions)
    return cleaned[max(0, center - 80) : min(len(cleaned), center + 240)].strip()


def _relation_units(text: str) -> list[str]:
    raw_units: list[str] = []
    for line in _LINE_SPLIT_RE.split(text or ""):
        line = line.strip()
        if not line:
            continue
        raw_units.extend(part.strip() for part in re.split(r"(?<=[.!?。])\s+|[;；]", line) if part.strip())
    if not raw_units and text:
        raw_units = [text]
    return [_clean_text(unit) for unit in raw_units if _clean_text(unit)]
