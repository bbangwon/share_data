from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class OntologyClassSpec(BaseModel):
    name: str
    label_ko: str
    module: str
    description: str
    examples: list[str] = Field(default_factory=list)


class OntologyRelationSpec(BaseModel):
    name: str
    label_ko: str
    domain: list[str]
    range: list[str]
    description: str


class OntologyModuleSpec(BaseModel):
    name: str
    label_ko: str
    description: str
    classes: list[str]
    priority: Literal["high", "medium", "low"] = "medium"


class OntologySchema(BaseModel):
    version: str
    description: str
    modules: list[OntologyModuleSpec]
    classes: list[OntologyClassSpec]
    relations: list[OntologyRelationSpec]


def build_initial_schema(version: str = "ontology-v0.1") -> OntologySchema:
    """Phase2 1차 적용을 위한 최소 모듈형 온톨로지 스키마를 반환합니다."""
    modules = [
        OntologyModuleSpec(
            name="emergency_level",
            label_ko="비상단계",
            description="방사선비상 단계, 위기경보, 단계별 발령 기준과 대응 흐름을 표현합니다.",
            classes=["EmergencyLevel", "ActivationCriteria", "ResponsePhase", "Trigger"],
            priority="high",
        ),
        OntologyModuleSpec(
            name="organization",
            label_ko="조직·협업반",
            description="부산광역시 부서, 협업반, 유관기관, 군·경·소방 등 조직과 역할을 표현합니다.",
            classes=["Department", "CooperationTeam", "EmergencyHQ", "ExternalAgency", "MilitaryUnit", "Role"],
            priority="high",
        ),
        OntologyModuleSpec(
            name="task_action",
            label_ko="임무·조치",
            description="상황별 조치, 체크리스트, 담당 임무, 절차의 선후 관계를 표현합니다.",
            classes=["Task", "Action", "Procedure", "ProcedureStep", "ChecklistItem"],
            priority="high",
        ),
        OntologyModuleSpec(
            name="resident_protection",
            label_ko="주민보호",
            description="옥내대피, 소개, 강제대피, 안전취약계층 보호, 구호 지원을 표현합니다.",
            classes=["ProtectiveAction", "ResidentGroup", "VulnerableGroup", "EvacuationOrder", "ReliefSupport"],
            priority="high",
        ),
        OntologyModuleSpec(
            name="facility_zone",
            label_ko="시설·구역",
            description="PAZ, UPZ, 행정구역, 구호소, 집결지, 병원, 학교, 역, 항만을 표현합니다.",
            classes=["EmergencyPlanningZone", "AdministrativeArea", "Facility", "VulnerableFacility", "Shelter", "AssemblyPoint"],
            priority="high",
        ),
        OntologyModuleSpec(
            name="transport",
            label_ko="교통·소개수단",
            description="버스, 선박, 철도, 구급차, 이동 경로, 역과 항만을 표현합니다.",
            classes=["TransportMode", "Bus", "Vessel", "RailTransport", "Route", "Station", "Port"],
            priority="medium",
        ),
        OntologyModuleSpec(
            name="contact_communication",
            label_ko="연락망·협조체계",
            description="담당자, 연락처, 협조기관, 보고·전파 채널을 표현합니다.",
            classes=["ContactPoint", "ContactRole", "CooperationAgency", "CommunicationChannel", "InformationSystem"],
            priority="medium",
        ),
        OntologyModuleSpec(
            name="radiation_medical",
            label_ko="방사선 감시·의료·제염",
            description="환경방사선 탐지, 감시센터, 진료센터, 오염구역, 제염 절차를 표현합니다.",
            classes=["RadiationMonitoring", "MonitoringResult", "JointMonitoringCenter", "ContaminatedArea", "Decontamination", "EmergencyMedicalCare"],
            priority="medium",
        ),
    ]
    class_specs = [
        _class("EmergencyLevel", "비상단계", "emergency_level", "방사선비상 또는 위기경보의 단계입니다.", ["이상상태", "백색비상", "청색비상", "적색비상"]),
        _class("ActivationCriteria", "발령기준", "emergency_level", "비상단계 또는 조치가 활성화되는 조건입니다."),
        _class("ResponsePhase", "대응단계", "emergency_level", "징후감지, 초기대응, 비상대응, 수습복구 등 대응 흐름 단계입니다."),
        _class("Trigger", "트리거", "emergency_level", "조치나 절차를 유발하는 사건 또는 조건입니다."),
        _class("Department", "부서", "organization", "부산광역시 내부 부서입니다.", ["원자력안전과", "보건위생과", "복지정책과"]),
        _class("CooperationTeam", "협업반", "organization", "방사능방재대책본부의 기능별 협업반입니다."),
        _class("EmergencyHQ", "비상대책본부", "organization", "방사능방재대책본부, 현장방사능방재지휘센터 같은 지휘 조직입니다."),
        _class("ExternalAgency", "유관기관", "organization", "부산광역시 외부 협조·지원 기관입니다."),
        _class("MilitaryUnit", "군부대", "organization", "육군, 해군, 공군 등 군 지원기관입니다."),
        _class("Role", "역할", "organization", "주관, 지원, 협조, 보고, 현장통제 같은 역할입니다."),
        _class("Task", "임무", "task_action", "조직이나 기관에 부여된 업무입니다."),
        _class("Action", "조치", "task_action", "재난 대응 과정에서 수행되는 개별 조치입니다."),
        _class("Procedure", "절차", "task_action", "순서가 있는 업무 절차입니다."),
        _class("ProcedureStep", "절차단계", "task_action", "절차 안의 개별 단계입니다."),
        _class("ChecklistItem", "체크리스트항목", "task_action", "주요상황조치목록의 점검 항목입니다."),
        _class("ProtectiveAction", "주민보호조치", "resident_protection", "옥내대피, 소개, 갑상샘 방호 약품 배포 같은 주민보호조치입니다."),
        _class("ResidentGroup", "주민집단", "resident_protection", "PAZ 주민, UPZ 주민, 관광객 등 보호 대상 집단입니다."),
        _class("VulnerableGroup", "안전취약계층", "resident_protection", "노인, 장애인, 입원환자, 학생 등 우선 보호 대상입니다."),
        _class("EvacuationOrder", "대피명령", "resident_protection", "소개 또는 대피 명령입니다."),
        _class("ReliefSupport", "구호지원", "resident_protection", "급식, 급수, 구호물품, 임시주거 지원입니다."),
        _class("EmergencyPlanningZone", "방사선비상계획구역", "facility_zone", "PAZ, UPZ 같은 방사선비상계획구역입니다."),
        _class("AdministrativeArea", "행정구역", "facility_zone", "기초지자체, 읍면동 등 행정구역입니다."),
        _class("Facility", "시설", "facility_zone", "학교, 병원, 항만, 철도역 등 시설입니다."),
        _class("VulnerableFacility", "안전취약시설", "facility_zone", "노인요양원, 장애인시설, 병원 등 안전취약계층 관련 시설입니다."),
        _class("Shelter", "구호소", "facility_zone", "이재민 구호소 또는 임시주거시설입니다."),
        _class("AssemblyPoint", "집결지", "facility_zone", "주민 소개를 위한 집결지 또는 승선·승차 지점입니다."),
        _class("TransportMode", "교통수단", "transport", "주민 소개나 물자 이동에 쓰이는 교통수단 유형입니다."),
        _class("Bus", "버스", "transport", "버스 기반 소개수단입니다."),
        _class("Vessel", "선박", "transport", "해상 소개수단입니다."),
        _class("RailTransport", "철도", "transport", "철도 기반 소개수단입니다."),
        _class("Route", "경로", "transport", "소개 경로, 우회 경로, 통제 구간입니다."),
        _class("Station", "철도역", "transport", "철도 소개와 연계되는 역입니다."),
        _class("Port", "항만", "transport", "선박 소개와 연계되는 항만·선착장입니다."),
        _class("ContactPoint", "연락처", "contact_communication", "담당자 또는 기관 연락처입니다."),
        _class("ContactRole", "연락역할", "contact_communication", "상황접수, 협조요청, 현장지원 등 연락처의 역할입니다."),
        _class("CooperationAgency", "협조기관", "contact_communication", "업무 수행을 위해 협조가 필요한 기관입니다."),
        _class("CommunicationChannel", "통신채널", "contact_communication", "재난안전통신망, 전화, 무전, 재난문자 등 전파·보고 수단입니다."),
        _class("InformationSystem", "정보시스템", "contact_communication", "상황정보공유시스템, 자원관리시스템 등 정보시스템입니다."),
        _class("RadiationMonitoring", "방사선감시", "radiation_medical", "환경방사선 탐지 및 감시 활동입니다."),
        _class("MonitoringResult", "감시결과", "radiation_medical", "방사선량률, 오염 측정값 등 감시 결과입니다."),
        _class("JointMonitoringCenter", "합동감시센터", "radiation_medical", "합동 환경방사선감시센터입니다."),
        _class("ContaminatedArea", "오염구역", "radiation_medical", "출입통제 또는 제염 대상 오염구역입니다."),
        _class("Decontamination", "제염", "radiation_medical", "인체, 차량, 시설 제염 조치입니다."),
        _class("EmergencyMedicalCare", "비상진료", "radiation_medical", "방사선비상진료 및 피폭환자 대응입니다."),
    ]
    relations = [
        _relation("MENTIONS", "언급", ["Chunk"], ["Entity"], "청크가 특정 엔티티를 언급합니다."),
        _relation("INSTANCE_OF", "인스턴스분류", ["Entity"], ["OntologyClass"], "엔티티가 온톨로지 클래스의 인스턴스임을 나타냅니다."),
        _relation("ASSIGNED_TO", "편성", ["Department", "ExternalAgency", "MilitaryUnit"], ["CooperationTeam"], "부서 또는 기관이 협업반에 편성됩니다."),
        _relation("RESPONSIBLE_FOR", "담당", ["Department", "ExternalAgency", "MilitaryUnit", "CooperationTeam"], ["Task", "Action", "Procedure"], "조직이 임무나 조치를 담당합니다."),
        _relation(
            "SUPPORTS",
            "지원",
            ["Department", "ExternalAgency", "MilitaryUnit", "CooperationTeam"],
            ["Task", "Action", "Department", "ExternalAgency", "MilitaryUnit", "CooperationTeam"],
            "조직이 임무나 다른 조직을 지원합니다.",
        ),
        _relation("ACTIVATED_AT", "단계활성화", ["Task", "Action", "Procedure", "ProtectiveAction"], ["EmergencyLevel", "ResponsePhase"], "조치나 절차가 특정 단계에서 활성화됩니다."),
        _relation("APPLIES_TO", "적용대상", ["ProtectiveAction", "Procedure"], ["ResidentGroup", "VulnerableGroup", "EmergencyPlanningZone", "Facility", "VulnerableFacility"], "조치나 절차가 특정 대상 또는 구역에 적용됩니다."),
        _relation("LOCATED_IN", "위치", ["Facility", "Shelter", "AssemblyPoint", "Station", "Port"], ["AdministrativeArea", "EmergencyPlanningZone"], "시설이나 지점이 행정구역 또는 방사선비상계획구역에 위치합니다."),
        _relation("USES_TRANSPORT", "교통수단사용", ["EvacuationOrder", "Procedure", "ProtectiveAction"], ["TransportMode", "Bus", "Vessel", "RailTransport"], "소개 절차가 특정 교통수단을 사용합니다."),
        _relation("HAS_CONTACT", "연락처보유", ["Department", "ExternalAgency", "MilitaryUnit", "CooperationAgency"], ["ContactPoint"], "조직이 연락처를 가집니다."),
        _relation("PRECEDES", "선행", ["Procedure", "ProcedureStep", "Action"], ["Procedure", "ProcedureStep", "Action"], "절차 또는 조치의 선후 관계입니다."),
        _relation("REQUIRES_COOPERATION_WITH", "협조필요", ["Task", "Action", "Procedure"], ["Department", "ExternalAgency", "MilitaryUnit", "CooperationAgency"], "조치 수행에 협조기관이 필요합니다."),
        _relation("HAS_CRITERIA", "기준보유", ["EmergencyLevel", "ProtectiveAction"], ["ActivationCriteria"], "단계 또는 조치가 발령·시행 기준을 가집니다."),
        _relation("REPORTS_TO", "보고", ["Department", "ExternalAgency", "CooperationTeam"], ["EmergencyHQ", "ExternalAgency"], "조직이 보고 대상에 보고합니다."),
        _relation("COMMUNICATES_VIA", "통신수단", ["Department", "ExternalAgency", "Action"], ["CommunicationChannel", "InformationSystem"], "조직이나 조치가 특정 통신수단을 통해 전파됩니다."),
        _relation("MONITORS", "감시", ["Department", "ExternalAgency", "MilitaryUnit", "JointMonitoringCenter"], ["ContaminatedArea", "AdministrativeArea", "EmergencyPlanningZone"], "기관이 특정 구역을 감시합니다."),
        _relation("OPERATES", "운영", ["Department", "ExternalAgency", "CooperationTeam"], ["Shelter", "Facility", "InformationSystem", "JointMonitoringCenter", "RailTransport"], "조직이 시설, 시스템 또는 철도 운영 자원을 운영합니다."),
        _relation("REFERENCES", "근거", ["CompetencyQuestion", "Entity", "RelationCandidate"], ["Chunk"], "CQ, 엔티티, 관계 후보가 근거 청크를 참조합니다."),
        _relation("BELONGS_TO", "소속", ["Entity", "Task", "Action"], ["OntologyModule", "EmergencyHQ", "CooperationTeam"], "엔티티나 임무가 모듈 또는 조직에 속합니다."),
        _relation("RELATED_TO", "관련", ["Entity"], ["Entity"], "정규화 전 관계가 명확하지 않지만 의미적으로 관련됩니다."),
    ]
    return OntologySchema(
        version=version,
        description="원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼 Phase2 Ontology Layer 최소 스키마",
        modules=modules,
        classes=class_specs,
        relations=relations,
    )


def _class(name: str, label_ko: str, module: str, description: str, examples: list[str] | None = None) -> OntologyClassSpec:
    return OntologyClassSpec(
        name=name,
        label_ko=label_ko,
        module=module,
        description=description,
        examples=examples or [],
    )


def _relation(name: str, label_ko: str, domain: list[str], range: list[str], description: str) -> OntologyRelationSpec:
    return OntologyRelationSpec(
        name=name,
        label_ko=label_ko,
        domain=domain,
        range=range,
        description=description,
    )
