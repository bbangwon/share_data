from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import re
import time
import warnings
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

from langchain_core.prompts import load_prompt
from langchain_openai import ChatOpenAI
from pydantic import AliasChoices, BaseModel, Field

from app.core.config import Settings
from app.services.ontology.extraction import (
    ChunkNode,
    DomainRelation,
    EntityNode,
    KGExtractionResult,
    MentionEdge,
    build_chunk_node,
    build_entity_id,
    build_graph_dataset_key,
    build_kg_extraction,
    build_relation_id,
)
from app.services.ontology.schema import OntologyRelationSpec, OntologySchema
from app.services.schemas import ChildChunk, DocumentMeta

PROJECT_ROOT = Path(__file__).resolve().parents[3]
ENTITY_PROMPT_PATH = PROJECT_ROOT / "prompts" / "ontology" / "entity_extraction.yaml"
RELATION_PROMPT_PATH = PROJECT_ROOT / "prompts" / "ontology" / "relation_extraction.yaml"
KG_CHUNK_CACHE_VERSION = 1

KGExtractionMode = Literal["rule_based", "llm", "hybrid"]


class LLMEntityCandidate(BaseModel):
    name: str = Field(validation_alias=AliasChoices("name", "canonical_name"))
    class_name: str = Field(validation_alias=AliasChoices("class_name", "type"))
    aliases: list[str] = Field(default_factory=list)
    evidence_text: str = ""
    confidence: float = 0.5


class LLMEntityResponse(BaseModel):
    entities: list[LLMEntityCandidate] = Field(default_factory=list)


class LLMRelationCandidate(BaseModel):
    relation_type: str = Field(validation_alias=AliasChoices("relation_type", "predicate"))
    source_entity_id: str | None = Field(
        default=None,
        validation_alias=AliasChoices("source_entity_id", "subject_entity_id"),
    )
    target_entity_id: str | None = Field(
        default=None,
        validation_alias=AliasChoices("target_entity_id", "object_entity_id"),
    )
    source_entity_name: str | None = Field(
        default=None,
        validation_alias=AliasChoices("source_entity_name", "subject"),
    )
    target_entity_name: str | None = Field(
        default=None,
        validation_alias=AliasChoices("target_entity_name", "object"),
    )
    evidence_text: str = ""
    confidence: float = 0.5


class LLMRelationResponse(BaseModel):
    relations: list[LLMRelationCandidate] = Field(default_factory=list)


class OntologyLLMExtractor:
    def __init__(self, settings: Settings, *, llm: Any | None = None) -> None:
        self.settings = settings
        self.llm = llm

    async def extract(
        self,
        *,
        chunks: list[ChildChunk],
        meta: DocumentMeta,
        schema: OntologySchema,
        collection_name: str,
        chunking_profile: str,
        graph_dataset_key: str,
        mode: KGExtractionMode,
        cache_dir: Path | None = None,
        progress_path: Path | None = None,
        progress_events_path: Path | None = None,
        resume: bool = True,
        total_source_chunk_count: int | None = None,
        selected_offset: int = 0,
        selected_limit: int | None = None,
    ) -> KGExtractionResult:
        if mode not in {"llm", "hybrid"}:
            raise ValueError(f"unsupported LLM ontology extraction mode: {mode!r}")
        llm = self.llm or self._build_llm()
        concurrency = max(1, self.settings.ontology.kg_llm_concurrency)
        progress = _initial_progress(
            document_key=meta.document_key,
            graph_dataset_key=graph_dataset_key,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
            mode=mode,
            total_source_chunk_count=total_source_chunk_count or len(chunks),
            selected_offset=selected_offset,
            selected_limit=selected_limit,
            selected_chunk_count=len(chunks),
        )
        progress_lock = asyncio.Lock()
        _write_progress(progress_path, progress)
        _log_kg_progress(progress, event="started")

        async def run_chunk(selection_index: int, chunk: ChildChunk) -> KGExtractionResult:
            async with semaphore:
                return await self._extract_chunk_with_cache(
                    selection_index=selection_index,
                    chunk=chunk,
                    meta=meta,
                    schema=schema,
                    collection_name=collection_name,
                    chunking_profile=chunking_profile,
                    graph_dataset_key=graph_dataset_key,
                    mode=mode,
                    llm=llm,
                    cache_dir=cache_dir,
                    resume=resume,
                    progress=progress,
                    progress_lock=progress_lock,
                    progress_path=progress_path,
                    progress_events_path=progress_events_path,
                )

        semaphore = asyncio.Semaphore(concurrency)
        per_chunk_results: list[KGExtractionResult] = []
        try:
            indexed_chunks = list(enumerate(chunks, start=selected_offset))
            for start in range(0, len(indexed_chunks), concurrency):
                batch = indexed_chunks[start : start + concurrency]
                per_chunk_results.extend(
                    await asyncio.gather(*(run_chunk(index, chunk) for index, chunk in batch))
                )
            progress["status"] = "completed"
            progress["completed_at"] = _now_iso()
            _refresh_progress(progress)
            _write_progress(progress_path, progress)
            _log_kg_progress(progress, event="completed")
            return _merge_chunk_results(
                per_chunk_results,
                document_key=meta.document_key,
                graph_dataset_key=graph_dataset_key,
                collection_name=collection_name,
                chunking_profile=chunking_profile,
                mode=mode,
            )
        except Exception as exc:
            progress["status"] = "failed"
            progress["error"] = str(exc)
            progress["failed_at"] = _now_iso()
            _refresh_progress(progress)
            _write_progress(progress_path, progress)
            _log_kg_progress(progress, event="failed", error=str(exc))
            raise

    def _build_llm(self) -> ChatOpenAI:
        if not self.settings.llm.base_url:
            raise ValueError("llm.base_url is required when ontology.kg_extraction_mode uses LLM")
        if not self.settings.llm.model_name:
            raise ValueError("llm.model_name is required when ontology.kg_extraction_mode uses LLM")
        return ChatOpenAI(
            model=self.settings.llm.model_name,
            base_url=self.settings.llm.base_url,
            timeout=self.settings.llm.timeout,
            temperature=self.settings.llm.temperature,
            api_key=self.settings.llm.api_key.get_secret_value(),
        )

    async def _extract_chunk_with_policy(
        self,
        *,
        chunk: ChildChunk,
        meta: DocumentMeta,
        schema: OntologySchema,
        collection_name: str,
        chunking_profile: str,
        graph_dataset_key: str,
        mode: KGExtractionMode,
        llm: Any,
    ) -> KGExtractionResult:
        try:
            return await self._extract_chunk(
                chunk=chunk,
                meta=meta,
                schema=schema,
                collection_name=collection_name,
                chunking_profile=chunking_profile,
                graph_dataset_key=graph_dataset_key,
                llm=llm,
            )
        except Exception as exc:
            if mode != "hybrid":
                raise
            fallback = build_kg_extraction(
                chunks=[chunk],
                meta=meta,
                schema=schema,
                collection_name=collection_name,
                chunking_profile=chunking_profile,
                graph_dataset_key=graph_dataset_key,
            )
            fallback.summary.update(
                {
                    "extraction_policy": "hybrid_llm_with_rule_based_fallback_v0.1",
                    "llm_chunk_count": 0,
                    "llm_failed_chunk_count": 1,
                    "fallback_chunk_count": 1,
                    "fallback_reasons": {chunk.chunk_id: str(exc)},
                }
            )
            return fallback

    async def _extract_chunk_with_cache(
        self,
        *,
        selection_index: int,
        chunk: ChildChunk,
        meta: DocumentMeta,
        schema: OntologySchema,
        collection_name: str,
        chunking_profile: str,
        graph_dataset_key: str,
        mode: KGExtractionMode,
        llm: Any,
        cache_dir: Path | None,
        resume: bool,
        progress: dict[str, Any],
        progress_lock: asyncio.Lock,
        progress_path: Path | None,
        progress_events_path: Path | None,
    ) -> KGExtractionResult:
        chunk_node = build_chunk_node(
            chunk,
            meta,
            graph_dataset_key=graph_dataset_key,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
        )
        cache_path = _chunk_cache_path(cache_dir, chunk_node.chunk_uid)
        started = time.perf_counter()
        if resume and cache_path and cache_path.exists():
            cached = _load_cached_chunk_result(
                cache_path,
                mode=mode,
                graph_dataset_key=graph_dataset_key,
                chunk_uid=chunk_node.chunk_uid,
            )
            if cached is not None:
                await _record_progress(
                    progress,
                    progress_lock,
                    progress_path,
                    progress_events_path,
                    event={
                        "event": "resumed",
                        "selection_index": selection_index,
                        "chunk_id": chunk.chunk_id,
                        "chunk_uid": chunk_node.chunk_uid,
                        "duration_ms": 0.0,
                    },
                    resumed=True,
                    duration_ms=0.0,
                )
                return cached
        try:
            result = await self._extract_chunk_with_policy(
                chunk=chunk,
                meta=meta,
                schema=schema,
                collection_name=collection_name,
                chunking_profile=chunking_profile,
                graph_dataset_key=graph_dataset_key,
                mode=mode,
                llm=llm,
            )
        except Exception as exc:
            duration_ms = _duration_ms(started)
            await _record_progress(
                progress,
                progress_lock,
                progress_path,
                progress_events_path,
                event={
                    "event": "failed",
                    "selection_index": selection_index,
                    "chunk_id": chunk.chunk_id,
                    "chunk_uid": chunk_node.chunk_uid,
                    "duration_ms": duration_ms,
                    "error": str(exc),
                },
                failed=True,
                duration_ms=duration_ms,
            )
            raise
        duration_ms = _duration_ms(started)
        _write_cached_chunk_result(
            cache_path,
            result,
            mode=mode,
            graph_dataset_key=graph_dataset_key,
            chunk_uid=chunk_node.chunk_uid,
            chunk_id=chunk.chunk_id,
            duration_ms=duration_ms,
        )
        await _record_progress(
            progress,
            progress_lock,
            progress_path,
            progress_events_path,
            event={
                "event": "completed",
                "selection_index": selection_index,
                "chunk_id": chunk.chunk_id,
                "chunk_uid": chunk_node.chunk_uid,
                "duration_ms": duration_ms,
            },
            processed=True,
            duration_ms=duration_ms,
        )
        return result

    async def _extract_chunk(
        self,
        *,
        chunk: ChildChunk,
        meta: DocumentMeta,
        schema: OntologySchema,
        collection_name: str,
        chunking_profile: str,
        graph_dataset_key: str,
        llm: Any,
    ) -> KGExtractionResult:
        chunk_node = build_chunk_node(
            chunk,
            meta,
            graph_dataset_key=graph_dataset_key,
            collection_name=collection_name,
            chunking_profile=chunking_profile,
        )
        ontology_schema = _schema_for_prompt(schema)
        chunk_metadata = _chunk_metadata_for_prompt(chunk, chunk_node, meta)
        chunk_text = _truncate(chunk.text, self.settings.ontology.kg_llm_max_chunk_chars)
        entity_response = await self._invoke_entity_prompt(
            llm=llm,
            ontology_schema=ontology_schema,
            chunk_metadata=chunk_metadata,
            chunk_text=chunk_text,
        )
        entities, mentions = _validated_entities(
            entity_response.entities,
            chunk=chunk,
            chunk_node=chunk_node,
            schema=schema,
            threshold=self.settings.ontology.kg_llm_confidence_threshold,
        )
        relation_response = await self._invoke_relation_prompt(
            llm=llm,
            ontology_schema=ontology_schema,
            chunk_metadata=chunk_metadata,
            entities=[entity.model_dump(mode="json") for entity in entities],
            chunk_text=chunk_text,
        )
        relations = _validated_relations(
            relation_response.relations,
            chunk=chunk,
            chunk_node=chunk_node,
            entities=entities,
            schema=schema,
            threshold=self.settings.ontology.kg_llm_confidence_threshold,
        )
        return KGExtractionResult(
            document_key=meta.document_key,
            chunks=[chunk_node],
            entities=entities,
            mentions=mentions,
            relations=relations,
            summary={
                "document_key": meta.document_key,
                "chunk_count": 1,
                "entity_count": len(entities),
                "mention_count": len(mentions),
                "relation_count": len(relations),
                "class_counts": dict(Counter(entity.class_name for entity in entities)),
                "relation_counts": dict(Counter(relation.relation_type for relation in relations)),
                "extraction_policy": "llm_prompt_based_v0.1",
                "graph_dataset_key": graph_dataset_key,
                "collection_name": collection_name,
                "chunking_profile": chunking_profile,
                "llm_chunk_count": 1,
                "llm_failed_chunk_count": 0,
                "fallback_chunk_count": 0,
            },
        )

    async def _invoke_entity_prompt(
        self,
        *,
        llm: Any,
        ontology_schema: str,
        chunk_metadata: str,
        chunk_text: str,
    ) -> LLMEntityResponse:
        prompt = _load_entity_prompt().format_prompt(
            ontology_schema=ontology_schema,
            chunk_metadata=chunk_metadata,
            chunk_text=chunk_text,
        )
        content = _message_content(await _maybe_await(_invoke_llm(llm, prompt)))
        return LLMEntityResponse.model_validate(_parse_json_object(content))

    async def _invoke_relation_prompt(
        self,
        *,
        llm: Any,
        ontology_schema: str,
        chunk_metadata: str,
        entities: list[dict[str, Any]],
        chunk_text: str,
    ) -> LLMRelationResponse:
        prompt = _load_relation_prompt().format_prompt(
            ontology_schema=ontology_schema,
            chunk_metadata=chunk_metadata,
            entities=json.dumps(entities, ensure_ascii=False, indent=2),
            chunk_text=chunk_text,
        )
        content = _message_content(await _maybe_await(_invoke_llm(llm, prompt)))
        return LLMRelationResponse.model_validate(_parse_json_object(content))


def _validated_entities(
    candidates: list[LLMEntityCandidate],
    *,
    chunk: ChildChunk,
    chunk_node: ChunkNode,
    schema: OntologySchema,
    threshold: float,
) -> tuple[list[EntityNode], list[MentionEdge]]:
    class_names = {item.name for item in schema.classes}
    entity_by_id: dict[str, EntityNode] = {}
    mentions: list[MentionEdge] = []
    for candidate in candidates:
        name = candidate.name.strip()
        class_name = candidate.class_name.strip()
        evidence_text = candidate.evidence_text.strip() or name
        if not name or class_name not in class_names or candidate.confidence < threshold:
            continue
        if not _evidence_is_backed(chunk.text, evidence_text, name):
            continue
        entity_id = build_entity_id(class_name, name)
        if entity_id in entity_by_id:
            continue
        entity = EntityNode(
            entity_id=entity_id,
            name=name,
            normalized_name=_normalize_name(name),
            class_name=class_name,
            aliases=_dedupe([alias.strip() for alias in candidate.aliases if alias.strip()]),
            mention_count=1,
        )
        entity_by_id[entity_id] = entity
        mentions.append(
            MentionEdge(
                chunk_uid=chunk_node.chunk_uid,
                chunk_id=chunk.chunk_id,
                entity_id=entity_id,
                evidence_text=evidence_text,
                page_numbers=chunk.page_numbers,
            )
        )
    return list(entity_by_id.values()), mentions


def _validated_relations(
    candidates: list[LLMRelationCandidate],
    *,
    chunk: ChildChunk,
    chunk_node: ChunkNode,
    entities: list[EntityNode],
    schema: OntologySchema,
    threshold: float,
) -> list[DomainRelation]:
    entity_by_id = {entity.entity_id: entity for entity in entities}
    entity_by_name = {(entity.name, entity.class_name): entity for entity in entities}
    entity_name_only = {entity.name: entity for entity in entities}
    relation_specs = {relation.name: relation for relation in schema.relations}
    relations: list[DomainRelation] = []
    seen: set[tuple[str, str, str, str]] = set()
    for candidate in candidates:
        relation_type = candidate.relation_type.strip()
        spec = relation_specs.get(relation_type)
        if spec is None or candidate.confidence < threshold:
            continue
        source = _resolve_relation_entity(candidate.source_entity_id, candidate.source_entity_name, entity_by_id, entity_by_name, entity_name_only)
        target = _resolve_relation_entity(candidate.target_entity_id, candidate.target_entity_name, entity_by_id, entity_by_name, entity_name_only)
        if source is None or target is None or source.entity_id == target.entity_id:
            continue
        if not _relation_matches_schema(spec, source.class_name, target.class_name):
            continue
        evidence_text = candidate.evidence_text.strip()
        if not evidence_text or not _evidence_is_backed(chunk.text, evidence_text, source.name, target.name):
            continue
        key = (relation_type, source.entity_id, target.entity_id, chunk_node.chunk_uid)
        if key in seen:
            continue
        seen.add(key)
        relations.append(
            DomainRelation(
                relation_id=build_relation_id(relation_type, source.entity_id, target.entity_id, chunk_node.chunk_uid),
                relation_type=relation_type,
                source_entity_id=source.entity_id,
                target_entity_id=target.entity_id,
                chunk_uid=chunk_node.chunk_uid,
                chunk_id=chunk.chunk_id,
                evidence_text=evidence_text,
                page_numbers=chunk.page_numbers,
                confidence=float(candidate.confidence),
            )
        )
    return relations


def _merge_chunk_results(
    results: list[KGExtractionResult],
    *,
    document_key: str,
    graph_dataset_key: str,
    collection_name: str,
    chunking_profile: str,
    mode: KGExtractionMode,
) -> KGExtractionResult:
    chunks: list[ChunkNode] = []
    entity_by_id: dict[str, EntityNode] = {}
    mentions: list[MentionEdge] = []
    mention_keys: set[tuple[str, str]] = set()
    relations: list[DomainRelation] = []
    relation_ids: set[str] = set()
    llm_chunk_count = 0
    llm_failed_chunk_count = 0
    fallback_chunk_count = 0
    fallback_reasons: dict[str, str] = {}

    for result in results:
        chunks.extend(result.chunks)
        llm_chunk_count += int(result.summary.get("llm_chunk_count") or 0)
        llm_failed_chunk_count += int(result.summary.get("llm_failed_chunk_count") or 0)
        fallback_chunk_count += int(result.summary.get("fallback_chunk_count") or 0)
        fallback_reasons.update(result.summary.get("fallback_reasons") or {})
        for entity in result.entities:
            existing = entity_by_id.get(entity.entity_id)
            if existing is None:
                entity_by_id[entity.entity_id] = entity.model_copy()
            else:
                existing.mention_count += entity.mention_count
                existing.aliases = _dedupe([*existing.aliases, *entity.aliases])
        for mention in result.mentions:
            key = (mention.chunk_uid, mention.entity_id)
            if key not in mention_keys:
                mention_keys.add(key)
                mentions.append(mention)
        for relation in result.relations:
            if relation.relation_id not in relation_ids:
                relation_ids.add(relation.relation_id)
                relations.append(relation)

    entities = sorted(entity_by_id.values(), key=lambda item: (item.class_name, item.normalized_name))
    class_counts = Counter(entity.class_name for entity in entities)
    relation_counts = Counter(relation.relation_type for relation in relations)
    return KGExtractionResult(
        document_key=document_key,
        chunks=chunks,
        entities=entities,
        mentions=mentions,
        relations=relations,
        summary={
            "document_key": document_key,
            "chunk_count": len(chunks),
            "entity_count": len(entities),
            "mention_count": len(mentions),
            "relation_count": len(relations),
            "class_counts": dict(sorted(class_counts.items())),
            "relation_counts": dict(sorted(relation_counts.items())),
            "extraction_policy": f"{mode}_ontology_extraction_v0.1",
            "graph_dataset_key": graph_dataset_key,
            "collection_name": collection_name,
            "chunking_profile": chunking_profile,
            "llm_chunk_count": llm_chunk_count,
            "llm_failed_chunk_count": llm_failed_chunk_count,
            "fallback_chunk_count": fallback_chunk_count,
            "fallback_reasons": fallback_reasons,
        },
    )


def _resolve_relation_entity(
    entity_id: str | None,
    entity_name: str | None,
    entity_by_id: dict[str, EntityNode],
    entity_by_name: dict[tuple[str, str], EntityNode],
    entity_name_only: dict[str, EntityNode],
) -> EntityNode | None:
    if entity_id and entity_id in entity_by_id:
        return entity_by_id[entity_id]
    if entity_name:
        if entity_name in entity_name_only:
            return entity_name_only[entity_name]
        for (name, _class_name), entity in entity_by_name.items():
            if _normalize_name(name) == _normalize_name(entity_name):
                return entity
    return None


def _relation_matches_schema(spec: OntologyRelationSpec, source_class: str, target_class: str) -> bool:
    return source_class in spec.domain and target_class in spec.range


def _schema_for_prompt(schema: OntologySchema) -> str:
    return json.dumps(schema.model_dump(mode="json"), ensure_ascii=False, indent=2)


def _chunk_metadata_for_prompt(chunk: ChildChunk, chunk_node: ChunkNode, meta: DocumentMeta) -> str:
    return json.dumps(
        {
            "chunk_uid": chunk_node.chunk_uid,
            "chunk_id": chunk.chunk_id,
            "document_key": meta.document_key,
            "file": meta.file,
            "page_numbers": chunk.page_numbers,
            "section_path": chunk.section_path,
            "parent_id": chunk.parent_id,
            "parent_idx": chunk.parent_idx,
            "child_idx": chunk.child_idx,
        },
        ensure_ascii=False,
        indent=2,
    )


def _invoke_llm(llm: Any, prompt: Any) -> Any:
    return llm.ainvoke(prompt) if hasattr(llm, "ainvoke") else llm.invoke(prompt)


async def _maybe_await(value: Any) -> Any:
    if inspect.isawaitable(value):
        return await value
    return value


def _message_content(message: Any) -> str:
    content = getattr(message, "content", message)
    if isinstance(content, list):
        return "\n".join(str(item.get("text") if isinstance(item, dict) else item) for item in content)
    return str(content)


def _parse_json_object(content: str) -> dict[str, Any]:
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", content, flags=re.DOTALL | re.IGNORECASE)
    if fenced:
        content = fenced.group(1)
    else:
        start = content.find("{")
        end = content.rfind("}")
        if start < 0 or end < start:
            raise ValueError("LLM response did not contain a JSON object")
        content = content[start : end + 1]
    payload = json.loads(content)
    if not isinstance(payload, dict):
        raise ValueError("LLM response JSON must be an object")
    return payload


def _evidence_is_backed(text: str, evidence_text: str, *anchors: str) -> bool:
    normalized_text = _normalize_for_evidence(text)
    normalized_evidence = _normalize_for_evidence(evidence_text)
    if normalized_evidence and normalized_evidence in normalized_text:
        return True
    return all(_normalize_for_evidence(anchor) in normalized_text for anchor in anchors if anchor)


def _normalize_for_evidence(value: str) -> str:
    return re.sub(r"\s+", "", value or "").lower()


def _normalize_name(value: str) -> str:
    return re.sub(r"[\s\W_]+", "", value or "").lower()


def _truncate(value: str, max_chars: int) -> str:
    value = value or ""
    if len(value) <= max_chars:
        return value
    return value[:max_chars].rsplit(" ", 1)[0].strip() or value[:max_chars]


def _dedupe(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        if value not in result:
            result.append(value)
    return result


def _chunk_cache_path(cache_dir: Path | None, chunk_uid: str) -> Path | None:
    if cache_dir is None:
        return None
    return cache_dir / f"{_safe_cache_name(chunk_uid)}.json"


def _load_cached_chunk_result(
    path: Path,
    *,
    mode: KGExtractionMode,
    graph_dataset_key: str,
    chunk_uid: str,
) -> KGExtractionResult | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("cache_version") != KG_CHUNK_CACHE_VERSION:
        return None
    if payload.get("mode") != mode:
        return None
    if payload.get("graph_dataset_key") != graph_dataset_key:
        return None
    if payload.get("chunk_uid") != chunk_uid:
        return None
    result = payload.get("result")
    if not isinstance(result, dict):
        return None
    return KGExtractionResult.model_validate(result)


def _write_cached_chunk_result(
    path: Path | None,
    result: KGExtractionResult,
    *,
    mode: KGExtractionMode,
    graph_dataset_key: str,
    chunk_uid: str,
    chunk_id: str,
    duration_ms: float,
) -> None:
    if path is None:
        return
    payload = {
        "cache_version": KG_CHUNK_CACHE_VERSION,
        "mode": mode,
        "graph_dataset_key": graph_dataset_key,
        "chunk_uid": chunk_uid,
        "chunk_id": chunk_id,
        "duration_ms": duration_ms,
        "created_at": _now_iso(),
        "result": result.model_dump(mode="json"),
    }
    _write_json_atomic(path, payload)


async def _record_progress(
    progress: dict[str, Any],
    lock: asyncio.Lock,
    progress_path: Path | None,
    events_path: Path | None,
    *,
    event: dict[str, Any],
    processed: bool = False,
    resumed: bool = False,
    failed: bool = False,
    duration_ms: float = 0.0,
) -> None:
    async with lock:
        progress["completed_chunk_count"] = int(progress.get("completed_chunk_count") or 0) + (0 if failed else 1)
        progress["processed_chunk_count"] = int(progress.get("processed_chunk_count") or 0) + (1 if processed else 0)
        progress["resumed_chunk_count"] = int(progress.get("resumed_chunk_count") or 0) + (1 if resumed else 0)
        progress["failed_chunk_count"] = int(progress.get("failed_chunk_count") or 0) + (1 if failed else 0)
        if processed:
            progress["processed_duration_ms"] = round(float(progress.get("processed_duration_ms") or 0.0) + duration_ms, 2)
        progress["last_event"] = {**event, "created_at": _now_iso()}
        _refresh_progress(progress)
        _write_progress(progress_path, progress)
        _append_jsonl(events_path, progress["last_event"])
        _log_kg_progress(progress, event=str(event.get("event") or "progress"))


def _initial_progress(
    *,
    document_key: str,
    graph_dataset_key: str,
    collection_name: str,
    chunking_profile: str,
    mode: KGExtractionMode,
    total_source_chunk_count: int,
    selected_offset: int,
    selected_limit: int | None,
    selected_chunk_count: int,
) -> dict[str, Any]:
    now = _now_iso()
    progress: dict[str, Any] = {
        "status": "running",
        "document_key": document_key,
        "graph_dataset_key": graph_dataset_key,
        "collection_name": collection_name,
        "chunking_profile": chunking_profile,
        "kg_extraction_mode": mode,
        "total_source_chunk_count": total_source_chunk_count,
        "selected_offset": selected_offset,
        "selected_limit": selected_limit,
        "selected_chunk_count": selected_chunk_count,
        "completed_chunk_count": 0,
        "processed_chunk_count": 0,
        "resumed_chunk_count": 0,
        "failed_chunk_count": 0,
        "processed_duration_ms": 0.0,
        "started_at": now,
        "started_timestamp_ms": round(time.time() * 1000, 2),
        "updated_at": now,
    }
    _refresh_progress(progress)
    return progress


def _refresh_progress(progress: dict[str, Any]) -> None:
    selected_count = int(progress.get("selected_chunk_count") or 0)
    completed_count = int(progress.get("completed_chunk_count") or 0)
    processed_count = int(progress.get("processed_chunk_count") or 0)
    remaining_count = max(0, selected_count - completed_count)
    processed_duration_ms = float(progress.get("processed_duration_ms") or 0.0)
    started_timestamp_ms = float(progress.get("started_timestamp_ms") or 0.0)
    avg_ms = round(processed_duration_ms / processed_count, 2) if processed_count else None
    progress["remaining_chunk_count"] = remaining_count
    progress["percent_complete"] = round((completed_count / selected_count) * 100, 2) if selected_count else 100.0
    progress["average_processed_chunk_duration_ms"] = avg_ms
    progress["estimated_remaining_ms"] = round(avg_ms * remaining_count, 2) if avg_ms is not None else None
    progress["elapsed_ms"] = round(time.time() * 1000 - started_timestamp_ms, 2) if started_timestamp_ms else None
    progress["updated_at"] = _now_iso()


def _write_progress(path: Path | None, progress: dict[str, Any]) -> None:
    if path is None:
        return
    _write_json_atomic(path, progress)


def _log_kg_progress(progress: dict[str, Any], *, event: str, **details: Any) -> None:
    completed = int(progress.get("completed_chunk_count") or 0)
    selected = int(progress.get("selected_chunk_count") or 0)
    percent = progress.get("percent_complete")
    last_event = progress.get("last_event") if isinstance(progress.get("last_event"), dict) else {}
    chunk_id = last_event.get("chunk_id")
    selection_index = last_event.get("selection_index")
    parts = [
        "[ingest][build_ontology_layer][kg]",
        event,
        f"{completed}/{selected} ({percent}%)",
    ]
    if selection_index is not None:
        parts.append(f"selection_index={selection_index}")
    if chunk_id:
        parts.append(f"chunk_id={chunk_id}")
    for key in (
        "processed_chunk_count",
        "resumed_chunk_count",
        "failed_chunk_count",
        "remaining_chunk_count",
        "estimated_remaining_ms",
    ):
        value = progress.get(key)
        if value is not None:
            parts.append(f"{key}={value}")
    for key, value in details.items():
        if value is not None:
            parts.append(f"{key}={value}")
    print(" ".join(parts), flush=True)


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(f"{path.name}.tmp")
    tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp_path.replace(path)


def _append_jsonl(path: Path | None, payload: dict[str, Any]) -> None:
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as file:
        file.write(json.dumps(payload, ensure_ascii=False) + "\n")


def _safe_cache_name(value: str) -> str:
    digest = hashlib.sha1(value.encode("utf-8")).hexdigest()[:16]
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_")
    return f"{safe[:80]}-{digest}"


def _duration_ms(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 2)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@lru_cache
def _load_entity_prompt() -> Any:
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning, message=r".*load_prompt.*")
        return load_prompt(ENTITY_PROMPT_PATH)


@lru_cache
def _load_relation_prompt() -> Any:
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning, message=r".*load_prompt.*")
        return load_prompt(RELATION_PROMPT_PATH)
