from __future__ import annotations

import json
import unicodedata
from pathlib import Path
from typing import Any

from app.services.schemas import DocumentMeta, RawElement


def load_parse_result(input_file: str | Path) -> tuple[list[RawElement], DocumentMeta]:
    path = Path(input_file)
    data = json.loads(path.read_text(encoding="utf-8"))
    elements = [RawElement.model_validate(payload) for payload in _extract_elements(data)]
    meta = _extract_meta(data, path)
    return elements, meta


def derive_document_key(path: str | Path) -> str:
    stem = Path(path).stem
    if stem.endswith(".parse_result"):
        stem = stem[: -len(".parse_result")]
    return unicodedata.normalize("NFC", stem)


def _extract_elements(data: dict[str, Any]) -> list[dict[str, Any]]:
    if isinstance(data.get("raw"), dict) and isinstance(data["raw"].get("elements"), list):
        return [_normalize_raw_element(payload, idx) for idx, payload in enumerate(data["raw"]["elements"])]
    if isinstance(data.get("elements"), list):
        return [_normalize_raw_element(payload, idx) for idx, payload in enumerate(data["elements"])]
    if isinstance(data.get("pages"), list):
        return _elements_from_pages(data["pages"])
    if isinstance(data.get("markdown_chunks"), list):
        return _elements_from_markdown_chunks(data["markdown_chunks"])
    if isinstance(data.get("markdown_pages"), list):
        return _elements_from_markdown_pages(data["markdown_pages"])
    if isinstance(data.get("markdown"), str):
        return [
            {
                "id": "markdown:0",
                "type": "text",
                "text": data["markdown"],
                "metadata": {"source": "markdown"},
            }
        ]
    raise ValueError("parse result must contain raw.elements, elements, pages, markdown_chunks, markdown_pages, or markdown")


def _elements_from_pages(pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    elements: list[dict[str, Any]] = []
    for page_index, page in enumerate(pages, start=1):
        page_number = _coerce_int(page.get("page_number") or page.get("page") or page.get("pageNo"), page_index)
        page_elements = page.get("elements")
        if not isinstance(page_elements, list):
            content = page.get("content") or page.get("markdown") or ""
            if content:
                elements.append(
                    {
                        "id": f"page:{page_number}",
                        "type": "text",
                        "text": str(content),
                        "page_number": page_number,
                        "metadata": {"source": "pages", "page_number": page_number},
                    }
                )
            continue
        sorted_elements = sorted(
            enumerate(page_elements),
            key=lambda item: (_coerce_int(item[1].get("layout_order"), item[0]), item[0]),
        )
        for element_index, element in sorted_elements:
            category = str(element.get("category") or element.get("type") or "Text")
            content = str(element.get("content") or element.get("text") or "")
            if not content.strip():
                continue
            element_type = _category_to_type(category)
            html = content if element_type == "table" and content.lstrip().startswith("<") else None
            metadata = {
                "source": "pages.elements",
                "raw_category": category,
                "layout_order": element.get("layout_order"),
                "bbox": element.get("bbox"),
                "added_element": element.get("added_element"),
                "picture_path": element.get("picture_path"),
                "document_type": page.get("document_type"),
            }
            elements.append(
                {
                    "id": f"p{page_number}:e{element_index}",
                    "type": element_type,
                    "text": content,
                    "html": html,
                    "page_number": page_number,
                    "metadata": {key: value for key, value in metadata.items() if value is not None},
                }
            )
    return elements


def _elements_from_markdown_chunks(markdown_chunks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    elements: list[dict[str, Any]] = []
    for idx, chunk in enumerate(markdown_chunks):
        page_start = _coerce_int(chunk.get("page_start") or chunk.get("page_statrt"), idx + 1)
        page_end = _coerce_int(chunk.get("page_end"), page_start)
        content = str(chunk.get("content") or chunk.get("context") or "")
        if not content.strip():
            continue
        elements.append(
            {
                "id": f"markdown_chunk:{chunk.get('chunk_index', idx)}",
                "type": "text",
                "text": content,
                "page_number": page_start,
                "metadata": {
                    "source": "markdown_chunks",
                    "chunk_index": chunk.get("chunk_index", idx),
                    "page_start": page_start,
                    "page_end": page_end,
                    "char_count": chunk.get("char_count") or chunk.get("chat_count"),
                    "element_count": chunk.get("element_count"),
                },
            }
        )
    return elements


def _elements_from_markdown_pages(markdown_pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    elements: list[dict[str, Any]] = []
    for idx, page in enumerate(markdown_pages, start=1):
        page_number = _coerce_int(page.get("page_number"), idx)
        content = str(page.get("content") or "")
        if not content.strip():
            continue
        elements.append(
            {
                "id": f"markdown_page:{page_number}",
                "type": "text",
                "text": content,
                "page_number": page_number,
                "metadata": {
                    "source": "markdown_pages",
                    "page_number": page_number,
                    "char_count": page.get("char_count"),
                    "element_count": page.get("element_count"),
                },
            }
        )
    return elements


def _normalize_raw_element(payload: dict[str, Any], idx: int) -> dict[str, Any]:
    normalized = dict(payload)
    normalized.setdefault("id", payload.get("id") or idx)
    normalized.setdefault("type", payload.get("type") or _category_to_type(str(payload.get("category") or "Text")))
    normalized.setdefault("text", payload.get("text") or payload.get("content") or "")
    if "page_number" not in normalized:
        normalized["page_number"] = payload.get("page") or payload.get("pageNo")
    metadata = dict(payload.get("metadata") or {})
    for key in ("category", "bbox", "layout_order", "added_element", "picture_path"):
        if key in payload and key not in metadata:
            metadata[key] = payload[key]
    normalized["metadata"] = metadata
    return normalized


def _extract_meta(data: dict[str, Any], path: Path) -> DocumentMeta:
    meta_payload = dict(data.get("meta") or {})
    meta_payload.setdefault("document_key", derive_document_key(path))
    meta_payload.setdefault("file", data.get("doc_name") or path.name)
    meta_payload["parse_result_path"] = str(path)
    meta_payload["doc_name"] = data.get("doc_name") or meta_payload.get("doc_name")
    for key in (
        "total_pages",
        "total_elements",
        "table_element_count",
        "picture_element_count",
        "page_integrity",
    ):
        if key in data and key not in meta_payload:
            meta_payload[key] = data[key]
    meta_payload["metadata"] = {
        "status": data.get("status"),
        "success": data.get("success"),
        "num_errors": data.get("num_errors"),
        "errors": data.get("errors") or [],
        "total_tokens": data.get("total_tokens"),
    }
    return DocumentMeta.model_validate(meta_payload)


def _category_to_type(category: str) -> str:
    normalized = category.strip().lower()
    if normalized in {"section-header", "heading", "header"}:
        return "heading"
    if normalized == "caption":
        return "caption"
    if normalized == "table":
        return "table"
    return "text"


def _coerce_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
