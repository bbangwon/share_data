from __future__ import annotations

import re

_TOKEN_RE = re.compile(r"[0-9A-Za-z가-힣]+")


def tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text)


def count_tokens(text: str) -> int:
    normalized = text.strip()
    if not normalized:
        return 0
    return max(len(tokenize(normalized)), max(1, len(normalized) // 2))
