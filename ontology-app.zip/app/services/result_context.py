from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ResultTextContext:
    text: str
    source: str
    expanded: bool
    original_text: str


def build_result_text_context(
    payload: dict[str, Any],
    *,
    min_chars: int,
    max_chars: int,
    use_parent_text: bool,
    use_page_text: bool,
    use_neighbor_text: bool = False,
    ignore_categories: tuple[str, ...] = (),
) -> ResultTextContext:
    original_text = _payload_text(payload, "text")
    if len(original_text) >= min_chars:
        return ResultTextContext(
            text=original_text,
            source="chunk_text",
            expanded=False,
            original_text=original_text,
        )

    parent_text = ""
    if use_parent_text:
        parent_text = _payload_text(payload, "parent_text")
        if len(parent_text) >= min_chars and len(parent_text) > len(original_text):
            return ResultTextContext(
                text=_limit_text(parent_text, max_chars),
                source="parent_text",
                expanded=True,
                original_text=original_text,
            )

    neighbor_text = ""
    if use_neighbor_text:
        neighbor_text = _payload_text(payload, "neighbor_text")
        if len(neighbor_text) >= min_chars and len(neighbor_text) > len(original_text):
            return ResultTextContext(
                text=_limit_text(neighbor_text, max_chars),
                source="neighbor_text",
                expanded=True,
                original_text=original_text,
            )

    page_text = ""
    if use_page_text:
        page_text = load_payload_page_text(
            payload,
            max_page_text_chars=max_chars,
            ignore_categories=ignore_categories,
        )
        if len(page_text) > len(original_text):
            return ResultTextContext(
                text=_limit_text(page_text, max_chars),
                source="page_text",
                expanded=True,
                original_text=original_text,
            )

    if len(parent_text) > len(original_text):
        return ResultTextContext(
            text=_limit_text(parent_text, max_chars),
            source="parent_text",
            expanded=True,
            original_text=original_text,
        )

    if len(neighbor_text) > len(original_text):
        return ResultTextContext(
            text=_limit_text(neighbor_text, max_chars),
            source="neighbor_text",
            expanded=True,
            original_text=original_text,
        )

    return ResultTextContext(
        text=original_text,
        source="chunk_text",
        expanded=False,
        original_text=original_text,
    )


def load_payload_page_text(
    payload: dict[str, Any],
    *,
    max_page_text_chars: int,
    ignore_categories: tuple[str, ...] = (),
) -> str:
    path = resolve_parse_result_path(payload)
    if path is None:
        return ""
    page_texts = load_parse_result_page_texts(
        path,
        max_page_text_chars=max_page_text_chars,
        ignore_categories=ignore_categories,
    )
    page_numbers = _coerce_page_numbers(payload.get("page_numbers") or [])
    if not page_numbers:
        return ""
    return "\n\n".join(page_texts[page] for page in page_numbers if page in page_texts).strip()


def resolve_parse_result_path(payload: dict[str, Any]) -> Path | None:
    value = payload.get("parse_result_path")
    if not value:
        return None
    path = Path(str(value))
    if path.suffix.lower() != ".json":
        return None
    return path if path.exists() else None


def load_parse_result_page_texts(
    parse_result_path: str | Path,
    *,
    max_page_text_chars: int | None = None,
    ignore_categories: tuple[str, ...] = (),
) -> dict[int, str]:
    path = Path(parse_result_path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}

    ignored = {category.lower() for category in ignore_categories}
    pages = _page_texts_from_pages(data.get("pages"), ignored=ignored)
    _merge_missing_pages(pages, _page_texts_from_markdown_pages(data.get("markdown_pages")))
    if not pages:
        pages = _page_texts_from_elements(data.get("elements"), ignored=ignored)
    if not pages and isinstance(data.get("raw"), dict):
        pages = _page_texts_from_elements(data["raw"].get("elements"), ignored=ignored)
    if not pages:
        pages = _page_texts_from_markdown_chunks(data.get("markdown_chunks"))

    if max_page_text_chars is not None and max_page_text_chars > 0:
        return {page: text[:max_page_text_chars] for page, text in pages.items()}
    return pages


def _page_texts_from_pages(value: Any, *, ignored: set[str]) -> dict[int, str]:
    if not isinstance(value, list):
        return {}

    pages: dict[int, str] = {}
    for page_index, page in enumerate(value, start=1):
        if not isinstance(page, dict):
            continue
        page_number = _coerce_int(page.get("page_number") or page.get("page") or page.get("pageNo"), page_index)
        elements = page.get("elements")
        if isinstance(elements, list):
            parts = _texts_from_page_elements(elements, ignored=ignored)
        else:
            parts = [_first_text(page, ("content", "markdown", "text"))]
        text = "\n".join(part for part in parts if part).strip()
        if text:
            pages[page_number] = text
    return pages


def _texts_from_page_elements(elements: list[Any], *, ignored: set[str]) -> list[str]:
    sorted_elements = sorted(
        (element for element in elements if isinstance(element, dict)),
        key=lambda element: (_coerce_int(element.get("layout_order"), 0), str(element.get("content") or "")),
    )
    parts: list[str] = []
    for element in sorted_elements:
        category = str(element.get("category") or element.get("type") or "").lower()
        if category in ignored:
            continue
        text = _first_text(element, ("content", "text", "markdown", "html"))
        if text:
            parts.append(text)
    return parts


def _page_texts_from_markdown_pages(value: Any) -> dict[int, str]:
    if not isinstance(value, list):
        return {}
    pages: dict[int, str] = {}
    for index, page in enumerate(value, start=1):
        if not isinstance(page, dict):
            continue
        page_number = _coerce_int(page.get("page_number"), index)
        text = _first_text(page, ("content", "markdown", "text"))
        if text:
            pages[page_number] = text
    return pages


def _page_texts_from_elements(value: Any, *, ignored: set[str]) -> dict[int, str]:
    if not isinstance(value, list):
        return {}
    parts_by_page: dict[int, list[str]] = {}
    for index, element in enumerate(value):
        if not isinstance(element, dict):
            continue
        category = str(element.get("category") or element.get("type") or "").lower()
        if category in ignored:
            continue
        page_number = _coerce_int(
            element.get("page_number") or element.get("page") or element.get("pageNo"),
            index + 1,
        )
        text = _first_text(element, ("text", "content", "markdown", "html"))
        if text:
            parts_by_page.setdefault(page_number, []).append(text)
    return {page: "\n".join(parts).strip() for page, parts in parts_by_page.items() if parts}


def _page_texts_from_markdown_chunks(value: Any) -> dict[int, str]:
    if not isinstance(value, list):
        return {}
    pages: dict[int, str] = {}
    for index, chunk in enumerate(value, start=1):
        if not isinstance(chunk, dict):
            continue
        page_number = _coerce_int(chunk.get("page_start") or chunk.get("page_statrt"), index)
        text = _first_text(chunk, ("content", "context", "markdown", "text"))
        if text:
            pages.setdefault(page_number, text)
    return pages


def _merge_missing_pages(target: dict[int, str], fallback: dict[int, str]) -> None:
    for page, text in fallback.items():
        target.setdefault(page, text)


def _first_text(source: dict[str, Any], keys: tuple[str, ...]) -> str:
    for key in keys:
        value = source.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _payload_text(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if value is None:
        return ""
    if isinstance(value, list):
        return " ".join(str(item) for item in value if item is not None).strip()
    return str(value).strip()


def _coerce_page_numbers(value: list[Any]) -> list[int]:
    pages: list[int] = []
    seen: set[int] = set()
    for item in value:
        try:
            page = int(item)
        except (TypeError, ValueError):
            continue
        if page in seen:
            continue
        pages.append(page)
        seen.add(page)
    return pages


def _coerce_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _limit_text(text: str, max_chars: int) -> str:
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip()
