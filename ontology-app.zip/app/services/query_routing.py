from __future__ import annotations

import inspect
import json
import re
import warnings
from functools import lru_cache
from typing import Any, Literal

from langchain_core.prompts import load_prompt
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field

from app.core.config import Settings

GraphMode = Literal["hybrid", "graph", "auto"]
QueryType = Literal[
    "factual",
    "semantic",
    "multi_hop",
    "aggregation",
    "temporal",
    "comparison",
    "causal",
    "relationship",
]
SelectedRetrieval = Literal["hybrid", "hybrid_graph"]

GRAPH_QUERY_TYPES: set[str] = {
    "relationship",
    "multi_hop",
    "aggregation",
    "temporal",
    "comparison",
    "causal",
}


class QueryRoutingDecision(BaseModel):
    graph_mode: GraphMode
    selected_retrieval: SelectedRetrieval
    query_types: list[QueryType]
    confidence: float = Field(ge=0.0, le=1.0)
    reasons: list[str]
    graph_activated: bool
    router: str = "rule_based"


def resolve_graph_mode(
    *,
    graph_mode: GraphMode | None,
    use_graph: bool | None,
    graph_search_enabled: bool,
    query_routing_enabled: bool,
) -> GraphMode:
    if graph_mode is not None:
        return graph_mode
    if use_graph is not None:
        return "graph" if use_graph else "hybrid"
    if query_routing_enabled:
        return "auto"
    return "graph" if graph_search_enabled else "hybrid"


async def route_query(
    *,
    query: str,
    graph_mode: GraphMode,
    settings: Settings,
    llm: Any | None = None,
) -> QueryRoutingDecision:
    decision = route_query_rule_based(
        query=query,
        graph_mode=graph_mode,
        graph_activation_threshold=settings.query_routing.graph_activation_threshold,
    )
    if (
        graph_mode == "auto"
        and settings.query_routing.llm_enabled
        and decision.confidence < settings.query_routing.llm_confidence_threshold
    ):
        try:
            return await _route_query_with_llm(
                query=query,
                settings=settings,
                llm=llm,
                fallback=decision,
            )
        except Exception as exc:
            return decision.model_copy(
                update={
                    "reasons": [
                        *decision.reasons,
                        f"LLM router fallback failed: {exc}",
                    ]
                }
            )
    return decision


def route_query_rule_based(
    *,
    query: str,
    graph_mode: GraphMode,
    graph_activation_threshold: float = 0.70,
) -> QueryRoutingDecision:
    if graph_mode == "hybrid":
        return QueryRoutingDecision(
            graph_mode=graph_mode,
            selected_retrieval="hybrid",
            query_types=["factual"],
            confidence=1.0,
            reasons=["graph_mode=hybrid로 그래프 확장을 명시적으로 비활성화했습니다."],
            graph_activated=False,
        )
    if graph_mode == "graph":
        query_types, reasons = _classify_query(query)
        confidence = _confidence(query_types)
        return QueryRoutingDecision(
            graph_mode=graph_mode,
            selected_retrieval="hybrid_graph",
            query_types=query_types,
            confidence=confidence,
            reasons=[
                *reasons,
                "graph_mode=graph로 그래프 확장을 명시적으로 활성화했습니다.",
            ],
            graph_activated=True,
        )

    query_types, reasons = _classify_query(query)
    confidence = _confidence(query_types)
    should_use_graph = (
        confidence >= graph_activation_threshold
        and bool(set(query_types).intersection(GRAPH_QUERY_TYPES))
    )
    selected_retrieval: SelectedRetrieval = "hybrid_graph" if should_use_graph else "hybrid"
    if not reasons:
        reasons = ["명확한 graph query signal이 없어 HybridRAG만 사용합니다."]
    elif should_use_graph:
        reasons = [*reasons, "graph query signal이 임계값을 넘어 Neo4j graph expansion을 사용합니다."]
    else:
        reasons = [*reasons, "graph query signal이 약해 HybridRAG만 사용합니다."]
    return QueryRoutingDecision(
        graph_mode=graph_mode,
        selected_retrieval=selected_retrieval,
        query_types=query_types,
        confidence=confidence,
        reasons=reasons,
        graph_activated=should_use_graph,
    )


def _classify_query(query: str) -> tuple[list[QueryType], list[str]]:
    text = _normalize_query(query)
    query_types: list[QueryType] = []
    reasons: list[str] = []

    if _contains_any(text, ("관계", "연관", "관련", "협조", "협업", "지원", "연계", "보고", "전파", "요청", "연락망", "편성")):
        query_types.append("relationship")
        reasons.append("관계/협업/보고/연계 질의 패턴을 감지했습니다.")
    if _contains_any(text, ("누가", "어느 부서", "어떤 부서", "기관", "부서", "담당", "역할", "임무", "책임")) and _contains_any(
        text, ("조치", "대응", "지원", "보고", "전파", "협조", "수행", "편성", "관계", "역할")
    ):
        query_types.append("multi_hop")
        reasons.append("담당 주체와 조치/업무를 함께 묻는 multi-hop 패턴을 감지했습니다.")
    if _contains_any(text, ("목록", "전체", "모두", "종류", "몇 가지", "어떤 것", "나열", "정리")):
        query_types.append("aggregation")
        reasons.append("여러 근거를 모아야 하는 aggregation 패턴을 감지했습니다.")
    if _contains_any(text, ("언제", "이후", "이전", "전후", "순서", "단계", "시점", "즉시", "종료 후")):
        query_types.append("temporal")
        reasons.append("단계/순서/시점 질의 패턴을 감지했습니다.")
    if _contains_any(text, ("차이", "비교", "구분", "각각", "반면", "대비", "다른 점")):
        query_types.append("comparison")
        reasons.append("비교/구분 질의 패턴을 감지했습니다.")
    if _contains_any(text, ("왜", "원인", "이유", "때문", "근거", "목적")):
        query_types.append("causal")
        reasons.append("원인/이유/근거 질의 패턴을 감지했습니다.")
    if _contains_any(text, ("무엇", "뭐", "정의", "의미", "설명", "개념")):
        query_types.append("semantic")
        reasons.append("정의/의미 설명 질의 패턴을 감지했습니다.")

    if _looks_like_simple_fact(text, query_types):
        query_types.append("factual")
        reasons.append("단일 사실 확인 질의 패턴을 감지했습니다.")

    if not query_types:
        query_types.append("factual")
    return _dedupe_query_types(query_types), reasons


def _confidence(query_types: list[QueryType]) -> float:
    weights = {
        "factual": 0.35,
        "semantic": 0.50,
        "aggregation": 0.70,
        "temporal": 0.72,
        "causal": 0.72,
        "comparison": 0.74,
        "relationship": 0.78,
        "multi_hop": 0.82,
    }
    score = max(weights[item] for item in query_types)
    graph_type_count = len(set(query_types).intersection(GRAPH_QUERY_TYPES))
    if graph_type_count > 1:
        score += min(0.14, 0.04 * (graph_type_count - 1))
    return round(min(0.95, score), 2)


async def _route_query_with_llm(
    *,
    query: str,
    settings: Settings,
    fallback: QueryRoutingDecision,
    llm: Any | None,
) -> QueryRoutingDecision:
    if not settings.llm.base_url or not settings.llm.model_name:
        return fallback
    prompt = _load_prompt(str(settings.query_routing.llm_prompt_path)).format_prompt(query=query)
    client = llm or ChatOpenAI(
        model=settings.llm.model_name,
        base_url=settings.llm.base_url,
        timeout=settings.llm.timeout,
        temperature=0.0,
        api_key=settings.llm.api_key.get_secret_value(),
    )
    response = client.ainvoke(prompt) if hasattr(client, "ainvoke") else client.invoke(prompt)
    message = await response if inspect.isawaitable(response) else response
    payload = _parse_json_object(_message_content(message))
    decision = QueryRoutingDecision.model_validate(
        {
            "graph_mode": "auto",
            "selected_retrieval": payload.get("selected_retrieval"),
            "query_types": payload.get("query_types"),
            "confidence": payload.get("confidence"),
            "reasons": payload.get("reasons"),
            "graph_activated": payload.get("selected_retrieval") == "hybrid_graph",
            "router": "llm",
        }
    )
    if (
        decision.selected_retrieval == "hybrid_graph"
        and decision.confidence < settings.query_routing.graph_activation_threshold
    ):
        return decision.model_copy(
            update={
                "selected_retrieval": "hybrid",
                "graph_activated": False,
                "reasons": [
                    *decision.reasons,
                    "LLM router confidence가 graph activation threshold보다 낮아 HybridRAG만 사용합니다.",
                ],
            }
        )
    return decision


@lru_cache(maxsize=8)
def _load_prompt(path: str) -> Any:
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning, message=r".*load_prompt.*")
        return load_prompt(path)


def _parse_json_object(content: str) -> dict[str, Any]:
    text = content.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text, flags=re.IGNORECASE).strip()
        text = re.sub(r"```$", "", text).strip()
    return json.loads(text)


def _message_content(message: Any) -> str:
    content = getattr(message, "content", message)
    if isinstance(content, list):
        return "\n".join(str(item) for item in content)
    return str(content or "")


def _normalize_query(query: str) -> str:
    return re.sub(r"\s+", " ", query.strip().lower())


def _contains_any(text: str, terms: tuple[str, ...]) -> bool:
    return any(term in text for term in terms)


def _looks_like_simple_fact(text: str, query_types: list[QueryType]) -> bool:
    if set(query_types).intersection(GRAPH_QUERY_TYPES):
        return False
    return text.endswith("?") or text.endswith("나요") or text.endswith("니까") or text.endswith("인가")


def _dedupe_query_types(values: list[QueryType]) -> list[QueryType]:
    ordered: list[QueryType] = []
    for value in values:
        if value not in ordered:
            ordered.append(value)
    return ordered
