from __future__ import annotations

import asyncio
import inspect
import time
import uuid
from collections.abc import Mapping, Sequence
from typing import Any

from qdrant_client import AsyncQdrantClient, models

from app.core.config import Settings, get_settings
from app.services.chunk_identity import chunk_identity_payload


def build_point_id(document_key: str, chunk_id: str, *, ingest_version: str | None = None) -> str:
    version_part = f"{ingest_version}:" if ingest_version else ""
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"graphrag-was:{document_key}:{version_part}{chunk_id}"))


def build_payload_indexes() -> dict[str, str]:
    return {
        "chunk_type": "keyword",
        "chunk_uid": "keyword",
        "chunk_id": "keyword",
        "graph_dataset_key": "keyword",
        "document_key": "keyword",
        "collection_name": "keyword",
        "chunking_profile": "keyword",
        "parent_id": "keyword",
        "parent_idx": "integer",
        "child_idx": "integer",
        "section_path": "text",
        "section_title": "keyword",
        "section_level": "integer",
        "file": "keyword",
        "doc_name": "keyword",
        "ingest_status": "keyword",
        "ingest_version": "keyword",
        "ingest_epoch_ns": "integer",
        "page_numbers": "integer",
        "page_start": "integer",
        "page_end": "integer",
    }


class QdrantStore:
    def __init__(
        self,
        *,
        client: Any | None = None,
        settings: Settings | None = None,
        collection_name: str | None = None,
        dense_name: str | None = None,
        sparse_name: str | None = None,
        dense_vector_size: int | None = None,
    ) -> None:
        settings = settings or get_settings()
        self.collection_name = collection_name or settings.qdrant.collection_name
        self.dense_name = dense_name or settings.qdrant.dense_name
        self.sparse_name = sparse_name or settings.qdrant.sparse_name
        configured_size = dense_vector_size or settings.qdrant.dense_vector_size
        if configured_size is None:
            raise ValueError("dense_vector_size is required before creating or validating a Qdrant collection")
        self.dense_vector_size = int(configured_size)
        self.upload_batch_size = int(settings.qdrant.upload_batch_size)
        self.upload_max_retries = int(settings.qdrant.upload_max_retries)
        self._document_locks: dict[str, asyncio.Lock] = {}
        self.client = client or AsyncQdrantClient(
            host=settings.qdrant.host,
            port=settings.qdrant.port,
            timeout=settings.qdrant.timeout,
            check_compatibility=False,
        )

    async def ensure_collection(self) -> None:
        if hasattr(self.client, "collection_exists"):
            exists = await self.client.collection_exists(collection_name=self.collection_name)
            if not exists:
                await self._create_collection()
            elif hasattr(self.client, "get_collection"):
                await self._validate_collection()
        elif hasattr(self.client, "get_collection"):
            try:
                await self._validate_collection()
            except Exception as exc:
                if not _is_not_found_error(exc):
                    raise
                await self._create_collection()
        elif hasattr(self.client, "create_collection"):
            await self._create_collection()
        await self._ensure_payload_indexes()

    async def recreate_collection(self) -> dict[str, Any]:
        existed = await self._collection_exists()
        if existed:
            if not hasattr(self.client, "delete_collection"):
                raise AttributeError("Qdrant client must expose delete_collection to reset a collection")
            await self.client.delete_collection(collection_name=self.collection_name)
        await self._create_collection()
        await self._ensure_payload_indexes()
        return {
            "collection_name": self.collection_name,
            "deleted_existing": existed,
            "created": True,
            "dense_name": self.dense_name,
            "sparse_name": self.sparse_name,
            "dense_vector_size": self.dense_vector_size,
        }

    async def _collection_exists(self) -> bool:
        if hasattr(self.client, "collection_exists"):
            return bool(await self.client.collection_exists(collection_name=self.collection_name))
        if hasattr(self.client, "get_collection"):
            try:
                await self.client.get_collection(collection_name=self.collection_name)
                return True
            except Exception as exc:
                if _is_not_found_error(exc):
                    return False
                raise
        return False

    async def has_current_document(self, document_key: str) -> bool:
        response = await self.client.scroll(
            collection_name=self.collection_name,
            scroll_filter=models.Filter(
                must=[
                    models.FieldCondition(key="document_key", match=models.MatchValue(value=document_key)),
                    models.FieldCondition(key="ingest_status", match=models.MatchValue(value="current")),
                ]
            ),
            limit=1,
            with_payload=False,
            with_vectors=False,
        )
        points = response[0] if isinstance(response, tuple) else getattr(response, "points", [])
        return bool(points)

    async def upsert_document(self, document_key: str, embedded: Sequence[Any]) -> dict[str, Any]:
        if not embedded:
            raise ValueError("embedded chunks must not be empty")
        async with self._document_lock(document_key):
            return await self._upsert_document_locked(document_key, embedded)

    async def _upsert_document_locked(self, document_key: str, embedded: Sequence[Any]) -> dict[str, Any]:
        ingest_version = uuid.uuid4().hex
        ingest_epoch_ns = time.time_ns()
        points = [
            self._point(document_key, item, ingest_version=ingest_version, ingest_epoch_ns=ingest_epoch_ns)
            for item in embedded
        ]
        if hasattr(self.client, "get_collection"):
            await self._validate_collection()

        succeeded = 0
        for batch in _batches(points, max(1, self.upload_batch_size)):
            await self._upsert_batch(batch)
            succeeded += len(batch)

        point_ids = [point.id for point in points]
        await self.mark_stale_by_document_key(document_key, exclude_point_ids=point_ids)
        try:
            await self._mark_points_current(point_ids, ingest_version=ingest_version, ingest_epoch_ns=ingest_epoch_ns)
        except Exception as exc:
            try:
                await self.mark_current_by_document_key(document_key, exclude_point_ids=point_ids)
            except Exception as rollback_exc:
                if hasattr(exc, "add_note"):
                    exc.add_note(f"stale rollback failed: {rollback_exc!r}")
            raise
        await self.delete_stale_by_document_key(document_key, keep_point_ids=point_ids)
        return {
            "total": len(points),
            "succeeded": succeeded,
            "failed": len(points) - succeeded,
            "ingest_version": ingest_version,
            "ingest_epoch_ns": ingest_epoch_ns,
        }

    def _document_lock(self, document_key: str) -> asyncio.Lock:
        lock = self._document_locks.get(document_key)
        if lock is None:
            lock = asyncio.Lock()
            self._document_locks[document_key] = lock
        return lock

    async def delete_by_document_key(self, document_key: str) -> None:
        await self.client.delete(
            collection_name=self.collection_name,
            points_selector=_document_filter(document_key),
            wait=True,
        )

    async def delete_stale_by_document_key(self, document_key: str, *, keep_point_ids: Sequence[str | int]) -> None:
        await self.client.delete(
            collection_name=self.collection_name,
            points_selector=_document_filter(document_key, exclude_point_ids=keep_point_ids),
            wait=True,
        )

    async def mark_stale_by_document_key(self, document_key: str, *, exclude_point_ids: Sequence[str | int]) -> None:
        await self.client.set_payload(
            collection_name=self.collection_name,
            payload={"ingest_status": "stale"},
            points=_document_filter(document_key, exclude_point_ids=exclude_point_ids),
            wait=True,
        )

    async def mark_current_by_document_key(self, document_key: str, *, exclude_point_ids: Sequence[str | int]) -> None:
        await self.client.set_payload(
            collection_name=self.collection_name,
            payload={"ingest_status": "current"},
            points=_document_filter(document_key, exclude_point_ids=exclude_point_ids),
            wait=True,
        )

    async def _mark_points_current(
        self,
        point_ids: Sequence[str | int],
        *,
        ingest_version: str,
        ingest_epoch_ns: int,
    ) -> None:
        await self.client.set_payload(
            collection_name=self.collection_name,
            payload={
                "ingest_status": "current",
                "ingest_version": ingest_version,
                "ingest_epoch_ns": ingest_epoch_ns,
            },
            points=list(point_ids),
            wait=True,
        )

    async def close(self) -> None:
        if hasattr(self.client, "close"):
            result = self.client.close()
            if inspect.isawaitable(result):
                await result

    async def _create_collection(self) -> None:
        await self.client.create_collection(
            collection_name=self.collection_name,
            vectors_config={
                self.dense_name: models.VectorParams(
                    size=self.dense_vector_size,
                    distance=models.Distance.COSINE,
                )
            },
            sparse_vectors_config={self.sparse_name: models.SparseVectorParams()},
        )

    async def _upsert_batch(self, points: Sequence[models.PointStruct]) -> None:
        last_error: Exception | None = None
        for attempt in range(self.upload_max_retries + 1):
            try:
                await self.client.upsert(
                    collection_name=self.collection_name,
                    points=list(points),
                    wait=True,
                )
                return
            except Exception as exc:
                last_error = exc
                if attempt >= self.upload_max_retries:
                    raise
        if last_error is not None:
            raise last_error

    async def _validate_collection(self) -> None:
        info = await self.client.get_collection(collection_name=self.collection_name)
        vectors = _as_mapping(_dig(info, "config", "params", "vectors"))
        sparse_vectors = _as_mapping(_dig(info, "config", "params", "sparse_vectors"))

        if vectors and "size" in vectors:
            raise ValueError("Qdrant collection must use named dense vectors")
        dense_config = vectors.get(self.dense_name)
        if dense_config is None:
            raise ValueError(f"Qdrant collection missing dense vector {self.dense_name!r}")
        size = _dig(dense_config, "size")
        if size is not None and int(size) != self.dense_vector_size:
            raise ValueError(
                f"Qdrant dense vector {self.dense_name!r} size mismatch: "
                f"expected {self.dense_vector_size}, got {size}"
            )
        distance = _dig(dense_config, "distance")
        if distance is not None and _normalize_distance(distance) != "cosine":
            raise ValueError(
                f"Qdrant dense vector {self.dense_name!r} distance mismatch: "
                f"expected cosine, got {distance}"
            )
        if not sparse_vectors or self.sparse_name not in sparse_vectors:
            raise ValueError(f"Qdrant collection missing sparse vector {self.sparse_name!r}")

    async def _ensure_payload_indexes(self) -> None:
        if not hasattr(self.client, "create_payload_index"):
            return
        for field_name, schema_name in build_payload_indexes().items():
            try:
                await self.client.create_payload_index(
                    collection_name=self.collection_name,
                    field_name=field_name,
                    field_schema=models.PayloadSchemaType(schema_name),
                    wait=True,
                )
            except Exception as exc:
                if "already exists" not in str(exc).lower():
                    raise

    def _point(
        self,
        document_key: str,
        embedded: Any,
        *,
        ingest_version: str,
        ingest_epoch_ns: int,
    ) -> models.PointStruct:
        payload = dict(embedded.payload)
        payload["document_key"] = document_key
        chunking_profile = str(payload.get("chunking_profile") or payload.get("transform_version") or "").strip()
        if chunking_profile:
            payload.update(
                chunk_identity_payload(
                    document_key=document_key,
                    collection_name=self.collection_name,
                    chunking_profile=chunking_profile,
                    chunk_id=str(embedded.chunk_id),
                )
            )
        payload["ingest_status"] = "staging"
        payload["ingest_version"] = ingest_version
        payload["ingest_epoch_ns"] = ingest_epoch_ns
        return models.PointStruct(
            id=build_point_id(document_key, embedded.chunk_id, ingest_version=ingest_version),
            vector={
                self.dense_name: list(embedded.dense_vector),
                self.sparse_name: _sparse_vector(embedded.sparse_vector),
            },
            payload=payload,
        )


def _document_filter(document_key: str, *, exclude_point_ids: Sequence[str | int] = ()) -> models.Filter:
    must_not = None
    if exclude_point_ids:
        must_not = [models.HasIdCondition(has_id=list(exclude_point_ids))]
    return models.Filter(
        must=[
            models.FieldCondition(
                key="document_key",
                match=models.MatchValue(value=document_key),
            )
        ],
        must_not=must_not,
    )


def _sparse_vector(value: Mapping[str, Sequence[int | float]]) -> models.SparseVector:
    return models.SparseVector(
        indices=[int(index) for index in value.get("indices", [])],
        values=[float(weight) for weight in value.get("values", [])],
    )


def _batches(points: Sequence[models.PointStruct], batch_size: int) -> list[Sequence[models.PointStruct]]:
    return [points[index : index + batch_size] for index in range(0, len(points), batch_size)]


def _is_not_found_error(exc: Exception) -> bool:
    status_code = getattr(exc, "status_code", None)
    response = getattr(exc, "response", None)
    if response is not None:
        status_code = getattr(response, "status_code", status_code)
    if status_code == 404:
        return True
    message = str(exc).lower()
    return "not found" in message or "does not exist" in message or "doesn't exist" in message


def _as_mapping(value: Any) -> Mapping[str, Any]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return value
    if hasattr(value, "model_dump"):
        dumped = value.model_dump()
        return dumped if isinstance(dumped, Mapping) else {}
    if hasattr(value, "dict"):
        dumped = value.dict()
        return dumped if isinstance(dumped, Mapping) else {}
    return {}


def _dig(value: Any, *path: str) -> Any:
    current = value
    for key in path:
        if isinstance(current, Mapping):
            current = current.get(key)
        else:
            current = getattr(current, key, None)
        if current is None:
            return None
    return current


def _normalize_distance(value: Any) -> str:
    raw = getattr(value, "value", value)
    return str(raw).lower()
