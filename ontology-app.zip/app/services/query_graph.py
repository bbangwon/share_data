from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import logging
import math
import re
import time
import uuid
import warnings
from collections.abc import Sequence
from functools import lru_cache
from pathlib import Path
from typing import Any

from langchain_core.prompts import load_prompt
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field
from qdrant_client import AsyncQdrantClient, models

from app.core.config import Settings
from app.services.embeddings import GpuDenseEmbedder, KiwiBm25SparseEmbedder
from app.services.ontology.extraction import build_chunk_uid
from app.services.ontology.neo4j_store import Neo4jOntologyStore
from app.services.schemas import ChildChunk, DocumentMeta, EmbeddedChunk

logger = logging.getLogger("uvicorn.error")


class SyntheticQueryRecord(BaseModel):
    query_id: str
    graph_dataset_key: str
    document_key: str
    collection_name: str
    chunking_profile: str
    chunk_uid: str
    chunk_id: str
    question: str
    answer: str
    page_numbers: list[int] = Field(default_factory=list)
    section_path: str | None = None
    source_text: str
    quality_score: float = 0.0
    accepted: bool = False
    quality_reason: str = ""
    dense_vector: list[float] = Field(default_factory=list)
    sparse_vector: dict[str, list[int] | list[float]] = Field(default_factory=dict)


class QueryGraphEdge(BaseModel):
    edge_id: str
    graph_dataset_key: str
    source_query_id: str
    target_query_id: str
    similarity: float


class QueryGraphChunkCache(BaseModel):
    chunk_id: str
    chunk_uid: str
    status: str
    records: list[SyntheticQueryRecord] = Field(default_factory=list)
    error: str | None = None
    duration_ms: float = 0.0


class QueryGraphBuilder:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    async def build(
        self,
        *,
        chunks: Sequence[ChildChunk],
        embedded_chunks: Sequence[EmbeddedChunk],
        meta: DocumentMeta,
        collection_name: str,
        chunking_profile: str,
        graph_dataset_key: str,
        output_root: Path,
        offset: int,
        limit: int | None,
        resume: bool,
        generation_enabled: bool,
        upsert_enabled: bool,
        reset_scope: bool,
    ) -> dict[str, Any]:
        selected_chunks = _select_chunks(chunks, offset=offset, limit=limit)
        query_graph_dir = output_root / "query_graph"
        cache_dir = query_graph_dir / "chunk_cache" / _cache_dir_name(graph_dataset_key)
        query_graph_dir.mkdir(parents=True, exist_ok=True)
        cache_dir.mkdir(parents=True, exist_ok=True)
        synthetic_jsonl = query_graph_dir / "synthetic_queries.jsonl"
        events_jsonl = query_graph_dir / "query_graph_events.jsonl"
        if not resume:
            _unlink_if_exists(
                synthetic_jsonl,
                events_jsonl,
                query_graph_dir / "query_graph_edges.jsonl",
                query_graph_dir / "query_graph_review.md",
            )

        if not generation_enabled:
            reset_result: dict[str, Any] = {"skipped": True, "reason": "query_graph.reset_scope=false"}
            if reset_scope and upsert_enabled:
                reset_result = await self._reset_query_graph_stores(graph_dataset_key=graph_dataset_key)
            result = {
                "skipped": True,
                "reason": "query_graph generation is disabled",
                "graph_dataset_key": graph_dataset_key,
                "selected_chunk_count": len(selected_chunks),
                "query_graph_reset": reset_result,
            }
            _write_progress(query_graph_dir, result)
            _log_query_graph_progress(result, event="skipped")
            return result

        embedded_by_chunk_id = {item.chunk_id: item for item in embedded_chunks}
        llm = self._build_llm()
        dense_embedder = GpuDenseEmbedder(
            base_url=self.settings.embedding.base_url,
            model=self.settings.embedding.dense_model_name,
            timeout=self.settings.embedding.timeout,
        )
        sparse_embedder = KiwiBm25SparseEmbedder(
            model_name=self.settings.embedding.sparse_model_name
        )
        chunk_caches: list[QueryGraphChunkCache] = []
        processed_count = 0
        resumed_count = 0
        started = time.perf_counter()
        _log_query_graph_progress(
            {
                "selected_chunk_count": len(selected_chunks),
                "completed_chunk_count": 0,
                "processed_chunk_count": 0,
                "resumed_chunk_count": 0,
                "failed_chunk_count": 0,
                "remaining_chunk_count": len(selected_chunks),
                "percent_complete": 0.0 if selected_chunks else 100.0,
                "chunk_offset": offset,
                "chunk_limit": limit,
            },
            event="started",
        )
        try:
            for index, chunk in enumerate(selected_chunks, start=offset):
                cache_path = cache_dir / f"{_safe_file_stem(chunk.chunk_id)}.json"
                event_type = "completed"
                if resume and cache_path.exists():
                    cache = _load_resumable_chunk_cache(cache_path)
                    if cache is not None:
                        event_type = "resumed"
                        resumed_count += 1
                    else:
                        event_type = "retried_failed_or_invalid_cache"
                if event_type != "resumed":
                    cache = await self._process_chunk(
                        chunk=chunk,
                        chunk_index=index,
                        meta=meta,
                        collection_name=collection_name,
                        chunking_profile=chunking_profile,
                        graph_dataset_key=graph_dataset_key,
                        embedded=embedded_by_chunk_id.get(chunk.chunk_id),
                        llm=llm,
                        dense_embedder=dense_embedder,
                        sparse_embedder=sparse_embedder,
                    )
                    processed_count += 1
                    _write_json_atomic(cache_path, cache.model_dump(mode="json"))
                    _append_records_jsonl(synthetic_jsonl, cache.records)
                    event_type = "failed" if cache.status == "failed" else event_type
                event = {
                    "event": event_type,
                    "chunk_index": index,
                    "chunk_id": chunk.chunk_id,
                    "chunk_uid": cache.chunk_uid,
                    "status": cache.status,
                    "record_count": len(cache.records),
                    "accepted_count": sum(1 for item in cache.records if item.accepted),
                    "error": cache.error,
                    "duration_ms": 0.0 if event_type == "resumed" else cache.duration_ms,
                }
                _append_jsonl(events_jsonl, {**event, "created_at": _now_iso()})
                chunk_caches.append(cache)
                progress = _progress_payload(
                    graph_dataset_key=graph_dataset_key,
                    total_source_chunk_count=len(chunks),
                    selected_chunk_count=len(selected_chunks),
                    completed_chunk_count=len(chunk_caches),
                    chunk_caches=chunk_caches,
                    processed_chunk_count=processed_count,
                    resumed_chunk_count=resumed_count,
                    offset=offset,
                    limit=limit,
                    started=started,
                    status="running",
                    last_event=event,
                )
                _write_progress(query_graph_dir, progress)
                _log_query_graph_progress(progress, event=event_type)
        finally:
            await dense_embedder.close()
            await sparse_embedder.close()

        records = [record for cache in chunk_caches for record in cache.records]
        accepted_records = [record for record in records if record.accepted]
        edges = _build_similarity_edges(
            accepted_records,
            graph_dataset_key=graph_dataset_key,
            neighbor_top_k=self.settings.query_graph.neighbor_top_k,
            threshold=self.settings.query_graph.quality_similarity_threshold,
        )
        artifacts = _write_query_graph_artifacts(
            query_graph_dir=query_graph_dir,
            records=records,
            edges=edges,
            chunk_caches=chunk_caches,
            graph_dataset_key=graph_dataset_key,
        )

        upsert_result: dict[str, Any]
        if upsert_enabled:
            upsert_result = await self._upsert_query_graph(
                records=accepted_records,
                edges=edges,
                graph_dataset_key=graph_dataset_key,
                reset_scope=reset_scope,
            )
        else:
            upsert_result = {"skipped": True, "reason": "query_graph upsert is disabled"}

        result = {
            **_progress_payload(
                graph_dataset_key=graph_dataset_key,
                total_source_chunk_count=len(chunks),
                selected_chunk_count=len(selected_chunks),
                completed_chunk_count=len(chunk_caches),
                chunk_caches=chunk_caches,
                processed_chunk_count=processed_count,
                resumed_chunk_count=resumed_count,
                offset=offset,
                limit=limit,
                started=started,
                status="completed_with_failures" if any(cache.status == "failed" for cache in chunk_caches) else "completed",
                last_event=None,
            ),
            "skipped": False,
            "generation_enabled": generation_enabled,
            "upsert_enabled": upsert_enabled,
            "qdrant_collection_name": _query_graph_collection_name(self.settings),
            "query_graph_upsert": upsert_result,
            "artifacts": artifacts,
        }
        _write_progress(query_graph_dir, result)
        _log_query_graph_progress(result, event=result["status"])
        return result

    async def _process_chunk(
        self,
        *,
        chunk: ChildChunk,
        chunk_index: int,
        meta: DocumentMeta,
        collection_name: str,
        chunking_profile: str,
        graph_dataset_key: str,
        embedded: EmbeddedChunk | None,
        llm: Any,
        dense_embedder: GpuDenseEmbedder,
        sparse_embedder: KiwiBm25SparseEmbedder,
    ) -> QueryGraphChunkCache:
        started = time.perf_counter()
        chunk_uid = build_chunk_uid(graph_dataset_key=graph_dataset_key, chunk_id=chunk.chunk_id)
        try:
            items = await self._generate_items(chunk=chunk, chunk_index=chunk_index, llm=llm)
            if not items:
                return QueryGraphChunkCache(
                    chunk_id=chunk.chunk_id,
                    chunk_uid=chunk_uid,
                    status="completed",
                    records=[],
                    duration_ms=_duration_ms(started),
                )
            qa_texts = [f"{item['question']}\n{item['answer']}" for item in items]
            dense_vectors = await dense_embedder.embed_many(qa_texts)
            sparse_vectors = await sparse_embedder.embed_many(qa_texts)
            source_vector = list(embedded.dense_vector) if embedded is not None else []
            scored: list[SyntheticQueryRecord] = []
            for item, dense_vector, sparse_vector in zip(items, dense_vectors, sparse_vectors, strict=True):
                score = _cosine_similarity(source_vector, list(dense_vector)) if source_vector else 0.0
                question = str(item["question"]).strip()
                answer = str(item["answer"]).strip()
                query_id = build_query_id(
                    graph_dataset_key=graph_dataset_key,
                    chunk_id=chunk.chunk_id,
                    question=question,
                )
                scored.append(
                    SyntheticQueryRecord(
                        query_id=query_id,
                        graph_dataset_key=graph_dataset_key,
                        document_key=meta.document_key,
                        collection_name=collection_name,
                        chunking_profile=chunking_profile,
                        chunk_uid=chunk_uid,
                        chunk_id=chunk.chunk_id,
                        question=question,
                        answer=answer,
                        page_numbers=chunk.page_numbers,
                        section_path=chunk.section_path,
                        source_text=_truncate(chunk.parent_text or chunk.text, 1200),
                        quality_score=round(score, 4),
                        dense_vector=list(dense_vector),
                        sparse_vector=_sparse_dict(sparse_vector),
                    )
                )
            records = _apply_quality_filter(
                scored,
                threshold=self.settings.query_graph.quality_similarity_threshold,
                top_ratio=self.settings.query_graph.quality_top_ratio,
            )
            return QueryGraphChunkCache(
                chunk_id=chunk.chunk_id,
                chunk_uid=chunk_uid,
                status="completed",
                records=records,
                duration_ms=_duration_ms(started),
            )
        except Exception as exc:
            return QueryGraphChunkCache(
                chunk_id=chunk.chunk_id,
                chunk_uid=chunk_uid,
                status="failed",
                error=str(exc),
                duration_ms=_duration_ms(started),
            )

    async def _generate_items(self, *, chunk: ChildChunk, chunk_index: int, llm: Any) -> list[dict[str, str]]:
        prompt = _load_prompt(str(self.settings.query_graph.llm_prompt_path)).format_prompt(
            questions_per_chunk=self.settings.query_graph.questions_per_chunk,
            chunk_index=chunk_index,
            chunk_id=chunk.chunk_id,
            page_numbers=", ".join(str(page) for page in chunk.page_numbers) or "-",
            section_path=chunk.section_path or "-",
            chunk_text=_truncate(chunk.parent_text or chunk.text, self.settings.query_graph.max_chunk_chars),
        )
        response = llm.ainvoke(prompt) if hasattr(llm, "ainvoke") else llm.invoke(prompt)
        message = await response if inspect.isawaitable(response) else response
        return _parse_generation_response(_message_content(message), limit=self.settings.query_graph.questions_per_chunk)

    def _build_llm(self) -> Any:
        if not self.settings.llm.base_url:
            raise ValueError("llm.base_url is required when query_graph generation is enabled")
        if not self.settings.llm.model_name:
            raise ValueError("llm.model_name is required when query_graph generation is enabled")
        return ChatOpenAI(
            model=self.settings.llm.model_name,
            base_url=self.settings.llm.base_url,
            timeout=self.settings.llm.timeout,
            temperature=self.settings.llm.temperature,
            api_key=self.settings.llm.api_key.get_secret_value(),
        )

    async def _upsert_query_graph(
        self,
        *,
        records: list[SyntheticQueryRecord],
        edges: list[QueryGraphEdge],
        graph_dataset_key: str,
        reset_scope: bool,
    ) -> dict[str, Any]:
        qdrant_result: dict[str, Any]
        qdrant = QueryGraphQdrantStore(self.settings)
        try:
            logger.info(
                "Query graph Qdrant upsert started: collection=%s host=%s port=%s timeout=%s records=%s graph_dataset_key=%s reset_scope=%s",
                qdrant.collection_name,
                self.settings.qdrant.host,
                self.settings.qdrant.port,
                self.settings.qdrant.timeout,
                len(records),
                graph_dataset_key,
                reset_scope,
            )
            await qdrant.ensure_collection(dense_vector_size=_dense_vector_size(records, self.settings))
            if reset_scope:
                await qdrant.delete_scope(graph_dataset_key=graph_dataset_key)
            qdrant_result = await qdrant.upsert(records)
            logger.info(
                "Query graph Qdrant upsert completed: collection=%s result=%s",
                qdrant.collection_name,
                qdrant_result,
            )
        except Exception:
            logger.exception(
                "Query graph Qdrant upsert failed: collection=%s host=%s port=%s timeout=%s records=%s graph_dataset_key=%s",
                qdrant.collection_name,
                self.settings.qdrant.host,
                self.settings.qdrant.port,
                self.settings.qdrant.timeout,
                len(records),
                graph_dataset_key,
            )
            raise
        finally:
            await qdrant.close()

        neo4j_result: dict[str, Any]
        store = Neo4jOntologyStore(self.settings.neo4j)
        try:
            logger.info(
                "Query graph Neo4j upsert started: records=%s edges=%s graph_dataset_key=%s reset_scope=%s",
                len(records),
                len(edges),
                graph_dataset_key,
                reset_scope,
            )
            if reset_scope:
                reset_result = await store.reset_query_graph_scope(graph_dataset_key=graph_dataset_key)
            else:
                reset_result = {"skipped": True, "reason": "query_graph.reset_scope=false"}
            neo4j_upsert = await store.upsert_query_graph(records=records, edges=edges)
            neo4j_result = {"reset": reset_result, **neo4j_upsert}
            logger.info(
                "Query graph Neo4j upsert completed: result=%s",
                neo4j_result,
            )
        except Exception:
            logger.exception(
                "Query graph Neo4j upsert failed: records=%s edges=%s graph_dataset_key=%s",
                len(records),
                len(edges),
                graph_dataset_key,
            )
            raise
        finally:
            await store.close()
        return {"qdrant": qdrant_result, "neo4j": neo4j_result}

    async def _reset_query_graph_stores(self, *, graph_dataset_key: str) -> dict[str, Any]:
        qdrant = QueryGraphQdrantStore(self.settings)
        try:
            if self.settings.qdrant.dense_vector_size is None:
                raise ValueError("qdrant.dense_vector_size is required to reset query graph Qdrant collection")
            await qdrant.ensure_collection(dense_vector_size=int(self.settings.qdrant.dense_vector_size))
            await qdrant.delete_scope(graph_dataset_key=graph_dataset_key)
            qdrant_result = {"collection_name": qdrant.collection_name, "deleted_scope": graph_dataset_key}
        finally:
            await qdrant.close()
        store = Neo4jOntologyStore(self.settings.neo4j)
        try:
            neo4j_result = await store.reset_query_graph_scope(graph_dataset_key=graph_dataset_key)
        finally:
            await store.close()
        return {"qdrant": qdrant_result, "neo4j": neo4j_result}


class QueryGraphQdrantStore:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.collection_name = _query_graph_collection_name(settings)
        self.upload_batch_size = max(1, int(settings.qdrant.upload_batch_size))
        self.upload_max_retries = max(0, int(settings.qdrant.upload_max_retries))
        self.client = AsyncQdrantClient(
            host=settings.qdrant.host,
            port=settings.qdrant.port,
            timeout=settings.qdrant.timeout,
            check_compatibility=False,
        )

    async def ensure_collection(self, *, dense_vector_size: int) -> None:
        exists = await self.client.collection_exists(collection_name=self.collection_name)
        if not exists:
            await self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config={
                    self.settings.qdrant.dense_name: models.VectorParams(
                        size=dense_vector_size,
                        distance=models.Distance.COSINE,
                    )
                },
                sparse_vectors_config={self.settings.qdrant.sparse_name: models.SparseVectorParams()},
            )
        for field_name, schema_name in {
            "query_id": "keyword",
            "graph_dataset_key": "keyword",
            "chunk_uid": "keyword",
            "chunk_id": "keyword",
            "document_key": "keyword",
            "ingest_status": "keyword",
        }.items():
            try:
                await self.client.create_payload_index(
                    collection_name=self.collection_name,
                    field_name=field_name,
                    field_schema=models.PayloadSchemaType(schema_name),
                    wait=True,
                )
            except Exception as exc:
                if "already exists" not in str(exc).lower():
                    raise

    async def delete_scope(self, *, graph_dataset_key: str) -> None:
        await self.client.delete(
            collection_name=self.collection_name,
            points_selector=models.Filter(
                must=[
                    models.FieldCondition(
                        key="graph_dataset_key",
                        match=models.MatchValue(value=graph_dataset_key),
                    )
                ]
            ),
            wait=True,
        )

    async def upsert(self, records: Sequence[SyntheticQueryRecord]) -> dict[str, Any]:
        points = [
            models.PointStruct(
                id=build_query_point_id(record.query_id),
                vector={
                    self.settings.qdrant.dense_name: record.dense_vector,
                    self.settings.qdrant.sparse_name: _as_sparse_vector(record.sparse_vector),
                },
                payload=_record_payload(record),
            )
            for record in records
            if record.accepted and record.dense_vector and record.sparse_vector
        ]
        succeeded = 0
        if points:
            total_batches = math.ceil(len(points) / self.upload_batch_size)
            for batch_index, batch in enumerate(_batches(points, self.upload_batch_size), start=1):
                await self._upsert_batch(
                    batch,
                    batch_index=batch_index,
                    total_batches=total_batches,
                )
                succeeded += len(batch)
        return {
            "collection_name": self.collection_name,
            "upserted": succeeded,
            "batch_size": self.upload_batch_size,
            "batch_count": math.ceil(len(points) / self.upload_batch_size) if points else 0,
        }

    async def _upsert_batch(
        self,
        points: Sequence[models.PointStruct],
        *,
        batch_index: int,
        total_batches: int,
    ) -> None:
        last_error: Exception | None = None
        for attempt in range(self.upload_max_retries + 1):
            try:
                logger.info(
                    "Query graph Qdrant batch upsert started: collection=%s batch=%s/%s points=%s attempt=%s/%s",
                    self.collection_name,
                    batch_index,
                    total_batches,
                    len(points),
                    attempt + 1,
                    self.upload_max_retries + 1,
                )
                await self.client.upsert(
                    collection_name=self.collection_name,
                    points=list(points),
                    wait=True,
                )
                logger.info(
                    "Query graph Qdrant batch upsert completed: collection=%s batch=%s/%s points=%s",
                    self.collection_name,
                    batch_index,
                    total_batches,
                    len(points),
                )
                return
            except Exception as exc:
                last_error = exc
                logger.warning(
                    "Query graph Qdrant batch upsert failed: collection=%s batch=%s/%s points=%s attempt=%s/%s error=%r",
                    self.collection_name,
                    batch_index,
                    total_batches,
                    len(points),
                    attempt + 1,
                    self.upload_max_retries + 1,
                    exc,
                )
                if attempt >= self.upload_max_retries:
                    raise
                await asyncio.sleep(min(2**attempt, 10))
        if last_error is not None:
            raise last_error

    async def search(
        self,
        *,
        dense_vector: list[float],
        sparse_vector: dict[str, list[int] | list[float]],
        graph_dataset_keys: list[str],
        limit: int,
    ) -> list[dict[str, Any]]:
        query_filter = _graph_dataset_filter(graph_dataset_keys)
        response = await self.client.query_points(
            collection_name=self.collection_name,
            prefetch=[
                models.Prefetch(
                    query=dense_vector,
                    using=self.settings.qdrant.dense_name,
                    filter=query_filter,
                    limit=limit,
                ),
                models.Prefetch(
                    query=_as_sparse_vector(sparse_vector),
                    using=self.settings.qdrant.sparse_name,
                    filter=query_filter,
                    limit=limit,
                ),
            ],
            query=models.FusionQuery(fusion=models.Fusion.DBSF),
            query_filter=query_filter,
            limit=limit,
            with_payload=True,
            with_vectors=False,
        )
        return _response_points(response)

    async def close(self) -> None:
        result = self.client.close()
        if inspect.isawaitable(result):
            await result


class QueryGraphExpansionService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    async def expand(
        self,
        *,
        dense_vector: list[float],
        sparse_vector: dict[str, list[int] | list[float]],
        seed_chunk_refs: list[dict[str, Any]],
        document_key: str | None,
        include_evidence_chains: bool = False,
        evidence_chain_limit: int = 5,
    ) -> list[dict[str, Any]]:
        graph_dataset_keys = sorted(
            {
                str(ref.get("graph_dataset_key"))
                for ref in seed_chunk_refs
                if ref.get("graph_dataset_key")
            }
        )
        qdrant = QueryGraphQdrantStore(self.settings)
        try:
            query_points = await qdrant.search(
                dense_vector=dense_vector,
                sparse_vector=sparse_vector,
                graph_dataset_keys=graph_dataset_keys,
                limit=self.settings.query_graph.retrieval_query_limit,
            )
        finally:
            await qdrant.close()
        query_rows = [
            {
                "query_id": (point.get("payload") or {}).get("query_id"),
                "question": (point.get("payload") or {}).get("question"),
                "score": float(point.get("score") or 0.0),
            }
            for point in query_points
            if (point.get("payload") or {}).get("query_id")
        ]
        if not query_rows:
            return []
        store = Neo4jOntologyStore(self.settings.neo4j)
        try:
            return await store.expand_query_graph_chunks(
                query_rows=query_rows,
                graph_dataset_keys=graph_dataset_keys,
                document_key=document_key,
                neighbor_top_k=self.settings.query_graph.neighbor_top_k,
                limit=self.settings.query_graph.retrieval_chunk_limit,
                include_evidence_chains=include_evidence_chains,
                evidence_chain_limit=evidence_chain_limit,
            )
        finally:
            await store.close()


def build_query_id(*, graph_dataset_key: str, chunk_id: str, question: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"qcg:{graph_dataset_key}:{chunk_id}:{question}"))


def build_query_point_id(query_id: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"qcg-point:{query_id}"))


def _query_graph_collection_name(settings: Settings) -> str:
    return f"{settings.qdrant.collection_name}{settings.query_graph.qdrant_collection_suffix}"


@lru_cache(maxsize=8)
def _load_prompt(path: str) -> Any:
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning, message=r".*load_prompt.*")
        return load_prompt(path)


def _parse_generation_response(content: str, *, limit: int) -> list[dict[str, str]]:
    text = content.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text, flags=re.IGNORECASE).strip()
        text = re.sub(r"```$", "", text).strip()
    payload = json.loads(text)
    raw_items = payload.get("items", payload) if isinstance(payload, dict) else payload
    if not isinstance(raw_items, list):
        raise ValueError("query graph generation response must be a JSON object with items[] or a JSON array")
    items: list[dict[str, str]] = []
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        question = str(item.get("question") or "").strip()
        answer = str(item.get("answer") or "").strip()
        if question and answer:
            items.append({"question": question, "answer": answer})
        if len(items) >= limit:
            break
    return items


def _message_content(message: Any) -> str:
    content = getattr(message, "content", message)
    if isinstance(content, list):
        return "\n".join(str(item) for item in content)
    return str(content or "")


def _select_chunks(chunks: Sequence[ChildChunk], *, offset: int, limit: int | None) -> list[ChildChunk]:
    if offset < 0:
        raise ValueError("query_graph chunk_offset must be greater than or equal to 0")
    if limit is not None and limit <= 0:
        raise ValueError("query_graph chunk_limit must be greater than 0 when provided")
    total = len(chunks)
    if offset >= total and total > 0:
        raise ValueError(f"query_graph chunk_offset={offset} is outside the available chunk range 0..{total - 1}")
    end = None if limit is None else offset + limit
    return list(chunks[offset:end])


def _apply_quality_filter(
    records: list[SyntheticQueryRecord],
    *,
    threshold: float,
    top_ratio: float,
) -> list[SyntheticQueryRecord]:
    if not records:
        return []
    top_count = max(1, math.ceil(len(records) * top_ratio))
    ranked = sorted(records, key=lambda item: item.quality_score, reverse=True)
    accepted_ids = {
        item.query_id
        for item in ranked[:top_count]
        if item.quality_score >= threshold
    }
    result: list[SyntheticQueryRecord] = []
    for record in records:
        if record.query_id in accepted_ids:
            result.append(record.model_copy(update={"accepted": True, "quality_reason": "accepted"}))
        elif record.quality_score < threshold:
            result.append(record.model_copy(update={"accepted": False, "quality_reason": "below_similarity_threshold"}))
        else:
            result.append(record.model_copy(update={"accepted": False, "quality_reason": "outside_top_ratio"}))
    return result


def _build_similarity_edges(
    records: list[SyntheticQueryRecord],
    *,
    graph_dataset_key: str,
    neighbor_top_k: int,
    threshold: float,
) -> list[QueryGraphEdge]:
    if len(records) < 2:
        return []
    edges_by_pair: dict[tuple[str, str], QueryGraphEdge] = {}
    for source in records:
        similarities: list[tuple[float, SyntheticQueryRecord]] = []
        for target in records:
            if source.query_id == target.query_id:
                continue
            similarity = _cosine_similarity(source.dense_vector, target.dense_vector)
            if similarity >= threshold:
                similarities.append((similarity, target))
        for similarity, target in sorted(similarities, key=lambda item: item[0], reverse=True)[:neighbor_top_k]:
            left, right = sorted((source.query_id, target.query_id))
            pair = (left, right)
            edge_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"qcg-edge:{graph_dataset_key}:{left}:{right}"))
            edge = QueryGraphEdge(
                edge_id=edge_id,
                graph_dataset_key=graph_dataset_key,
                source_query_id=left,
                target_query_id=right,
                similarity=round(similarity, 4),
            )
            previous = edges_by_pair.get(pair)
            if previous is None or edge.similarity > previous.similarity:
                edges_by_pair[pair] = edge
    return sorted(edges_by_pair.values(), key=lambda item: item.similarity, reverse=True)


def _write_query_graph_artifacts(
    *,
    query_graph_dir: Path,
    records: list[SyntheticQueryRecord],
    edges: list[QueryGraphEdge],
    chunk_caches: list[QueryGraphChunkCache],
    graph_dataset_key: str,
) -> dict[str, str]:
    synthetic_jsonl = query_graph_dir / "synthetic_queries.jsonl"
    edges_jsonl = query_graph_dir / "query_graph_edges.jsonl"
    review_md = query_graph_dir / "query_graph_review.md"
    synthetic_jsonl.write_text(
        "".join(json.dumps(_record_payload(record), ensure_ascii=False) + "\n" for record in records),
        encoding="utf-8",
    )
    edges_jsonl.write_text(
        "".join(json.dumps(edge.model_dump(mode="json"), ensure_ascii=False) + "\n" for edge in edges),
        encoding="utf-8",
    )
    review_md.write_text(_review_markdown(records, edges, chunk_caches, graph_dataset_key), encoding="utf-8")
    return {
        "synthetic_queries_jsonl": str(synthetic_jsonl),
        "query_graph_edges_jsonl": str(edges_jsonl),
        "query_graph_review_markdown": str(review_md),
        "progress_json": str(query_graph_dir / "progress.json"),
        "events_jsonl": str(query_graph_dir / "query_graph_events.jsonl"),
    }


def _write_progress(query_graph_dir: Path, payload: dict[str, Any]) -> None:
    query_graph_dir.mkdir(parents=True, exist_ok=True)
    _write_json_atomic(query_graph_dir / "progress.json", payload)


def _log_query_graph_progress(payload: dict[str, Any], *, event: str) -> None:
    selected = int(payload.get("selected_chunk_count") or 0)
    completed = int(payload.get("completed_chunk_count") or 0)
    percent = payload.get("percent_complete")
    last_event = payload.get("last_event") if isinstance(payload.get("last_event"), dict) else {}
    parts = [
        "[ingest][build_query_graph_layer]",
        event,
        f"{completed}/{selected} ({percent}%)",
    ]
    if last_event.get("chunk_index") is not None:
        parts.append(f"chunk_index={last_event['chunk_index']}")
    if last_event.get("chunk_id"):
        parts.append(f"chunk_id={last_event['chunk_id']}")
    for key in (
        "processed_chunk_count",
        "resumed_chunk_count",
        "failed_chunk_count",
        "remaining_chunk_count",
        "accepted_query_count",
        "rejected_query_count",
        "estimated_remaining_ms",
    ):
        value = payload.get(key)
        if value is not None:
            parts.append(f"{key}={value}")
    print(" ".join(parts), flush=True)


def _progress_payload(
    *,
    graph_dataset_key: str,
    total_source_chunk_count: int,
    selected_chunk_count: int,
    completed_chunk_count: int,
    chunk_caches: list[QueryGraphChunkCache],
    processed_chunk_count: int,
    resumed_chunk_count: int,
    offset: int,
    limit: int | None,
    started: float,
    status: str,
    last_event: dict[str, Any] | None,
) -> dict[str, Any]:
    accepted = sum(1 for cache in chunk_caches for record in cache.records if record.accepted)
    rejected = sum(1 for cache in chunk_caches for record in cache.records if not record.accepted)
    failed = sum(1 for cache in chunk_caches if cache.status == "failed")
    successful = sum(1 for cache in chunk_caches if cache.status == "completed")
    average_ms = _average_duration_ms(chunk_caches)
    remaining = max(0, selected_chunk_count - completed_chunk_count)
    return {
        "status": status,
        "graph_dataset_key": graph_dataset_key,
        "total_source_chunk_count": total_source_chunk_count,
        "selected_chunk_count": selected_chunk_count,
        "completed_chunk_count": completed_chunk_count,
        "successful_chunk_count": successful,
        "processed_chunk_count": processed_chunk_count,
        "resumed_chunk_count": resumed_chunk_count,
        "failed_chunk_count": failed,
        "remaining_chunk_count": remaining,
        "percent_complete": round((completed_chunk_count / selected_chunk_count) * 100, 2) if selected_chunk_count else 100.0,
        "average_chunk_duration_ms": average_ms,
        "estimated_remaining_ms": round(average_ms * remaining, 2) if average_ms is not None else None,
        "accepted_query_count": accepted,
        "rejected_query_count": rejected,
        "chunk_offset": offset,
        "chunk_limit": limit,
        "duration_ms": _duration_ms(started),
        "updated_at": _now_iso(),
        "last_event": last_event,
    }


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as file:
        file.write(json.dumps(payload, ensure_ascii=False) + "\n")


def _append_records_jsonl(path: Path, records: Sequence[SyntheticQueryRecord]) -> None:
    if not records:
        return
    with path.open("a", encoding="utf-8") as file:
        for record in records:
            file.write(json.dumps(_record_payload(record), ensure_ascii=False) + "\n")


def _load_resumable_chunk_cache(path: Path) -> QueryGraphChunkCache | None:
    try:
        cache = QueryGraphChunkCache.model_validate(
            json.loads(path.read_text(encoding="utf-8"))
        )
    except Exception:
        return None
    return cache if cache.status == "completed" else None


def _average_duration_ms(chunk_caches: Sequence[QueryGraphChunkCache]) -> float | None:
    durations = [float(cache.duration_ms) for cache in chunk_caches if cache.duration_ms > 0]
    if not durations:
        return None
    return round(sum(durations) / len(durations), 2)


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def _unlink_if_exists(*paths: Path) -> None:
    for path in paths:
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _record_payload(record: SyntheticQueryRecord) -> dict[str, Any]:
    return record.model_dump(mode="json", exclude={"dense_vector", "sparse_vector"})


def _batches(items: Sequence[Any], size: int) -> list[Sequence[Any]]:
    return [items[index : index + size] for index in range(0, len(items), max(1, size))]


def _review_markdown(
    records: list[SyntheticQueryRecord],
    edges: list[QueryGraphEdge],
    chunk_caches: list[QueryGraphChunkCache],
    graph_dataset_key: str,
) -> str:
    accepted = [record for record in records if record.accepted]
    rejected = [record for record in records if not record.accepted]
    lines = [
        "# Query Graph Review",
        "",
        f"- Graph dataset key: `{graph_dataset_key}`",
        f"- Processed chunk count: `{len(chunk_caches)}`",
        f"- Failed chunk count: `{sum(1 for item in chunk_caches if item.status == 'failed')}`",
        f"- Accepted synthetic query count: `{len(accepted)}`",
        f"- Rejected synthetic query count: `{len(rejected)}`",
        f"- Query-query edge count: `{len(edges)}`",
        "",
        "## Accepted Samples",
        "",
    ]
    for record in accepted[:20]:
        lines.append(f"- `{record.chunk_id}` score={record.quality_score}: {record.question}")
    lines.extend(["", "## Rejected Samples", ""])
    for record in rejected[:20]:
        lines.append(f"- `{record.chunk_id}` score={record.quality_score} reason={record.quality_reason}: {record.question}")
    failed = [item for item in chunk_caches if item.status == "failed"]
    if failed:
        lines.extend(["", "## Failed Chunks", ""])
        for item in failed[:30]:
            lines.append(f"- `{item.chunk_id}`: {item.error}")
    lines.append("")
    return "\n".join(lines)


def _graph_dataset_filter(graph_dataset_keys: list[str]) -> models.Filter | None:
    keys = [key for key in graph_dataset_keys if key]
    if not keys:
        return None
    conditions = [
        models.FieldCondition(key="graph_dataset_key", match=models.MatchValue(value=key))
        for key in keys
    ]
    if len(conditions) == 1:
        return models.Filter(must=conditions)
    return models.Filter(should=conditions)


def _response_points(response: Any) -> list[dict[str, Any]]:
    if response is None:
        return []
    if hasattr(response, "model_dump"):
        dumped = response.model_dump()
        points = dumped.get("points", []) if isinstance(dumped, dict) else []
    elif isinstance(response, dict):
        points = response.get("points", [])
    else:
        points = getattr(response, "points", [])
    normalized: list[dict[str, Any]] = []
    for point in points or []:
        if isinstance(point, dict):
            normalized.append(point)
        elif hasattr(point, "model_dump"):
            normalized.append(point.model_dump())
        else:
            normalized.append(
                {
                    "id": getattr(point, "id", None),
                    "score": getattr(point, "score", None),
                    "payload": getattr(point, "payload", None) or {},
                }
            )
    return normalized


def _as_sparse_vector(value: dict[str, list[int] | list[float]]) -> models.SparseVector:
    return models.SparseVector(
        indices=[int(index) for index in value.get("indices", [])],
        values=[float(weight) for weight in value.get("values", [])],
    )


def _sparse_dict(value: Any) -> dict[str, list[int] | list[float]]:
    if isinstance(value, dict):
        return {
            "indices": [int(index) for index in value.get("indices", [])],
            "values": [float(weight) for weight in value.get("values", [])],
        }
    return {
        "indices": [int(index) for index in getattr(value, "indices", [])],
        "values": [float(weight) for weight in getattr(value, "values", [])],
    }


def _cosine_similarity(left: Sequence[float], right: Sequence[float]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    dot = sum(a * b for a, b in zip(left, right, strict=True))
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    if left_norm == 0 or right_norm == 0:
        return 0.0
    return dot / (left_norm * right_norm)


def _dense_vector_size(records: Sequence[SyntheticQueryRecord], settings: Settings) -> int:
    for record in records:
        if record.dense_vector:
            return len(record.dense_vector)
    if settings.qdrant.dense_vector_size:
        return int(settings.qdrant.dense_vector_size)
    raise ValueError("dense_vector_size is required before creating query graph collection")


def _truncate(text: str, limit: int) -> str:
    value = text or ""
    return value if len(value) <= limit else value[:limit].rstrip()


def _safe_file_stem(value: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", value)
    if len(safe) > 80:
        digest = hashlib.sha1(value.encode("utf-8")).hexdigest()[:12]
        return f"{safe[:60]}-{digest}"
    return safe or hashlib.sha1(value.encode("utf-8")).hexdigest()[:12]


def _cache_dir_name(graph_dataset_key: str) -> str:
    return hashlib.sha1(graph_dataset_key.encode("utf-8")).hexdigest()[:16]


def _duration_ms(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 2)
