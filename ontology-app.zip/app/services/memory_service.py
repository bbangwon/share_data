"""Reserved for conversation memory or LangGraph checkpointer wiring."""
