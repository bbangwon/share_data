from __future__ import annotations

import inspect
import time
from typing import Any

from qdrant_client import AsyncQdrantClient

from app.core.config import Settings
from app.services.chunking_profiles import apply_search_overrides
from app.services.ontology.neo4j_store import Neo4jOntologyStore


async def check_dependency_connections(
    settings: Settings,
    *,
    retrieval_profile: str | None = None,
    collection_name: str | None = None,
    check_collection: bool = True,
) -> dict[str, Any]:
    """Qdrant와 Neo4j의 실제 연결 상태를 가볍게 확인합니다.

    retrieval_profile이 있으면 해당 profile의 Qdrant collection과 Neo4j URI를 적용합니다.
    collection_name은 profile 없이 Qdrant collection만 직접 확인하고 싶을 때 사용합니다.
    """
    if retrieval_profile is None and collection_name is None:
        retrieval_profile = settings.search.default_retrieval_profile

    settings = apply_search_overrides(
        settings,
        retrieval_profile=retrieval_profile,
        collection_name=collection_name,
    )
    checks = {
        "qdrant": await _check_qdrant(settings, check_collection=check_collection),
        "neo4j": await _check_neo4j(settings),
    }
    ok = all(item.get("status") == "ok" for item in checks.values())
    return {
        "status": "ok" if ok else "degraded",
        "app": {"status": "ok"},
        "retrieval_profile": retrieval_profile,
        "collection_name": settings.qdrant.collection_name,
        "neo4j_database": settings.neo4j.database or "neo4j",
        "checks": checks,
    }


async def _check_qdrant(settings: Settings, *, check_collection: bool) -> dict[str, Any]:
    started = time.perf_counter()
    client = AsyncQdrantClient(
        host=settings.qdrant.host,
        port=settings.qdrant.port,
        timeout=settings.qdrant.timeout,
    )
    try:
        result: dict[str, Any] = {
            "status": "ok",
            "host": settings.qdrant.host,
            "port": settings.qdrant.port,
            "collection_name": settings.qdrant.collection_name,
        }
        collections = await _list_qdrant_collections(client)
        result["collections"] = collections
        result["collection_count"] = len(collections)
        if check_collection:
            exists = settings.qdrant.collection_name in collections
            result["collection_exists"] = bool(exists)
            if not exists:
                result["status"] = "error"
                result["error"] = "collection_not_found"
        else:
            result["collection_exists"] = None
        return _with_duration(result, started)
    except Exception as exc:  # pragma: no cover - depends on external Qdrant state
        return _with_duration(
            {
                "status": "error",
                "host": settings.qdrant.host,
                "port": settings.qdrant.port,
                "collection_name": settings.qdrant.collection_name,
                "collection_exists": None,
                "collections": [],
                "collection_count": 0,
                "error": type(exc).__name__,
                "detail": str(exc),
            },
            started,
        )
    finally:
        if hasattr(client, "close"):
            close_result = client.close()
            if inspect.isawaitable(close_result):
                await close_result


async def _check_neo4j(settings: Settings) -> dict[str, Any]:
    started = time.perf_counter()
    if not settings.neo4j.uri or not settings.neo4j.username or settings.neo4j.password is None:
        return _with_duration(
            {
                "status": "error",
                "uri": settings.neo4j.uri,
                "database": settings.neo4j.database or "neo4j",
                "connected": False,
                "error": "not_configured",
            },
            started,
        )

    store = Neo4jOntologyStore(settings.neo4j)
    try:
        await store.verify_connectivity()
        async with store.driver.session(database=store.database) as session:
            result = await session.run("RETURN 1 AS ok")
            record = await result.single()
        return _with_duration(
            {
                "status": "ok",
                "uri": settings.neo4j.uri,
                "database": store.database,
                "query_ok": bool(record and record.get("ok") == 1),
                "connected": True,
            },
            started,
        )
    except Exception as exc:  # pragma: no cover - depends on external Neo4j state
        return _with_duration(
            {
                "status": "error",
                "uri": settings.neo4j.uri,
                "database": settings.neo4j.database or "neo4j",
                "connected": False,
                "error": type(exc).__name__,
                "detail": str(exc),
            },
            started,
        )
    finally:
        await store.close()


def _with_duration(payload: dict[str, Any], started: float) -> dict[str, Any]:
    payload["duration_ms"] = round((time.perf_counter() - started) * 1000, 2)
    return payload


async def _list_qdrant_collections(client: AsyncQdrantClient) -> list[str]:
    response = await client.get_collections()
    collections = getattr(response, "collections", [])
    names = []
    for collection in collections:
        name = collection.get("name") if isinstance(collection, dict) else getattr(collection, "name", None)
        if name is not None:
            names.append(str(name))
    return sorted(names)
