from __future__ import annotations

from dataclasses import dataclass
from html.parser import HTMLParser

from app.services.tokenizer import count_tokens


@dataclass(frozen=True)
class LinearizedTable:
    header: list[str]
    rows: list[list[str]]

    @property
    def header_line(self) -> str:
        return " | ".join(self.header)

    @property
    def row_lines(self) -> list[str]:
        return [" | ".join(row) for row in self.rows]

    def to_lines(self) -> list[str]:
        lines: list[str] = []
        if self.header:
            lines.append(self.header_line)
        lines.extend(self.row_lines)
        return lines


@dataclass(frozen=True)
class _TableCell:
    text: str
    is_header: bool
    rowspan: int = 1
    colspan: int = 1


class _TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[tuple[list[_TableCell], bool]] = []
        self._in_row = False
        self._in_cell = False
        self._cell_is_header = False
        self._cell_rowspan = 1
        self._cell_colspan = 1
        self._current_row: list[_TableCell] = []
        self._current_row_has_header = False
        self._current_cell: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "tr":
            self._in_row = True
            self._current_row = []
            self._current_row_has_header = False
        elif tag in {"td", "th"} and self._in_row:
            attrs_dict = {name.lower(): value for name, value in attrs}
            self._in_cell = True
            self._cell_is_header = tag == "th"
            self._cell_rowspan = _parse_span(attrs_dict.get("rowspan"))
            self._cell_colspan = _parse_span(attrs_dict.get("colspan"))
            self._current_cell = []

    def handle_endtag(self, tag: str) -> None:
        if tag in {"td", "th"} and self._in_cell:
            cell_text = _normalize_space("".join(self._current_cell))
            self._current_row.append(
                _TableCell(
                    text=cell_text,
                    is_header=self._cell_is_header,
                    rowspan=self._cell_rowspan,
                    colspan=self._cell_colspan,
                )
            )
            self._current_row_has_header = self._current_row_has_header or self._cell_is_header
            self._in_cell = False
            self._cell_is_header = False
            self._cell_rowspan = 1
            self._cell_colspan = 1
            self._current_cell = []
        elif tag == "tr" and self._in_row:
            if any(cell.text for cell in self._current_row):
                self.rows.append((self._current_row, self._current_row_has_header))
            self._in_row = False
            self._current_row = []
            self._current_row_has_header = False

    def handle_data(self, data: str) -> None:
        if self._in_cell:
            self._current_cell.append(data)


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def html_to_text(html: str) -> str:
    parser = _TextExtractor()
    parser.feed(html)
    return _normalize_space(" ".join(parser.parts))


def parse_html_table(html: str) -> LinearizedTable:
    parser = _TableParser()
    parser.feed(html)
    rows = _expand_spans(parser.rows)
    if not rows:
        text = html_to_text(html)
        return LinearizedTable(header=[], rows=[[text]] if text else [])

    header_rows: list[list[str]] = []
    body_start = 0
    for row, is_header in rows:
        if not is_header:
            break
        header_rows.append(row)
        body_start += 1

    if header_rows:
        return LinearizedTable(header=_merge_header_rows(header_rows), rows=[row for row, _ in rows[body_start:]])
    return LinearizedTable(header=[], rows=[row for row, _ in rows])


def parse_pipe_table(markdown: str) -> LinearizedTable:
    rows = [_split_pipe_row(line) for line in markdown.splitlines() if "|" in line]
    rows = [row for row in rows if any(cell for cell in row)]
    if not rows:
        return LinearizedTable(header=[], rows=[])
    if len(rows) >= 2 and _is_separator_row(rows[1]):
        return LinearizedTable(header=rows[0], rows=rows[2:])
    return LinearizedTable(header=rows[0], rows=rows[1:])


def linearize_html_table(html: str) -> str:
    return "\n".join(parse_html_table(html).to_lines())


def split_linearized_table(
    html: str,
    *,
    max_chars: int,
    token_cap: int,
    caption: str | None = None,
) -> list[str]:
    return _split_table(parse_html_table(html), max_chars=max_chars, token_cap=token_cap, caption=caption)


def split_pipe_table(
    markdown: str,
    *,
    max_chars: int,
    token_cap: int,
    caption: str | None = None,
) -> list[str]:
    return _split_table(parse_pipe_table(markdown), max_chars=max_chars, token_cap=token_cap, caption=caption)


def _split_table(
    table: LinearizedTable,
    *,
    max_chars: int,
    token_cap: int,
    caption: str | None = None,
) -> list[str]:
    prefix_lines = [caption] if caption else []
    if table.header:
        prefix_lines.append(table.header_line)
    prefix_lines = _fit_prefix_lines(prefix_lines, max_chars=max_chars, token_cap=token_cap)

    row_lines = table.row_lines
    if not row_lines:
        text = "\n".join(prefix_lines)
        return [text] if text else []

    segments: list[str] = []
    current_rows: list[str] = []
    for row_line in row_lines:
        candidate_rows = [*current_rows, row_line]
        candidate = "\n".join([*prefix_lines, *candidate_rows])
        if current_rows and _exceeds_limits(candidate, max_chars=max_chars, token_cap=token_cap):
            segments.append("\n".join([*prefix_lines, *current_rows]))
            current_rows = []
            candidate_rows = [row_line]
        row_candidate = "\n".join([*prefix_lines, row_line])
        if not current_rows and _exceeds_limits(row_candidate, max_chars=max_chars, token_cap=token_cap):
            segments.extend(_split_oversized_row(row_line, prefix_lines=prefix_lines, max_chars=max_chars, token_cap=token_cap))
        else:
            current_rows = candidate_rows
    if current_rows:
        segments.append("\n".join([*prefix_lines, *current_rows]))
    return segments


def _expand_spans(rows: list[tuple[list[_TableCell], bool]]) -> list[tuple[list[str], bool]]:
    expanded: list[tuple[list[str], bool]] = []
    carry: dict[int, tuple[str, int]] = {}
    for cells, is_header in rows:
        row, carry = _expand_row(cells, carry)
        if any(cell for cell in row):
            expanded.append((row, is_header))
    while carry:
        row, carry = _expand_row([], carry)
        if any(cell for cell in row):
            expanded.append((row, False))
    return expanded


def _expand_row(
    cells: list[_TableCell],
    carry: dict[int, tuple[str, int]],
) -> tuple[list[str], dict[int, tuple[str, int]]]:
    row: list[str] = []
    next_carry: dict[int, tuple[str, int]] = {}
    col = 0

    def place_carried(column: int) -> None:
        text, remaining = carry.pop(column)
        _place(row, column, text)
        if remaining > 1:
            next_carry[column] = (text, remaining - 1)

    for cell in cells:
        while col in carry:
            place_carried(col)
            col += 1
        for offset in range(cell.colspan):
            target = col + offset
            _place(row, target, cell.text)
            if cell.rowspan > 1:
                next_carry[target] = (cell.text, cell.rowspan - 1)
        col += cell.colspan
    while carry:
        next_col = min(carry)
        while col < next_col:
            _place(row, col, "")
            col += 1
        place_carried(next_col)
        col = next_col + 1
    return row, next_carry


def _place(row: list[str], index: int, text: str) -> None:
    while len(row) <= index:
        row.append("")
    row[index] = text


def _merge_header_rows(header_rows: list[list[str]]) -> list[str]:
    width = max((len(row) for row in header_rows), default=0)
    header: list[str] = []
    for col in range(width):
        parts: list[str] = []
        for row in header_rows:
            value = row[col] if col < len(row) else ""
            if value and value not in parts:
                parts.append(value)
        header.append(" ".join(parts))
    return header


def _normalize_space(value: str) -> str:
    return " ".join(value.split())


def _parse_span(value: str | None) -> int:
    try:
        span = int(value or 1)
    except (TypeError, ValueError):
        return 1
    return max(1, span)


def _exceeds_limits(text: str, *, max_chars: int, token_cap: int) -> bool:
    return len(text) > max_chars or count_tokens(text) > token_cap


def _fit_prefix_lines(prefix_lines: list[str], *, max_chars: int, token_cap: int) -> list[str]:
    prefix = "\n".join(line for line in prefix_lines if line).strip()
    if not prefix:
        return []
    while prefix and _exceeds_limits(f"{prefix}\nX", max_chars=max_chars, token_cap=token_cap):
        prefix = prefix[:-1].rstrip()
    return prefix.splitlines() if prefix else []


def _split_pipe_row(line: str) -> list[str]:
    stripped = line.strip()
    if stripped.startswith("|"):
        stripped = stripped[1:]
    if stripped.endswith("|"):
        stripped = stripped[:-1]
    return [_normalize_space(cell) for cell in stripped.split("|")]


def _is_separator_row(row: list[str]) -> bool:
    return bool(row) and all(cell and set(cell) <= {"-", ":"} for cell in row)


def _split_oversized_row(row_line: str, *, prefix_lines: list[str], max_chars: int, token_cap: int) -> list[str]:
    prefix = "\n".join(prefix_lines)
    prefix_extra = len(prefix) + (1 if prefix else 0)
    prefix_tokens = count_tokens(prefix) if prefix else 0
    remaining_token_cap = max(1, token_cap - prefix_tokens)
    split_limit = max(1, min(max_chars - prefix_extra, remaining_token_cap * 2))
    parts: list[str] = []
    remaining = row_line.strip()
    while remaining:
        split_at = min(len(remaining), split_limit)
        if split_at < len(remaining):
            whitespace_at = remaining.rfind(" ", 0, split_at)
            if whitespace_at >= split_limit // 2:
                split_at = whitespace_at
        part = _fit_row_part(
            remaining[:split_at].strip(),
            prefix_lines=prefix_lines,
            max_chars=max_chars,
            token_cap=token_cap,
        )
        if not part:
            part = remaining[:1]
        if part:
            parts.append("\n".join([*prefix_lines, part]))
        remaining = remaining[len(part) :].strip()
    return parts


def _fit_row_part(part: str, *, prefix_lines: list[str], max_chars: int, token_cap: int) -> str:
    while part and _exceeds_limits("\n".join([*prefix_lines, part]), max_chars=max_chars, token_cap=token_cap):
        part = part[:-1].rstrip()
    return part
