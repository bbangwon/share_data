from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from app.services.chunk_identity import chunk_identity_payload


class RawElement(BaseModel):
    id: int | str
    type: str = "text"
    text: str = ""
    html: str | None = None
    page_number: int | None = None
    section_path: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class DocumentMeta(BaseModel):
    document_key: str
    file: str
    parse_result_path: str
    doc_name: str | None = None
    total_pages: int | None = None
    total_elements: int | None = None
    table_element_count: int | None = None
    picture_element_count: int | None = None
    page_integrity: bool | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ParentChunk(BaseModel):
    chunk_id: str
    text: str
    token_count: int
    char_count: int
    parent_idx: int
    page_numbers: list[int] = Field(default_factory=list)
    source_element_ids: list[int | str] = Field(default_factory=list)
    source_element_types: list[str] = Field(default_factory=list)
    source_element_metadata: list[dict[str, Any]] = Field(default_factory=list)
    section_path: str | None = None
    section_title: str | None = None
    section_level: int | None = None
    contextual_prefix: str | None = None
    child_ids: list[str] = Field(default_factory=list)


class ChildChunk(BaseModel):
    chunk_id: str
    text: str
    token_count: int
    char_count: int
    parent_text: str
    parent_id: str
    parent_idx: int
    child_idx: int
    page_numbers: list[int] = Field(default_factory=list)
    source_element_ids: list[int | str] = Field(default_factory=list)
    source_element_types: list[str] = Field(default_factory=list)
    source_element_metadata: list[dict[str, Any]] = Field(default_factory=list)
    section_path: str | None = None
    section_title: str | None = None
    section_level: int | None = None
    contextual_prefix: str | None = None
    metadata_prefix: str | None = None
    boost_keywords: str | None = None


class ChunkingResult(BaseModel):
    document_key: str
    meta: DocumentMeta
    parents: list[ParentChunk]
    children: list[ChildChunk]


class EmbeddedChunk(BaseModel):
    chunk_id: str
    payload: dict[str, Any]
    dense_vector: list[float]
    sparse_vector: dict[str, list[int] | list[float]]
    chunk: ChildChunk


def chunk_to_payload(
    chunk: ChildChunk,
    meta: DocumentMeta,
    *,
    transform_version: str | None = None,
    collection_name: str | None = None,
    chunking_profile: str | None = None,
    document_key: str | None = None,
) -> dict[str, Any]:
    page_numbers = [int(page) for page in chunk.page_numbers]
    effective_document_key = document_key or meta.document_key
    effective_chunking_profile = chunking_profile or transform_version
    payload: dict[str, Any] = {
        "chunk_type": "child",
        "chunk_id": chunk.chunk_id,
        "document_key": effective_document_key,
        "file": meta.file,
        "doc_name": meta.doc_name or meta.file,
        "parse_result_path": meta.parse_result_path,
        "text": chunk.text,
        "parent_text": chunk.parent_text,
        "parent_id": chunk.parent_id,
        "parent_idx": chunk.parent_idx,
        "child_idx": chunk.child_idx,
        "char_count": chunk.char_count,
        "token_count": chunk.token_count,
        "page_numbers": page_numbers,
        "source_element_ids": [str(item) for item in chunk.source_element_ids],
        "source_element_types": chunk.source_element_types,
        "source_element_metadata": chunk.source_element_metadata,
        "section_path": chunk.section_path,
        "section_title": chunk.section_title,
        "section_level": chunk.section_level,
        "contextual_prefix": chunk.contextual_prefix,
        "metadata_prefix": chunk.metadata_prefix,
        "boost_keywords": chunk.boost_keywords,
        "retrieval_signal_prefix": _retrieval_signal(page_numbers),
    }
    if collection_name and effective_chunking_profile:
        payload.update(
            chunk_identity_payload(
                document_key=effective_document_key,
                collection_name=collection_name,
                chunking_profile=effective_chunking_profile,
                chunk_id=chunk.chunk_id,
            )
        )
    if page_numbers:
        payload["page_start"] = min(page_numbers)
        payload["page_end"] = max(page_numbers)
    if transform_version:
        payload["transform_version"] = transform_version
    for key in (
        "total_pages",
        "total_elements",
        "table_element_count",
        "picture_element_count",
        "page_integrity",
    ):
        value = getattr(meta, key)
        if value is not None:
            payload[key] = value
    return {key: value for key, value in payload.items() if value is not None}


def _retrieval_signal(page_numbers: list[int]) -> str:
    if not page_numbers:
        return ""
    if len(page_numbers) == 1:
        return f"page: {page_numbers[0]}"
    return f"pages: {min(page_numbers)}-{max(page_numbers)}"
