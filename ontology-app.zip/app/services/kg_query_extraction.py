from __future__ import annotations

import inspect
import json
import re
import warnings
from functools import lru_cache
from typing import Any, Literal

from langchain_core.prompts import load_prompt
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field, field_validator, model_validator

from app.core.config import Settings

KGExpansionMode = Literal["legacy", "query_guided"]
KGQueryExtractionStatus = Literal["completed", "fallback", "skipped", "failed"]
KGQueryIntent = Literal[
    "role",
    "procedure",
    "cooperation",
    "temporal",
    "criteria",
    "contact",
    "location",
    "resource",
    "comparison",
    "unknown",
]

SUPPORTED_RELATION_TYPES: tuple[str, ...] = (
    "ASSIGNED_TO",
    "RESPONSIBLE_FOR",
    "SUPPORTS",
    "ACTIVATED_AT",
    "APPLIES_TO",
    "LOCATED_IN",
    "USES_TRANSPORT",
    "HAS_CONTACT",
    "PRECEDES",
    "REQUIRES_COOPERATION_WITH",
    "HAS_CRITERIA",
    "REPORTS_TO",
    "COMMUNICATES_VIA",
    "MONITORS",
    "OPERATES",
    "REFERENCES",
    "BELONGS_TO",
    "RELATED_TO",
)

INTENT_RELATION_TYPES: dict[str, list[str]] = {
    "role": ["ASSIGNED_TO", "RESPONSIBLE_FOR", "REPORTS_TO"],
    "procedure": ["PRECEDES", "ACTIVATED_AT", "APPLIES_TO", "REFERENCES"],
    "cooperation": ["SUPPORTS", "REQUIRES_COOPERATION_WITH", "REPORTS_TO", "COMMUNICATES_VIA"],
    "temporal": ["PRECEDES", "ACTIVATED_AT"],
    "criteria": ["HAS_CRITERIA", "APPLIES_TO"],
    "contact": ["HAS_CONTACT", "COMMUNICATES_VIA"],
    "location": ["LOCATED_IN", "APPLIES_TO"],
    "resource": ["USES_TRANSPORT", "OPERATES", "SUPPORTS"],
    "comparison": ["ASSIGNED_TO", "RESPONSIBLE_FOR", "SUPPORTS", "APPLIES_TO", "HAS_CRITERIA", "PRECEDES", "ACTIVATED_AT", "RELATED_TO"],
    "unknown": [],
}


class KGQueryExtraction(BaseModel):
    entities: list[str] = Field(default_factory=list)
    relation_types: list[str] = Field(default_factory=list)
    intent: KGQueryIntent = "unknown"
    constraints: dict[str, Any] = Field(default_factory=dict)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)

    @field_validator("entities", mode="before")
    @classmethod
    def normalize_entities(cls, value: Any) -> list[str]:
        return _coerce_string_list(value)

    @field_validator("relation_types", mode="before")
    @classmethod
    def normalize_relation_types(cls, value: Any) -> list[str]:
        return _coerce_string_list(value)

    @field_validator("constraints", mode="before")
    @classmethod
    def normalize_constraints(cls, value: Any) -> dict[str, Any]:
        return value if isinstance(value, dict) else {}

    @model_validator(mode="after")
    def sanitize(self) -> "KGQueryExtraction":
        self.entities = _dedupe([item.strip() for item in self.entities if item.strip()])[:12]
        self.relation_types = _filter_supported_relation_types(self.relation_types)
        self.confidence = max(0.0, min(1.0, float(self.confidence)))
        return self


class KGQueryExtractionResult(BaseModel):
    status: KGQueryExtractionStatus
    extraction: KGQueryExtraction = Field(default_factory=KGQueryExtraction)
    extractor: str = "none"
    error: str | None = None

    def trace_payload(self) -> dict[str, Any]:
        extraction = self.extraction
        return {
            "query_extraction_status": self.status,
            "query_extraction_error": self.error,
            "query_extractor": self.extractor,
            "query_entities": extraction.entities,
            "query_relation_types": extraction.relation_types,
            "query_intent": extraction.intent,
            "query_constraints": extraction.constraints,
            "query_extraction_confidence": extraction.confidence,
        }


class KGQueryExtractionService:
    def __init__(self, settings: Settings, *, llm: Any | None = None) -> None:
        self.settings = settings
        self.llm = llm

    async def extract(
        self,
        *,
        query: str,
        relation_allowlist: list[str] | None = None,
    ) -> KGQueryExtractionResult:
        if not self.settings.kg_query_extraction.enabled:
            if self.settings.kg_query_extraction.fallback_to_rule_based:
                return KGQueryExtractionResult(
                    status="fallback",
                    extraction=extract_kg_query_rule_based(
                        query=query,
                        relation_allowlist=relation_allowlist,
                    ),
                    extractor="rule_based",
                    error="kg_query_extraction.enabled=false",
                )
            return KGQueryExtractionResult(status="skipped", error="kg_query_extraction.enabled=false")

        if self.settings.kg_query_extraction.mode == "rule_based":
            return KGQueryExtractionResult(
                status="fallback",
                extraction=extract_kg_query_rule_based(
                    query=query,
                    relation_allowlist=relation_allowlist,
                ),
                extractor="rule_based",
            )

        try:
            extraction = await self._extract_with_llm(
                query=query,
                relation_allowlist=relation_allowlist,
            )
            return KGQueryExtractionResult(
                status="completed",
                extraction=extraction,
                extractor="llm",
            )
        except Exception as exc:
            if not self.settings.kg_query_extraction.fallback_to_rule_based:
                return KGQueryExtractionResult(status="failed", extractor="llm", error=str(exc))
            return KGQueryExtractionResult(
                status="fallback",
                extraction=extract_kg_query_rule_based(
                    query=query,
                    relation_allowlist=relation_allowlist,
                ),
                extractor="rule_based",
                error=str(exc),
            )

    async def _extract_with_llm(
        self,
        *,
        query: str,
        relation_allowlist: list[str] | None,
    ) -> KGQueryExtraction:
        if not self.settings.llm.base_url:
            raise ValueError("llm.base_url is required for kg query extraction")
        if not self.settings.llm.model_name:
            raise ValueError("llm.model_name is required for kg query extraction")
        allowed_relation_types = _allowed_relation_types(relation_allowlist)
        prompt = _load_prompt(str(self.settings.kg_query_extraction.prompt_path)).format_prompt(
            query=query,
            allowed_relation_types=", ".join(allowed_relation_types),
            allowed_intents=", ".join(_KG_QUERY_INTENTS),
        )
        client = self.llm or ChatOpenAI(
            model=self.settings.llm.model_name,
            base_url=self.settings.llm.base_url,
            timeout=self.settings.kg_query_extraction.timeout or self.settings.llm.timeout,
            temperature=self.settings.kg_query_extraction.temperature,
            api_key=self.settings.llm.api_key.get_secret_value(),
        )
        response = client.ainvoke(prompt) if hasattr(client, "ainvoke") else client.invoke(prompt)
        message = await response if inspect.isawaitable(response) else response
        payload = _parse_json_object(_message_content(message))
        extraction = KGQueryExtraction.model_validate(
            {
                "entities": payload.get("entities"),
                "relation_types": payload.get("relation_types"),
                "intent": _sanitize_intent(payload.get("intent")),
                "constraints": payload.get("constraints"),
                "confidence": payload.get("confidence") or 0.0,
            }
        )
        return extraction.model_copy(
            update={
                "relation_types": _filter_supported_relation_types(
                    extraction.relation_types,
                    relation_allowlist=relation_allowlist,
                )
            }
        )


def extract_kg_query_rule_based(
    *,
    query: str,
    relation_allowlist: list[str] | None = None,
) -> KGQueryExtraction:
    text = _normalize_text(query)
    intent = _classify_intent(text)
    relation_types = list(INTENT_RELATION_TYPES.get(intent, []))
    if not relation_types:
        relation_types = _keyword_relation_types(text)
    if not relation_types and relation_allowlist:
        relation_types = list(relation_allowlist)
    entities = _entity_terms(query)
    confidence = 0.58 if intent != "unknown" else 0.42
    if relation_types:
        confidence += 0.08
    if entities:
        confidence += 0.08
    return KGQueryExtraction(
        entities=entities,
        relation_types=_filter_supported_relation_types(
            relation_types,
            relation_allowlist=relation_allowlist,
        ),
        intent=intent,
        constraints=_extract_constraints(query),
        confidence=min(0.82, confidence),
    )


def relation_types_for_intent(intent: str | None) -> list[str]:
    return list(INTENT_RELATION_TYPES.get(intent or "unknown", []))


def normalize_query_entity_terms(entities: list[str]) -> list[str]:
    result: list[str] = []
    for entity in entities:
        normalized = _normalize_entity(_clean_entity_token(entity))
        if len(normalized) >= 2 and normalized not in result:
            result.append(normalized)
    return result[:12]


def _classify_intent(text: str) -> KGQueryIntent:
    if _contains_any(text, ("비교", "차이", "구분", "각각", "대비")):
        return "comparison"
    if _contains_any(text, ("순서", "단계", "언제", "이후", "이전", "전후", "시점", "즉시")):
        return "temporal"
    if _contains_any(text, ("협조", "협업", "지원", "연계", "공조", "전파", "보고", "연락")):
        return "cooperation"
    if _contains_any(text, ("담당", "역할", "임무", "책임", "누가", "부서", "기관")):
        return "role"
    if _contains_any(text, ("기준", "조건", "요건", "근거", "판단")):
        return "criteria"
    if _contains_any(text, ("연락처", "연락망", "전화", "통신", "보고체계")):
        return "contact"
    if _contains_any(text, ("장소", "지역", "위치", "현장", "부산", "구역")):
        return "location"
    if _contains_any(text, ("장비", "수단", "차량", "운송", "자원", "운영")):
        return "resource"
    if _contains_any(text, ("절차", "조치", "대응", "수행", "흐름")):
        return "procedure"
    return "unknown"


def _keyword_relation_types(text: str) -> list[str]:
    result: list[str] = []
    keyword_map = {
        "HAS_CONTACT": ("연락", "전화", "연락망", "통신"),
        "COMMUNICATES_VIA": ("전파", "통보", "보고", "통신"),
        "LOCATED_IN": ("장소", "위치", "지역", "현장"),
        "USES_TRANSPORT": ("차량", "운송", "수송", "이동"),
        "HAS_CRITERIA": ("기준", "조건", "요건", "근거"),
        "REQUIRES_COOPERATION_WITH": ("협조", "협업", "공조", "연계"),
        "PRECEDES": ("순서", "이후", "이전", "전후", "먼저", "다음"),
        "RESPONSIBLE_FOR": ("담당", "책임", "역할", "임무"),
    }
    for relation_type, keywords in keyword_map.items():
        if _contains_any(text, keywords):
            result.append(relation_type)
    return result


def _entity_terms(query: str) -> list[str]:
    stopwords = {
        "어떤",
        "무엇",
        "어떻게",
        "주세요",
        "알려",
        "대한",
        "관련",
        "방사능",
        "누출",
        "상황",
        "조치",
        "절차",
        "역할",
        "관계",
    }
    terms: list[str] = []
    for token in re.findall(r"[가-힣A-Za-z0-9]{2,}", query):
        cleaned = _clean_entity_token(token)
        normalized = _normalize_entity(cleaned)
        if normalized in stopwords or len(normalized) < 2:
            continue
        if cleaned not in terms:
            terms.append(cleaned)
    return terms[:10]


def _extract_constraints(query: str) -> dict[str, Any]:
    constraints: dict[str, Any] = {}
    pages = [int(value) for value in re.findall(r"(\d+)\s*페이지", query)]
    if pages:
        constraints["pages"] = pages
    stages = re.findall(r"(초기대응|비상\s*\d+\s*단계|비상\s*[ⅠⅡⅢIVX]+단계|상황판단회의)", query)
    if stages:
        constraints["stages"] = _dedupe([re.sub(r"\s+", "", item) for item in stages])
    return constraints


def _allowed_relation_types(relation_allowlist: list[str] | None) -> list[str]:
    relation_allowlist = relation_allowlist or []
    allowed = [item for item in relation_allowlist if item in SUPPORTED_RELATION_TYPES]
    return allowed or list(SUPPORTED_RELATION_TYPES)


def _filter_supported_relation_types(
    values: list[str],
    *,
    relation_allowlist: list[str] | None = None,
) -> list[str]:
    allowed = set(_allowed_relation_types(relation_allowlist))
    result: list[str] = []
    for value in values:
        normalized = str(value or "").strip().upper()
        if normalized in allowed and normalized not in result:
            result.append(normalized)
    return result


def _normalize_text(value: str) -> str:
    return re.sub(r"\s+", "", value.lower())


def _normalize_entity(value: str) -> str:
    return re.sub(r"[\s\W_]+", "", value.lower())


def _clean_entity_token(value: str) -> str:
    cleaned = value.strip()
    for suffix in ("으로부터", "으로", "에서", "에게", "부터", "까지", "와", "은", "는", "이", "가", "을", "를", "의", "로"):
        if len(cleaned) > len(suffix) + 1 and cleaned.endswith(suffix):
            return cleaned[: -len(suffix)]
    return cleaned


def _sanitize_intent(value: Any) -> str:
    intent = str(value or "unknown").strip().lower()
    return intent if intent in _KG_QUERY_INTENTS else "unknown"


def _contains_any(text: str, needles: tuple[str, ...]) -> bool:
    return any(needle in text for needle in needles)


def _coerce_string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value:
        if isinstance(item, str):
            result.append(item)
        elif isinstance(item, dict):
            name = item.get("name") or item.get("text") or item.get("value")
            if name:
                result.append(str(name))
    return result


def _dedupe(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        if value not in result:
            result.append(value)
    return result


def _parse_json_object(text: str) -> dict[str, Any]:
    stripped = text.strip()
    fence = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", stripped, re.DOTALL)
    if fence:
        stripped = fence.group(1)
    if not stripped.startswith("{"):
        match = re.search(r"\{.*\}", stripped, re.DOTALL)
        if match:
            stripped = match.group(0)
    payload = json.loads(stripped)
    if not isinstance(payload, dict):
        raise ValueError("LLM kg query extraction response must be a JSON object")
    return payload


def _message_content(message: Any) -> str:
    content = getattr(message, "content", message)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(str(item.get("text") or ""))
            elif isinstance(item, str):
                parts.append(item)
        return "\n".join(parts)
    return str(content)


@lru_cache(maxsize=8)
def _load_prompt(path: str) -> Any:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return load_prompt(path)


_KG_QUERY_INTENTS: tuple[str, ...] = (
    "role",
    "procedure",
    "cooperation",
    "temporal",
    "criteria",
    "contact",
    "location",
    "resource",
    "comparison",
    "unknown",
)
