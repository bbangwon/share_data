from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class ChunkEvalClient:
    """Client for the optional external chunk-eval reranking/filtering service."""

    def __init__(
        self,
        *,
        base_url: str,
        timeout: float,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.client = client

    async def evaluate(
        self,
        queries: list[str],
        documents: list[list[dict[str, Any]]],
    ) -> list[list[dict[str, Any]]]:
        payload = {"queries": queries, "documents": documents}
        try:
            if self.client is not None:
                response = await self.client.post(
                    f"{self.base_url}/v1/chunk-eval",
                    json=payload,
                    timeout=self.timeout,
                )
            else:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    response = await client.post(f"{self.base_url}/v1/chunk-eval", json=payload)
            response.raise_for_status()
            data = response.json()
            evaluated = data.get("documents")
            if is_document_groups(evaluated, expected_groups=len(queries)):
                return evaluated
            logger.warning("chunk-eval returned invalid document groups; falling back to raw documents")
        except Exception as exc:
            logger.warning("chunk-eval failed; falling back to raw documents: %s", exc)
        return documents


def is_document_groups(value: Any, *, expected_groups: int | None = None) -> bool:
    if expected_groups is not None and (not isinstance(value, list) or len(value) != expected_groups):
        return False
    return isinstance(value, list) and all(
        isinstance(group, list) and all(isinstance(document, dict) for document in group)
        for group in value
    )
