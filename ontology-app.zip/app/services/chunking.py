from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TypeVar

from app.core.config import Settings, get_settings
from app.services.schemas import ChildChunk, ChunkingResult, DocumentMeta, ParentChunk, RawElement
from app.services.table_utils import html_to_text, linearize_html_table, split_linearized_table, split_pipe_table
from app.services.tokenizer import count_tokens

T = TypeVar("T")


@dataclass(frozen=True)
class _Leaf:
    text: str
    source_elements: list[RawElement]
    section_path: str | None = None
    section_title: str | None = None
    section_level: int | None = None


@dataclass(frozen=True)
class _SectionContext:
    path: str
    title: str
    level: int


_ROMAN_HEADING_RE = re.compile(r"^[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ]+[.\s]")
_ASCII_ROMAN_HEADING_RE = re.compile(r"^(?:[IVXLCDM]+)[.\s]")
_PAREN_NUM_HEADING_RE = re.compile(r"^\d+\)")
_KOREAN_PAREN_HEADING_RE = re.compile(r"^[가-힣]\)")
_KOREAN_DOT_HEADING_RE = re.compile(r"^[가-힣]\.")
_DECIMAL_HEADING_RE = re.compile(r"^(\d+(?:\.\d+)*)(?:[.)]|\s|$)")


def chunk_document(
    elements: list[RawElement],
    meta: DocumentMeta,
    settings: Settings | None = None,
) -> ChunkingResult:
    settings = settings or get_settings()
    leaves = _build_leaves(elements, settings)
    parent_groups = _smooth_parent_groups(_group_parent_leaves(leaves, settings), settings)
    parents = _build_parents(parent_groups, settings)
    children = _build_children(parent_groups, parents, settings)
    return ChunkingResult(document_key=meta.document_key, meta=meta, parents=parents, children=children)


def _build_leaves(elements: list[RawElement], settings: Settings) -> list[_Leaf]:
    leaves: list[_Leaf] = []
    idx = 0
    section_stack: list[_SectionContext] = []
    ignored_categories = {category.lower() for category in settings.chunking.ignore_categories}
    while idx < len(elements):
        element = elements[idx]
        raw_category = str(element.metadata.get("raw_category") or element.metadata.get("category") or "")
        if raw_category.lower() in ignored_categories:
            idx += 1
            continue
        element_type = element.type.lower()
        next_element = elements[idx + 1] if idx + 1 < len(elements) else None

        if element_type in {"heading", "header"}:
            _update_section_stack(section_stack, element)
            idx += 1
            continue
        section_context = _element_section_context(element, section_stack[-1] if section_stack else None)

        if element_type == "caption" and next_element and next_element.type.lower() == "table":
            leaves.extend(
                _table_leaves(
                    next_element,
                    settings,
                    caption=element.text,
                    sources=[element, next_element],
                    section_context=_element_section_context(next_element, section_context),
                )
            )
            idx += 2
            continue

        if element_type == "table":
            leaves.extend(
                _table_leaves(
                    element,
                    settings,
                    caption=None,
                    sources=[element],
                    section_context=section_context,
                )
            )
            idx += 1
            continue

        text = _element_text(element)
        for segment in _split_text(
            text,
            max_chars=settings.chunking.child_char_max,
            token_cap=settings.chunking.child_token_cap,
            min_leaf_chars=settings.chunking.min_leaf_chars,
        ):
            leaves.append(_leaf(segment, [element], section_context))
        idx += 1
    return [leaf for leaf in leaves if leaf.text.strip()]


def _table_leaves(
    element: RawElement,
    settings: Settings,
    *,
    caption: str | None,
    sources: list[RawElement],
    section_context: _SectionContext | None,
) -> list[_Leaf]:
    html = element.html or element.text or ""
    if element.html:
        segments = split_linearized_table(
            html,
            max_chars=settings.chunking.child_char_max,
            token_cap=settings.chunking.child_token_cap,
            caption=caption,
        )
    elif _looks_like_pipe_table(html):
        segments = split_pipe_table(
            html,
            max_chars=settings.chunking.child_char_max,
            token_cap=settings.chunking.child_token_cap,
            caption=caption,
        )
    else:
        linearized = "\n".join(part for part in [caption, html] if part)
        segments = _split_text(
            linearized,
            max_chars=settings.chunking.child_char_max,
            token_cap=settings.chunking.child_token_cap,
            min_leaf_chars=settings.chunking.min_leaf_chars,
        )
    return [_leaf(segment, sources, section_context) for segment in segments]


def _leaf(
    text: str,
    sources: list[RawElement],
    section_context: _SectionContext | None,
) -> _Leaf:
    return _Leaf(
        text=text,
        source_elements=sources,
        section_path=section_context.path if section_context else None,
        section_title=section_context.title if section_context else None,
        section_level=section_context.level if section_context else None,
    )


def _update_section_stack(
    section_stack: list[_SectionContext],
    element: RawElement,
) -> _SectionContext | None:
    title = (element.text or element.section_path or "").strip()
    if not title:
        return section_stack[-1] if section_stack else None
    if element.section_path and ">" in element.section_path:
        parts = _split_section_path(element.section_path)
        if parts:
            section_stack[:] = [
                _SectionContext(
                    path=" > ".join(parts[: index + 1]),
                    title=part,
                    level=index + 1,
                )
                for index, part in enumerate(parts)
            ]
            return section_stack[-1]
    level = _infer_heading_level(title, current_depth=len(section_stack))
    level = max(1, min(level, len(section_stack) + 1))
    prefix = section_stack[: level - 1]
    context = _SectionContext(
        path=" > ".join([*(item.title for item in prefix), title]),
        title=title,
        level=level,
    )
    section_stack[:] = [*prefix, context]
    return context


def _element_section_context(
    element: RawElement,
    current: _SectionContext | None,
) -> _SectionContext | None:
    if element.section_path and ">" in element.section_path:
        parts = _split_section_path(element.section_path)
        if parts:
            return _SectionContext(
                path=" > ".join(parts),
                title=parts[-1],
                level=len(parts),
            )
    if current is not None:
        return current
    if element.section_path:
        title = element.section_path.strip()
        return _SectionContext(path=title, title=title, level=1)
    return None


def _infer_heading_level(title: str, *, current_depth: int) -> int:
    stripped = title.strip()
    if _ROMAN_HEADING_RE.match(stripped) or _ASCII_ROMAN_HEADING_RE.match(stripped):
        return 1
    if _PAREN_NUM_HEADING_RE.match(stripped):
        return 3
    if _KOREAN_PAREN_HEADING_RE.match(stripped):
        return 4
    if _KOREAN_DOT_HEADING_RE.match(stripped):
        return 3
    decimal_match = _DECIMAL_HEADING_RE.match(stripped)
    if decimal_match:
        return 2 + decimal_match.group(1).count(".")
    return current_depth or 1


def _split_section_path(value: str) -> list[str]:
    return [part.strip() for part in value.split(">") if part.strip()]


def _looks_like_pipe_table(text: str) -> bool:
    pipe_lines = [line for line in text.splitlines() if "|" in line]
    return len(pipe_lines) >= 2


def _element_text(element: RawElement) -> str:
    if element.text:
        return element.text
    if element.html:
        if element.type.lower() == "table":
            return linearize_html_table(element.html)
        return html_to_text(element.html)
    return ""


def _split_text(text: str, *, max_chars: int, token_cap: int, min_leaf_chars: int) -> list[str]:
    text = text.strip()
    if not text or (len(text) <= max_chars and count_tokens(text) <= token_cap):
        return [text] if text else []

    segments: list[str] = []
    remaining = text
    while len(remaining) > max_chars or count_tokens(remaining) > token_cap:
        split_limit = min(max_chars, max(1, token_cap * 2))
        split_at = remaining.rfind("\n", 0, split_limit)
        if split_at < split_limit // 2:
            split_at = remaining.rfind(" ", 0, split_limit)
        if split_at < split_limit // 2:
            split_at = split_limit
        segments.append(remaining[:split_at].strip())
        remaining = remaining[split_at:].strip()
    if remaining:
        segments.append(remaining)
    return _merge_short_segments(segments, min_leaf_chars=min_leaf_chars, max_chars=max_chars, token_cap=token_cap)


def _merge_short_segments(segments: list[str], *, min_leaf_chars: int, max_chars: int, token_cap: int) -> list[str]:
    if min_leaf_chars <= 0:
        return segments
    merged: list[str] = []
    for segment in segments:
        if merged and len(segment) < min_leaf_chars:
            candidate = f"{merged[-1]}\n{segment}".strip()
            if len(candidate) <= max_chars and count_tokens(candidate) <= token_cap:
                merged[-1] = candidate
                continue
        merged.append(segment)
    return merged


def _group_parent_leaves(leaves: list[_Leaf], settings: Settings) -> list[list[_Leaf]]:
    groups: list[list[_Leaf]] = []
    current: list[_Leaf] = []

    def flush() -> None:
        if not current:
            return
        groups.append(list(current))
        current.clear()

    for leaf in leaves:
        if current and leaf.section_path != current[-1].section_path:
            flush()
        candidate = "\n\n".join([*(item.text for item in current), leaf.text])
        if current and len(candidate) > settings.chunking.parent_char_max:
            flush()
        elif (
            current
            and _leaf_group_char_count(current) >= settings.chunking.parent_min_chars
            and len(candidate) > settings.chunking.parent_target_chars
        ):
            flush()
        current.append(leaf)
    flush()
    return groups


def _smooth_parent_groups(parent_groups: list[list[_Leaf]], settings: Settings) -> list[list[_Leaf]]:
    if settings.chunking.parent_min_chars <= 0:
        return parent_groups

    smoothed: list[list[_Leaf]] = []
    for group in parent_groups:
        current = list(group)
        if (
            smoothed
            and (
                _leaf_group_char_count(smoothed[-1]) < settings.chunking.parent_min_chars
                or _leaf_group_char_count(current) < settings.chunking.parent_min_chars
            )
            and _can_merge_leaf_groups(smoothed[-1], current, max_chars=settings.chunking.parent_char_max)
        ):
            smoothed[-1].extend(current)
        else:
            smoothed.append(current)

    index = 0
    while index < len(smoothed) - 1:
        if (
            _leaf_group_char_count(smoothed[index]) < settings.chunking.parent_min_chars
            and _can_merge_leaf_groups(smoothed[index], smoothed[index + 1], max_chars=settings.chunking.parent_char_max)
        ):
            smoothed[index].extend(smoothed.pop(index + 1))
            continue
        index += 1

    return smoothed


def _build_parents(parent_groups: list[list[_Leaf]], settings: Settings) -> list[ParentChunk]:
    parents: list[ParentChunk] = []
    for current in parent_groups:
        parent_idx = len(parents)
        text = "\n\n".join(leaf.text for leaf in current)[: settings.chunking.parent_char_max]
        parents.append(
            ParentChunk(
                chunk_id=f"parent:{parent_idx}",
                text=text,
                token_count=count_tokens(text),
                char_count=len(text),
                parent_idx=parent_idx,
                page_numbers=_unique_pages(current),
                source_element_ids=_unique_ids(current),
                source_element_types=_unique_types(current),
                source_element_metadata=_metadata_for_sources([source for leaf in current for source in leaf.source_elements]),
                section_path=_first_section(current),
                section_title=_first_section_title(current),
                section_level=_first_section_level(current),
                contextual_prefix=_section_context(_first_section(current)),
            )
        )
    return parents


def _build_children(
    parent_groups: list[list[_Leaf]],
    parents: list[ParentChunk],
    settings: Settings,
) -> list[ChildChunk]:
    children: list[ChildChunk] = []
    for parent, leaves in zip(parents, parent_groups, strict=True):
        parent_child_ids: list[str] = []
        child_groups = _group_child_leaves(leaves, settings)
        for child_idx, child_leaves in enumerate(child_groups):
            child_text = "\n\n".join(leaf.text for leaf in child_leaves)
            source_elements = [source for leaf in child_leaves for source in leaf.source_elements]
            section_path = _first_section(child_leaves)
            section_title = _first_section_title(child_leaves)
            section_level = _first_section_level(child_leaves)
            chunk_id = f"child:{parent.parent_idx}:{child_idx}"
            child = ChildChunk(
                chunk_id=chunk_id,
                text=child_text,
                token_count=count_tokens(child_text),
                char_count=len(child_text),
                parent_text=parent.text,
                parent_id=parent.chunk_id,
                parent_idx=parent.parent_idx,
                child_idx=child_idx,
                page_numbers=_pages_for_sources(source_elements),
                source_element_ids=_ids_for_sources(source_elements),
                source_element_types=_types_for_sources(source_elements),
                source_element_metadata=_metadata_for_sources(source_elements),
                section_path=section_path,
                section_title=section_title,
                section_level=section_level,
                contextual_prefix=_section_context(section_path),
            )
            children.append(child)
            parent_child_ids.append(chunk_id)
        parent.child_ids = parent_child_ids
    return children


def _group_child_leaves(leaves: list[_Leaf], settings: Settings) -> list[list[_Leaf]]:
    groups: list[list[_Leaf]] = []
    current: list[_Leaf] = []

    def flush() -> None:
        if not current:
            return
        groups.append(list(current))
        current.clear()

    for leaf in leaves:
        if _contains_table(leaf):
            flush()
            groups.append([leaf])
            continue

        if not current:
            current.append(leaf)
            continue

        candidate = [*current, leaf]
        current_chars = _leaf_group_char_count(current)
        candidate_chars = _leaf_group_char_count(candidate)
        if (
            _fits_child_group(candidate, settings)
            and (
                current_chars < settings.chunking.child_min_chars
                or candidate_chars <= settings.chunking.child_target_chars
            )
        ):
            current.append(leaf)
        else:
            flush()
            current.append(leaf)
    flush()

    return _smooth_child_groups(groups, settings)


def _smooth_child_groups(child_groups: list[list[_Leaf]], settings: Settings) -> list[list[_Leaf]]:
    if settings.chunking.child_min_chars <= 0:
        return child_groups

    smoothed: list[list[_Leaf]] = []
    for group in child_groups:
        current = list(group)
        if (
            smoothed
            and _leaf_group_char_count(current) < settings.chunking.child_min_chars
            and not _contains_table_group(smoothed[-1])
            and not _contains_table_group(current)
            and _fits_child_group([*smoothed[-1], *current], settings)
        ):
            smoothed[-1].extend(current)
        else:
            smoothed.append(current)

    index = 0
    while index < len(smoothed) - 1:
        if (
            _leaf_group_char_count(smoothed[index]) < settings.chunking.child_min_chars
            and not _contains_table_group(smoothed[index])
            and not _contains_table_group(smoothed[index + 1])
            and _fits_child_group([*smoothed[index], *smoothed[index + 1]], settings)
        ):
            smoothed[index].extend(smoothed.pop(index + 1))
            continue
        index += 1
    return smoothed


def _unique_pages(leaves: list[_Leaf]) -> list[int]:
    pages: list[int] = []
    for leaf in leaves:
        pages.extend(_pages_for_sources(leaf.source_elements))
    return _dedupe(pages)


def _unique_ids(leaves: list[_Leaf]) -> list[int | str]:
    ids: list[int | str] = []
    for leaf in leaves:
        ids.extend(_ids_for_sources(leaf.source_elements))
    return _dedupe(ids)


def _unique_types(leaves: list[_Leaf]) -> list[str]:
    types: list[str] = []
    for leaf in leaves:
        types.extend(_types_for_sources(leaf.source_elements))
    return _dedupe(types)


def _first_section(leaves: list[_Leaf]) -> str | None:
    return next((leaf.section_path for leaf in leaves if leaf.section_path), None)


def _first_section_title(leaves: list[_Leaf]) -> str | None:
    return next((leaf.section_title for leaf in leaves if leaf.section_title), None)


def _first_section_level(leaves: list[_Leaf]) -> int | None:
    return next((leaf.section_level for leaf in leaves if leaf.section_level is not None), None)


def _leaf_group_text(leaves: list[_Leaf]) -> str:
    return "\n\n".join(leaf.text for leaf in leaves)


def _leaf_group_char_count(leaves: list[_Leaf]) -> int:
    return len(_leaf_group_text(leaves))


def _can_merge_leaf_groups(left: list[_Leaf], right: list[_Leaf], *, max_chars: int) -> bool:
    return _leaf_group_char_count([*left, *right]) <= max_chars


def _fits_child_group(leaves: list[_Leaf], settings: Settings) -> bool:
    text = _leaf_group_text(leaves)
    return len(text) <= settings.chunking.child_char_max and count_tokens(text) <= settings.chunking.child_token_cap


def _contains_table(leaf: _Leaf) -> bool:
    return any(source.type.lower() == "table" for source in leaf.source_elements)


def _contains_table_group(leaves: list[_Leaf]) -> bool:
    return any(_contains_table(leaf) for leaf in leaves)


def _pages_for_sources(sources: list[RawElement]) -> list[int]:
    return _dedupe([source.page_number for source in sources if source.page_number is not None])


def _ids_for_sources(sources: list[RawElement]) -> list[int | str]:
    return _dedupe([source.id for source in sources])


def _types_for_sources(sources: list[RawElement]) -> list[str]:
    return _dedupe([source.type for source in sources])


def _metadata_for_sources(sources: list[RawElement]) -> list[dict[str, object]]:
    return [dict(source.metadata) for source in sources if source.metadata]


def _dedupe(values: list[T]) -> list[T]:
    seen: set[T] = set()
    result: list[T] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _section_context(section_path: str | None) -> str | None:
    if not section_path:
        return None
    return f"section_path: {section_path}"
