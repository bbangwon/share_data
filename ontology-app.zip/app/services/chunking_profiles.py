from __future__ import annotations

from pathlib import Path
from typing import Literal

from app.core.config import Settings

ChunkingMode = Literal["small", "large"]


def apply_ingest_overrides(
    settings: Settings,
    *,
    retrieval_profile: str | None = None,
    chunking_mode: ChunkingMode | None = None,
    collection_name: str | None = None,
    ontology_artifact_root: str | Path | None = None,
) -> Settings:
    settings = apply_retrieval_profile(settings, retrieval_profile)
    if retrieval_profile:
        profile = _profile(settings, retrieval_profile)
        chunking_mode = chunking_mode or profile.chunking_mode
    updates = {}
    if chunking_mode:
        updates["chunking"] = _chunking_for_mode(settings, chunking_mode)
    if collection_name:
        updates["qdrant"] = settings.qdrant.model_copy(update={"collection_name": collection_name})
    if ontology_artifact_root:
        updates["ontology"] = settings.ontology.model_copy(
            update={"artifact_root": _resolve_project_path(Path(ontology_artifact_root))}
        )
    return settings.model_copy(update=updates) if updates else settings


def apply_search_overrides(
    settings: Settings,
    *,
    retrieval_profile: str | None = None,
    collection_name: str | None = None,
) -> Settings:
    settings = apply_retrieval_profile(settings, retrieval_profile)
    if collection_name:
        settings = settings.model_copy(
            update={
                "qdrant": settings.qdrant.model_copy(update={"collection_name": collection_name})
            }
        )
    return settings


def apply_retrieval_profile(settings: Settings, retrieval_profile: str | None) -> Settings:
    if not retrieval_profile:
        return settings
    profile = _profile(settings, retrieval_profile)
    updates = {
        "qdrant": settings.qdrant.model_copy(update={"collection_name": profile.collection_name})
    }
    neo4j_updates = {}
    if profile.neo4j_uri:
        neo4j_updates["uri"] = profile.neo4j_uri
    if profile.neo4j_username:
        neo4j_updates["username"] = profile.neo4j_username
    if profile.neo4j_database:
        neo4j_updates["database"] = profile.neo4j_database
    if neo4j_updates:
        updates["neo4j"] = settings.neo4j.model_copy(update=neo4j_updates)
    if profile.ontology_artifact_root:
        updates["ontology"] = settings.ontology.model_copy(
            update={"artifact_root": profile.ontology_artifact_root}
        )
    return settings.model_copy(update=updates)


def _profile(settings: Settings, retrieval_profile: str):
    profile = settings.retrieval_profiles.profiles.get(retrieval_profile)
    if profile is None:
        available = ", ".join(sorted(settings.retrieval_profiles.profiles)) or "<none>"
        raise ValueError(
            f"unknown retrieval_profile {retrieval_profile!r}; available profiles: {available}"
        )
    return profile


def build_artifact_key(
    *,
    document_key: str,
    collection_name: str,
    chunking_profile: str,
) -> str:
    return f"{document_key}::collection={collection_name}::chunking={chunking_profile}"


def _chunking_for_mode(settings: Settings, mode: ChunkingMode):
    if mode == "small":
        return settings.chunking.model_copy(
            update={
                "child_min_chars": 0,
                "child_target_chars": 1,
                "parent_char_max": 5000,
                "parent_min_chars": 0,
                "parent_target_chars": 5000,
                "profile": _profile_with_suffix(settings.chunking.profile, "small"),
            }
        )
    if mode == "large":
        return settings.chunking.model_copy(
            update={
                "child_char_max": 1400,
                "child_token_cap": 900,
                "child_min_chars": 250,
                "child_target_chars": 600,
                "parent_char_max": 2000,
                "parent_min_chars": 500,
                "parent_target_chars": 1400,
                "profile": _profile_with_suffix(settings.chunking.profile, "large"),
            }
        )
    raise ValueError(f"unsupported chunking mode: {mode!r}")


def _profile_with_suffix(profile: str, suffix: str) -> str:
    parts = profile.split(":")
    if parts[-1] in {"small", "large"}:
        return ":".join([*parts[:-1], suffix])
    return f"{profile}:{suffix}"


def _resolve_project_path(path: Path) -> Path:
    if path.is_absolute():
        return path
    from app.core.config import BASE_DIR

    return BASE_DIR / path
