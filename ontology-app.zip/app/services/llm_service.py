"""Reserved for provider-agnostic LLM client wiring."""
