from __future__ import annotations

import inspect
from typing import Any

import httpx


def build_rerank_input(
    document: dict[str, Any],
    *,
    target: str = "text",
    include_file_name: bool = True,
    include_summary: bool = False,
    include_retrieval_signal_prefix: bool = True,
) -> str:
    payload = document.get("payload") or {}
    parts: list[str] = []
    if include_retrieval_signal_prefix:
        signal = _payload_text(payload, "retrieval_signal_prefix")
        if not signal:
            page_numbers = payload.get("page_numbers") or []
            if page_numbers:
                signal = f"pages: {', '.join(str(page) for page in page_numbers)}"
        parts.append(signal)
    if include_file_name:
        parts.append(_payload_text(payload, "file"))
    if include_summary:
        parts.append(_payload_text(payload, "summary"))
    parts.append(_payload_text(payload, target))
    return "\n".join(part for part in parts if part)


class GpuReranker:
    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        timeout: float,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.client = client

    async def rerank(self, query: str, documents: list[str], *, top_n: int | None = None) -> list[dict[str, Any]]:
        if not documents:
            return []
        payload = {
            "model": self.model,
            "query": query,
            "documents": documents,
            "top_n": top_n or len(documents),
        }
        if self.client is not None:
            response = await self.client.post(f"{self.base_url}/v1/rerank", json=payload, timeout=self.timeout)
        else:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(f"{self.base_url}/v1/rerank", json=payload)
        response.raise_for_status()
        data = response.json()
        results = data.get("results") or data.get("data") or []
        if not isinstance(results, list) or not all(isinstance(item, dict) for item in results):
            raise ValueError("invalid rerank response shape")
        for item in results:
            try:
                index = int(item["index"])
            except (KeyError, TypeError, ValueError):
                raise ValueError(f"invalid rerank result index: {item!r}") from None
            if index < 0 or index >= len(documents):
                raise ValueError(f"invalid rerank result index: {index!r}")
        return results


async def rerank_documents(
    query: str,
    documents: list[dict[str, Any]],
    *,
    reranker: Any,
    inputs: list[str],
    top_n: int | None = None,
) -> list[dict[str, Any]]:
    if not documents or reranker is None:
        return documents
    try:
        results = await _maybe_await(reranker.rerank(query, inputs, top_n=top_n or len(documents)))
    except Exception:
        return documents

    ordered: list[dict[str, Any]] = []
    seen: set[int] = set()
    for item in results or []:
        try:
            index = int(item["index"])
        except (KeyError, TypeError, ValueError):
            raise ValueError(f"invalid rerank result index: {item!r}") from None
        if index < 0 or index >= len(documents) or index in seen:
            raise ValueError(f"invalid rerank result index: {index!r}")
        document = {**documents[index], "rerank_score": item.get("score")}
        ordered.append(document)
        seen.add(index)
    for index, document in enumerate(documents):
        if index not in seen:
            ordered.append(document)
    return ordered[: top_n or len(ordered)]


def _payload_text(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if value is None:
        return ""
    if isinstance(value, list):
        return " ".join(str(item) for item in value if item is not None).strip()
    return str(value).strip()


async def _maybe_await(value: Any) -> Any:
    if inspect.isawaitable(value):
        return await value
    return value
