from __future__ import annotations

import uuid


def build_graph_dataset_key(
    *,
    document_key: str,
    collection_name: str,
    chunking_profile: str,
) -> str:
    return f"{document_key}::collection={collection_name}::chunking={chunking_profile}"


def build_chunk_uid(*, graph_dataset_key: str, chunk_id: str) -> str:
    return "chunk:" + uuid.uuid5(
        uuid.NAMESPACE_URL,
        f"graphrag-was:chunk:{graph_dataset_key}:{chunk_id}",
    ).hex


def chunk_identity_payload(
    *,
    document_key: str,
    collection_name: str,
    chunking_profile: str,
    chunk_id: str,
) -> dict[str, str]:
    graph_dataset_key = build_graph_dataset_key(
        document_key=document_key,
        collection_name=collection_name,
        chunking_profile=chunking_profile,
    )
    return {
        "collection_name": collection_name,
        "chunking_profile": chunking_profile,
        "graph_dataset_key": graph_dataset_key,
        "chunk_uid": build_chunk_uid(graph_dataset_key=graph_dataset_key, chunk_id=chunk_id),
    }
