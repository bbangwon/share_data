from __future__ import annotations

from fastapi import APIRouter

from app.api.v1.endpoints import answer, eval, health, ingest, search

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(ingest.router)
api_router.include_router(search.router)
api_router.include_router(answer.router)
api_router.include_router(eval.router)
