from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.services.dependency_health import check_dependency_connections

router = APIRouter(tags=["health"])


@router.get("/health")
@router.get("/health/dependencies")
@router.get("/health/ready")
async def health(
    retrieval_profile: str | None = Query(
        default=None,
        description="확인할 retrieval profile 이름입니다. 지정하면 해당 profile의 Qdrant collection과 Neo4j URI를 사용합니다.",
    ),
    collection_name: str | None = Query(
        default=None,
        description="profile 없이 특정 Qdrant collection만 직접 확인할 때 사용합니다.",
    ),
    check_collection: bool = Query(
        default=True,
        description="true이면 Qdrant 연결뿐 아니라 collection 존재 여부까지 확인합니다.",
    ),
) -> JSONResponse:
    """앱, Qdrant collection 목록, Neo4j 연결 상태를 한 번에 확인합니다."""

    try:
        result = await check_dependency_connections(
            get_settings(),
            retrieval_profile=retrieval_profile,
            collection_name=collection_name,
            check_collection=check_collection,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    status_code = 200 if result["status"] == "ok" else 503
    return JSONResponse(status_code=status_code, content=result)
