from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from app.api.deps import get_app_settings
from app.api.v1.endpoints.search import _effective_retrieval_profile, _settings_for_search
from app.core.config import Settings
from app.schemas.answer import AnswerRequest, EnhancedGraphAnswerRequest
from app.services.answer_generation import AnswerGenerationService
from app.services.graph.search.workflow import SearchWorkflow

router = APIRouter(tags=["answer"])


@router.post("/answer")
async def answer(request: AnswerRequest, settings: Settings = Depends(get_app_settings)) -> dict:
    try:
        effective_query = request.effective_query()
        effective_retrieval_profile = _effective_retrieval_profile(
            settings,
            retrieval_profile=request.retrieval_profile,
            collection_name=request.collection_name,
        )
        effective_settings = _settings_for_search(
            settings,
            retrieval_profile=effective_retrieval_profile,
            collection_name=request.collection_name,
        )
        search_response = await SearchWorkflow(effective_settings).run(
            query=effective_query,
            limit=request.limit,
            dense_limit=request.dense_limit,
            sparse_limit=request.sparse_limit,
            rerank=request.rerank,
            hybrid_rerank=request.hybrid_rerank,
            post_graph_rerank=request.post_graph_rerank,
            use_graph=request.use_graph,
            graph_mode=request.graph_mode,
            graph_strategy=request.graph_strategy,
            kg_expansion_mode=request.kg_expansion_mode,
            document_key=request.document_key,
            retrieval_profile=effective_retrieval_profile,
        )
        generation = await AnswerGenerationService(effective_settings).generate(
            query=effective_query,
            search_response=search_response,
            max_context_chars=request.max_context_chars,
        )
        response = {
            "query": effective_query,
            "collection_name": search_response.get("collection_name"),
            "retrieval_profile": search_response.get("retrieval_profile"),
            "routing": search_response.get("routing"),
            "kg_expansion_mode": search_response.get("kg_expansion_mode"),
            "kg_query_extraction": search_response.get("kg_query_extraction"),
            "selected_graph_strategy": search_response.get("selected_graph_strategy"),
            "query_graph_activated": search_response.get("query_graph_activated"),
            "post_graph_rerank_applied": search_response.get("post_graph_rerank_applied"),
            "hybrid_rerank": search_response.get("hybrid_rerank"),
            "post_graph_rerank": search_response.get("post_graph_rerank"),
            **generation,
        }
        if request.include_search:
            response["search"] = search_response
        return response
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/answer/graph-enhanced")
async def answer_graph_enhanced(
    request: EnhancedGraphAnswerRequest,
    settings: Settings = Depends(get_app_settings),
) -> dict:
    try:
        effective_query = request.effective_query()
        effective_retrieval_profile = _effective_retrieval_profile(
            settings,
            retrieval_profile=request.retrieval_profile,
            collection_name=request.collection_name,
        )
        effective_settings = _settings_for_search(
            settings,
            retrieval_profile=effective_retrieval_profile,
            collection_name=request.collection_name,
        )
        search_response = await SearchWorkflow(effective_settings).run(
            query=effective_query,
            limit=request.limit,
            dense_limit=request.dense_limit,
            sparse_limit=request.sparse_limit,
            rerank=request.rerank,
            hybrid_rerank=request.hybrid_rerank,
            post_graph_rerank=request.post_graph_rerank,
            use_graph=request.use_graph,
            graph_mode=request.graph_mode,
            graph_strategy=request.graph_strategy,
            kg_expansion_mode=request.kg_expansion_mode,
            include_evidence_chains=request.include_evidence_chains,
            relation_allowlist=request.effective_relation_allowlist(),
            evidence_chain_limit=request.evidence_chain_limit,
            graph_context_version="evidence-chain-v1",
            document_key=request.document_key,
            retrieval_profile=effective_retrieval_profile,
        )
        generation = await AnswerGenerationService(effective_settings).generate(
            query=effective_query,
            search_response=search_response,
            max_context_chars=request.max_context_chars,
            include_evidence_chains=request.include_evidence_chains,
        )
        response = {
            "query": effective_query,
            "collection_name": search_response.get("collection_name"),
            "retrieval_profile": search_response.get("retrieval_profile"),
            "graph_context_version": search_response.get("graph_context_version"),
            "routing": search_response.get("routing"),
            "kg_expansion_mode": search_response.get("kg_expansion_mode"),
            "kg_query_extraction": search_response.get("kg_query_extraction"),
            "selected_graph_strategy": search_response.get("selected_graph_strategy"),
            "query_graph_activated": search_response.get("query_graph_activated"),
            "post_graph_rerank_applied": search_response.get("post_graph_rerank_applied"),
            "hybrid_rerank": search_response.get("hybrid_rerank"),
            "post_graph_rerank": search_response.get("post_graph_rerank"),
            **generation,
        }
        if request.include_search:
            response["search"] = search_response
        return response
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
