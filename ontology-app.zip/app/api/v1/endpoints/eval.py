from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException

from app.api.deps import get_app_settings
from app.api.v1.endpoints.search import _effective_retrieval_profile, _settings_for_search
from app.core.config import BASE_DIR, Settings
from app.schemas.eval import (
    AnswerEvalJobProgressResponse,
    AnswerEvalJobRequest,
    AnswerEvalJobStartResponse,
)
from app.services.answer_generation import AnswerGenerationService
from app.services.graph.search.workflow import SearchWorkflow

router = APIRouter(tags=["eval"])


@router.post("/eval/answer-jobs", response_model=AnswerEvalJobStartResponse)
async def start_answer_eval_job(
    request: AnswerEvalJobRequest,
    settings: Settings = Depends(get_app_settings),
) -> dict[str, Any]:
    job_id = uuid4().hex[:12]
    output_path = _resolve_eval_output_path(
        settings,
        request.output_path,
        default_name=f"api_answer_eval_{job_id}.jsonl",
    )
    progress_path = _resolve_eval_output_path(
        settings,
        request.progress_output,
        default=Path(f"{output_path}.progress.json"),
    )
    job_path = _job_path(settings, job_id)
    job_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json_atomic(
        job_path,
        {
            "job_id": job_id,
            "status": "created",
            "output_path": str(output_path),
            "progress_path": str(progress_path),
            "created_at": _now_iso(),
        },
    )
    asyncio.create_task(
        _run_answer_eval_job(
            job_id=job_id,
            request=request,
            settings=settings,
            output_path=output_path,
            progress_path=progress_path,
        )
    )
    return {
        "job_id": job_id,
        "status": "started",
        "output_path": str(output_path),
        "progress_path": str(progress_path),
        "progress_url": f"/eval/answer-jobs/{job_id}",
    }


@router.get("/eval/answer-jobs/{job_id}", response_model=AnswerEvalJobProgressResponse)
async def answer_eval_job_progress(
    job_id: str,
    settings: Settings = Depends(get_app_settings),
) -> dict[str, Any]:
    job = _read_job(settings, job_id)
    progress_path = Path(str(job.get("progress_path") or ""))
    if progress_path.exists():
        return json.loads(progress_path.read_text(encoding="utf-8"))
    return {
        "job_id": job_id,
        "status": str(job.get("status") or "unknown"),
        "output_path": job.get("output_path"),
        "progress_path": job.get("progress_path"),
    }


@router.get("/eval/answer-jobs/{job_id}/results")
async def answer_eval_job_results(
    job_id: str,
    limit: int = 100,
    settings: Settings = Depends(get_app_settings),
) -> dict[str, Any]:
    job = _read_job(settings, job_id)
    output_path = Path(str(job.get("output_path") or ""))
    if not output_path.exists():
        raise HTTPException(status_code=404, detail=f"result file not found: {output_path}")
    rows = _read_jsonl(output_path)
    return {
        "job_id": job_id,
        "output_path": str(output_path),
        "count": len(rows),
        "rows": rows[: max(0, limit)],
    }


async def _run_answer_eval_job(
    *,
    job_id: str,
    request: AnswerEvalJobRequest,
    settings: Settings,
    output_path: Path,
    progress_path: Path,
) -> None:
    run_started = time.perf_counter()
    try:
        rows = _load_eval_rows(request, settings)
        selected = rows[request.offset :]
        if request.max_queries is not None:
            selected = selected[: request.max_queries]

        graph_mode, graph_strategy = _eval_mode_to_graph_options(request.eval_mode)
        if request.graph_mode is not None:
            graph_mode = request.graph_mode
        if request.graph_strategy is not None:
            graph_strategy = request.graph_strategy

        output_path.parent.mkdir(parents=True, exist_ok=True)
        progress_path.parent.mkdir(parents=True, exist_ok=True)
        if request.overwrite and output_path.exists():
            output_path.unlink()
        if request.overwrite and progress_path.exists():
            progress_path.unlink()

        completed_keys = _completed_keys(output_path)
        pending_rows = [
            (index, row)
            for index, row in enumerate(selected, start=request.offset)
            if _result_key(
                query_id=row.get("query_id"),
                query_index=index,
                retrieval_profile=request.retrieval_profile,
                graph_mode=graph_mode,
                graph_strategy=graph_strategy,
                kg_expansion_mode=request.kg_expansion_mode or "default",
            )
            not in completed_keys
        ]
        total_selected = len(selected)
        skipped_count = total_selected - len(pending_rows)
        ok_count = 0
        error_count = 0
        completed_this_run = 0
        duration_sum_ms = 0.0
        _write_eval_progress(
            progress_path,
            _progress_payload(
                job_id=job_id,
                status="running",
                output_path=output_path,
                progress_path=progress_path,
                total_selected=total_selected,
                skipped_count=skipped_count,
                pending_count=len(pending_rows),
                completed_this_run=completed_this_run,
                ok_count=ok_count,
                error_count=error_count,
                duration_sum_ms=duration_sum_ms,
                run_started=run_started,
                last_result=None,
            ),
        )

        with output_path.open("a", encoding="utf-8") as output:
            for index, row in pending_rows:
                result = await _run_one_question(
                    row=row,
                    query_index=index,
                    request=request,
                    settings=settings,
                    graph_mode=graph_mode,
                    graph_strategy=graph_strategy,
                )
                output.write(json.dumps(result, ensure_ascii=False) + "\n")
                output.flush()
                completed_this_run += 1
                duration_sum_ms += float(result.get("duration_ms") or 0.0)
                if result.get("status") == "ok":
                    ok_count += 1
                else:
                    error_count += 1
                    if request.stop_on_error:
                        _write_eval_progress(
                            progress_path,
                            _progress_payload(
                                job_id=job_id,
                                status="failed",
                                output_path=output_path,
                                progress_path=progress_path,
                                total_selected=total_selected,
                                skipped_count=skipped_count,
                                pending_count=len(pending_rows),
                                completed_this_run=completed_this_run,
                                ok_count=ok_count,
                                error_count=error_count,
                                duration_sum_ms=duration_sum_ms,
                                run_started=run_started,
                                last_result=result,
                                error=str(result.get("error") or "evaluation failed"),
                            ),
                        )
                        return

                _write_eval_progress(
                    progress_path,
                    _progress_payload(
                        job_id=job_id,
                        status="running",
                        output_path=output_path,
                        progress_path=progress_path,
                        total_selected=total_selected,
                        skipped_count=skipped_count,
                        pending_count=len(pending_rows),
                        completed_this_run=completed_this_run,
                        ok_count=ok_count,
                        error_count=error_count,
                        duration_sum_ms=duration_sum_ms,
                        run_started=run_started,
                        last_result=result,
                    ),
                )

        _write_eval_progress(
            progress_path,
            _progress_payload(
                job_id=job_id,
                status="completed_with_errors" if error_count else "completed",
                output_path=output_path,
                progress_path=progress_path,
                total_selected=total_selected,
                skipped_count=skipped_count,
                pending_count=len(pending_rows),
                completed_this_run=completed_this_run,
                ok_count=ok_count,
                error_count=error_count,
                duration_sum_ms=duration_sum_ms,
                run_started=run_started,
                last_result=None,
            ),
        )
    except Exception as exc:
        _write_eval_progress(
            progress_path,
            _progress_payload(
                job_id=job_id,
                status="failed",
                output_path=output_path,
                progress_path=progress_path,
                total_selected=0,
                skipped_count=0,
                pending_count=0,
                completed_this_run=0,
                ok_count=0,
                error_count=1,
                duration_sum_ms=0.0,
                run_started=run_started,
                last_result=None,
                error=str(exc),
            ),
        )


async def _run_one_question(
    *,
    row: dict[str, Any],
    query_index: int,
    request: AnswerEvalJobRequest,
    settings: Settings,
    graph_mode: str,
    graph_strategy: str,
) -> dict[str, Any]:
    query = str(row.get("query") or "").strip()
    started = time.perf_counter()
    payload = {
        "query": query,
        "retrieval_profile": request.retrieval_profile,
        "limit": request.limit,
        "dense_limit": request.dense_limit,
        "sparse_limit": request.sparse_limit,
        "graph_mode": graph_mode,
        "graph_strategy": graph_strategy,
        "kg_expansion_mode": request.kg_expansion_mode,
        "max_context_chars": request.max_context_chars,
        "include_search": request.include_search,
        "rerank": request.rerank,
        "hybrid_rerank": request.hybrid_rerank,
        "post_graph_rerank": request.post_graph_rerank,
    }
    try:
        if not query:
            raise ValueError(f"query is required at index {query_index}")
        response = await _answer_for_eval(
            query=query,
            request=request,
            settings=settings,
            graph_mode=graph_mode,
            graph_strategy=graph_strategy,
        )
        duration_ms = _duration_ms(started)
        graph_details = _graph_expand_details(response)
        result = {
            "status": "ok",
            "mode": request.eval_mode,
            "eval_mode": request.eval_mode,
            "query_index": query_index,
            "query_id": row.get("query_id"),
            "query": query,
            "priority": row.get("priority"),
            "category": row.get("category"),
            "expected_classes": row.get("expected_classes", []),
            "expected_relations": row.get("expected_relations", []),
            "retrieval_profile": request.retrieval_profile,
            "graph_mode": graph_mode,
            "graph_strategy": graph_strategy,
            "kg_expansion_mode": response.get("kg_expansion_mode") or request.kg_expansion_mode or "default",
            "requested_kg_expansion_mode": request.kg_expansion_mode,
            "hybrid_rerank": response.get("hybrid_rerank"),
            "post_graph_rerank": response.get("post_graph_rerank"),
            "routing": _routing_from_response(response),
            "graph_activated": _graph_activated(response),
            "selected_graph_strategy": response.get("selected_graph_strategy"),
            "query_graph_activated": bool(response.get("query_graph_activated")),
            "post_graph_rerank_applied": bool(response.get("post_graph_rerank_applied")),
            "graph_candidate_count": int(graph_details.get("graph_candidate_count") or 0),
            "kg_candidate_count": int(graph_details.get("kg_candidate_count") or 0),
            "query_graph_candidate_count": int(graph_details.get("query_graph_candidate_count") or 0),
            "request": {key: value for key, value in payload.items() if value is not None},
            "duration_ms": duration_ms,
            "timings": _timings_from_response(response, total_duration_ms=duration_ms),
            "answer": response.get("answer"),
            "collection_name": response.get("collection_name"),
            "contexts": _compact_contexts(response.get("contexts", [])),
            "search_results": _compact_search_results(response),
        }
        if request.full_response:
            result["response"] = response
        return result
    except Exception as exc:
        duration_ms = _duration_ms(started)
        return {
            "status": "error",
            "mode": request.eval_mode,
            "eval_mode": request.eval_mode,
            "query_index": query_index,
            "query_id": row.get("query_id"),
            "query": query or row.get("query"),
            "retrieval_profile": request.retrieval_profile,
            "graph_mode": graph_mode,
            "graph_strategy": graph_strategy,
            "kg_expansion_mode": request.kg_expansion_mode or "default",
            "requested_kg_expansion_mode": request.kg_expansion_mode,
            "request": {key: value for key, value in payload.items() if value is not None},
            "duration_ms": duration_ms,
            "timings": {"total_duration_ms": duration_ms},
            "error": str(exc),
        }


async def _answer_for_eval(
    *,
    query: str,
    request: AnswerEvalJobRequest,
    settings: Settings,
    graph_mode: str,
    graph_strategy: str,
) -> dict[str, Any]:
    effective_retrieval_profile = _effective_retrieval_profile(
        settings,
        retrieval_profile=request.retrieval_profile,
        collection_name=None,
    )
    effective_settings = _settings_for_search(
        settings,
        retrieval_profile=effective_retrieval_profile,
        collection_name=None,
    )
    search_response = await SearchWorkflow(effective_settings).run(
        query=query,
        limit=request.limit,
        dense_limit=request.dense_limit,
        sparse_limit=request.sparse_limit,
        rerank=request.rerank,
        hybrid_rerank=request.hybrid_rerank,
        post_graph_rerank=request.post_graph_rerank,
        graph_mode=graph_mode,
        graph_strategy=graph_strategy,
        kg_expansion_mode=request.kg_expansion_mode,
        retrieval_profile=effective_retrieval_profile,
    )
    generation = await AnswerGenerationService(effective_settings).generate(
        query=query,
        search_response=search_response,
        max_context_chars=request.max_context_chars,
    )
    response = {
        "query": query,
        "collection_name": search_response.get("collection_name"),
        "retrieval_profile": search_response.get("retrieval_profile"),
        "routing": search_response.get("routing"),
        "kg_expansion_mode": search_response.get("kg_expansion_mode"),
        "kg_query_extraction": search_response.get("kg_query_extraction"),
        "selected_graph_strategy": search_response.get("selected_graph_strategy"),
        "query_graph_activated": search_response.get("query_graph_activated"),
        "post_graph_rerank_applied": search_response.get("post_graph_rerank_applied"),
        "hybrid_rerank": search_response.get("hybrid_rerank"),
        "post_graph_rerank": search_response.get("post_graph_rerank"),
        **generation,
    }
    if request.include_search:
        response["search"] = search_response
    return response


def _load_eval_rows(request: AnswerEvalJobRequest, settings: Settings) -> list[dict[str, Any]]:
    if request.queries:
        return [item.model_dump(mode="json") for item in request.queries]
    if request.queries_path is None:
        return []
    return _read_jsonl(_resolve_eval_input_path(settings, request.queries_path))


def _eval_mode_to_graph_options(eval_mode: str) -> tuple[str, str]:
    mapping = {
        "hybrid": ("hybrid", "kg"),
        "kg": ("graph", "kg"),
        "query_graph": ("graph", "query_graph"),
        "combined": ("graph", "combined"),
        "auto": ("auto", "auto"),
    }
    return mapping[eval_mode]


def _completed_keys(path: Path) -> set[tuple[str, str, str, str]]:
    if not path.exists():
        return set()
    keys: set[tuple[str, str, str, str]] = set()
    for row in _read_jsonl(path):
        if row.get("status") != "ok":
            continue
        keys.add(
            _result_key(
                query_id=row.get("query_id"),
                query_index=row.get("query_index"),
                retrieval_profile=str(row.get("retrieval_profile") or ""),
                graph_mode=str(row.get("graph_mode") or ""),
                graph_strategy=str(row.get("graph_strategy") or ""),
                kg_expansion_mode=str(row.get("requested_kg_expansion_mode") or "default"),
            )
        )
    return keys


def _result_key(
    *,
    query_id: object,
    query_index: object,
    retrieval_profile: str,
    graph_mode: str,
    graph_strategy: str,
    kg_expansion_mode: str,
) -> tuple[str, str, str, str]:
    query_key = str(query_id or f"index:{query_index}")
    return retrieval_profile, graph_mode, f"{graph_strategy}:{kg_expansion_mode}", query_key


def _compact_contexts(contexts: Any) -> list[dict[str, Any]]:
    if not isinstance(contexts, list):
        return []
    compact: list[dict[str, Any]] = []
    for item in contexts:
        if not isinstance(item, dict):
            continue
        compact.append(
            {
                "index": item.get("index"),
                "chunk_id": item.get("chunk_id"),
                "reference": item.get("reference"),
                "section_path": item.get("section_path"),
                "context_text": item.get("context_text"),
            }
        )
    return compact


def _compact_search_results(response: dict[str, Any]) -> list[dict[str, Any]]:
    search = response.get("search")
    if not isinstance(search, dict) or not isinstance(search.get("results"), list):
        return []
    compact: list[dict[str, Any]] = []
    for rank, item in enumerate(search["results"], start=1):
        if not isinstance(item, dict):
            continue
        compact.append(
            {
                "rank": rank,
                "id": item.get("id"),
                "score": item.get("score"),
                "rerank_score": item.get("rerank_score"),
                "quality_score": item.get("quality_score"),
                "retrieval_sources": item.get("retrieval_sources", []),
                "graph_score": item.get("graph_score"),
                "query_graph_score": item.get("query_graph_score"),
                "document_key": item.get("document_key"),
                "file": item.get("file"),
                "page_numbers": item.get("page_numbers"),
                "section_path": item.get("section_path"),
                "chunk_id": item.get("chunk_id"),
                "context_text": item.get("context_text"),
            }
        )
    return compact


def _timings_from_response(response: dict[str, Any], *, total_duration_ms: float) -> dict[str, Any]:
    trace = []
    search = response.get("search")
    if isinstance(search, dict) and isinstance(search.get("trace"), list):
        trace = search["trace"]
    durations_by_node = {
        str(item.get("node")): float(item.get("duration_ms") or 0.0)
        for item in trace
        if isinstance(item, dict)
    }
    search_duration_ms = round(sum(durations_by_node.values()), 2)
    return {
        "total_duration_ms": total_duration_ms,
        "search_duration_ms": search_duration_ms,
        "routing_duration_ms": round(durations_by_node.get("route_query", 0.0), 2),
        "graph_search_duration_ms": round(durations_by_node.get("graph_expand", 0.0), 2),
        "answer_generation_duration_ms": round(max(0.0, total_duration_ms - search_duration_ms), 2),
        "trace_durations_by_node": durations_by_node,
    }


def _routing_from_response(response: dict[str, Any]) -> dict[str, Any]:
    routing = response.get("routing")
    if isinstance(routing, dict):
        return routing
    search = response.get("search")
    if isinstance(search, dict) and isinstance(search.get("routing"), dict):
        return search["routing"]
    return {}


def _graph_expand_details(response: dict[str, Any]) -> dict[str, Any]:
    search = response.get("search")
    if not isinstance(search, dict):
        return {}
    trace = search.get("trace")
    if not isinstance(trace, list):
        return {}
    for item in trace:
        if isinstance(item, dict) and item.get("node") == "graph_expand":
            details = item.get("details")
            return details if isinstance(details, dict) else {}
    return {}


def _graph_activated(response: dict[str, Any]) -> bool:
    routing = _routing_from_response(response)
    if "graph_activated" in routing:
        return bool(routing["graph_activated"])
    return routing.get("selected_retrieval") == "hybrid_graph"


def _progress_payload(
    *,
    job_id: str,
    status: str,
    output_path: Path,
    progress_path: Path,
    total_selected: int,
    skipped_count: int,
    pending_count: int,
    completed_this_run: int,
    ok_count: int,
    error_count: int,
    duration_sum_ms: float,
    run_started: float,
    last_result: dict[str, Any] | None,
    error: str | None = None,
) -> dict[str, Any]:
    done = skipped_count + completed_this_run
    average_ms = duration_sum_ms / completed_this_run if completed_this_run else None
    return {
        "job_id": job_id,
        "status": status,
        "output_path": str(output_path),
        "progress_path": str(progress_path),
        "total_selected": total_selected,
        "skipped_count": skipped_count,
        "pending_count": pending_count,
        "completed_this_run": completed_this_run,
        "ok_count": ok_count,
        "error_count": error_count,
        "percent_complete": round((done / total_selected) * 100, 2) if total_selected else 100.0,
        "average_query_duration_ms": round(average_ms, 2) if average_ms is not None else None,
        "elapsed_ms": _duration_ms(run_started),
        "updated_at": _now_iso(),
        "last_result": _compact_progress_result(last_result),
        "error": error,
    }


def _compact_progress_result(result: dict[str, Any] | None) -> dict[str, Any] | None:
    if not result:
        return None
    return {
        "status": result.get("status"),
        "query_index": result.get("query_index"),
        "query_id": result.get("query_id"),
        "query": result.get("query"),
        "duration_ms": result.get("duration_ms"),
        "error": result.get("error"),
    }


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _write_eval_progress(path: Path, payload: dict[str, Any]) -> None:
    _write_json_atomic(path, payload)


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp_path.replace(path)


def _read_job(settings: Settings, job_id: str) -> dict[str, Any]:
    if not job_id.replace("-", "").isalnum():
        raise HTTPException(status_code=400, detail="invalid job_id")
    job_path = _job_path(settings, job_id)
    if not job_path.exists():
        raise HTTPException(status_code=404, detail=f"eval job not found: {job_id}")
    return json.loads(job_path.read_text(encoding="utf-8"))


def _job_path(settings: Settings, job_id: str) -> Path:
    return settings.eval.job_dir / f"{job_id}.json"


def _resolve_eval_input_path(settings: Settings, value: Path | None) -> Path:
    if value is None:
        raise ValueError("queries_path is required when queries are not provided")
    if value.is_absolute():
        return value
    project_path = BASE_DIR / value
    if _looks_like_project_relative_path(value) or project_path.exists():
        return project_path
    return settings.eval.input_dir / value


def _resolve_eval_output_path(
    settings: Settings,
    value: Path | None,
    *,
    default: Path | None = None,
    default_name: str | None = None,
) -> Path:
    path = value or default or (Path(default_name) if default_name else None)
    if path is None:
        raise ValueError("path is required")
    if path.is_absolute():
        return path
    if _looks_like_project_relative_path(path):
        return BASE_DIR / path
    return settings.eval.output_dir / path


def _looks_like_project_relative_path(path: Path) -> bool:
    return bool(path.parts) and path.parts[0] in {"data", "docs", "configs", "logs", "outputs"}


def _duration_ms(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 2)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
