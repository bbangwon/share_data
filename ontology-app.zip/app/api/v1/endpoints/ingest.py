from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, HTTPException

from app.api.deps import get_app_settings
from app.core.config import Settings
from app.schemas.ingest import IngestRequest
from app.services.chunking_profiles import apply_ingest_overrides
from app.services.graph.ingest.workflow import IngestWorkflow

router = APIRouter(tags=["ingest"])
logger = logging.getLogger("uvicorn.error")


@router.post("/ingest")
async def ingest(request: IngestRequest, settings: Settings = Depends(get_app_settings)) -> dict:
    try:
        effective_settings = apply_ingest_overrides(
            settings,
            retrieval_profile=request.retrieval_profile,
            chunking_mode=request.chunking_mode,
            collection_name=request.collection_name,
            ontology_artifact_root=request.ontology_artifact_root,
        )
        workflow = IngestWorkflow(effective_settings)
        return await workflow.run(
            input_path=request.input_path,
            resume=request.resume,
            force_steps=request.force_steps,
            skip_qdrant=request.skip_qdrant,
            skip_existing_qdrant=request.skip_existing_qdrant,
            reset_qdrant_collection=request.reset.qdrant_collection,
            reset_qdrant_confirm_collection_name=request.reset.confirm_collection_name,
            reset_neo4j_graph=request.reset.neo4j_graph,
            reset_neo4j_confirm_retrieval_profile=request.reset.confirm_retrieval_profile,
            chunking_mode=request.chunking_mode,
            retrieval_profile=request.retrieval_profile,
            kg_extraction_mode=request.kg.extraction_mode,
            kg_chunk_offset=request.kg.chunk_offset,
            kg_chunk_limit=request.kg.chunk_limit,
            query_graph_enabled=request.query_graph.enabled,
            query_graph_generation_enabled=request.query_graph.generation_enabled,
            query_graph_upsert_enabled=request.query_graph.upsert_enabled,
            query_graph_chunk_offset=request.query_graph.chunk_offset,
            query_graph_chunk_limit=request.query_graph.chunk_limit,
            reset_query_graph_scope=request.query_graph.reset_scope,
            reset_query_graph_confirm_retrieval_profile=request.query_graph.confirm_retrieval_profile,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Unhandled /ingest error: retrieval_profile=%s force_steps=%s "
            "skip_qdrant=%s query_graph_enabled=%s query_graph_upsert_enabled=%s",
            request.retrieval_profile,
            request.force_steps,
            request.skip_qdrant,
            request.query_graph.enabled,
            request.query_graph.upsert_enabled,
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/ingest/kg-progress")
async def kg_progress(
    retrieval_profile: str | None = None,
    ontology_artifact_root: str | None = None,
    settings: Settings = Depends(get_app_settings),
) -> dict:
    try:
        effective_settings = apply_ingest_overrides(
            settings,
            retrieval_profile=retrieval_profile,
            ontology_artifact_root=ontology_artifact_root,
        )
        progress_path = effective_settings.ontology.artifact_root / "kg" / "kg_extraction_progress.json"
        if not progress_path.exists():
            raise HTTPException(
                status_code=404,
                detail=f"KG extraction progress file not found: {progress_path}",
            )
        return json.loads(progress_path.read_text(encoding="utf-8"))
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Unhandled /ingest/kg-progress error: retrieval_profile=%s ontology_artifact_root=%s",
            retrieval_profile,
            ontology_artifact_root,
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/ingest/query-graph-progress")
async def query_graph_progress(
    retrieval_profile: str | None = None,
    ontology_artifact_root: str | None = None,
    settings: Settings = Depends(get_app_settings),
) -> dict:
    try:
        effective_settings = apply_ingest_overrides(
            settings,
            retrieval_profile=retrieval_profile,
            ontology_artifact_root=ontology_artifact_root,
        )
        progress_path = effective_settings.ontology.artifact_root / "query_graph" / "progress.json"
        if not progress_path.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Query graph progress file not found: {progress_path}",
            )
        return json.loads(progress_path.read_text(encoding="utf-8"))
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Unhandled /ingest/query-graph-progress error: retrieval_profile=%s ontology_artifact_root=%s",
            retrieval_profile,
            ontology_artifact_root,
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc
