from __future__ import annotations

import logging
import time
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException

from app.api.deps import get_app_settings
from app.core.config import Settings
from app.schemas.search import (
    EnhancedGraphSearchRequest,
    SearchPromptOnlyResponse,
    SearchPromptResponse,
    SearchRequest,
)
from app.services.answer_generation import build_prompt_preview
from app.services.chunking_profiles import apply_search_overrides
from app.services.graph.search.workflow import SearchWorkflow

router = APIRouter(tags=["search"])
logger = logging.getLogger("app.api.search")


@router.post("/search", response_model=SearchPromptResponse | SearchPromptOnlyResponse)
async def search(request: SearchRequest, settings: Settings = Depends(get_app_settings)) -> dict:
    request_id = uuid4().hex[:12]
    started_at = time.perf_counter()
    effective_query = request.effective_query()
    log_context = _search_log_context(
        request,
        request_id=request_id,
        endpoint="/search",
        effective_query=effective_query,
    )
    try:
        effective_retrieval_profile = _effective_retrieval_profile(
            settings,
            retrieval_profile=request.retrieval_profile,
            collection_name=request.collection_name,
        )
        effective_settings = _settings_for_search(
            settings,
            retrieval_profile=effective_retrieval_profile,
            collection_name=request.collection_name,
        )
        workflow = SearchWorkflow(effective_settings)
        result = await workflow.run(
            query=effective_query,
            limit=request.limit,
            dense_limit=request.dense_limit,
            sparse_limit=request.sparse_limit,
            rerank=request.rerank,
            hybrid_rerank=request.hybrid_rerank,
            post_graph_rerank=request.post_graph_rerank,
            use_graph=request.use_graph,
            #graph_mode=request.graph_mode,
            #graph_strategy=request.graph_strategy,
            #kg_expansion_mode=request.kg_expansion_mode,
	    graph_mode="graph",
            graph_strategy="kg",
            kg_expansion_mode="legacy",
            document_key=request.document_key,
            retrieval_profile=effective_retrieval_profile,
        )
        only_prompt = request.effective_only_prompt(
            effective_settings.search.only_prompt_default
        )
        logger.info(
            "Search API completed request_id=%s duration_ms=%.2f profile=%s collection=%s graph_mode=%s graph_strategy=%s",
            request_id,
            _elapsed_ms(started_at),
            effective_retrieval_profile,
            effective_settings.qdrant.collection_name,
            request.graph_mode,
            request.graph_strategy,
        )
        return _search_prompt_response(
            query=effective_query,
            search_response=result,
            include_evidence_chains=False,
            started_at=started_at,
            only_prompt=only_prompt,
        )
    except ValueError as exc:
        logger.warning(
            "Search API rejected request context=%s error=%s duration_ms=%.2f",
            log_context,
            exc,
            _elapsed_ms(started_at),
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Search API failed context=%s duration_ms=%.2f",
            log_context,
            _elapsed_ms(started_at),
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/search/graph-enhanced", response_model=SearchPromptResponse | SearchPromptOnlyResponse)
async def search_graph_enhanced(
    request: EnhancedGraphSearchRequest,
    settings: Settings = Depends(get_app_settings),
) -> dict:
    request_id = uuid4().hex[:12]
    started_at = time.perf_counter()
    effective_query = request.effective_query()
    log_context = _search_log_context(
        request,
        request_id=request_id,
        endpoint="/search/graph-enhanced",
        effective_query=effective_query,
    )
    try:
        effective_retrieval_profile = _effective_retrieval_profile(
            settings,
            retrieval_profile=request.retrieval_profile,
            collection_name=request.collection_name,
        )
        effective_settings = _settings_for_search(
            settings,
            retrieval_profile=effective_retrieval_profile,
            collection_name=request.collection_name,
        )
        workflow = SearchWorkflow(effective_settings)
        result = await workflow.run(
            query=effective_query,
            limit=request.limit,
            dense_limit=request.dense_limit,
            sparse_limit=request.sparse_limit,
            rerank=request.rerank,
            hybrid_rerank=request.hybrid_rerank,
            post_graph_rerank=request.post_graph_rerank,
            use_graph=request.use_graph,
            graph_mode=request.graph_mode,
            graph_strategy=request.graph_strategy,
            kg_expansion_mode=request.kg_expansion_mode,
            include_evidence_chains=request.include_evidence_chains,
            relation_allowlist=request.effective_relation_allowlist(),
            evidence_chain_limit=request.evidence_chain_limit,
            graph_context_version="evidence-chain-v1",
            document_key=request.document_key,
            retrieval_profile=effective_retrieval_profile,
        )
        only_prompt = request.effective_only_prompt(
            effective_settings.search.only_prompt_default
        )
        logger.info(
            "Enhanced search API completed request_id=%s duration_ms=%.2f profile=%s collection=%s graph_mode=%s graph_strategy=%s",
            request_id,
            _elapsed_ms(started_at),
            effective_retrieval_profile,
            effective_settings.qdrant.collection_name,
            request.graph_mode,
            request.graph_strategy,
        )
        return _search_prompt_response(
            query=effective_query,
            search_response=result,
            include_evidence_chains=request.include_evidence_chains,
            started_at=started_at,
            only_prompt=only_prompt,
        )
    except ValueError as exc:
        logger.warning(
            "Enhanced search API rejected request context=%s error=%s duration_ms=%.2f",
            log_context,
            exc,
            _elapsed_ms(started_at),
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Enhanced search API failed context=%s duration_ms=%.2f",
            log_context,
            _elapsed_ms(started_at),
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc


def _settings_for_search(
    settings: Settings,
    *,
    retrieval_profile: str | None = None,
    collection_name: str | None = None,
) -> Settings:
    retrieval_profile = _effective_retrieval_profile(
        settings,
        retrieval_profile=retrieval_profile,
        collection_name=collection_name,
    )
    return apply_search_overrides(
        settings,
        retrieval_profile=retrieval_profile,
        collection_name=collection_name,
    )


def _effective_retrieval_profile(
    settings: Settings,
    *,
    retrieval_profile: str | None = None,
    collection_name: str | None = None,
) -> str | None:
    if retrieval_profile or collection_name:
        return retrieval_profile
    return settings.search.default_retrieval_profile


def _elapsed_ms(started_at: float) -> float:
    return (time.perf_counter() - started_at) * 1000


def _search_log_context(
    request: SearchRequest,
    *,
    request_id: str,
    endpoint: str,
    effective_query: str | None = None,
) -> dict:
    query = effective_query if effective_query is not None else request.effective_query()
    return {
        "request_id": request_id,
        "endpoint": endpoint,
        "query_length": len(query),
        "query_preview": query[:120],
        "used_query_complete": bool((request.query_complete or "").strip()),
        "limit": request.limit,
        "dense_limit": request.dense_limit,
        "sparse_limit": request.sparse_limit,
        "rerank": request.rerank,
        "hybrid_rerank": request.hybrid_rerank,
        "post_graph_rerank": request.post_graph_rerank,
        "use_graph": request.use_graph,
        "graph_mode": request.graph_mode,
        "graph_strategy": request.graph_strategy,
        "kg_expansion_mode": request.kg_expansion_mode,
        "only_prompt": request.only_prompt,
        "document_key": request.document_key,
        "retrieval_profile": request.retrieval_profile,
        "collection_name": request.collection_name,
    }


def _search_prompt_response(
    *,
    query: str,
    search_response: dict,
    include_evidence_chains: bool,
    started_at: float,
    only_prompt: bool,
) -> dict:
    preview = build_prompt_preview(
        query=query,
        search_response=search_response,
        include_evidence_chains=include_evidence_chains,
    )
    if only_prompt:
        return {"prompt": preview["prompt"]}

    return {
        "query": query,
        "search_type": _search_type(search_response),
        "search_result": [
            _search_result_item(block) for block in preview["context_blocks"]
        ],
        "empty_prompt": preview["empty_prompt"],
        "prompt": preview["prompt"],
        "total_duration_ms": round(_elapsed_ms(started_at), 2),
    }


def _search_result_item(block: dict) -> dict:
    return {
        "rank": block.get("index"),
        "id": block.get("chunk_id"),
        "filename": block.get("file"),
        "page": block.get("page_numbers") or [],
        "context_text": block.get("context_text") or block.get("text") or "",
    }


def _search_type(search_response: dict) -> str:
    routing = search_response.get("routing")
    if not _graph_activated(routing):
        return "hybrid"

    selected = search_response.get("selected_graph_strategy") or _trace_selected_strategy(
        search_response
    )
    if selected in {"kg", "query_graph", "combined"}:
        return selected
    if search_response.get("query_graph_activated"):
        return "query_graph"
    return "kg"


def _graph_activated(routing: object) -> bool:
    if not isinstance(routing, dict):
        return False
    if "graph_activated" in routing:
        return bool(routing["graph_activated"])
    return routing.get("selected_retrieval") == "hybrid_graph"


def _trace_selected_strategy(search_response: dict) -> str | None:
    for item in search_response.get("trace") or []:
        if not isinstance(item, dict) or item.get("node") != "graph_expand":
            continue
        details = item.get("details")
        if isinstance(details, dict):
            selected = details.get("selected_graph_strategy")
            if isinstance(selected, str):
                return selected
    return None
