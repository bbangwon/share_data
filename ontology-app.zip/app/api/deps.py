from __future__ import annotations

from app.core.dependencies import get_app_settings

__all__ = ["get_app_settings"]
