"""FastAPI API package."""
