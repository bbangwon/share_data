from __future__ import annotations

from pathlib import Path
from typing import Any, Literal, Self

from pydantic import BaseModel, Field, model_validator

from app.schemas.search import GraphMode, GraphStrategy, KGExpansionMode

EvalMode = Literal["hybrid", "kg", "query_graph", "combined", "auto"]


class EvalQuestion(BaseModel):
    query: str = Field(description="평가에 사용할 사용자 질문입니다.")
    query_id: str | None = Field(default=None, description="질문 식별자입니다. 재실행 skip 기준에 사용됩니다.")
    category: str | None = Field(default=None, description="질문 분류입니다.")
    priority: str | None = Field(default=None, description="질문 우선순위입니다.")
    expected_classes: list[str] = Field(default_factory=list, description="기대 ontology class 목록입니다.")
    expected_relations: list[str] = Field(default_factory=list, description="기대 relation type 목록입니다.")


class AnswerEvalJobRequest(BaseModel):
    queries: list[EvalQuestion] | None = Field(
        default=None,
        description="API body로 직접 전달할 평가 질문 목록입니다. queries_path와 둘 중 하나는 필요합니다.",
    )
    queries_path: Path | None = Field(
        default=None,
        description="서버 로컬 JSONL 질문 파일 경로입니다. 상대 경로는 기본적으로 eval.input_dir 아래에서 찾으며, 각 row에는 최소 query 필드가 필요합니다.",
    )
    output_path: Path | None = Field(
        default=None,
        description="결과 JSONL 저장 경로입니다. 상대 경로는 기본적으로 eval.output_dir 아래에 저장하며, 생략하면 api_answer_eval_<job_id>.jsonl 입니다.",
    )
    progress_output: Path | None = Field(
        default=None,
        description="진행률 JSON 저장 경로입니다. 상대 경로는 기본적으로 eval.output_dir 아래에 저장하며, 생략하면 output_path 뒤에 .progress.json을 붙입니다.",
    )
    retrieval_profile: str = Field(default="large", description="검색에 사용할 retrieval profile입니다.")
    eval_mode: EvalMode = Field(
        default="hybrid",
        description="강제 평가 모드입니다. hybrid, kg, query_graph, combined, auto 중 하나입니다.",
    )
    graph_mode: GraphMode | None = Field(
        default=None,
        description="고급 옵션입니다. eval_mode가 우선하며, eval_mode를 쓰지 않는 확장용 필드입니다.",
    )
    graph_strategy: GraphStrategy | None = Field(
        default=None,
        description="고급 옵션입니다. eval_mode가 우선하며, eval_mode를 쓰지 않는 확장용 필드입니다.",
    )
    kg_expansion_mode: KGExpansionMode | None = Field(
        default=None,
        description="KG 확장 방식입니다. 생략하면 서버 TOML 기본값을 사용합니다.",
    )
    offset: int = Field(default=0, ge=0, description="평가 시작 offset입니다.")
    max_queries: int | None = Field(default=None, gt=0, description="최대 평가 질문 수입니다.")
    limit: int = Field(default=5, gt=0, description="최종 검색 결과 개수입니다.")
    dense_limit: int | None = Field(default=None, gt=0, description="Dense 검색 후보 수입니다.")
    sparse_limit: int | None = Field(default=None, gt=0, description="Sparse 검색 후보 수입니다.")
    max_context_chars: int = Field(default=12000, gt=0, description="답변 생성 context 최대 문자 수입니다.")
    include_search: bool = Field(default=True, description="결과에 내부 search 응답을 포함할지 여부입니다.")
    full_response: bool = Field(default=False, description="/answer 형태의 전체 응답을 결과 JSONL에 저장할지 여부입니다.")
    overwrite: bool = Field(default=False, description="기존 output/progress 파일을 지우고 다시 실행할지 여부입니다.")
    stop_on_error: bool = Field(default=False, description="오류 발생 시 작업을 중단할지 여부입니다.")
    rerank: bool | None = Field(default=None, description="하위 호환용 전체 rerank 스위치입니다.")
    hybrid_rerank: bool | None = Field(default=None, description="Hybrid Search 직후 rerank 스위치입니다.")
    post_graph_rerank: bool | None = Field(default=None, description="Graph 후보 병합 후 rerank 스위치입니다.")

    @model_validator(mode="after")
    def validate_question_source(self) -> Self:
        if not self.queries and self.queries_path is None:
            raise ValueError("queries or queries_path is required")
        if self.queries and self.queries_path is not None:
            raise ValueError("queries and queries_path cannot be used together")
        return self


class AnswerEvalJobStartResponse(BaseModel):
    job_id: str
    status: str
    output_path: str
    progress_path: str
    progress_url: str


class AnswerEvalJobProgressResponse(BaseModel):
    job_id: str
    status: str
    output_path: str | None = None
    progress_path: str | None = None
    total_selected: int = 0
    skipped_count: int = 0
    pending_count: int = 0
    completed_this_run: int = 0
    ok_count: int = 0
    error_count: int = 0
    percent_complete: float = 0.0
    average_query_duration_ms: float | None = None
    last_result: dict[str, Any] | None = None
    error: str | None = None
