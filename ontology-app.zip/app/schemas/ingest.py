from __future__ import annotations

from typing import Literal, Self

from pydantic import BaseModel, Field, model_validator


class IngestResetOptions(BaseModel):
    qdrant_collection: bool = Field(
        default=False,
        description=(
            "Qdrant 컬렉션을 삭제 후 재생성하고 새로 적재할지 여부입니다. 컬렉션 전체 데이터가 삭제되는 "
            "파괴적 작업이므로 confirm_collection_name에 최종 사용 컬렉션명을 정확히 입력해야 합니다."
        ),
    )
    confirm_collection_name: str | None = Field(
        default=None,
        description=(
            "qdrant_collection=true일 때 필요한 확인용 컬렉션명입니다. collection_name 요청 override까지 "
            "반영된 최종 컬렉션명과 정확히 일치해야 컬렉션 초기화가 실행됩니다."
        ),
        examples=["ontology-radiation-safety-action-manual"],
    )
    neo4j_graph: bool = Field(
        default=False,
        description=(
            "현재 retrieval_profile/document/chunking scope에 해당하는 Neo4j 그래프를 삭제한 뒤 "
            "다시 생성할지 여부입니다. Qdrant 컬렉션은 건드리지 않습니다."
        ),
    )
    confirm_retrieval_profile: str | None = Field(
        default=None,
        description=(
            "neo4j_graph=true일 때 필요한 확인용 retrieval_profile 이름입니다. 요청의 "
            "retrieval_profile과 정확히 일치해야 그래프 초기화가 실행됩니다."
        ),
        examples=["large"],
    )

    @model_validator(mode="after")
    def validate_reset_options(self) -> Self:
        if self.qdrant_collection and not self.confirm_collection_name:
            raise ValueError("reset.confirm_collection_name is required when reset.qdrant_collection=true")
        if self.neo4j_graph and not self.confirm_retrieval_profile:
            raise ValueError("reset.confirm_retrieval_profile is required when reset.neo4j_graph=true")
        return self


class IngestKgOptions(BaseModel):
    extraction_mode: Literal["rule_based", "llm", "hybrid"] | None = Field(
        default=None,
        description=(
            "Phase2 KG 생성 시 사용할 엔티티/관계 추출 방식입니다. rule_based는 기존 규칙 기반, "
            "llm은 prompt 기반 LLM 추출만 사용, hybrid는 LLM 실패 chunk를 규칙 기반으로 보완합니다. "
            "생략하면 TOML의 ontology.kg_extraction_mode를 사용합니다."
        ),
        examples=["hybrid"],
    )
    chunk_offset: int = Field(
        default=0,
        ge=0,
        description=(
            "KG 추출을 시작할 child chunk offset입니다. 기본값 0은 첫 청크부터 처리합니다. "
            "긴 LLM 추출을 일부 구간만 테스트하거나 중간 구간부터 재실행할 때 사용합니다."
        ),
        examples=[0],
    )
    chunk_limit: int | None = Field(
        default=None,
        gt=0,
        description=(
            "KG 추출에서 처리할 최대 child chunk 수입니다. null이면 전체 청크를 처리합니다. "
            "초기 테스트에서는 5, 10, 20처럼 작은 값으로 설정하는 것을 권장합니다."
        ),
        examples=[20],
    )


class IngestQueryGraphOptions(BaseModel):
    enabled: bool = Field(
        default=False,
        description=(
            "Query-Centric GraphRAG용 synthetic query graph를 생성할지 여부입니다. true이면 "
            "기존 chunk/KG 산출물을 재사용해 query_graph 레이어를 생성합니다."
        ),
    )
    generation_enabled: bool | None = Field(
        default=None,
        description=(
            "synthetic query-answer 생성을 실행할지 여부입니다. null이면 enabled=true 요청 또는 "
            "TOML query_graph.generation_enabled 설정을 따릅니다."
        ),
    )
    upsert_enabled: bool | None = Field(
        default=None,
        description=(
            "생성된 query graph를 Neo4j와 Qdrant query graph 컬렉션에 적재할지 여부입니다. "
            "null이면 enabled=true 요청 또는 TOML query_graph.upsert_enabled 설정을 따릅니다."
        ),
    )
    chunk_offset: int | None = Field(
        default=None,
        ge=0,
        description="query graph 생성을 시작할 child chunk offset입니다. null이면 TOML 기본값을 사용합니다.",
        examples=[0],
    )
    chunk_limit: int | None = Field(
        default=None,
        gt=0,
        description="query graph 생성에서 처리할 최대 child chunk 수입니다. null이면 전체 또는 TOML 기본값을 사용합니다.",
        examples=[20],
    )
    reset_scope: bool = Field(
        default=False,
        description=(
            "현재 retrieval_profile/document/chunking scope의 SyntheticQuery와 query graph Qdrant points를 "
            "삭제한 뒤 다시 생성할지 여부입니다. Qdrant 원본 chunk 컬렉션과 KG Chunk/Entity는 건드리지 않습니다."
        ),
    )
    confirm_retrieval_profile: str | None = Field(
        default=None,
        description=(
            "reset_scope=true일 때 필요한 확인용 retrieval_profile 이름입니다. 요청의 retrieval_profile과 "
            "정확히 일치해야 query graph scope 초기화가 실행됩니다."
        ),
        examples=["large"],
    )

    @model_validator(mode="after")
    def validate_query_graph_options(self) -> Self:
        if self.reset_scope and not self.confirm_retrieval_profile:
            raise ValueError("query_graph.confirm_retrieval_profile is required when query_graph.reset_scope=true")
        return self


class IngestRequest(BaseModel):
    input_path: str | None = Field(
        default=None,
        description=(
            "적재할 PDF 추출 JSON 파일 경로입니다. 생략하면 설정의 "
            "runtime.default_json_dirs에서 첫 번째 JSON 파일을 찾아 사용합니다."
        ),
        examples=["data/json/manual.json"],
    )
    resume: bool = Field(
        default=True,
        description=(
            "이전에 성공한 중간 산출물을 재사용할지 여부입니다. true이면 "
            "raw_document.json, chunks.json, embedded_chunks.json, upsert_result.json 등이 "
            "존재하는 단계는 다시 실행하지 않고 건너뜁니다."
        ),
    )
    force_steps: list[str] = Field(
        default_factory=list,
        description=(
            "resume=true여도 강제로 다시 실행할 단계 목록입니다. 사용 가능한 값은 "
            "load_document, chunk_document, embed_chunks, reset_qdrant_collection, "
            "upsert_qdrant, build_ontology_layer, build_query_graph_layer입니다."
        ),
        examples=[["chunk_document", "embed_chunks"], ["reset_qdrant_collection", "upsert_qdrant"]],
    )
    skip_qdrant: bool = Field(
        default=False,
        description=(
            "Qdrant 적재 단계를 건너뜁니다. JSON 로드, 청킹, 임베딩, 중간 산출물 저장까지만 "
            "확인하고 싶을 때 사용합니다."
        ),
    )
    skip_existing_qdrant: bool = Field(
        default=False,
        description=(
            "Qdrant에 같은 document_key의 current 문서가 이미 있으면 upsert를 건너뜁니다. "
            "이미 적재된 문서는 유지하고 후속 단계 확장이나 산출물 확인만 하고 싶을 때 사용합니다."
        ),
    )
    chunking_mode: Literal["small", "large"] | None = Field(
        default=None,
        description=(
            "적재 시 사용할 청킹 방식입니다. small은 첫 번째 커밋의 작은 text 청크 방식에 가깝게 "
            "child 병합과 parent 보정을 끄고, large는 현재 튜닝된 큰 text/제한된 parent_text 방식을 사용합니다. "
            "생략하면 서버 TOML 설정을 그대로 사용합니다."
        ),
        examples=["large"],
    )
    collection_name: str | None = Field(
        default=None,
        min_length=1,
        description=(
            "이번 ingest 실행에서 사용할 Qdrant 컬렉션명입니다. 생략하면 설정의 qdrant.collection_name을 사용합니다. "
            "reset.qdrant_collection=true인 경우 reset.confirm_collection_name은 이 최종 컬렉션명과 정확히 같아야 합니다."
        ),
        examples=["ontology-radiation-safety-action-manual-large"],
    )
    ontology_artifact_root: str | None = Field(
        default=None,
        min_length=1,
        description=(
            "이번 ingest 실행에서 사용할 ontology/KG 산출물 저장 루트입니다. retrieval_profile 없이 "
            "collection_name과 chunking_mode를 직접 지정할 때 large/small KG 산출물이 기본 data/ontology에 "
            "섞이지 않도록 지정합니다."
        ),
        examples=["data/ontology-large"],
    )
    retrieval_profile: str | None = Field(
        default=None,
        min_length=1,
        description=(
            "Qdrant 컬렉션명, 청킹 방식, Neo4j 접속 정보, ontology 산출물 경로를 함께 선택하는 서버 설정 "
            "profile 이름입니다. small/large 그래프를 분리 생성할 때 사용합니다. 이 값을 쓰면 "
            "chunking_mode와 collection_name을 별도로 지정하지 않습니다."
        ),
        examples=["large"],
    )
    kg: IngestKgOptions = Field(
        default_factory=IngestKgOptions,
        description=(
            "KG 생성과 관련된 옵션입니다. LLM 기반 추출 방식, 청크 offset/limit 같은 장시간 작업 제어 "
            "옵션을 한 객체로 묶습니다."
        ),
        examples=[
            {
                "extraction_mode": "hybrid",
                "chunk_offset": 0,
                "chunk_limit": 20,
            }
        ],
    )
    query_graph: IngestQueryGraphOptions = Field(
        default_factory=IngestQueryGraphOptions,
        description=(
            "Query-Centric GraphRAG용 synthetic query graph 생성 옵션입니다. 비용이 큰 LLM 생성 작업이므로 "
            "초기에는 chunk_limit으로 작은 구간부터 테스트하는 것을 권장합니다."
        ),
        examples=[
            {
                "enabled": True,
                "chunk_offset": 0,
                "chunk_limit": 20,
            }
        ],
    )
    reset: IngestResetOptions = Field(
        default_factory=IngestResetOptions,
        description=(
            "컬렉션 초기화 같은 파괴적 작업을 묶어서 지정하는 옵션입니다. 생략하면 어떤 초기화도 수행하지 않습니다."
        ),
        examples=[
            {
                "qdrant_collection": True,
                "confirm_collection_name": "ontology-radiation-safety-action-manual",
            }
        ],
    )

    @model_validator(mode="after")
    def validate_reset_request(self) -> Self:
        if self.reset.qdrant_collection and self.skip_qdrant:
            raise ValueError("reset.qdrant_collection cannot be used with skip_qdrant=true")
        if self.reset.neo4j_graph:
            if not self.retrieval_profile:
                raise ValueError("reset.neo4j_graph requires retrieval_profile")
            if self.reset.confirm_retrieval_profile != self.retrieval_profile:
                raise ValueError("reset.confirm_retrieval_profile must exactly match retrieval_profile")
        if self.query_graph.reset_scope:
            if not self.retrieval_profile:
                raise ValueError("query_graph.reset_scope requires retrieval_profile")
            if self.query_graph.confirm_retrieval_profile != self.retrieval_profile:
                raise ValueError("query_graph.confirm_retrieval_profile must exactly match retrieval_profile")
        if self.retrieval_profile and (self.chunking_mode or self.collection_name or self.ontology_artifact_root):
            raise ValueError(
                "retrieval_profile cannot be used with chunking_mode, collection_name, or ontology_artifact_root"
            )
        return self
