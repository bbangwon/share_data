from __future__ import annotations

from typing import ClassVar, Literal, Self

from pydantic import BaseModel, Field, model_validator

GraphMode = Literal["hybrid", "graph", "auto"]
GraphStrategy = Literal["kg", "query_graph", "combined", "auto"]
SearchType = Literal["hybrid", "kg", "query_graph", "combined"]
KGExpansionMode = Literal["legacy", "query_guided"]

DEFAULT_GRAPH_RELATION_ALLOWLIST: tuple[str, ...] = (
    "ASSIGNED_TO",
    "RESPONSIBLE_FOR",
    "SUPPORTS",
    "ACTIVATED_AT",
    "APPLIES_TO",
    "LOCATED_IN",
    "USES_TRANSPORT",
    "HAS_CONTACT",
    "PRECEDES",
    "REQUIRES_COOPERATION_WITH",
    "HAS_CRITERIA",
    "REPORTS_TO",
    "COMMUNICATES_VIA",
    "MONITORS",
    "OPERATES",
    "REFERENCES",
    "BELONGS_TO",
    "RELATED_TO",
)


class SearchRequest(BaseModel):
    query: str = Field(
        description=(
            "원본 사용자 질의입니다. query_complete가 비어 있으면 이 값이 dense/sparse query embedding과 "
            "query routing에 사용됩니다."
        ),
        examples=["방사능 누출 초기 대응 절차는?"],
    )
    query_complete: str | None = Field(
        default=None,
        description=(
            "질의 확장 API를 통해 생성된 정제된 사용자 질의입니다. 값이 있으면 query보다 우선해서 "
            "검색 실행, query routing, 답변 생성 질문으로 사용됩니다."
        ),
        examples=["방사능 누출 초기 대응 절차에 대해 알려주세요."],
    )
    search_queries: list[str] | None = Field(
        default=None,
        description="질의 확장 API를 통해 생성된 검색용 사용자 질의 목록 입니다.",
        examples=[["부산광역시청 하수처리장의 방사능 누출 사고 초기 대응 절차는?", ""]],
    )
    limit: int | None = Field(
        default=None,
        gt=0,
        description=(
            "최종 반환할 검색 결과 개수입니다. 생략하면 설정의 search.final_limit 값을 사용합니다."
        ),
        examples=[5],
    )
    dense_limit: int | None = Field(
        default=None,
        gt=0,
        description=(
            "Qdrant dense vector prefetch 후보 개수입니다. 생략하면 설정의 search.dense_limit 값을 사용합니다."
        ),
        examples=[50],
    )
    sparse_limit: int | None = Field(
        default=None,
        gt=0,
        description=(
            "Qdrant sparse vector prefetch 후보 개수입니다. 생략하면 설정의 search.sparse_limit 값을 사용합니다."
        ),
        examples=[50],
    )
    rerank: bool | None = Field(
        default=None,
        description=(
            "하위 호환용 rerank 전체 스위치입니다. 새 요청에서는 hybrid_rerank와 post_graph_rerank를 "
            "각각 사용하는 것을 권장합니다. 이 값을 보내고 개별 값이 생략되면 두 rerank 단계의 기본값으로 "
            "사용합니다. 이 값까지 생략하면 toml의 search.hybrid_rerank_default와 "
            "search.post_graph_rerank_default를 사용합니다."
        ),
        examples=[False],
    )
    hybrid_rerank: bool | None = Field(
        default=None,
        description=(
            "Qdrant Hybrid Search 직후 후보를 reranker로 재정렬할지 여부입니다. "
            "생략하면 rerank 요청값을 따르고, rerank도 생략하면 toml의 search.hybrid_rerank_default를 따릅니다."
        ),
        examples=[True],
    )
    post_graph_rerank: bool | None = Field(
        default=None,
        description=(
            "KG/query graph 후보를 병합한 뒤 reranker를 한 번 더 수행할지 여부입니다. "
            "생략하면 rerank 요청값을 따르고, rerank도 생략하면 toml의 search.post_graph_rerank_default를 따릅니다."
        ),
        examples=[True],
    )
    use_graph: bool | None = Field(
        default=None,
        description=(
            "Neo4j 그래프 확장을 사용할지 여부입니다. true이면 기존 Qdrant Hybrid Search 결과 뒤에 "
            "그래프 기반 chunk 확장을 추가합니다. 하위 호환용 파라미터이며 graph_mode가 생략된 경우 "
            "true는 graph, false는 hybrid로 매핑됩니다."
        ),
        examples=[True],
    )
    graph_mode: GraphMode | None = Field(
        default="auto",
        description=(
            "그래프 확장 제어 모드입니다. hybrid는 그래프를 사용하지 않고, graph는 기존처럼 강제로 사용하며, "
            "auto는 query router가 질의 성격에 따라 graph expansion 여부를 결정합니다. 생략하면 기존 "
            "use_graph/서버 설정과 호환되는 방식으로 결정됩니다."
        ),
        examples=["auto"],
    )
    graph_strategy: GraphStrategy = Field(
        default="kg",
        description=(
            "graph_mode가 graph 또는 auto로 활성화되었을 때 사용할 그래프 확장 전략입니다. "
            "kg는 기존 Neo4j KG expansion, query_graph는 synthetic query graph 기반 확장, "
            "combined는 둘을 함께 사용한 뒤 post-graph rerank를 수행하며, auto는 routing 결과에 따라 "
            "kg/query_graph/combined 중 하나를 자동 선택합니다."
        ),
        examples=["query_graph"],
    )
    kg_expansion_mode: KGExpansionMode | None = Field(
        default=None,
        description=(
            "KG graph expansion 세부 동작 방식입니다. legacy는 기존 seed chunk 기반 KG 확장을 그대로 사용하고, "
            "query_guided는 사용자 질의에서 엔티티/관계 의도/제약 조건을 추출해 KG 탐색 힌트로 사용합니다. "
            "graph_strategy가 kg 또는 combined일 때만 적용되며 query_graph 단독 모드에는 영향을 주지 않습니다. "
            "생략하면 toml의 search.kg_expansion_mode_default를 사용합니다."
        ),
        examples=["query_guided"],
    )
    only_prompt: bool | None = Field(
        default=None,
        description=(
            "true이면 /search 응답에서 최종 prompt 문자열만 반환합니다. false이면 query, search_type, "
            "search_result, empty_prompt, prompt, total_duration_ms를 모두 반환합니다. 생략하면 toml의 "
            "search.only_prompt_default를 사용합니다."
        ),
        examples=[False],
    )
    document_key: str | None = Field(
        default=None,
        description=(
            "특정 문서 안에서만 검색하고 싶을 때 사용하는 필터입니다. 생략하면 컬렉션 전체 current 문서를 대상으로 검색합니다."
        ),
        examples=[
            "(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정 251013)"
        ],
    )
    collection_name: str | None = Field(
        default=None,
        min_length=1,
        description=(
            "검색 대상 Qdrant 컬렉션명입니다. small/large 등 여러 방식으로 적재한 컬렉션을 비교할 때 사용합니다. "
            "생략하면 설정의 qdrant.collection_name을 사용합니다."
        ),
        examples=["ontology-radiation-safety-action-manual-large"],
    )
    retrieval_profile: str | None = Field(
        default=None,
        min_length=1,
        description=(
            "Qdrant 컬렉션과 Neo4j 접속 정보를 함께 선택하는 서버 설정 profile 이름입니다. "
            "small/large 비교처럼 벡터 컬렉션과 그래프 컨테이너를 같이 바꿔야 할 때 사용합니다. "
            "이 값을 쓰면 collection_name을 별도로 지정하지 않습니다."
        ),
        examples=["large"],
    )

    @model_validator(mode="after")
    def validate_profile_request(self) -> Self:
        if self.retrieval_profile and self.collection_name:
            raise ValueError("retrieval_profile cannot be used with collection_name")
        if self.graph_mode is not None and self.use_graph is not None:
            mapped = "graph" if self.use_graph else "hybrid"
            if self.graph_mode != mapped:
                raise ValueError("graph_mode conflicts with use_graph")
        return self

    def effective_hybrid_rerank(self, default: bool = True) -> bool:
        alias_default = default if self.rerank is None else self.rerank
        return alias_default if self.hybrid_rerank is None else self.hybrid_rerank

    def effective_post_graph_rerank(self, default: bool = True) -> bool:
        alias_default = default if self.rerank is None else self.rerank
        return alias_default if self.post_graph_rerank is None else self.post_graph_rerank

    def effective_query(self) -> str:
        query_complete = (self.query_complete or "").strip()
        return query_complete or self.query

    def effective_only_prompt(self, default: bool = True) -> bool:
        return default if self.only_prompt is None else self.only_prompt


class EnhancedGraphSearchRequest(SearchRequest):
    allowed_relation_types: ClassVar[set[str]] = set(DEFAULT_GRAPH_RELATION_ALLOWLIST)

    include_evidence_chains: bool = Field(
        default=True,
        description=(
            "그래프 확장으로 추가된 chunk가 어떤 entity/relation/query graph 경로로 연결되었는지 "
            "구조화된 evidence_chains로 응답에 포함할지 여부입니다."
        ),
    )
    relation_allowlist: list[str] | None = Field(
        default=None,
        description=(
            "KG relation traversal에 사용할 관계 타입 목록입니다. 생략하면 query router의 질의 타입에 맞춰 "
            "서비스가 자동 allowlist를 생성합니다. 요청값이 있으면 허용된 relation type만 사용할 수 있고, "
            "알 수 없는 relation type은 400 에러가 됩니다."
        ),
        examples=[["ASSIGNED_TO", "RESPONSIBLE_FOR", "REQUIRES_COOPERATION_WITH"]],
    )
    evidence_chain_limit: int = Field(
        default=5,
        ge=1,
        le=20,
        description="결과 chunk별로 보존할 최대 evidence chain 개수입니다.",
        examples=[5],
    )

    @model_validator(mode="after")
    def validate_graph_enhancement(self) -> Self:
        unknown = [
            item
            for item in self.relation_allowlist or []
            if item not in self.allowed_relation_types
        ]
        if unknown:
            raise ValueError(
                "relation_allowlist contains unsupported relation types: "
                + ", ".join(sorted(set(unknown)))
            )
        return self

    def effective_relation_allowlist(self) -> list[str] | None:
        if self.relation_allowlist is None:
            return None
        result: list[str] = []
        for item in self.relation_allowlist:
            if item in self.allowed_relation_types and item not in result:
                result.append(item)
        return result


class SearchPromptResultItem(BaseModel):
    rank: int | None = Field(
        description="프롬프트 context에 포함된 참고자료 순번입니다.",
        examples=[1],
    )
    id: str | None = Field(
        default=None,
        description="검색 결과 chunk_id입니다. 프롬프트 XML의 source id와 같습니다.",
        examples=["child:31:0"],
    )
    filename: str | None = Field(
        default=None,
        description="원본 파일명입니다.",
        examples=["(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정 251013).pdf"],
    )
    page: list[int] = Field(
        default_factory=list,
        description="참고자료가 포함된 페이지 번호 목록입니다.",
        examples=[[46]],
    )
    context_text: str = Field(
        description="답변 생성 프롬프트에 context로 전달되는 본문입니다.",
        examples=["주민 보호 조치는 상황 접수 후 관계기관 전파와 함께 검토한다."],
    )


class SearchPromptResponse(BaseModel):
    query: str = Field(
        description="실제 검색과 프롬프트 생성에 사용한 질의입니다.",
        examples=["방사능 누출 초기 대응 절차는?"],
    )
    search_type: SearchType = Field(
        description=(
            "최종 검색 응답을 만든 검색 방식입니다. 그래프가 비활성화되면 hybrid이고, "
            "그래프가 활성화되면 실제 선택된 graph strategy인 kg, query_graph, combined 중 하나입니다."
        ),
        examples=["hybrid"],
    )
    search_result: list[SearchPromptResultItem] = Field(
        description="답변 프롬프트 context로 들어간 최종 참고자료 목록입니다.",
    )
    empty_prompt: str = Field(
        description="YAML 프롬프트 template 원문입니다. query/context placeholder가 채워지기 전 상태입니다.",
    )
    prompt: str = Field(
        description="query와 검색 결과 XML context가 채워진 최종 프롬프트 문자열입니다.",
    )
    total_duration_ms: float = Field(
        description="검색 workflow 실행과 prompt preview 생성까지 걸린 전체 수행시간입니다.",
        examples=[123.45],
    )


class SearchPromptOnlyResponse(BaseModel):
    prompt: str = Field(
        description="query와 검색 결과 XML context가 채워진 최종 프롬프트 문자열입니다.",
    )
