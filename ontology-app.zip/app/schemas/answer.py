from __future__ import annotations

from pydantic import Field

from app.schemas.search import EnhancedGraphSearchRequest, SearchRequest


class AnswerRequest(SearchRequest):
    max_context_chars: int = Field(
        default=12000,
        gt=0,
        description=(
            "LLM 프롬프트에 넣을 검색 근거 컨텍스트의 최대 문자 수입니다. "
            "검색 결과의 context_text를 순서대로 합치다가 이 값을 넘으면 잘라냅니다."
        ),
        examples=[12000],
    )
    include_search: bool = Field(
        default=True,
        description="응답에 내부 search API 결과를 함께 포함할지 여부입니다. 디버깅 단계에서는 true를 권장합니다.",
    )


class EnhancedGraphAnswerRequest(EnhancedGraphSearchRequest):
    max_context_chars: int = Field(
        default=12000,
        gt=0,
        description=(
            "LLM 프롬프트에 넣을 검색 근거 컨텍스트의 최대 문자 수입니다. "
            "검색 결과의 context_text를 순서대로 합치다가 이 값을 넘으면 잘라냅니다."
        ),
        examples=[12000],
    )
    include_search: bool = Field(
        default=True,
        description="응답에 내부 search API 결과를 함께 포함할지 여부입니다. 디버깅 단계에서는 true를 권장합니다.",
    )
