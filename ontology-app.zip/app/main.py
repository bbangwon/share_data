from __future__ import annotations

import logging

from fastapi import FastAPI

from app.api.v1.router import api_router
from app.core.config import get_settings
from app.core.logging import configure_logging

logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    try:
        configure_logging(get_settings())
    except Exception:
        logging.basicConfig(level=logging.INFO)
        logger.exception("Failed to configure application logging from settings")

    app = FastAPI(title="GraphRAG WAS HybridRAG API", version="0.1.0")
    app.include_router(api_router)
    return app


app = create_app()
