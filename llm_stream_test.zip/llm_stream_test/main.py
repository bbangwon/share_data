from fastapi import FastAPI, Response, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from stream_data_processor import StreamDataProcessor

from pydantic import BaseModel
from typing import Annotated

class Question(BaseModel):
    chat_session_id: int
    chat_number: int
    question: str


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

stream_datas: dict[int, StreamDataProcessor] = {}



@app.post("/llm_request")
async def llm_request(body: Annotated[Question, Body(...)]):
    stream_data = StreamDataProcessor()
    stream_datas[body.chat_session_id] = stream_data
    await stream_data.request_to_llm(body.question)
    return {"message": "Hello, World!"}

@app.get("/stream")
async def stream(chat_session_id: int, chat_number: int):
    stream_data = stream_datas.get(chat_session_id)

    if not stream_data:
        return StreamingResponse(content="data not found", status_code=404)

    def post_func():
        print("post_func called")
        stream_datas.pop(chat_session_id, None)

    return StreamingResponse(
        stream_data.stream(post_func),
        media_type="text/event-stream",
    )

