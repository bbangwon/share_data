import asyncio
import httpx
import json

class StreamDataProcessor:
    def __init__(self):
        self.reset()
    
    def reset(self):
        self.buffer = []
        self.condition = asyncio.Condition()
        self.start = False
        self.end = False

    async def request_to_llm(self, user_query):
        request_json = {
            "user_query": user_query,
            "stream": True,
            "is_rag": False
        }

        url= "http://99.1.82.207:8080/llm-studio/v1/api/task/generate/syncapi/busan_ai_llm/qa_response"
        try:
            async with httpx.AsyncClient() as client:
                async with client.stream("POST", url, json=request_json) as response:
                    async for line in response.aiter_lines():
                        if line.startswith("data: "):
                            json_data = line.replace("data:", "")                            
                            self.buffer.append(json_data)

                            dict_data = json.loads(json_data)
                            print(f"dict_data: {dict_data}")
                            finish_reason = dict_data["llm_result"]["finish_reason"]

                            print(f"finish_reason: {finish_reason}")

                            if finish_reason == "stop":
                                self.end = True

                            async with self.condition:
                                self.condition.notify_all()

                            if self.end:
                                break                        

                            await asyncio.sleep(0.5)
                    return

        except httpx.ConnectError as e:
            print(f"Error connecting to the server: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")            

    async def stream(self, post_func):
        last_idx = 0
        while last_idx < len(self.buffer):
            yield f"data: {self.buffer[last_idx]}\n\n"
            last_idx += 1

        while True:
            async with self.condition:
                await self.condition.wait()
                while last_idx < len(self.buffer):
                    yield f"data: {self.buffer[last_idx]}\n\n"
                    last_idx += 1

                if self.end:
                    print("streaming finished.")
                    self.reset()
                    if post_func:
                        post_func()
                    break
            print("waiting for new data...")
    