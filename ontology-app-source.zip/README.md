# 🌋 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼 GraphRAG

이 프로젝트는 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼의 PDF에서 가공된 계층 구조 데이터를 활용하여, **Neo4j**와 **Ollama**를 이용한 **계층형 GraphRAG (Hierarchical GraphRAG) 시스템**을 구축합니다.

---

## 🏗️ 시스템 아키텍처 및 특징

1. **계층적 문서 파싱**: `main.py`를 통해 대제목, 중제목, 소제목, 세부제목으로 이어지는 계층 구조를 파싱하여 부모-자식 관계(`parent_id`)를 보존한 JSON 형태로 데이터를 정제합니다.
2. **Neo4j 그래프 데이터베이스 저장**: 정제된 섹션을 `DocumentSection` 노드로 저장하며, 계층 구조를 `PARENT_OF` 관계로 연결합니다.
3. **로컬 임베딩 생성**: HuggingFace의 `BAAI/bge-m3` 모델을 로컬에서 구동하여 각 섹션의 제목 및 본문 텍스트에 대한 고차원 벡터 임베딩을 생성하고 Neo4j의 벡터 인덱스에 등록합니다.
4. **계층 구조 기반 검색 (Hierarchical Context Retrieval)**: 사용자가 입력한 자연어 질문에 대해 벡터 검색을 수행한 후, 매칭된 노드뿐만 아니라 **직계 부모 노드(상위 맥락)** 및 **자식 노드(하위 세부 절차)**를 Neo4j 그래프 상에서 탐색하여 LLM의 프롬프트 컨텍스트로 함께 주입합니다.
5. **로컬 LLM (Ollama) 답변 생성**: 외부 클라우드 API 호출 없이 로컬 Ollama 모델을 활용해 보안성이 높은 재난 대응 답변을 생성하고 실시간으로 스트리밍합니다.

---

## 📂 파일 구성

- [main.py](file:///Users/youngilchung/study/graph_test/main.py): 원본 JSON에서 계층 구조를 파싱해 `graph_rag_inputs.json`을 생성하는 ETL 스크립트.
- [ingest.py](file:///Users/youngilchung/study/graph_test/ingest.py): `graph_rag_inputs.json` 로드 ➔ 임베딩 생성 ➔ Neo4j 노드 및 관계 구축 ➔ 벡터 인덱스 생성.
- [query.py](file:///Users/youngilchung/study/graph_test/query.py): 자연어 입력 ➔ Neo4j Vector + Graph 검색 ➔ 트리형 맥락 로깅 ➔ Ollama LLM을 통한 답변 스트리밍.
- [.env](file:///Users/youngilchung/study/graph_test/.env): 데이터베이스 및 로컬 LLM 환경 설정 파일.

---

## 🛠️ 설치 및 실행 방법

### 1. 사전 요구사항

- **Python 3.13 이상** 및 **uv** 패키지 매니저
- **Neo4j 인스턴스** (Docker 실행 권장)
- **Ollama** 서비스 구동 중 및 사용할 LLM 모델 다운로드 완료

### 2. Neo4j & Ollama 설정 예시 (Docker & CLI)

**Neo4j Docker 실행:**
```bash
docker run \
    --name neo4j-graphrag \
    -p 7474:7474 -p 7687:7687 \
    -e NEO4J_AUTH=neo4j/password \
    -d neo4j:latest
```

**Ollama 모델 다운로드:**
```bash
ollama run llama3.1
```

### 3. 환경 변수 설정

[.env](file:///Users/youngilchung/study/graph_test/.env) 파일을 프로젝트 루트 디렉토리에 생성하고 환경에 맞게 정보를 수정합니다.

```ini
# Neo4j Database Configuration
NEO4J_URI=bolt://localhost:7687
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=password

# Ollama Configuration
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3.1

# Embedding Model Configuration (HuggingFace)
EMBEDDING_MODEL_NAME=BAAI/bge-m3
```

### 4. 데이터 적재 및 인덱싱 실행

다음 명령을 실행하여 데이터 전처리 및 Neo4j 적재를 진행합니다:

```bash
# uv를 사용하는 경우:
uv run ingest.py
```

*성공 시, 터미널에 총 노드 수 및 관계 수 검증 결과가 표시됩니다.*

### 5. 대화형 질의 CLI 실행

질문과 답변을 입력받을 수 있는 CLI 환경을 띄웁니다:

```bash
uv run query.py
```

---

## 🔍 실행 결과 예시 (query.py)

```text
💬 질문을 입력하세요: 방사능 누출 시 주민 대피 행동요령은 무엇인가요?

🔍 계층 구조 벡터 검색 진행 중...

=== 🌿 [GraphRAG가 탐색한 문서 계층 구조] ===
[1] 📌 SEC_0428 가. 주민보호조치 요령 (유사도: 0.8142) -> [부모: SEC_0420]
    ├── 🏢 부모 섹션: 3. 방사선비상 시 대응 활동
    └── 📄 하위 세부 섹션 (3개):
        ├── ▫️ SEC_0429: ① 옥내대피령 발령 시 조치사항
        ├── ▫️ SEC_0430: ② 소개령(대피령) 발령 시 조치사항
        └── ▫️ SEC_0431: ③ 갑상샘 방호약품 복용 요령
============================================

🤖 LLM 답변 생성 중 (스트리밍):
--------------------------------------------------
[SEC_0428] 주민보호조치 요령 및 상위 단계인 [SEC_0420] 방사선비상 시 대응 활동에 의거한 행동 요령은 다음과 같습니다:

1. **옥내대피령 발령 시 (SEC_0429)**
   - 즉시 가옥 내 또는 견고한 건물 안으로 대피하고 문과 창문을 닫아 외부 공기 유입을 차단합니다.
   - 라디오, TV 등을 통해 재난 방송 안내에 귀를 기울입니다.
   - ...
--------------------------------------------------
```
