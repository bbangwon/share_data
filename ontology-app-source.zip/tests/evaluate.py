import asyncio
import json
import os
import sys
import traceback
from datetime import datetime
from pathlib import Path

# Add project root to sys.path to allow importing app config
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

import httpx
from dotenv import load_dotenv

load_dotenv(override=True)


async def main():
    # 0. Argument Parser 추가 (개발 및 디버깅 시 소수 샘플만 신속하게 돌릴 수 있도록 제어)
    import argparse

    parser = argparse.ArgumentParser(description="GraphRAG Retrieval Evaluation Script")
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="평가할 테스트 케이스 개수 제한 (기본값: 전체 평가)",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="기존 트레이스 캐시를 무시하고 무조건 API를 다시 호출",
    )
    parser.add_argument(
        "--step",
        type=int,
        choices=[1, 2, 3],
        default=3,
        help="평가 및 실행할 최대 단계 (1: 1단계만, 2: 2단계까지, 3: 3단계 전체)",
    )
    args, unknown = parser.parse_known_args()

    # 1. 경로 설정
    script_dir = Path(__file__).resolve().parent
    goldenset_path = script_dir / "goldenset.jsonl"
    results_dir = script_dir / "results"
    results_dir.mkdir(parents=True, exist_ok=True)

    project_root = script_dir.parent
    traces_dir = project_root / "logs" / "traces"

    # 2. goldenset 로드
    items = []
    with open(goldenset_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                items.append(json.loads(line))

    if args.limit is not None:
        items = items[: args.limit]
        print(f"Limiting evaluation to the first {args.limit} items.")

    total = len(items)
    print(f"Loaded {total} evaluation items from goldenset.")
    print(f"Traces directory: {traces_dir}")

    # 3. 통계용 변수 초기화
    pages_results = {"step_1": 0, "step_2": 0, "step_3": 0}
    pages_new_results = {"step_1": 0, "step_2": 0, "step_3": 0}

    detailed_results = []

    # 4. 루프 수행하며 API 호출 및 평가
    async with httpx.AsyncClient(timeout=600.0) as client:
        for idx, item in enumerate(items, start=1):
            query = item["query"]
            query_complete = item["query_complete"]

            # 정답 페이지 정수 셋으로 정규화
            gold_pages = set()
            for p in item.get("pages") or []:
                try:
                    gold_pages.add(int(p))
                except (ValueError, TypeError):
                    pass

            gold_pages_new = set()
            for p in item.get("pages_new") or []:
                try:
                    gold_pages_new.add(int(p))
                except (ValueError, TypeError):
                    pass

            # --- 캐시 검사 로직 ---
            cached_trace_file = None
            if not args.no_cache:
                try:
                    from app.config import settings

                    for path in traces_dir.glob("trace_*.json"):
                        try:
                            with open(path, "r", encoding="utf-8") as tf:
                                trace_data = json.load(tf)
                            if trace_data.get("query", "").strip() == query.strip():
                                # 캐시된 파라미터가 현재 설정(settings)과 일치하는지 비교 검증
                                params = trace_data.get("parameters", {})
                                match_synonym = (
                                    params.get("use_synonym_search")
                                    == settings.DEFAULT_USE_SYNONYM_SEARCH
                                )
                                match_graph = (
                                    params.get("use_graph_expansion")
                                    == settings.DEFAULT_USE_GRAPH_EXPANSION
                                )
                                match_reasoning = (
                                    params.get("use_reasoning_selector")
                                    == settings.DEFAULT_USE_REASONING_SELECTOR
                                )

                                if match_synonym and match_graph and match_reasoning:
                                    # 정상적으로 기록된 trace 파일이 존재하면 캐시로 간주
                                    steps = trace_data.get("steps", {})
                                    if (
                                        "step_1_candidates" in steps
                                        and "combined_candidates"
                                        in steps["step_1_candidates"]
                                    ):
                                        cached_trace_file = path
                                        break
                        except Exception:
                            continue
                except ImportError:
                    # app.config를 불러올 수 없는 경우 기본 매칭으로 폴백
                    for path in traces_dir.glob("trace_*.json"):
                        try:
                            with open(path, "r", encoding="utf-8") as tf:
                                trace_data = json.load(tf)
                            if trace_data.get("query", "").strip() == query.strip():
                                steps = trace_data.get("steps", {})
                                if (
                                    "step_1_candidates" in steps
                                    and "combined_candidates"
                                    in steps["step_1_candidates"]
                                ):
                                    cached_trace_file = path
                                    break
                        except Exception:
                            continue

            trace_file = None
            if cached_trace_file:
                print(
                    f"[{idx}/{total}] Found cached trace: {cached_trace_file.name} for query: '{query}'"
                )
                trace_file = cached_trace_file
            else:
                print(f"[{idx}/{total}] Evaluating query: '{query}'")

                # API 요청 페이로드
                payload = {
                    "query": query,
                    "query_complete": query_complete,
                    "only_prompt": False,
                    "save_trace": True,
                }
                if args.step < 3:
                    payload["use_reasoning_selector"] = False
                if args.step < 2:
                    payload["use_reranker"] = False

                # 재시도 메커니즘 (최대 3회)
                success = False
                for attempt in range(1, 4):
                    print(f"  -> Calling search API (Attempt {attempt}/3)...")
                    try:
                        response = await client.post(
                            "http://localhost:48080/search", json=payload
                        )
                        response.raise_for_status()
                        success = True
                        break
                    except Exception as e:
                        print(f"  -> Attempt {attempt} failed: {e}")
                        if attempt < 3:
                            await asyncio.sleep(
                                5.0
                            )  # 서버 안정을 위해 5초 대기 후 재시도
                        else:
                            traceback.print_exc()
                            if hasattr(e, "response") and e.response is not None:
                                print(f"  -> Response status: {e.response.status_code}")
                                print(f"  -> Response text: {e.response.text[:500]}")

                if not success:
                    print(
                        f"Warning: Skipping query '{query}' due to repeated failures."
                    )
                    continue

                # 디스크 저장 대기 및 서버 부하 조율 (LLM 비활성화 시 대기 최소화)
                sleep_time = 0.5 if args.step < 3 else 3.0
                await asyncio.sleep(sleep_time)

                # 생성된 최신 트레이스 파일 매칭
                newest_time = None
                for path in traces_dir.glob("trace_*.json"):
                    try:
                        mtime = path.stat().st_mtime
                        with open(path, "r", encoding="utf-8") as tf:
                            trace_data = json.load(tf)
                        if trace_data.get("query", "").strip() == query.strip():
                            if newest_time is None or mtime > newest_time:
                                newest_time = mtime
                                trace_file = path
                    except Exception:
                        continue

            if not trace_file:
                print(
                    f"Warning: Trace file for query '{query}' not found in {traces_dir}"
                )
                continue

            print(f"Processing trace file: {trace_file.name}")
            with open(trace_file, "r", encoding="utf-8") as tf:
                trace_data = json.load(tf)

            # 각 검색 단계별 청크 추출
            steps = trace_data.get("steps", {})
            step_1 = steps.get("step_1_candidates", {})
            combined_candidates = step_1.get("combined_candidates", [])
            step_2_reranked = steps.get("step_2_reranked", [])
            step_3_documents = steps.get("step_3_documents", [])

            # 1단계 후보 페이지 추출
            step_1_pages = set()
            for cand in combined_candidates:
                p_pages = cand.get("parent_pages")
                if p_pages:
                    for page in p_pages:
                        step_1_pages.add(int(page))
                else:
                    page = cand.get("child_page") or cand.get("start_page")
                    if page is not None:
                        try:
                            step_1_pages.add(int(page))
                        except (ValueError, TypeError):
                            pass

            # 2단계 후보 페이지 추출
            step_2_pages = set()
            try:
                from app.config import settings
                default_rerank_limit = settings.DEFAULT_RERANK_LIMIT
            except ImportError:
                default_rerank_limit = 30
            
            limit = trace_data.get("parameters", {}).get("rerank_limit") or default_rerank_limit
            
            for cand in step_2_reranked[:limit]:
                p_pages = cand.get("parent_pages")
                if p_pages:
                    for page in p_pages:
                        step_2_pages.add(int(page))
                else:
                    page = cand.get("child_page") or cand.get("start_page")
                    if page is not None:
                        try:
                            step_2_pages.add(int(page))
                        except (ValueError, TypeError):
                            pass

            # 3단계 후보 페이지 추출
            step_3_pages = set()
            for doc in step_3_documents:
                p_pages = doc.get("parent_pages")
                if p_pages:
                    for page in p_pages:
                        step_3_pages.add(int(page))
                else:
                    page = doc.get("child_page") or doc.get("start_page")
                    if page is not None:
                        try:
                            step_3_pages.add(int(page))
                        except (ValueError, TypeError):
                            pass

            # pages 기준 매칭 평가
            s1_ok = (
                len(step_1_pages.intersection(gold_pages)) > 0 if gold_pages else False
            )
            s2_ok = (
                len(step_2_pages.intersection(gold_pages)) > 0 if gold_pages else False
            )
            s3_ok = (
                len(step_3_pages.intersection(gold_pages)) > 0 if gold_pages else False
            )

            if s1_ok:
                pages_results["step_1"] += 1
            if s2_ok:
                pages_results["step_2"] += 1
            if s3_ok:
                pages_results["step_3"] += 1

            # pages_new 기준 매칭 평가
            s1_new_ok = (
                len(step_1_pages.intersection(gold_pages_new)) > 0
                if gold_pages_new
                else False
            )
            s2_new_ok = (
                len(step_2_pages.intersection(gold_pages_new)) > 0
                if gold_pages_new
                else False
            )
            s3_new_ok = (
                len(step_3_pages.intersection(gold_pages_new)) > 0
                if gold_pages_new
                else False
            )

            if s1_new_ok:
                pages_new_results["step_1"] += 1
            if s2_new_ok:
                pages_new_results["step_2"] += 1
            if s3_new_ok:
                pages_new_results["step_3"] += 1

            detailed_results.append(
                {
                    "query": query,
                    "gold_pages": list(gold_pages),
                    "gold_pages_new": list(gold_pages_new),
                    "step_1": {
                        "pages": list(step_1_pages),
                        "hit": s1_ok,
                        "hit_new": s1_new_ok,
                    },
                    "step_2": {
                        "pages": list(step_2_pages),
                        "hit": s2_ok,
                        "hit_new": s2_new_ok,
                    },
                    "step_3": {
                        "pages": list(step_3_pages),
                        "hit": s3_ok,
                        "hit_new": s3_new_ok,
                    },
                }
            )

    # 5. 리포트 생성 및 통계 도출
    try:
        from app.config import settings

        use_synonym = settings.DEFAULT_USE_SYNONYM_SEARCH
        use_reasoning = settings.DEFAULT_USE_REASONING_SELECTOR
        top_k = settings.DEFAULT_TOP_K
        rerank_limit = settings.DEFAULT_RERANK_LIMIT
        dense_limit = settings.PREFETCH_DENSE_LIMIT
        sparse_limit = settings.PREFETCH_SPARSE_LIMIT
        synonym_term_limit = settings.SYNONYM_TERM_LIMIT
    except ImportError:
        use_synonym = True
        use_reasoning = True
        top_k = 5
        rerank_limit = 30
        dense_limit = 50
        sparse_limit = 50
        synonym_term_limit = 30

    # 1단계 설명 빌드 (Dense Limit + Sparse Limit + 동의어 매칭 후보군 수 수식화)
    fusion_limit = dense_limit + sparse_limit
    if use_synonym:
        max_chunks = (
            fusion_limit + synonym_term_limit
        )  # Neo4j 동의어 탐색 및 BM25 Pruning 최대 추가
        step_1_desc = f"하이브리드(Dense/Sparse) 검색 + Neo4j 동의어 사전 매칭 후보군 (최대 {max_chunks}개 청크)"
    else:
        step_1_desc = (
            f"하이브리드(Dense/Sparse) 검색 후보군 (최대 {fusion_limit}개 청크)"
        )

    # 2단계 설명 빌드
    step_2_desc = f"CrossEncoder 리랭크 정렬 결과 (상위 {rerank_limit}개 청크)"

    # 3단계 설명 빌드
    if use_reasoning:
        step_3_desc = f"리즈닝 셀렉터(LLM 평가) 기반 최종 선별 결과 (Top-{top_k})"
    else:
        step_3_desc = (
            f"리랭크 점수 단순 정렬 기반 최종 선별 결과 (Top-{top_k}, LLM 비활성화)"
        )

    report_lines = []
    report_lines.append("# pages 정답")
    report_lines.append(f"## {step_1_desc}")
    report_lines.append(
        f"1단계: {pages_results['step_1']} / {total} | {pages_results['step_1'] / total * 100:.2f}%"
    )
    if args.step >= 2:
        report_lines.append(f"## {step_2_desc}")
        report_lines.append(
            f"2단계: {pages_results['step_2']} / {total} | {pages_results['step_2'] / total * 100:.2f}%"
        )
    if args.step >= 3:
        report_lines.append(f"## {step_3_desc}")
        report_lines.append(
            f"3단계: {pages_results['step_3']} / {total} | {pages_results['step_3'] / total * 100:.2f}%"
        )

    report_lines.append("")
    report_lines.append("# pages_new 정답")
    report_lines.append(f"## {step_1_desc}")
    report_lines.append(
        f"1단계: {pages_new_results['step_1']} / {total} | {pages_new_results['step_1'] / total * 100:.2f}%"
    )
    if args.step >= 2:
        report_lines.append(f"## {step_2_desc}")
        report_lines.append(
            f"2단계: {pages_new_results['step_2']} / {total} | {pages_new_results['step_2'] / total * 100:.2f}%"
        )
    if args.step >= 3:
        report_lines.append(f"## {step_3_desc}")
        report_lines.append(
            f"3단계: {pages_new_results['step_3']} / {total} | {pages_new_results['step_3'] / total * 100:.2f}%"
        )

    report_text = "\n".join(report_lines)
    print("\n" + report_text)

    # 6. 결과 파일들 디렉토리에 저장
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_output_path = results_dir / f"eval_report_{timestamp}.txt"
    json_output_path = results_dir / f"eval_details_{timestamp}.json"

    with open(report_output_path, "w", encoding="utf-8") as f:
        f.write(report_text)

    with open(json_output_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "summary": {"pages": pages_results, "pages_new": pages_new_results},
                "details": detailed_results,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    print(f"\nSaved report to: {report_output_path}")
    print(f"Saved details to: {json_output_path}")


if __name__ == "__main__":
    asyncio.run(main())
