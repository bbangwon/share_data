ls
cd app/
ls
cd api/
ls
cd v1/
ls
cd endpoints/
ls
vi ingest.py 
cat ingest.py 
cd ..
cd ..
ls
cd ..
ls
cd core
cat ingest_pipeline.py 
ls
exit
