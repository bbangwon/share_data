from __future__ import annotations

from typing import Any
import httpx


class GpuReranker:
    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        timeout: float = 60.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self._owns_client = client is None
        self.client = client or httpx.AsyncClient(timeout=timeout)

    async def rerank(
        self, query: str, documents: list[str], *, top_n: int | None = None
    ) -> list[dict[str, Any]]:
        if not documents:
            return []
        payload = {
            "model": self.model,
            "query": query,
            "documents": documents,
        }
        if top_n is not None:
            payload["top_n"] = top_n
        
        response = await self.client.post(
            f"{self.base_url}/v1/rerank",
            json=payload,
            timeout=self.timeout
        )
        response.raise_for_status()
        data = response.json()
        results = data.get("results") or data.get("data") or []
        if not isinstance(results, list) or not all(isinstance(item, dict) for item in results):
            raise ValueError("invalid rerank response shape")
        for item in results:
            try:
                index = int(item["index"])
            except (KeyError, TypeError, ValueError):
                raise ValueError(f"invalid rerank result index: {item!r}") from None
            if index < 0 or index >= len(documents):
                raise ValueError(f"invalid rerank result index: {index!r}")
            item["index"] = index
            item["rerank_score"] = self._rerank_score(item)
        return results

    async def close(self) -> None:
        if self._owns_client:
            await self.client.aclose()

    async def __aenter__(self) -> GpuReranker:
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    @staticmethod
    def _rerank_score(item: dict[str, Any]) -> float | None:
        for key in ("score", "relevance_score", "relevanceScore", "rerank_score"):
            if key in item:
                value = item.get(key)
                try:
                    if value is not None:
                        return float(value)
                except (TypeError, ValueError):
                    return None
        return None
