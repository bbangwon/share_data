from __future__ import annotations

import asyncio
import os
import json
import math
import logging
from collections import Counter
from collections.abc import Iterable, Sequence
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import httpx
from fastembed import SparseTextEmbedding
from kiwipiepy import Kiwi

SparseVectorDict = dict[str, list[int] | list[float]]

logger = logging.getLogger("graphrag_embeddings")


def create_configured_kiwi() -> Kiwi:
    """
    Creates and configures a Kiwi tokenizer instance.
    Sets kiwi.global_config.space_tolerance = 2
    """
    kiwi = Kiwi()
    kiwi.global_config.space_tolerance = 2
    return kiwi


def build_embed_text(chunk: Any) -> str:
    parts = [
        getattr(chunk, "contextual_prefix", None),
        getattr(chunk, "metadata_prefix", None),
        getattr(chunk, "boost_keywords", None),
        getattr(chunk, "text", None),
    ]
    return "\n".join(str(part) for part in parts if part)


class GpuDenseEmbedder:
    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        timeout: float = 60.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self._owns_client = client is None
        self.client = client or httpx.AsyncClient(timeout=timeout)

    async def embed(self, text: str) -> list[float]:
        return (await self.embed_many([text]))[0]

    async def embed_many(self, texts: Sequence[str]) -> list[list[float]]:
        if not texts:
            return []
        response = await self.client.post(
            f"{self.base_url}/v1/embeddings",
            json={"model": self.model, "input": list(texts)},
            timeout=self.timeout
        )
        response.raise_for_status()
        data = response.json().get("data", [])
        if len(data) != len(texts):
            raise ValueError(
                f"embedding response count mismatch: expected {len(texts)}, got {len(data)}"
            )

        ordered: list[list[float] | None] = [None] * len(texts)
        for position, item in enumerate(data):
            try:
                index = int(item.get("index", position))
            except (AttributeError, TypeError, ValueError):
                raise ValueError(
                    f"invalid embedding response index: {item!r}"
                ) from None
            if index < 0 or index >= len(texts) or ordered[index] is not None:
                raise ValueError(f"invalid embedding response index: {index!r}")
            ordered[index] = list(item["embedding"])
        if any(vector is None for vector in ordered):
            raise ValueError("embedding response missing one or more indexes")
        return [vector for vector in ordered if vector is not None]

    async def embed_query_many(self, queries: Sequence[str]) -> list[list[float]]:
        return await self.embed_many(queries)

    async def close(self) -> None:
        if self._owns_client:
            await self.client.aclose()

    async def __aenter__(self) -> GpuDenseEmbedder:
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()


class KiwiBm25SparseEmbedder:
    TOKEN_TAGS = {"NNG", "NNP", "SN", "SL"}

    def __init__(
        self,
        *,
        tokenizer: Any | None = None,
        model: Any | None = None,
        model_name: str = "Qdrant/bm25",
    ) -> None:
        if tokenizer is None:
            self.tokenizer = create_configured_kiwi()
        else:
            self.tokenizer = tokenizer
            try:
                self.tokenizer.global_config.space_tolerance = 2
            except AttributeError:
                pass
        self.model = model or SparseTextEmbedding(model_name=model_name)
        self._executor = ThreadPoolExecutor(max_workers=1)

    def tokenize(self, text: str) -> list[str]:
        tokens: list[str] = []
        for token in self.tokenizer.tokenize(text or ""):
            form = getattr(token, "form", "")
            tag = getattr(token, "tag", "")
            if not form:
                continue
            if tag in self.TOKEN_TAGS:
                val = str(form).lower() if tag == "SL" else str(form)
                tokens.append(val)
                if len(val) >= 2:
                    for i in range(len(val) - 1):
                        tokens.append(val[i:i+2])
        return tokens

    def preprocess(self, text: str) -> str:
        return " ".join(self.tokenize(text))

    async def embed(self, text: str) -> SparseVectorDict:
        return (await self.embed_many([text]))[0]

    async def embed_many(self, texts: Sequence[str]) -> list[SparseVectorDict]:
        return await self._embed_with("embed", texts)

    async def query_embed(self, text: str) -> SparseVectorDict:
        return (await self.embed_query_many([text]))[0]

    async def embed_query_many(self, queries: Sequence[str]) -> list[SparseVectorDict]:
        return await self._embed_with("query_embed", queries)

    async def _embed_with(
        self, method_name: str, texts: Sequence[str]
    ) -> list[SparseVectorDict]:
        if not texts:
            return []
        loop = asyncio.get_running_loop()
        embeddings = await loop.run_in_executor(
            self._executor, self._embed_sync, method_name, list(texts)
        )
        return [self._to_sparse_dict(embedding) for embedding in embeddings]

    def _embed_sync(self, method_name: str, texts: list[str]) -> list[Any]:
        preprocessed = [self.preprocess(text) for text in texts]
        method = getattr(self.model, method_name)
        return list(method(preprocessed))

    async def close(self) -> None:
        self._executor.shutdown(wait=True)

    @staticmethod
    def _to_sparse_dict(embedding: Any) -> SparseVectorDict:
        if hasattr(embedding, "as_object"):
            raw = embedding.as_object()
            return {
                "indices": _as_list(raw.get("indices", []), int),
                "values": _as_list(raw.get("values", []), float),
            }
        if hasattr(embedding, "indices") and hasattr(embedding, "values"):
            return {
                "indices": _as_list(embedding.indices, int),
                "values": _as_list(embedding.values, float),
            }
        if hasattr(embedding, "as_dict"):
            raw_dict = embedding.as_dict()
            return {
                "indices": [int(index) for index in raw_dict.keys()],
                "values": [float(value) for value in raw_dict.values()],
            }
        if isinstance(embedding, dict):
            return {
                "indices": _as_list(embedding.get("indices", []), int),
                "values": _as_list(embedding.get("values", []), float),
            }
        raise TypeError(f"Unsupported sparse embedding shape: {type(embedding)!r}")


def _as_list(values: Iterable[Any], item_type: type) -> list[Any]:
    if hasattr(values, "tolist"):
        values = values.tolist()
    return [item_type(value) for value in values]


class KiwiBM25:
    """
    한국어 형태소 분석기(Kiwi)와 BM25 알고리즘을 결합한 Sparse Vector 생성 모델
    """
    def __init__(self, k1=1.5, b=0.75):
        self.k1 = k1
        self.b = b
        self.kiwi = create_configured_kiwi()
        self.vocab = {}      # 형태소 토큰 -> 정수 인덱스
        self.idf = {}        # 정수 인덱스 -> IDF 값
        self.avgdl = 0.0     # 코퍼스 내 평균 문서 형태소 길이
        self.doc_count = 0

    def tokenize(self, text):
        """
        텍스트를 토큰화하고 핵심 형태소(명사, 동사, 형용사, 부사 등)를 추출합니다.
        """
        if not text:
            return []
            
        tokens = []
        # 형태소 분석 실행
        for token in self.kiwi.tokenize(text or ""):
            # N(체언/명사 등), V(용언/동사/형용사 등), XR(어근), MAG(일반부사) 태그 추출
            if token.tag.startswith(('N', 'V', 'XR', 'MAG')):
                # 형태소 충돌 방지를 위해 '형태/태그' 구조로 결합
                tokens.append(f"{token.form}/{token.tag}")
                if len(token.form) >= 2:
                    for i in range(len(token.form) - 1):
                        tokens.append(f"{token.form[i:i+2]}/BI")
        return tokens

    def fit(self, corpus):
        """
        문서 코퍼스 리스트를 학습하여 IDF 및 평균 문서 길이를 계산합니다.
        """
        tokenized_corpus = [self.tokenize(doc) for doc in corpus]
        self.doc_count = len(tokenized_corpus)
        
        # 문서별 길이 계산
        doc_lengths = [len(tokens) for tokens in tokenized_corpus]
        self.avgdl = sum(doc_lengths) / self.doc_count if self.doc_count > 0 else 0.0
        
        # 형태소당 문헌 빈도(Document Frequency) 계산
        term_doc_counts = Counter()
        vocab_set = set()
        for tokens in tokenized_corpus:
            unique_tokens = set(tokens)
            vocab_set.update(unique_tokens)
            for token in unique_tokens:
                term_doc_counts[token] += 1
                
        # 알파벳/한글 순으로 정렬하여 일관된 인덱스 할당
        self.vocab = {token: idx for idx, token in enumerate(sorted(vocab_set))}
        
        # IDF 계산 (Lucene BM25 공식 사용: 항상 양수값 보장)
        self.idf = {}
        for token, count in term_doc_counts.items():
            idx = self.vocab[token]
            self.idf[idx] = math.log(1.0 + (self.doc_count - count + 0.5) / (count + 0.5))

    def get_document_vector(self, text):
        """
        인덱싱용 문서(청크)에 대한 BM25 Sparse Vector(indices, values)를 구합니다.
        """
        tokens = self.tokenize(text)
        if not tokens:
            return [], []
            
        doc_len = len(tokens)
        tf_counter = Counter(tokens)
        
        indices = []
        values = []
        
        for token, tf in tf_counter.items():
            if token in self.vocab:
                idx = self.vocab[token]
                # BM25 TF 가중치 계산 공식 적용
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (1.0 - self.b + self.b * (doc_len / self.avgdl))
                weight = numerator / denominator
                
                indices.append(idx)
                values.append(weight)
                
        # Qdrant의 요구사항에 맞춰 인덱스 오름차순으로 정렬
        sorted_pairs = sorted(zip(indices, values))
        if not sorted_pairs:
            return [], []
        idx_list, val_list = zip(*sorted_pairs)
        return list(idx_list), list(val_list)

    def get_query_vector(self, text):
        """
        검색 질의(Query)에 대한 BM25 Sparse Vector(indices, values)를 구합니다.
        """
        tokens = self.tokenize(text)
        if not tokens:
            return [], []
            
        tf_counter = Counter(tokens)
        
        indices = []
        values = []
        
        for token, tf in tf_counter.items():
            if token in self.vocab:
                idx = self.vocab[token]
                # 질의에 대해서는 IDF * TF 가중치 적용
                weight = self.idf[idx] * tf
                indices.append(idx)
                values.append(weight)
                
        # 인덱스 오름차순으로 정렬
        sorted_pairs = sorted(zip(indices, values))
        if not sorted_pairs:
            return [], []
        idx_list, val_list = zip(*sorted_pairs)
        return list(idx_list), list(val_list)

    def save(self, filepath):
        """
        학습된 모델 정보를 파일로 직렬화합니다.
        """
        state = {
            "k1": self.k1,
            "b": self.b,
            "vocab": self.vocab,
            "idf": self.idf,
            "avgdl": self.avgdl,
            "doc_count": self.doc_count
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=4)

    @classmethod
    def load(cls, filepath):
        """
        직렬화된 파일로부터 모델 정보를 역직렬화하여 객체를 생성합니다.
        """
        with open(filepath, "r", encoding="utf-8") as f:
            state = json.load(f)
        bm25 = cls(k1=state["k1"], b=state["b"])
        bm25.vocab = state["vocab"]
        # JSON 키가 문자열로 로드되므로 정수로 캐스팅
        bm25.idf = {int(k): v for k, v in state["idf"].items()}
        bm25.avgdl = state["avgdl"]
        bm25.doc_count = state["doc_count"]
        return bm25


logger = logging.getLogger("graphrag_search_kiwibm25")
_kiwi_bm25 = None

def get_kiwi_bm25() -> KiwiBM25 | None:
    """학습된 KiwiBM25 모델 로드 (싱글톤 제공)"""
    global _kiwi_bm25
    if _kiwi_bm25 is None:
        model_path = "data/models/kiwi_bm25_model.json"
        if os.path.exists(model_path):
            try:
                _kiwi_bm25 = KiwiBM25.load(model_path)
                logger.info("Successfully loaded KiwiBM25 model.")
            except Exception as e:
                logger.error(f"Failed to load KiwiBM25 model: {e}")
                _kiwi_bm25 = None
        else:
            logger.warning(f"KiwiBM25 model file not found at '{model_path}'. Sparse search will be disabled.")
            _kiwi_bm25 = None
    return _kiwi_bm25
