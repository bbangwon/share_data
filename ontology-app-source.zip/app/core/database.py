import logging
from qdrant_client import AsyncQdrantClient
from langchain_neo4j import Neo4jGraph
from app.config import settings

logger = logging.getLogger("graphrag_search_db")

_qdrant_client = None
_neo4j_graph = None

def get_qdrant_client() -> AsyncQdrantClient:
    """Qdrant 비동기 클라이언트 싱글톤 인스턴스 반환"""
    global _qdrant_client
    if _qdrant_client is None:
        _qdrant_client = AsyncQdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
        logger.info(f"Connected to Qdrant Server (Async) at {settings.QDRANT_HOST}:{settings.QDRANT_PORT}")
    return _qdrant_client

def get_neo4j_graph() -> Neo4jGraph | None:
    """Neo4j 연결 인스턴스 반환. 연결 실패 시 None 반환"""
    global _neo4j_graph
    if _neo4j_graph is None:
        try:
            _neo4j_graph = Neo4jGraph(
                url=settings.NEO4J_URI,
                username=settings.NEO4J_USERNAME,
                password=settings.NEO4J_PASSWORD,
                refresh_schema=False
            )
            logger.info("Successfully connected to Neo4j DB.")
        except Exception as e:
            logger.error(f"Failed to connect to Neo4j DB: {e}")
            _neo4j_graph = None
    return _neo4j_graph

def is_neo4j_online() -> bool:
    """Neo4j 데이터베이스 활성화 상태 확인"""
    graph = get_neo4j_graph()
    if graph is None:
        return False
    try:
        graph.query("RETURN 1 AS val")
        return True
    except Exception:
        return False

async def is_qdrant_online() -> bool:
    """Qdrant 데이터베이스 활성화 상태 확인"""
    client = get_qdrant_client()
    try:
        await client.get_collections()
        return True
    except Exception:
        return False
