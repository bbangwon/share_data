import asyncio
import json
import logging
import os
import re
import time
import uuid
from typing import Any, Dict

from qdrant_client.models import (
    Distance,
    PointStruct,
    SparseIndexParams,
    SparseVector,
    SparseVectorParams,
    VectorParams,
)

from app.config import settings
from app.core.database import get_neo4j_graph, get_qdrant_client
from app.services.embeddings import GpuDenseEmbedder, KiwiBm25SparseEmbedder

logger = logging.getLogger("graphrag_ingest_pipeline")

# 전역 작업 상태 관리 딕셔너리
INGEST_TASKS: Dict[str, Dict[str, Any]] = {}


def get_header_level(content: str) -> int:
    """행동 매뉴얼 번호 체계를 분석해 레벨 분류"""
    if re.match(r"^[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫXIV\d]+\s*[\.\,]", content):
        return 1
    if re.match(r"^\d+\s*[\.\,]", content):
        return 2
    if re.match(r"^[가-힣]\s*[\.\,]", content):
        return 3
    if re.match(r"^(\d+\)|[가-힣]\)|[①-⑳])", content):
        return 4
    return 3


def group_units_into_chunks(units: list, target_size: int, overlap: int) -> list:
    """문장/표 단위의 units 리스트를 target_size에 맞춰 병합 및 오버랩 처리"""
    chunks = []
    if not units:
        return chunks

    current_chunk_units = []
    current_size = 0
    i = 0
    while i < len(units):
        unit = units[i]
        unit_text = unit["text"]
        unit_len = len(unit_text)

        # 표 데이터인 경우 독립된 청크로 생성
        if unit["is_table"]:
            if current_chunk_units:
                chunks.append(
                    {
                        "text": " ".join([u["text"] for u in current_chunk_units]),
                        "units": current_chunk_units,
                    }
                )
                current_chunk_units = []
                current_size = 0
            chunks.append({"text": unit_text, "units": [unit]})
            i += 1
            continue

        # 일반 텍스트
        if current_chunk_units and current_size + unit_len > target_size:
            chunks.append(
                {
                    "text": " ".join([u["text"] for u in current_chunk_units]),
                    "units": current_chunk_units,
                }
            )

            # 오버랩 버퍼 수집
            overlap_units = []
            overlap_len = 0
            for ou in reversed(current_chunk_units):
                if ou["is_table"]:
                    break
                if overlap_len + len(ou["text"]) > overlap:
                    break
                overlap_units.insert(0, ou)
                overlap_len += len(ou["text"])

            current_chunk_units = overlap_units
            current_size = sum(len(u["text"]) for u in current_chunk_units)

        current_chunk_units.append(unit)
        current_size += unit_len
        i += 1

    if current_chunk_units:
        chunks.append(
            {
                "text": " ".join([u["text"] for u in current_chunk_units]),
                "units": current_chunk_units,
            }
        )
    return chunks


def parse_hierarchical_json(json_file_path: str) -> list:
    """원본 JSON 파일을 읽어 부모-자식 관계가 잡힌 계층형 구조로 가공"""
    if not os.path.exists(json_file_path):
        raise FileNotFoundError(f"원본 파일을 찾을 수 없습니다: {json_file_path}")

    with open(json_file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    exclude_categories = {"Page-header", "Page-footer", "Caption"}
    ignore_patterns = re.compile(
        r"(^\s*목\s*차\s*$|^\s*차\s*례\s*$|^\s*-\s*\d+\s*-\s*$)"
    )

    all_sections = []
    current_path = {1: None, 2: None, 3: None, 4: None}
    section_id_counter = 0

    for page in data.get("pages", []):
        page_num = page.get("page_number", 0)

        for element in page.get("elements", []):
            category = element.get("category", "")
            content = element.get("content", "").strip()

            if (
                category in exclude_categories
                or ignore_patterns.search(content)
                or not content
            ):
                continue

            if category == "Section-header":
                section_id_counter += 1
                level = get_header_level(content)
                new_section = {
                    "node_id": f"SEC_{section_id_counter:04d}",
                    "node_type": "DocumentSection",
                    "level": level,
                    "title": content,
                    "parent_id": None,
                    "start_page": page_num,
                    "body_content": "",
                    "raw_elements": [],
                    "parent_chunks": [],
                }

                # 직계 부모 노드 ID 설정
                for parent_level in range(level - 1, 0, -1):
                    if current_path[parent_level] is not None:
                        new_section["parent_id"] = current_path[parent_level]["node_id"]
                        break

                current_path[level] = new_section
                for l in range(level + 1, 5):
                    current_path[l] = None
                all_sections.append(new_section)
            else:
                active_section = None
                for l in range(4, 0, -1):
                    if current_path[l] is not None:
                        active_section = current_path[l]
                        break
                if active_section:
                    active_section["raw_elements"].append(
                        {
                            "category": category,
                            "content": content,
                            "page_number": page_num,
                        }
                    )
                    if category == "Table":
                        formatted_content = f"\n[표 구조 데이터]\n{content}\n"
                    else:
                        formatted_content = f"\n{content}"
                    active_section["body_content"] += formatted_content

    # 문장/표 단위 쪼개기 및 3단계 청크 구조화
    for sec in all_sections:
        sec["body_content"] = sec["body_content"].strip()
        units = []
        for elem in sec["raw_elements"]:
            cat = elem["category"]
            cnt = elem["content"].strip()
            if not cnt:
                continue

            elem_page = elem.get("page_number", sec["start_page"])
            if cat == "Table":
                units.append(
                    {
                        "text": f"[표 구조 데이터]\n{cnt}",
                        "is_table": True,
                        "page_number": elem_page,
                    }
                )
            else:
                sentences = re.split(r"(?<=[.?!])\s+", cnt)
                for sent in sentences:
                    sent = sent.strip()
                    if sent:
                        units.append(
                            {"text": sent, "is_table": False, "page_number": elem_page}
                        )

        # section_pages 수집
        sec_pages = sorted(list(set(int(u["page_number"]) for u in units if u.get("page_number") is not None)))
        if not sec_pages:
            sec_pages = [int(sec["start_page"])]

        # Parent Chunk 생성 (최대 2048자, overlap 200자)
        parent_chunks_raw = group_units_into_chunks(units, 2048, 200)
        sec_parent_chunks = []

        for p_idx, p_raw in enumerate(parent_chunks_raw):
            parent_chunk_id = f"{sec['node_id']}_P{p_idx + 1:02d}"

            # parent_pages 수집
            p_pages = sorted(list(set(int(u.get("page_number", sec["start_page"])) for u in p_raw["units"] if u.get("page_number") is not None)))
            if not p_pages:
                p_pages = [int(sec["start_page"])]

            # Child Chunk 생성 (최대 512자, overlap 50자)
            child_chunks_raw = group_units_into_chunks(p_raw["units"], 512, 50)
            sec_child_chunks = []

            for c_idx, c_raw in enumerate(child_chunks_raw):
                child_chunk_id = f"{parent_chunk_id}_C{c_idx + 1:02d}"
                c_page = (
                    int(c_raw["units"][0].get("page_number", sec["start_page"]))
                    if c_raw.get("units")
                    else int(sec["start_page"])
                )
                sec_child_chunks.append(
                    {
                        "child_chunk_id": child_chunk_id,
                        "text": c_raw["text"],
                        "child_page": c_page,
                    }
                )

            sec_parent_chunks.append(
                {
                    "parent_chunk_id": parent_chunk_id,
                    "text": p_raw["text"],
                    "parent_pages": p_pages,
                    "child_chunks": sec_child_chunks,
                }
            )

        sec["parent_chunks"] = sec_parent_chunks
        sec["section_pages"] = sec_pages
        if "raw_elements" in sec:
            del sec["raw_elements"]

    return all_sections


async def run_ingest_pipeline(task_id: str, input_file: str, output_file: str):
    """비동기 데이터 전처리, API 임베딩 생성 및 외장 DB 데이터 적재 전체 파이프라인"""
    INGEST_TASKS[task_id] = {
        "task_id": task_id,
        "status": "processing",
        "progress": "10%",
        "message": f"원본 JSON 전처리 시작... 파일: {input_file}",
        "results": None,
        "error": None,
    }

    start_time = time.time()
    try:
        # 1. JSON 파일 전처리 및 파싱
        logger.info(f"[{task_id}] Parsing raw JSON from {input_file}...")
        sections = parse_hierarchical_json(input_file)

        INGEST_TASKS[task_id].update(
            {"progress": "25%", "message": "중간 계층 inputs JSON 파일 생성 중..."}
        )

        # 중간 결과물 저장 (요청된 output_file로 저장)
        logger.info(f"[{task_id}] Saving intermediate output to {output_file}...")
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(sections, f, ensure_ascii=False, indent=4)

        INGEST_TASKS[task_id].update(
            {"progress": "35%", "message": "임베딩 API 및 로컬 형태소 분석 준비 중..."}
        )

        # 2. 임베딩 연산 대상 데이터 준비
        flat_child_chunks = []
        texts_to_embed = []
        for sec in sections:
            title = sec.get("title", "").strip()
            sec_pages = sec.get("section_pages", [int(sec.get("start_page", 1))])
            for p_chunk in sec.get("parent_chunks", []):
                p_id = p_chunk["parent_chunk_id"]
                p_text = p_chunk["text"]
                p_pages = p_chunk.get("parent_pages", [int(sec.get("start_page", 1))])
                for c_chunk in p_chunk.get("child_chunks", []):
                    c_id = c_chunk["child_chunk_id"]
                    c_text = c_chunk["text"]
                    c_page = c_chunk.get("child_page", int(sec.get("start_page", 1)))

                    combined_text = f"{title}\n\n{c_text}".strip()
                    flat_child_chunks.append(
                        {
                            "child_chunk_id": c_id,
                            "text": c_text,
                            "parent_chunk_id": p_id,
                            "parent_chunk_text": p_text,
                            "node_id": sec["node_id"],
                            "title": title,
                            "level": sec.get("level"),
                            "parent_id": sec.get("parent_id"),
                            "child_page": c_page,
                            "parent_pages": p_pages,
                            "section_pages": sec_pages,
                        }
                    )
                    texts_to_embed.append(
                        combined_text if combined_text else "Empty Section"
                    )

        total_chunks = len(flat_child_chunks)
        INGEST_TASKS[task_id].update(
            {
                "progress": "50%",
                "message": f"Dense API 및 Sparse 전처리 임베딩 병렬 연산 중 (총 {total_chunks}개 청크)...",
            }
        )

        # Dense API 임베딩 클라이언트 및 Sparse 로컬 토크나이저 연동
        logger.info(f"[{task_id}] Generating dense and sparse embeddings...")
        embedder = GpuDenseEmbedder(
            base_url=settings.EMBEDDING_API_URL,
            model=settings.EMBEDDING_MODEL_NAME,
            timeout=300.0
        )
        sparse_embedder = KiwiBm25SparseEmbedder()
        try:
            # 배치 크기를 32로 줄여 서버 부하 경감
            batch_size = 32
            all_embeddings = []
            all_sparse_embeddings = []

            for i in range(0, total_chunks, batch_size):
                batch_texts = texts_to_embed[i : i + batch_size]
                
                # 타임아웃 방지를 위해 순차적으로 연산 수행
                batch_dense = await embedder.embed_many(batch_texts)
                batch_sparse = await sparse_embedder.embed_many(batch_texts)

                all_embeddings.extend(batch_dense)
                all_sparse_embeddings.extend(batch_sparse)
        finally:
            await asyncio.gather(embedder.close(), sparse_embedder.close())

        embedding_dimension = len(all_embeddings[0])
        INGEST_TASKS[task_id].update(
            {
                "progress": "70%",
                "message": f"Qdrant 외부 데이터베이스 연결 및 재생색인 시작... ({settings.QDRANT_HOST}:{settings.QDRANT_PORT})",
            }
        )

        # 3. Qdrant 데이터 적재
        logger.info(f"[{task_id}] Upserting to Qdrant vector database...")
        qdrant_client = get_qdrant_client()
        collection_name = settings.QDRANT_COLLECTION_NAME

        # 컬렉션 초기화 및 재생성
        if await qdrant_client.collection_exists(collection_name=collection_name):
            await qdrant_client.delete_collection(collection_name=collection_name)

        await qdrant_client.create_collection(
            collection_name=collection_name,
            vectors_config={
                "": VectorParams(size=embedding_dimension, distance=Distance.COSINE)
            },
            sparse_vectors_config={
                "text-sparse": SparseVectorParams(index=SparseIndexParams(on_disk=True))
            },
        )

        # 포인트 생성
        points = []
        for idx, chunk in enumerate(flat_child_chunks):
            c_id = chunk["child_chunk_id"]
            point_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, c_id))
            sparse_emb = all_sparse_embeddings[idx]

            points.append(
                PointStruct(
                    id=point_id,
                    vector={
                        "": all_embeddings[idx],
                        "text-sparse": SparseVector(
                            indices=sparse_emb["indices"], values=sparse_emb["values"]
                        ),
                    },
                    payload={
                        "child_chunk_id": c_id,
                        "text": chunk["text"],
                        "parent_chunk_id": chunk["parent_chunk_id"],
                        "parent_chunk_text": chunk["parent_chunk_text"],
                        "node_id": chunk["node_id"],
                        "title": chunk["title"],
                        "level": chunk["level"],
                        "parent_id": chunk["parent_id"],
                        "child_page": chunk["child_page"],
                        "parent_pages": chunk["parent_pages"],
                        "section_pages": chunk["section_pages"],
                    },
                )
            )

        # 500개 묶음으로 적재
        q_batch_size = 500
        for i in range(0, len(points), q_batch_size):
            await qdrant_client.upsert(
                collection_name=collection_name, points=points[i : i + q_batch_size]
            )

        INGEST_TASKS[task_id].update(
            {
                "progress": "85%",
                "message": f"Neo4j 외부 데이터베이스 연결 및 그래프 계층 생성 시작... ({settings.NEO4J_URI})",
            }
        )

        # 4. Neo4j 그래프 적재
        logger.info(f"[{task_id}] Uploading to Neo4j database...")
        neo4j_graph = get_neo4j_graph()
        if neo4j_graph is None:
            raise ConnectionError(
                "Neo4j 외부 데이터베이스에 연결하지 못했습니다. 설정 값을 확인해 주세요."
            )

        loop = asyncio.get_event_loop()
        # 기존 지식 초기화
        await loop.run_in_executor(
            None, lambda: neo4j_graph.query("MATCH (n:DocumentSection) DETACH DELETE n")
        )
        await loop.run_in_executor(
            None, lambda: neo4j_graph.query("MATCH (n:ParentChunk) DETACH DELETE n")
        )
        await loop.run_in_executor(
            None, lambda: neo4j_graph.query("MATCH (n:ChildChunk) DETACH DELETE n")
        )
        await loop.run_in_executor(
            None, lambda: neo4j_graph.query("MATCH (n:Term) DETACH DELETE n")
        )

        # 고유 제약조건 생성
        try:
            await loop.run_in_executor(
                None,
                lambda: neo4j_graph.query(
                    "CREATE CONSTRAINT document_section_node_id IF NOT EXISTS FOR (s:DocumentSection) REQUIRE s.node_id IS UNIQUE"
                ),
            )
            await loop.run_in_executor(
                None,
                lambda: neo4j_graph.query(
                    "CREATE CONSTRAINT parent_chunk_chunk_id IF NOT EXISTS FOR (p:ParentChunk) REQUIRE p.chunk_id IS UNIQUE"
                ),
            )
            await loop.run_in_executor(
                None,
                lambda: neo4j_graph.query(
                    "CREATE CONSTRAINT child_chunk_chunk_id IF NOT EXISTS FOR (c:ChildChunk) REQUIRE c.chunk_id IS UNIQUE"
                ),
            )
            await loop.run_in_executor(
                None,
                lambda: neo4j_graph.query(
                    "CREATE CONSTRAINT term_name IF NOT EXISTS FOR (t:Term) REQUIRE t.name IS UNIQUE"
                ),
            )
        except Exception as ex:
            logger.warning(
                f"Neo4j Constraints creation ignored or already exists: {ex}"
            )

        # 200개 묶음 벌크 적재
        ingest_batch_size = 200

        # 4.1 DocumentSection 적재
        for i in range(0, len(sections), ingest_batch_size):
            batch_nodes = sections[i : i + ingest_batch_size]
            create_nodes_query = """
            UNWIND $batch AS row
            MERGE (s:DocumentSection {node_id: row.node_id})
            SET s.title = row.title,
                s.level = toInteger(row.level),
                s.start_page = toInteger(row.start_page),
                s.section_pages = row.section_pages,
                s.body_content = row.body_content
            """
            await loop.run_in_executor(
                None,
                lambda: neo4j_graph.query(create_nodes_query, {"batch": batch_nodes}),
            )

        # 4.2 PARENT_OF 관계 생성
        create_relationships_query = """
        UNWIND $batch AS row
        WITH row WHERE row.parent_id IS NOT NULL
        MATCH (child:DocumentSection {node_id: row.node_id})
        MATCH (parent:DocumentSection {node_id: row.parent_id})
        MERGE (parent)-[:PARENT_OF]->(child)
        """
        for i in range(0, len(sections), ingest_batch_size):
            batch_nodes = sections[i : i + ingest_batch_size]
            await loop.run_in_executor(
                None,
                lambda: neo4j_graph.query(
                    create_relationships_query, {"batch": batch_nodes}
                ),
            )

        # 4.3 Parent / Child 청크 데이터 분리 준비
        parent_batch = []
        child_batch = []
        for sec in sections:
            node_id = sec["node_id"]
            for p_chunk in sec.get("parent_chunks", []):
                parent_batch.append(
                    {
                        "node_id": node_id,
                        "parent_chunk_id": p_chunk["parent_chunk_id"],
                        "text": p_chunk["text"],
                        "parent_pages": p_chunk.get("parent_pages", []),
                    }
                )
                for c_chunk in p_chunk.get("child_chunks", []):
                    child_batch.append(
                        {
                            "parent_chunk_id": p_chunk["parent_chunk_id"],
                            "child_chunk_id": c_chunk["child_chunk_id"],
                            "text": c_chunk["text"],
                            "child_page": c_chunk.get("child_page"),
                        }
                    )

        # 4.4 ParentChunk 노드 및 HAS_PARENT_CHUNK 적재
        create_parents_query = """
        UNWIND $batch AS row
        MATCH (s:DocumentSection {node_id: row.node_id})
        MERGE (p:ParentChunk {chunk_id: row.parent_chunk_id})
        SET p.text = row.text,
            p.parent_pages = row.parent_pages
        MERGE (s)-[:HAS_PARENT_CHUNK]->(p)
        """
        for i in range(0, len(parent_batch), ingest_batch_size):
            await loop.run_in_executor(
                None,
                lambda: neo4j_graph.query(
                    create_parents_query,
                    {"batch": parent_batch[i : i + ingest_batch_size]},
                ),
            )

        # 4.5 ChildChunk 노드 및 HAS_CHILD_CHUNK 적재
        create_children_query = """
        UNWIND $batch AS row
        MATCH (p:ParentChunk {chunk_id: row.parent_chunk_id})
        MERGE (c:ChildChunk {chunk_id: row.child_chunk_id})
        SET c.text = row.text,
            c.child_page = toInteger(row.child_page)
        MERGE (p)-[:HAS_CHILD_CHUNK]->(c)
        """
        for i in range(0, len(child_batch), ingest_batch_size):
            await loop.run_in_executor(
                None,
                lambda: neo4j_graph.query(
                    create_children_query,
                    {"batch": child_batch[i : i + ingest_batch_size]},
                ),
            )

        # 4.6 동의어 사전 및 관계 적재
        paths = [
            "/data/dictionary/glossary.json",
            "data/dictionary/glossary.json",
            os.path.join(
                os.path.dirname(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                ),
                "data/dictionary/glossary.json",
            ),
        ]
        synonyms_path = None
        for path in paths:
            if os.path.exists(path):
                synonyms_path = path
                break

        if synonyms_path:
            logger.info(
                f"[{task_id}] Ingesting synonyms and ontology mapping from {synonyms_path}..."
            )
            with open(synonyms_path, "r", encoding="utf-8") as f:
                syn_data = json.load(f)

            for entry in syn_data:
                headword = entry["headword"].replace(" ", "")
                synonyms = [
                    syn["word"].replace(" ", "") for syn in entry.get("synonyms", [])
                ]

                await loop.run_in_executor(
                    None,
                    lambda: neo4j_graph.query(
                        "MERGE (t:Term {name: $name})", {"name": headword}
                    ),
                )
                for syn in synonyms:
                    await loop.run_in_executor(
                        None,
                        lambda: neo4j_graph.query(
                            "MERGE (s:Term {name: $name})", {"name": syn}
                        ),
                    )
                    await loop.run_in_executor(
                        None,
                        lambda: neo4j_graph.query(
                            """
                        MATCH (t:Term {name: $headword})
                        MATCH (s:Term {name: $syn})
                        MERGE (s)-[:SYNONYM_OF]->(t)
                    """,
                            {"headword": headword, "syn": syn},
                        ),
                    )

            logger.info(
                f"[{task_id}] Creating MENTIONS relationships between DocumentSections and Term nodes..."
            )
            for entry in syn_data:
                headword = entry["headword"].replace(" ", "")
                synonyms = [
                    syn["word"].replace(" ", "") for syn in entry.get("synonyms", [])
                ]
                all_keywords = [headword] + synonyms

                link_query = """
                UNWIND $keywords AS kw
                MATCH (sec:DocumentSection)
                WHERE replace(sec.title, ' ', '') CONTAINS kw 
                   OR replace(sec.body_content, ' ', '') CONTAINS kw
                MATCH (t:Term {name: $headword})
                MERGE (sec)-[:MENTIONS]->(t)
                """
                await loop.run_in_executor(
                    None,
                    lambda: neo4j_graph.query(
                        link_query, {"keywords": all_keywords, "headword": headword}
                    ),
                )

        # 5. DB 적재 데이터 요약 검증
        verification_query = """
        RETURN count { MATCH (s:DocumentSection) } AS section_count, 
               count { MATCH (p:ParentChunk) } AS parent_count,
               count { MATCH (c:ChildChunk) } AS child_count
        """
        verify_res = await loop.run_in_executor(
            None, lambda: neo4j_graph.query(verification_query)
        )

        duration = round(time.time() - start_time, 2)
        results = {
            "total_sections": len(sections),
            "total_parent_chunks": len(parent_batch),
            "total_child_chunks": len(child_batch),
            "qdrant_points_upserted": len(points),
            "neo4j_section_count": verify_res[0]["section_count"] if verify_res else 0,
            "neo4j_parent_count": verify_res[0]["parent_count"] if verify_res else 0,
            "neo4j_child_count": verify_res[0]["child_count"] if verify_res else 0,
            "duration_seconds": duration,
        }

        # 완료 업데이트
        INGEST_TASKS[task_id].update(
            {
                "status": "completed",
                "progress": "100%",
                "message": "데이터 가공 및 외부 데이터베이스 적재가 성공적으로 완료되었습니다.",
                "results": results,
            }
        )
        logger.info(f"[{task_id}] Ingestion successfully completed in {duration}s.")

    except Exception as e:
        duration = round(time.time() - start_time, 2)
        logger.error(f"[{task_id}] Ingestion pipeline failed: {e}", exc_info=True)
        INGEST_TASKS[task_id].update(
            {
                "status": "failed",
                "progress": "100%",
                "message": f"인제스트 프로세스 실행 중 예외가 발생했습니다: {str(e)}",
                "error": str(e),
            }
        )
