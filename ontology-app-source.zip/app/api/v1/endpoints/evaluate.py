import asyncio
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from app.api.v1.endpoints.search import search_manual
from app.config import settings
from app.schemas.search import SearchRequest

logger = logging.getLogger("graphrag_evaluate_api")
router = APIRouter()


class EvaluateRequest(BaseModel):
    limit: Optional[int] = Field(
        None, description="평가할 테스트 케이스 개수 제한 (기본값: 전체 평가)"
    )
    no_cache: Optional[bool] = Field(
        True, description="기존 트레이스 캐시를 무시하고 무조건 API를 다시 호출"
    )
    step: Optional[int] = Field(
        3,
        description="평가 및 실행할 최대 단계 (1: 1단계만, 2: 2단계까지, 3: 3단계 전체)",
    )


class EvaluateResponse(BaseModel):
    summary: Dict[str, Any]
    report: str
    details: List[Dict[str, Any]]
    report_file: str
    details_file: str


@router.post(
    "/evaluate",
    response_model=EvaluateResponse,
    status_code=status.HTTP_200_OK,
    summary="매뉴얼 검색 품질 자동 평가",
    description="goldenset.jsonl 파일을 로드하여 다단계 검색의 정확도(Hit Rate)를 측정하고 리포트를 생성합니다.",
)
async def run_evaluation(request: EvaluateRequest):
    project_root = Path(__file__).resolve().parent.parent.parent.parent.parent
    goldenset_path = project_root / "tests" / "goldenset.jsonl"
    traces_dir = project_root / "logs" / "traces"
    results_dir = project_root / "tests" / "results"
    results_dir.mkdir(parents=True, exist_ok=True)

    if not goldenset_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"goldenset.jsonl 파일을 찾을 수 없습니다. 경로: {goldenset_path}",
        )

    # goldenset 로드
    items = []
    with open(goldenset_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                items.append(json.loads(line))

    if request.limit is not None:
        items = items[: request.limit]

    total = len(items)
    if total == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="평가할 데이터가 없습니다."
        )

    pages_results = {"step_1": 0, "step_2": 0, "step_3": 0}
    pages_new_results = {"step_1": 0, "step_2": 0, "step_3": 0}
    detailed_results = []

    for idx, item in enumerate(items, start=1):
        query = item["query"]
        query_complete = item["query_complete"]

        # 정답 페이지 정규화
        gold_pages = set()
        for p in item.get("pages") or []:
            try:
                gold_pages.add(int(p))
            except (ValueError, TypeError):
                pass

        gold_pages_new = set()
        for p in item.get("pages_new") or []:
            try:
                gold_pages_new.add(int(p))
            except (ValueError, TypeError):
                pass

        # 캐시 검사
        cached_trace_file = None
        if not request.no_cache and traces_dir.exists():
            for path in traces_dir.glob("trace_*.json"):
                try:
                    with open(path, "r", encoding="utf-8") as tf:
                        trace_data = json.load(tf)
                    if trace_data.get("query", "").strip() == query.strip():
                        # 캐시 유효성 판단
                        params = trace_data.get("parameters", {})
                        if (
                            params.get("top_k") == settings.DEFAULT_TOP_K
                            and params.get("threshold") == settings.DEFAULT_THRESHOLD
                            and params.get("dense_limit")
                            == settings.PREFETCH_DENSE_LIMIT
                            and params.get("sparse_limit")
                            == settings.PREFETCH_SPARSE_LIMIT
                            and params.get("rerank_limit")
                            == settings.DEFAULT_RERANK_LIMIT
                            and params.get("use_reasoning_selector")
                            == settings.DEFAULT_USE_REASONING_SELECTOR
                            and params.get("use_synonym_search")
                            == settings.DEFAULT_USE_SYNONYM_SEARCH
                            and params.get("use_graph_expansion")
                            == settings.DEFAULT_USE_GRAPH_EXPANSION
                        ):
                            steps = trace_data.get("steps", {})
                            if (
                                "step_1_candidates" in steps
                                and "step_2_reranked" in steps
                                and "step_3_documents" in steps
                            ):
                                cached_trace_file = path
                                break
                except Exception:
                    continue

        trace_file = None
        if cached_trace_file:
            trace_file = cached_trace_file
        else:
            # API 직접 호출 (인메모리)
            search_req = SearchRequest(
                query=query,
                query_complete=query_complete,
                top_k=settings.DEFAULT_TOP_K,
                threshold=settings.DEFAULT_THRESHOLD,
                dense_limit=settings.PREFETCH_DENSE_LIMIT,
                sparse_limit=settings.PREFETCH_SPARSE_LIMIT,
                rerank_limit=settings.DEFAULT_RERANK_LIMIT,
                use_reasoning_selector=settings.DEFAULT_USE_REASONING_SELECTOR,
                use_synonym_search=settings.DEFAULT_USE_SYNONYM_SEARCH,
                use_graph_expansion=settings.DEFAULT_USE_GRAPH_EXPANSION,
                save_trace=True,
            )
            try:
                # 직접 호출하여 트레이스 로그 저장 유도
                await search_manual(search_req)

                # 디스크 쓰기 대기
                await asyncio.sleep(0.5 if request.step < 3 else 3.0)

                # 방금 저장된 트레이스 매칭
                newest_time = None
                if traces_dir.exists():
                    for path in traces_dir.glob("trace_*.json"):
                        try:
                            mtime = path.stat().st_mtime
                            with open(path, "r", encoding="utf-8") as tf:
                                trace_data = json.load(tf)
                            if trace_data.get("query", "").strip() == query.strip():
                                if newest_time is None or mtime > newest_time:
                                    newest_time = mtime
                                    trace_file = path
                        except Exception:
                            continue
            except Exception as e:
                logger.error(f"Error during query execution: {query}, error: {e}")
                continue

        if not trace_file:
            logger.warning(f"Trace file for query '{query}' not found")
            continue

        with open(trace_file, "r", encoding="utf-8") as tf:
            trace_data = json.load(tf)

        steps = trace_data.get("steps", {})
        step_1 = steps.get("step_1_candidates", {})
        combined_candidates = step_1.get("combined_candidates", [])
        step_2_reranked = steps.get("step_2_reranked", [])
        step_3_documents = steps.get("step_3_documents", [])

        # 1단계 페이지 추출
        step_1_pages = set()
        for cand in combined_candidates:
            p_pages = cand.get("parent_pages")
            if p_pages:
                for page in p_pages:
                    step_1_pages.add(int(page))
            else:
                page = cand.get("child_page") or cand.get("start_page")
                if page is not None:
                    try:
                        step_1_pages.add(int(page))
                    except (ValueError, TypeError):
                        pass

        # 2단계 페이지 추출 (Rerank Limit 제약 적용)
        step_2_pages = set()
        limit = (
            trace_data.get("parameters", {}).get("rerank_limit")
            or settings.DEFAULT_RERANK_LIMIT
        )
        for cand in step_2_reranked[:limit]:
            p_pages = cand.get("parent_pages")
            if p_pages:
                for page in p_pages:
                    step_2_pages.add(int(page))
            else:
                page = cand.get("child_page") or cand.get("start_page")
                if page is not None:
                    try:
                        step_2_pages.add(int(page))
                    except (ValueError, TypeError):
                        pass

        # 3단계 페이지 추출
        step_3_pages = set()
        for doc in step_3_documents:
            p_pages = doc.get("parent_pages")
            if p_pages:
                for page in p_pages:
                    step_3_pages.add(int(page))
            else:
                page = doc.get("child_page") or doc.get("start_page")
                if page is not None:
                    try:
                        step_3_pages.add(int(page))
                    except (ValueError, TypeError):
                        pass

        # 평가 채점
        s1_ok = len(step_1_pages.intersection(gold_pages)) > 0 if gold_pages else False
        s2_ok = len(step_2_pages.intersection(gold_pages)) > 0 if gold_pages else False
        s3_ok = len(step_3_pages.intersection(gold_pages)) > 0 if gold_pages else False

        if s1_ok:
            pages_results["step_1"] += 1
        if s2_ok:
            pages_results["step_2"] += 1
        if s3_ok:
            pages_results["step_3"] += 1

        s1_new_ok = (
            len(step_1_pages.intersection(gold_pages_new)) > 0
            if gold_pages_new
            else False
        )
        s2_new_ok = (
            len(step_2_pages.intersection(gold_pages_new)) > 0
            if gold_pages_new
            else False
        )
        s3_new_ok = (
            len(step_3_pages.intersection(gold_pages_new)) > 0
            if gold_pages_new
            else False
        )

        if s1_new_ok:
            pages_new_results["step_1"] += 1
        if s2_new_ok:
            pages_new_results["step_2"] += 1
        if s3_new_ok:
            pages_new_results["step_3"] += 1

        detailed_results.append(
            {
                "query": query,
                "gold_pages": list(gold_pages),
                "gold_pages_new": list(gold_pages_new),
                "step_1": {
                    "pages": list(step_1_pages),
                    "hit": s1_ok,
                    "hit_new": s1_new_ok,
                },
                "step_2": {
                    "pages": list(step_2_pages),
                    "hit": s2_ok,
                    "hit_new": s2_new_ok,
                },
                "step_3": {
                    "pages": list(step_3_pages),
                    "hit": s3_ok,
                    "hit_new": s3_new_ok,
                },
            }
        )

    # 리포트 구성
    use_synonym = settings.DEFAULT_USE_SYNONYM_SEARCH
    use_reasoning = settings.DEFAULT_USE_REASONING_SELECTOR
    top_k = settings.DEFAULT_TOP_K
    rerank_limit = settings.DEFAULT_RERANK_LIMIT
    dense_limit = settings.PREFETCH_DENSE_LIMIT
    sparse_limit = settings.PREFETCH_SPARSE_LIMIT
    synonym_term_limit = settings.SYNONYM_TERM_LIMIT

    fusion_limit = dense_limit + sparse_limit
    if use_synonym:
        max_chunks = fusion_limit + synonym_term_limit
        step_1_desc = f"하이브리드(Dense/Sparse) 검색 + Neo4j 동의어 사전 매칭 후보군 (최대 {max_chunks}개 청크)"
    else:
        step_1_desc = (
            f"하이브리드(Dense/Sparse) 검색 후보군 (최대 {fusion_limit}개 청크)"
        )

    step_2_desc = f"CrossEncoder 리랭크 정렬 결과 (상위 {rerank_limit}개 청크)"
    if use_reasoning:
        step_3_desc = f"리즈닝 셀렉터(LLM 평가) 기반 최종 선별 결과 (Top-{top_k})"
    else:
        step_3_desc = (
            f"리랭크 점수 단순 정렬 기반 최종 선별 결과 (Top-{top_k}, LLM 비활성화)"
        )

    report_lines = []
    report_lines.append("# pages 정답")
    report_lines.append(f"## {step_1_desc}")
    report_lines.append(
        f"1단계: {pages_results['step_1']} / {total} | {pages_results['step_1'] / total * 100:.2f}%"
    )
    if request.step >= 2:
        report_lines.append(f"## {step_2_desc}")
        report_lines.append(
            f"2단계: {pages_results['step_2']} / {total} | {pages_results['step_2'] / total * 100:.2f}%"
        )
    if request.step >= 3:
        report_lines.append(f"## {step_3_desc}")
        report_lines.append(
            f"3단계: {pages_results['step_3']} / {total} | {pages_results['step_3'] / total * 100:.2f}%"
        )

    report_lines.append("")
    report_lines.append("# pages_new 정답")
    report_lines.append(f"## {step_1_desc}")
    report_lines.append(
        f"1단계: {pages_new_results['step_1']} / {total} | {pages_new_results['step_1'] / total * 100:.2f}%"
    )
    if request.step >= 2:
        report_lines.append(f"## {step_2_desc}")
        report_lines.append(
            f"2단계: {pages_new_results['step_2']} / {total} | {pages_new_results['step_2'] / total * 100:.2f}%"
        )
    if request.step >= 3:
        report_lines.append(f"## {step_3_desc}")
        report_lines.append(
            f"3단계: {pages_new_results['step_3']} / {total} | {pages_new_results['step_3'] / total * 100:.2f}%"
        )

    report_text = "\n".join(report_lines)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_output_path = results_dir / f"eval_report_{timestamp}.txt"
    json_output_path = results_dir / f"eval_details_{timestamp}.json"

    with open(report_output_path, "w", encoding="utf-8") as f:
        f.write(report_text)

    summary_data = {"pages": pages_results, "pages_new": pages_new_results}
    with open(json_output_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "summary": summary_data,
                "details": detailed_results,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    return EvaluateResponse(
        summary=summary_data,
        report=report_text,
        details=detailed_results,
        report_file=str(report_output_path.relative_to(project_root)),
        details_file=str(json_output_path.relative_to(project_root)),
    )
