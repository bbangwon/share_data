import httpx
from fastapi import APIRouter, Response, status

from app.config import settings
from app.core.database import is_neo4j_online, is_qdrant_online

router = APIRouter()


async def check_api_server_health(base_url: str) -> bool:
    """일반 API 서버(Rerank, Embed 등)의 헬스체크 수행"""
    try:
        url = f"{base_url.rstrip('/')}/health"
        async with httpx.AsyncClient(timeout=3.0) as client:
            res = await client.get(url)
            return res.status_code == 200
    except Exception:
        pass
    return False


async def check_reasoning_selector_status() -> str:
    """
    Reasoning Selector WAS의 상태체크 수행 (healthy/offline)
    상대 서버의 /health API 버그 대응을 위해 실제 사용되는 /evaluate-simple-nuclear에
    가벼운 더미 핑(POST) 요청을 보내 기동 상태를 검증합니다.
    """
    try:
        url = (
            f"{settings.REASONING_SELECTOR_API_URL.rstrip('/')}/evaluate-simple-nuclear"
        )
        payload = {
            "query": "정상 동작 확인",
            "chunks": [{"content": "정상", "filename": "정상", "score": 1.0}],
        }
        async with httpx.AsyncClient(timeout=5.0) as client:
            res = await client.post(url, json=payload)
            if res.status_code == 200:
                return "healthy"
    except Exception:
        pass
    return "offline"


@router.get(
    "/health",
    summary="서버 및 외부 DB 헬스 체크",
    description="FastAPI 서버 상태 및 Qdrant, Neo4j, Reranker, Embedding, Reasoning Selector 외부 서비스와의 연결성을 동적으로 모니터링합니다.",
)
async def health_check(response: Response):
    qdrant_ok = await is_qdrant_online()
    neo4j_ok = is_neo4j_online()
    rerank_ok = await check_api_server_health(settings.RERANK_API_URL)
    embed_ok = await check_api_server_health(settings.EMBEDDING_API_URL)
    reasoning_status = await check_reasoning_selector_status()

    # 핵심 데이터 저장소 및 핵심 AI 모델 서비스가 모두 온라인이어야 전체 정상 작동 가능
    overall_healthy = qdrant_ok and neo4j_ok and rerank_ok and embed_ok
    if not overall_healthy:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE

    status_str = "healthy"
    if not overall_healthy:
        status_str = "unhealthy"
    elif reasoning_status != "healthy":
        status_str = "degraded"  # 핵심 서비스는 온전하나 보조 기능(LLM 평가) 장애 상황

    return {
        "status": status_str,
        "services": {
            "fastapi": "online",
            "qdrant": "online" if qdrant_ok else "offline",
            "neo4j": "online" if neo4j_ok else "offline",
            "embedding": "online" if embed_ok else "offline",
            "reranker": "online" if rerank_ok else "offline",
            "reasoning_selector": reasoning_status,
        },
    }
