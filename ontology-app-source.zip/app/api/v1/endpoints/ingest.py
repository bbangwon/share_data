import os
import logging
import uuid
from datetime import datetime
from fastapi import APIRouter, HTTPException, status, BackgroundTasks
from app.schemas.ingest import IngestRequest, IngestTaskStatus
from app.core.ingest_pipeline import run_ingest_pipeline, INGEST_TASKS

logger = logging.getLogger("graphrag_ingest_api")
router = APIRouter()

@router.post(
    "/ingest",
    status_code=status.HTTP_202_ACCEPTED,
    summary="원전안전 매뉴얼 데이터 가공 및 DB 적재 기동",
    description="원본 JSON 매뉴얼 데이터의 계층 구조 전처리를 수행하고 중간 JSON 파일을 생성한 뒤, Qdrant/Neo4j에 데이터 적재 작업을 백그라운드 태스크로 구동합니다."
)
async def trigger_ingest(request: IngestRequest, background_tasks: BackgroundTasks):
    # 고유 작업 Task ID 생성
    task_id = f"ingest-job-{uuid.uuid4().hex[:8]}"
    
    # input_file 에 경로 정보가 없으면 기본 디렉토리(data/raw_json/) 결합
    target_input_file = request.input_file
    if not os.path.dirname(target_input_file):
        target_input_file = os.path.join("data/raw_json", target_input_file)
        
    # output_file 이 지정되지 않은 경우 datetime 기반으로 자동 생성
    if not request.output_file:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target_output_file = f"data/preprocessed/graph_rag_inputs_{timestamp}.json"
    else:
        target_output_file = request.output_file
        # output_file 에 경로 정보가 없으면 기본 디렉토리(data/preprocessed/) 결합
        if not os.path.dirname(target_output_file):
            target_output_file = os.path.join("data/preprocessed", target_output_file)
        
    # 태스크 초기 상태 등록
    INGEST_TASKS[task_id] = {
        "task_id": task_id,
        "status": "pending",
        "progress": "0%",
        "message": f"백그라운드 적재 작업 대기 중... 결과 파일: {target_output_file}",
        "results": None,
        "error": None
    }
    
    logger.info(f"Triggering background ingestion task '{task_id}' for input: '{target_input_file}' -> output: '{target_output_file}'")
    
    # 백그라운드 태스크 등록
    background_tasks.add_task(
        run_ingest_pipeline, 
        task_id=task_id, 
        input_file=target_input_file, 
        output_file=target_output_file
    )
    
    return {
        "task_id": task_id,
        "status": "processing",
        "output_file": target_output_file,
        "message": "인제스트 파이프라인이 성공적으로 가동되었습니다."
    }

@router.get(
    "/ingest/status/{task_id}",
    response_model=IngestTaskStatus,
    status_code=status.HTTP_200_OK,
    summary="인제스트 작업 진행 상태 및 결과 조회",
    description="지정한 task_id에 대한 전처리 및 적재 상태(pending, processing, completed, failed) 및 적재 통계 결과를 확인합니다."
)
async def get_ingest_status(task_id: str):
    if task_id not in INGEST_TASKS:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"해당 Task ID '{task_id}'를 찾을 수 없습니다."
        )
    return INGEST_TASKS[task_id]

@router.get(
    "/ingest",
    response_model=list[IngestTaskStatus],
    status_code=status.HTTP_200_OK,
    summary="모든 인제스트 작업 목록 및 상태 조회",
    description="서버 메모리에 관리되고 있는 모든 백그라운드 인제스트 작업 목록을 한눈에 조회합니다."
)
async def list_ingest_tasks():
    return list(INGEST_TASKS.values())
