import logging
import time
import json
import hashlib
from datetime import datetime
from pathlib import Path
from fastapi import APIRouter, HTTPException, status
from langchain_core.prompts import load_prompt
from app.schemas.search import SearchRequest, SearchResponse
from app.graph.workflow import create_search_graph
from app.core.database import is_neo4j_online
from app.config import settings

logger = logging.getLogger("graphrag_search_api")
router = APIRouter()

# 컴파일된 LangGraph 인스턴스 로드
search_graph = create_search_graph()

# 프롬프트 템플릿 로드 (절대경로 확인)
PROMPT_PATH = Path(__file__).parent.parent.parent.parent / "prompts" / "answer_graph_generation.yaml"
PROMPT_TEMPLATE = load_prompt(str(PROMPT_PATH))

NO_GRAPH_PROMPT_PATH = Path(__file__).parent.parent.parent.parent / "prompts" / "answer_no_graph_generation.yaml"
NO_GRAPH_PROMPT_TEMPLATE = load_prompt(str(NO_GRAPH_PROMPT_PATH))

def serialize_documents_to_xml(documents: list) -> str:
    xml_lines = ["<sources>"]
    for idx, doc in enumerate(documents, start=1):
        c_id = doc.get("child_chunk_id") or doc.get("node_id") or "N/A"
        body = doc.get("body_content") or ""
        
        parent_pages = doc.get("parent_pages") or []
        if parent_pages:
            page_str = ", ".join(str(p) for p in parent_pages)
        else:
            page = doc.get("child_page") or doc.get("start_page")
            page_str = str(page) if page is not None else "1"
            
        filename = doc.get("filename") or "(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).pdf"
        
        parent_title = doc.get("parent_title")
        title = doc.get("title") or "N/A"
        if parent_title and "상위 정보 없음" not in parent_title:
            section_path = f"{parent_title} > {title}"
        else:
            section_path = title
            
        xml_lines.append(f'  <source index="{idx}" id="{c_id}">')
        xml_lines.append(f'    <reference>')
        xml_lines.append(f'      <filename>{filename}</filename>')
        xml_lines.append(f'      <page>{page_str}</page>')
        xml_lines.append(f'    </reference>')
        xml_lines.append(f'    <section_title>{title}</section_title>')
        xml_lines.append(f'    <section_path>{section_path}</section_path>')
        xml_lines.append(f'    <context_text>{body}</context_text>')
        xml_lines.append(f'  </source>')
    xml_lines.append("</sources>")
    return "\n".join(xml_lines)

def save_search_trace(request: SearchRequest, final_state: dict, duration_ms: float, prompt_text: str):
    should_save = request.save_trace if request.save_trace is not None else settings.SAVE_SEARCH_TRACE
    if not should_save:
        return
    try:
        # Create traces directory if not exists
        trace_dir = Path(__file__).resolve().parent.parent.parent.parent.parent / "logs" / "traces"
        trace_dir.mkdir(parents=True, exist_ok=True)
        
        # Helper to serialize qdrant points
        def serialize_qdrant_points(points):
            serialized = []
            for hit in points or []:
                payload = getattr(hit, "payload", {}) or {}
                serialized.append({
                    "id": getattr(hit, "id", None) or payload.get("child_chunk_id"),
                    "score": getattr(hit, "score", 0.0),
                    "title": payload.get("title"),
                    "child_chunk_id": payload.get("child_chunk_id"),
                    "parent_chunk_id": payload.get("parent_chunk_id"),
                    "parent_chunk_text": payload.get("parent_chunk_text") or payload.get("text"),
                    "node_id": payload.get("node_id"),
                    "child_page": payload.get("child_page"),
                    "parent_pages": payload.get("parent_pages"),
                    "section_pages": payload.get("section_pages"),
                    "start_page": payload.get("child_page") or (payload.get("parent_pages")[0] if payload.get("parent_pages") else payload.get("start_page")),
                    "text_snippet": (payload.get("text") or "")[:150] + "..." if len(payload.get("text") or "") > 150 else payload.get("text")
                })
            return serialized

        # Serialize candidate chunks
        candidates = serialize_qdrant_points(final_state.get("qdrant_candidates", []) or [])
        dense_candidates = serialize_qdrant_points(final_state.get("dense_candidates", []) or [])
        sparse_candidates = serialize_qdrant_points(final_state.get("sparse_candidates", []) or [])
            
        # Serialize reranked chunks
        reranked = []
        for hit in final_state.get("reranked_chunks", []) or []:
            payload = getattr(hit, "payload", {}) or {}
            reranked.append({
                "id": getattr(hit, "id", None) or payload.get("child_chunk_id"),
                "rerank_score": getattr(hit, "score", 0.0),
                "title": payload.get("title"),
                "node_id": payload.get("node_id"),
                "child_page": payload.get("child_page"),
                "parent_pages": payload.get("parent_pages"),
                "section_pages": payload.get("section_pages"),
                "start_page": payload.get("child_page") or (payload.get("parent_pages")[0] if payload.get("parent_pages") else payload.get("start_page")),
                "parent_chunk_text": payload.get("parent_chunk_text") or payload.get("text"),
            })
            
        # Serialize final selected documents
        documents = []
        for doc in final_state.get("documents", []) or []:
            documents.append({
                "child_chunk_id": doc.get("child_chunk_id") or doc.get("node_id"),
                "node_id": doc.get("node_id"),
                "title": doc.get("title"),
                "score": doc.get("score"),
                "child_page": doc.get("child_page"),
                "parent_pages": doc.get("parent_pages"),
                "section_pages": doc.get("section_pages"),
                "start_page": doc.get("child_page") or (doc.get("parent_pages")[0] if doc.get("parent_pages") else doc.get("start_page")),
                "parent_title": doc.get("parent_title"),
                "parent_chunk_text": doc.get("body_content"),
                "children_count": len(doc.get("children", []) or []),
                "body_content_snippet": (doc.get("body_content") or "")[:150] + "..." if len(doc.get("body_content") or "") > 150 else doc.get("body_content")
            })
            
        # Compile trace dict
        query = request.query
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        query_hash = hashlib.md5(query.encode("utf-8")).hexdigest()[:8]
        trace_filename = f"trace_{timestamp}_{query_hash}.json"
        
        trace_data = {
            "timestamp": datetime.now().isoformat(),
            "query": query,
            "query_complete": final_state.get("query_complete") or request.query_complete,
            "search_queries": request.search_queries or [],
            "parameters": {
                "top_k": request.top_k,
                "threshold": request.threshold,
                "dense_limit": request.dense_limit,
                "sparse_limit": request.sparse_limit,
                "fusion_method": request.fusion_method,
                "rerank_limit": request.rerank_limit,
                "use_reasoning_selector": request.use_reasoning_selector,
                "use_synonym_search": request.use_synonym_search,
                "use_graph_expansion": request.use_graph_expansion,
                "synonym_term_limit": request.synonym_term_limit if request.synonym_term_limit is not None else settings.SYNONYM_TERM_LIMIT
            },
            "database_status": {
                "neo4j_online": final_state.get("neo4j_online", False)
            },
            "metrics": {
                "total_duration_ms": duration_ms,
                "candidate_count": len(candidates),
                "dense_candidate_count": len(dense_candidates),
                "sparse_candidate_count": len(sparse_candidates),
                "reranked_count": len(reranked),
                "final_document_count": len(documents)
            },
            "steps": {
                "step_1_candidates": {
                    "combined_candidates": candidates,
                    "dense_candidates": dense_candidates,
                    "sparse_candidates": sparse_candidates,
                    "glossary_detected_terms": final_state.get("detected_terms", []) or [],
                    "glossary_raw_synonym_candidates": final_state.get("raw_synonym_candidates", []) or [],
                    "glossary_pruned_synonym_candidates_top_30": final_state.get("pruned_synonym_candidates", []) or []
                },
                "step_2_reranked": reranked,
                "step_3_documents": documents,
                "step_4_final_prompt": prompt_text
            }
        }
        
        trace_filepath = trace_dir / trace_filename
        with open(trace_filepath, "w", encoding="utf-8") as f:
            json.dump(trace_data, f, ensure_ascii=False, indent=2)
            
        logger.info(f"Successfully saved execution trace to {trace_filepath}")
    except Exception as e:
        logger.error(f"Failed to save execution trace: {e}", exc_info=True)

@router.post(
    "/search",
    response_model=SearchResponse,
    response_model_exclude_none=True,
    status_code=status.HTTP_200_OK,
    summary="LangGraph 기반 계층형 GraphRAG 검색",
    description="Qdrant 하이브리드 검색, CrossEncoder Rerank 및 Neo4j 그래프 맥락 융합을 LangGraph 상태 전이로 수행합니다."
)
async def search_manual(request: SearchRequest):
    start_time = time.perf_counter()
    # Neo4j 온라인 상태 체크 (동적 conditional routing 제어용)
    neo4j_connected = is_neo4j_online()
    
    # Pydantic 스키마가 .env 기반 기본값 주입을 보장하므로 바로 사용 가능
    fusion_method = request.fusion_method.upper() if request.fusion_method else "RRF"
    if fusion_method not in ["RRF", "DBSF"]:
        fusion_method = "RRF"
        
    initial_state = {
        "query": request.query,
        "query_complete": request.query_complete,
        "search_queries": request.search_queries or [],
        "top_k": request.top_k,
        "threshold": request.threshold,
        "dense_limit": request.dense_limit,
        "sparse_limit": request.sparse_limit,
        "fusion_method": fusion_method,
        "rerank_limit": request.rerank_limit,
        "use_reranker": request.use_reranker,
        "use_reasoning_selector": request.use_reasoning_selector,
        "use_synonym_search": request.use_synonym_search,
        "use_graph_expansion": request.use_graph_expansion,
        "neo4j_online": neo4j_connected,
        "synonym_term_limit": request.synonym_term_limit if request.synonym_term_limit is not None else settings.SYNONYM_TERM_LIMIT
    }
    
    try:
        logger.info(f"Query: '{request.query}' | top_k: {request.top_k} | threshold: {request.threshold} | neo4j_online: {neo4j_connected}")
        
        # LangGraph 비동기 실행 (LLM 생성이 없으므로 END까지 실행)
        final_state = await search_graph.ainvoke(initial_state)
        
        # 실제 검색에 사용된 질의
        actual_query = final_state.get("query_complete") or final_state.get("query") or (request.query_complete if request.query_complete else request.query)
        
        # 검색 결과 문서
        documents = final_state.get("documents", [])
        
        # XML 형식의 참고자료 생성
        context_xml = serialize_documents_to_xml(documents)
        
        # use_graph_expansion 및 Neo4j 상태에 따라 프롬프트 템플릿 선택
        if neo4j_connected and request.use_graph_expansion:
            prompt_template = PROMPT_TEMPLATE
        else:
            prompt_template = NO_GRAPH_PROMPT_TEMPLATE

        # LLM 답변 생성용 컨텍스트 프롬프트 생성
        prompt_text = prompt_template.format(query=actual_query, context=context_xml)
        empty_prompt_template = getattr(prompt_template, "template", "")
        
        # 수행 속도 측정
        duration_ms = (time.perf_counter() - start_time) * 1000.0
        
        # 실행 단계 추적 로그 저장 (로컬 JSON)
        save_search_trace(request, final_state, duration_ms, prompt_text)
        
        if request.only_prompt:
            return SearchResponse(prompt=prompt_text)
        
        search_type = "combined" if (neo4j_connected and request.use_graph_expansion) else "hybrid"
        
        search_results = []
        for idx, doc in enumerate(documents, start=1):
            c_id = doc.get("child_chunk_id") or doc.get("node_id") or "N/A"
            body = doc.get("body_content") or ""
            
            parent_pages = doc.get("parent_pages") or []
            if not parent_pages:
                page = doc.get("child_page") or doc.get("start_page")
                page_list = [page] if page is not None else []
            else:
                page_list = parent_pages
            
            search_results.append({
                "rank": idx,
                "id": c_id,
                "filename": "(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).pdf",
                "page": page_list,
                "context_text": body
            })
            
        return SearchResponse(
            prompt=prompt_text,
            query=actual_query,
            search_type=search_type,
            search_result=search_results,
            empty_prompt=empty_prompt_template,
            total_duration_ms=duration_ms
        )
    except Exception as e:
        logger.error(f"Error during LangGraph invocation: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"LangGraph 실행 중 내부 오류가 발생했습니다: {str(e)}"
        )
