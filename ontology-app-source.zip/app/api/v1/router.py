from fastapi import APIRouter
from app.api.v1.endpoints import search, ingest, health, evaluate

api_router = APIRouter()

api_router.include_router(health.router, tags=["Health"])
api_router.include_router(search.router, tags=["Search"])
api_router.include_router(ingest.router, tags=["Ingest"])
api_router.include_router(evaluate.router, tags=["Evaluate"])
