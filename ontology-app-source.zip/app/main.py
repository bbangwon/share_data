import logging
import uvicorn
from fastapi import FastAPI
from fastapi.responses import RedirectResponse

from app.api.v1.router import api_router

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger("graphrag_search_api")

app = FastAPI(
    title="🌋 원전안전 GraphRAG 검색 엔진 API (LangGraph 기반)",
    description="이 API 서버는 사용자 질문에 대해 문서 매칭, Reranking, 그래프 계층 탐색을 수행하고, 결합된 검색 컨텍스트만 반환합니다.",
    version="1.0.0"
)

# v1 API 라우터 포함
app.include_router(api_router)

@app.get(
    "/",
    include_in_schema=False,
    summary="메인 페이지 (Swagger API 문서로 리다이렉션)"
)
async def root_redirect():
    return RedirectResponse(url="/docs")

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
