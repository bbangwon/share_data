from typing import List, Optional

from pydantic import BaseModel, Field

from app.config import settings


class SearchRequest(BaseModel):
    query: str = Field(
        ...,
        description="사용자 질문 또는 검색 키워드",
        examples=["이재민 구호소에 코로나 의심환자가 발생한 것 같은데 어떻게 하지?"],
    )
    query_complete: Optional[str] = Field(
        default=None,
        description="정제된 질의 원문 (이 값이 있으면 우선 검색에 사용)",
        examples=[
            "이재민 구호소에서 코로나19 의심 환자가 발생했을 때 어떻게 대처해야 하나요?"
        ],
    )
    search_queries: Optional[List[str]] = Field(
        default=[],
        description="추가 검색 쿼리 리스트",
        examples=[
            [
                "이재민 구호소 코로나19 대응 매뉴얼",
                "코로나19 의심 환자 발생 시 조치 절차",
                "이재민 구호소 방역 지침",
            ]
        ],
    )
    top_k: Optional[int] = Field(
        default=settings.DEFAULT_TOP_K,
        description="상위 검색 개수",
        examples=[settings.DEFAULT_TOP_K],
    )
    threshold: float = Field(
        default=settings.DEFAULT_THRESHOLD,
        description="유사도 점수 임계값",
        examples=[settings.DEFAULT_THRESHOLD],
    )
    dense_limit: Optional[int] = Field(
        default=settings.PREFETCH_DENSE_LIMIT,
        description="Dense prefetch 검색 개수",
        examples=[settings.PREFETCH_DENSE_LIMIT],
    )
    sparse_limit: Optional[int] = Field(
        default=settings.PREFETCH_SPARSE_LIMIT,
        description="Sparse prefetch 검색 개수",
        examples=[settings.PREFETCH_SPARSE_LIMIT],
    )
    fusion_method: Optional[str] = Field(
        default=settings.DEFAULT_FUSION_METHOD,
        description="결과 취합/융합 방식 (RRF 또는 DBSF)",
        examples=[settings.DEFAULT_FUSION_METHOD],
    )
    rerank_limit: Optional[int] = Field(
        default=settings.DEFAULT_RERANK_LIMIT,
        description="Rerank 매칭 후 보유할 상위 개수",
        examples=[settings.DEFAULT_RERANK_LIMIT],
    )
    use_reranker: Optional[bool] = Field(
        default=True,
        description="Reranker 사용 여부 (False 설정 시 1단계 결과가 그대로 2단계로 위임)",
        examples=[True],
    )
    use_reasoning_selector: Optional[bool] = Field(
        default=settings.DEFAULT_USE_REASONING_SELECTOR,
        description="Reasoning Selector 사용 여부",
        examples=[settings.DEFAULT_USE_REASONING_SELECTOR],
    )
    use_synonym_search: Optional[bool] = Field(
        default=settings.DEFAULT_USE_SYNONYM_SEARCH,
        description="동의어 사전 매칭 사용 여부",
        examples=[settings.DEFAULT_USE_SYNONYM_SEARCH],
    )
    use_graph_expansion: Optional[bool] = Field(
        default=settings.DEFAULT_USE_GRAPH_EXPANSION,
        description="Neo4j 그래프 확장(상하위 계층 맥락 융합) 사용 여부",
        examples=[settings.DEFAULT_USE_GRAPH_EXPANSION],
    )
    only_prompt: Optional[bool] = Field(
        default=True,
        description="응답값으로 prompt만 반환 여부",
        examples=[True],
    )
    save_trace: Optional[bool] = Field(
        default=None,
        description="실행 트레이스 로그 저장 여부 (None일 경우 settings.SAVE_SEARCH_TRACE 설정 적용)",
        examples=[None],
    )
    synonym_term_limit: Optional[int] = Field(
        default=None,
        description="동의어 단어당 최대 청크 선별 수 (None일 경우 settings.SYNONYM_TERM_LIMIT 적용)",
        examples=[None],
    )


class SiblingSectionInfo(BaseModel):
    node_id: str
    title: str
    body_content: str
    section_pages: Optional[List[int]] = None
    start_page: Optional[int] = None


class RerankedDocument(BaseModel):
    node_id: str
    level: int
    title: str
    body_content: str
    child_page: Optional[int] = None
    parent_pages: Optional[List[int]] = None
    section_pages: Optional[List[int]] = None
    start_page: Optional[int] = None
    score: float = Field(..., description="Reranker 매칭 점수")
    parent_node_id: Optional[str] = None
    parent_title: Optional[str] = None
    parent_body_content: Optional[str] = None
    parent_section_pages: Optional[List[int]] = None
    parent_start_page: Optional[int] = None
    children: List[SiblingSectionInfo] = Field(
        default=[], description="동일 부모 하위 시블링/자식 섹션 정보"
    )


class SearchResultItem(BaseModel):
    rank: int = Field(..., description="결과 순위")
    id: str = Field(..., description="청크 고유 ID (예: child:31:0)")
    filename: str = Field(..., description="원본 파일명")
    page: List[int] = Field(..., description="청크가 속한 페이지 번호 배열")
    context_text: str = Field(..., description="참고 청크 본문 텍스트")


class SearchResponse(BaseModel):
    prompt: str = Field(..., description="LLM 답변 생성용으로 조합된 컨텍스트 프롬프트 전문. 검색 결과가 XML 형식으로 포함")
    query: Optional[str] = Field(default=None, description="실제 검색에 사용된 질의")
    search_type: Optional[str] = Field(default=None, description="검색 방식 (hybrid, kg, query_graph, combined)")
    search_result: Optional[List[SearchResultItem]] = Field(default=None, description="검색 결과 청크 목록")
    empty_prompt: Optional[str] = Field(default=None, description="프롬프트 템플릿")
    total_duration_ms: Optional[float] = Field(default=None, description="전체 검색 시간 (단위: 밀리초)")
