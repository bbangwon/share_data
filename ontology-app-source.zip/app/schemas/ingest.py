from pydantic import BaseModel, Field
from typing import Optional, Dict, Any

class IngestRequest(BaseModel):
    input_file: str = Field(
        default="(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).json",
        description="전처리할 원본 JSON 파일명 (경로 미지정 시 data/raw_json/ 하위에서 자동 탐색)"
    )
    output_file: Optional[str] = Field(
        default=None,
        description="저장할 중간 전처리 결과물 JSON 파일명 (미지정 시 datetime 기반으로 자동 생성)"
    )

class IngestTaskStatus(BaseModel):
    task_id: str
    status: str = Field(..., description="현재 상태 (pending, processing, completed, failed)")
    progress: str = Field(default="0%", description="진행 진척도")
    message: Optional[str] = None
    results: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
