import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv(override=True)

class Settings:
    NEO4J_URI: str = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    NEO4J_USERNAME: str = os.getenv("NEO4J_USERNAME", "neo4j")
    NEO4J_PASSWORD: str = os.getenv("NEO4J_PASSWORD", "password123")
    
    QDRANT_HOST: str = os.getenv("QDRANT_HOST", "localhost")
    QDRANT_PORT: int = int(os.getenv("QDRANT_PORT", "6333"))
    QDRANT_COLLECTION_NAME: str = os.getenv("QDRANT_COLLECTION_NAME", "document_sections")
    
    EMBEDDING_MODEL_NAME: str = os.getenv("EMBEDDING_MODEL_NAME", "dragonkue/BGE-m3-ko")
    EMBEDDING_API_URL: str = os.getenv("EMBEDDING_API_URL", "http://localhost:8000")
    
    RERANK_MODEL_NAME: str = os.getenv("RERANK_MODEL_NAME", "dragonkue/bge-reranker-v2-m3-ko")
    RERANK_API_URL: str = os.getenv("RERANK_API_URL", "http://localhost:8000")
    
    REASONING_SELECTOR_API_URL: str = os.getenv("REASONING_SELECTOR_API_URL", "http://localhost:8010")
    
    DEFAULT_TOP_K: int = int(os.getenv("DEFAULT_TOP_K", "3"))
    PREFETCH_DENSE_LIMIT: int = int(os.getenv("PREFETCH_DENSE_LIMIT", "12"))
    PREFETCH_SPARSE_LIMIT: int = int(os.getenv("PREFETCH_SPARSE_LIMIT", "12"))
    DEFAULT_FUSION_METHOD: str = os.getenv("DEFAULT_FUSION_METHOD", "RRF")
    DEFAULT_THRESHOLD: float = float(os.getenv("DEFAULT_THRESHOLD", "0.3"))
    DEFAULT_RERANK_LIMIT: int = int(os.getenv("DEFAULT_RERANK_LIMIT", "30"))
    DEFAULT_USE_REASONING_SELECTOR: bool = os.getenv("DEFAULT_USE_REASONING_SELECTOR", "true").lower() == "true"
    DEFAULT_USE_SYNONYM_SEARCH: bool = os.getenv("DEFAULT_USE_SYNONYM_SEARCH", "true").lower() == "true"
    DEFAULT_USE_GRAPH_EXPANSION: bool = os.getenv("DEFAULT_USE_GRAPH_EXPANSION", "true").lower() == "true"
    SAVE_SEARCH_TRACE: bool = os.getenv("SAVE_SEARCH_TRACE", "false").lower() == "true"
    SYNONYM_TERM_LIMIT: int = int(os.getenv("SYNONYM_TERM_LIMIT", "50"))

settings = Settings()
