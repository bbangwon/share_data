from typing import Any, Dict, List, Optional, TypedDict


class SearchState(TypedDict):
    # 입력 검색 파라미터
    query: str
    query_complete: Optional[str]
    search_queries: List[str]
    top_k: int
    threshold: float
    dense_limit: int
    sparse_limit: int
    fusion_method: str
    rerank_limit: int
    use_reasoning_selector: bool
    use_synonym_search: bool
    use_graph_expansion: bool
    use_reranker: bool
    synonym_term_limit: Optional[int]

    # DB 상태 제어용 변수
    neo4j_online: bool

    # 노드 간 전달 임시 데이터
    qdrant_candidates: List[Any]
    reranked_chunks: List[Any]

    # 최종 결과 반환 데이터
    context_text: str
    documents: List[Dict[str, Any]]

    # 디버그/트레이스용 수집 데이터
    dense_candidates: Optional[List[Any]]
    sparse_candidates: Optional[List[Any]]
    detected_terms: Optional[List[str]]
    raw_synonym_candidates: Optional[List[Any]]
    pruned_synonym_candidates: Optional[List[Any]]
