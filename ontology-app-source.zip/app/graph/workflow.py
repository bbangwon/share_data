from langgraph.graph import StateGraph, END
from app.graph.state import SearchState
from app.graph.nodes import (
    retrieve_candidates,
    rerank_candidates,
    fetch_neo4j_context,
    fallback_payload_context,
    reasoning_selector,
    serialize_context
)

def route_by_neo4j(state: SearchState) -> str:
    """Neo4j 연결 상태 및 그래프 확장 사용 여부에 따라 분기 노드 지정"""
    if state.get("neo4j_online", False) and state.get("use_graph_expansion", True):
        return "fetch_neo4j_context"
    return "fallback_payload_context"

def create_search_graph():
    """검색 전용 LangGraph 컴파일 및 반환"""
    workflow = StateGraph(SearchState)
    
    # 1. 노드 추가
    workflow.add_node("retrieve_candidates", retrieve_candidates)
    workflow.add_node("rerank_candidates", rerank_candidates)
    workflow.add_node("fetch_neo4j_context", fetch_neo4j_context)
    workflow.add_node("fallback_payload_context", fallback_payload_context)
    workflow.add_node("reasoning_selector", reasoning_selector)
    workflow.add_node("serialize_context", serialize_context)
    
    # 2. 에지 구성
    workflow.set_entry_point("retrieve_candidates")
    workflow.add_edge("retrieve_candidates", "rerank_candidates")
    
    # 조건부 에지 구성 (Neo4j 온라인 체크 결과에 따름)
    workflow.add_conditional_edges(
        "rerank_candidates",
        route_by_neo4j,
        {
            "fetch_neo4j_context": "fetch_neo4j_context",
            "fallback_payload_context": "fallback_payload_context"
        }
    )
    
    # 그래프 확장 노드들이 완료되면 Reasoning Selector로 이동
    workflow.add_edge("fetch_neo4j_context", "reasoning_selector")
    workflow.add_edge("fallback_payload_context", "reasoning_selector")
    
    # Reasoning Selector 완료 후 마크다운 컨텍스트 직렬화
    workflow.add_edge("reasoning_selector", "serialize_context")
    workflow.add_edge("serialize_context", END)
    
    return workflow.compile()
