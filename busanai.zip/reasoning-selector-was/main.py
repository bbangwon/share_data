"""RAG 청크 평가기 FastAPI 애플리케이션 진입점"""

import uvicorn


def main():
    """uvicorn으로 FastAPI 애플리케이션 실행"""
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info",
    )


if __name__ == "__main__":
    main()
