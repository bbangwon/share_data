"""Pydantic Settings를 사용한 애플리케이션 설정"""

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """환경 변수에서 로드되는 애플리케이션 설정"""

    # Model 설정
    base_url: str = ""
    model: str = ""
    temperature: float = 0.0
    timeout: int = 60
    api_key: str = ""

    # Reasoning & Evaluation 설정
    enable_reasoning: bool = False  # reasoning 활성화 여부
    response_max_tokens: int = 4096  # reasoning 비활성화 시 응답 토큰 제한
    parent_text_max_length: int = (
        -1
    )  # 평가 시 parent_text 최대 길이 (-1로 설정하면 전체 사용)
    llm_max_concurrency: int = 8  # 요청 단위 LLM 동시 호출 제한
    health_check_timeout: int = 5  # /health LLM 체크 타임아웃(초)
    max_concurrent_requests: int = 3  # HTTP 요청 레벨 동시 처리 수
    max_queue_size: int = 10  # 최대 대기 요청 수 (초과 시 503 반환)

    # 점수 가중치 설정 (최종 점수 = original_score_weight * 원본점수 + llm_score_weight * LLM점수)
    original_score_weight: float = 0.1  # 원본 rerank 점수 가중치
    llm_score_weight: float = 0.9  # LLM 평가 점수 가중치

    # 애플리케이션 설정
    log_level: str = "INFO"
    log_dir: str = "./logs"
    log_backup_count: int = 7
    sqlite_db_path: str = "./data/doc_type_cache.db"
    sqlite_db_echo: bool = False

    app_title: str = "RAG Chunk Evaluator"
    app_version: str = "0.1.0"
    app_description: str = (
        "LLM-based relevance evaluation for RAG pipeline document chunks"
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    @field_validator("temperature")
    @classmethod
    def validate_temperature(cls, v: float) -> float:
        """온도 값이 유효한 범위(0.0~2.0)인지 검증"""
        if not 0.0 <= v <= 2.0:
            raise ValueError(f"temperature는 0.0에서 2.0 사이여야 합니다. 입력값: {v}")
        return v

    @field_validator(
        "timeout",
        "llm_max_concurrency",
        "health_check_timeout",
        "log_backup_count",
        "max_concurrent_requests",
        "max_queue_size",
    )
    @classmethod
    def validate_timeout(cls, v: int) -> int:
        """양수 정수 설정값 검증"""
        if v <= 0:
            raise ValueError(f"양수 값이어야 합니다. 입력값: {v}")
        return v

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """로그 레벨이 유효한 값인지 검증"""
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if v.upper() not in valid_levels:
            raise ValueError(
                f"log_level은 {valid_levels} 중 하나여야 합니다. 입력값: {v}"
            )
        return v.upper()

    @field_validator("original_score_weight", "llm_score_weight")
    @classmethod
    def validate_score_weight(cls, v: float) -> float:
        """점수 가중치가 0.0~1.0 범위인지 검증"""
        if not 0.0 <= v <= 1.0:
            raise ValueError(f"가중치는 0.0에서 1.0 사이여야 합니다. 입력값: {v}")
        return v

    def model_post_init(self, __context) -> None:
        """모델 초기화 후 가중치 합 검증"""
        weight_sum = self.original_score_weight + self.llm_score_weight
        if not 0.99 <= weight_sum <= 1.01:  # 부동소수점 오차 허용
            raise ValueError(
                f"original_score_weight + llm_score_weight는 1.0이어야 합니다. "
                f"현재: {self.original_score_weight} + {self.llm_score_weight} = {weight_sum}"
            )


# 전역 설정 인스턴스
settings = Settings()
