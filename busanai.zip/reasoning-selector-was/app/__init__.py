"""RAG 청크 평가기 FastAPI 애플리케이션"""

__version__ = "0.1.0"
