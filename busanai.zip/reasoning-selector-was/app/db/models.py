"""SQLite 캐시를 위한 SQLAlchemy 모델 정의"""

from datetime import datetime

from sqlalchemy import DateTime, String, Text, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """모든 SQLAlchemy 모델의 베이스 클래스"""


class DocTypeCache(Base):
    """문서 유형 분류 결과 캐시 테이블"""

    __tablename__ = "doc_type_cache"

    filename: Mapped[str] = mapped_column(String(1024), primary_key=True)
    doc_type: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
