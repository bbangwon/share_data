"""문서 유형 캐시 저장소 계층"""

import logging
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import DocTypeCache

logger = logging.getLogger(__name__)


class DocTypeCacheRepository:
    """문서 유형 캐시 조회/저장을 담당하는 저장소"""

    def __init__(self, session_factory):
        self._session_factory = session_factory

    async def get_doc_type(self, filename: str) -> Optional[str]:
        """filename으로 캐시된 문서 유형을 조회합니다."""
        async for session in self._session_factory():
            return await self._get_doc_type_with_session(session, filename)
        return None

    async def upsert_doc_type(self, filename: str, doc_type: str) -> None:
        """filename 기준으로 문서 유형을 저장하거나 갱신합니다."""
        async for session in self._session_factory():
            await self._upsert_doc_type_with_session(session, filename, doc_type)
            return

    async def _get_doc_type_with_session(
        self,
        session: AsyncSession,
        filename: str,
    ) -> Optional[str]:
        stmt = select(DocTypeCache).where(DocTypeCache.filename == filename)
        result = await session.execute(stmt)
        record = result.scalar_one_or_none()
        if record is None:
            return None
        return record.doc_type

    async def _upsert_doc_type_with_session(
        self,
        session: AsyncSession,
        filename: str,
        doc_type: str,
    ) -> None:
        record = await session.get(DocTypeCache, filename)

        if record is None:
            session.add(DocTypeCache(filename=filename, doc_type=doc_type))
        else:
            record.doc_type = doc_type

        try:
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.warning(
                "문서 유형 캐시 저장 실패: filename='%s', error=%s",
                filename,
                e,
            )
            raise
