"""SQLite 비동기 세션 초기화 및 수명주기 관리"""

from pathlib import Path
from typing import AsyncGenerator, Optional

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.config import settings
from app.db.models import Base

_engine: Optional[AsyncEngine] = None
_session_maker: Optional[async_sessionmaker[AsyncSession]] = None


def _build_sqlite_url() -> str:
    db_path = Path(settings.sqlite_db_path).expanduser()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite+aiosqlite:///{db_path.as_posix()}"


async def init_db() -> None:
    """엔진/세션을 초기화하고 필요한 테이블을 생성합니다."""
    global _engine, _session_maker

    if _engine is not None:
        return

    _engine = create_async_engine(
        _build_sqlite_url(),
        echo=settings.sqlite_db_echo,
        future=True,
    )
    _session_maker = async_sessionmaker(
        bind=_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db() -> None:
    """애플리케이션 종료 시 DB 엔진을 정리합니다."""
    global _engine, _session_maker

    if _engine is not None:
        await _engine.dispose()

    _engine = None
    _session_maker = None


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """비동기 세션을 생성해 컨텍스트로 제공합니다."""
    if _session_maker is None:
        raise RuntimeError(
            "DB 세션이 초기화되지 않았습니다. init_db()를 먼저 호출하세요."
        )

    async with _session_maker() as session:
        yield session
