"""간단한 요청 포맷을 기존 평가기로 변환하는 어댑터"""

from app.models import (
    DocumentPayload,
    RetrievedDocument,
    SimpleChunk,
    SimpleEvaluationRequest,
    SimpleEvaluationResponse,
)
from app.services.llm_evaluator import LLMEvaluator


class SimpleEvaluationAdapter:
    """간단한 청크 포맷과 기존 평가 포맷 사이를 변환한다"""

    def __init__(self, evaluator: LLMEvaluator):
        self.evaluator = evaluator

    def _to_retrieved_document(
        self, chunk: SimpleChunk, index: int
    ) -> RetrievedDocument:
        payload = DocumentPayload(
            file=chunk.filename,
            page_num=0,
            group=None,
            title=chunk.title,
            parent_text=chunk.content,
            text=chunk.content,
            chunk_index=index,
            parent_id=None,
            parent_idx=index,
            parent_table_statuses=[],
            child_idx=0,
            child_table_statuses=[],
            dept=None,
            service=None,
            ner=False,
            summary=None,
            file_path=chunk.filename,
            boost_keywords=None,
            parent_chunk_length=len(chunk.content),
            child_chunk_length=len(chunk.content),
            file_index=None,
        )
        return RetrievedDocument(
            id=f"simple-chunk-{index}",
            score=chunk.score,
            payload=payload,
        )

    @staticmethod
    def _to_simple_chunk(document: RetrievedDocument) -> SimpleChunk:
        return SimpleChunk(
            content=document.payload.parent_text,
            filename=document.payload.file,
            title=document.payload.title,
            score=document.score,
        )

    async def evaluate(
        self, request: SimpleEvaluationRequest
    ) -> SimpleEvaluationResponse:
        documents = [
            self._to_retrieved_document(chunk, index)
            for index, chunk in enumerate(request.chunks)
        ]
        updated_documents = await self.evaluator.evaluate_documents(
            query=request.query,
            documents=documents,
        )
        return SimpleEvaluationResponse(
            query=request.query,
            chunks=[self._to_simple_chunk(document) for document in updated_documents],
        )

    async def evaluate_nuclear(
        self, request: SimpleEvaluationRequest
    ) -> SimpleEvaluationResponse:
        documents = [
            self._to_retrieved_document(chunk, index)
            for index, chunk in enumerate(request.chunks)
        ]
        updated_documents = await self.evaluator.evaluate_documents_nuclear(
            query=request.query,
            documents=documents,
        )
        return SimpleEvaluationResponse(
            query=request.query,
            chunks=[self._to_simple_chunk(document) for document in updated_documents],
        )

