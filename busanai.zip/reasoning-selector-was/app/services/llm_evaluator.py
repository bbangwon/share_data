"""LLM 기반 문서 청크 평가 서비스"""

import asyncio
import json
import logging
import time
from typing import Dict, List, Optional

from langchain_core.output_parsers import PydanticOutputParser
from langchain_openai import ChatOpenAI

from app.config import settings
from app.db import DocTypeCacheRepository
from app.models import (
    DocType,
    DocTypeClassification,
    QueryTypeClassification,
    RelevanceScore,
    RetrievedDocument,
)
from app.prompts import (
    doc_classifier_prompt,
    nuclear_prompt,
    nuclear_prompt_simple,
    query_classifier_prompt,
    scorer_prompt,
    scorer_prompt_simple,
)

logger = logging.getLogger(__name__)


class LLMEvaluator:
    """LLM을 사용하여 문서 청크의 연관성을 평가하는 클래스"""

    def __init__(self, doc_type_cache_repo: Optional[DocTypeCacheRepository] = None):
        """ChatOpenAI와 LCEL 체인으로 LLM 평가기를 초기화합니다"""
        self.doc_type_cache_repo = doc_type_cache_repo

        # reasoning 비활성화 시 max_tokens 제한으로 응답 속도 향상
        llm_kwargs = {
            "base_url": settings.base_url,
            "model": settings.model,
            "temperature": settings.temperature,
            "timeout": settings.timeout,
            "api_key": settings.api_key,
            "max_tokens": settings.response_max_tokens,
        }

        # gpt-oss 모델은 reasoning_effort를 low로 설정하여 빠른 응답을 유도
        if "gpt-oss" in settings.model:
            llm_kwargs["model_kwargs"] = {"reasoning_effort": "low"}

        self.llm = ChatOpenAI(**llm_kwargs)

        # 가장 단순한 JSON 모드 활성화
        constrained_llm = self.llm.bind(response_format={"type": "json_object"})

        self.parser = PydanticOutputParser(pydantic_object=RelevanceScore)

        # enable_reasoning에 따라 hierarchical 최종 점수 프롬프트만 선택
        score_prompt = (
            scorer_prompt if settings.enable_reasoning else scorer_prompt_simple
        )

        # 계층적 3단계 평가 체인
        self.query_classifier_parser = PydanticOutputParser(
            pydantic_object=QueryTypeClassification
        )
        self.doc_classifier_parser = PydanticOutputParser(
            pydantic_object=DocTypeClassification
        )

        self.query_classifier_chain = (
            query_classifier_prompt | constrained_llm | self.query_classifier_parser
        )
        self.doc_classifier_chain = (
            doc_classifier_prompt | constrained_llm | self.doc_classifier_parser
        )
        self.scorer_chain = score_prompt | constrained_llm | self.parser

        # 원자력 안전 분야 평가 체인
        nuclear_score_prompt = (
            nuclear_prompt if settings.enable_reasoning else nuclear_prompt_simple
        )
        self.nuclear_scorer_chain = nuclear_score_prompt | constrained_llm | self.parser

        logger.info(
            f"LLM 평가기 초기화 완료: model={settings.model}, "
            f"base_url={settings.base_url}, "
            f"enable_reasoning={settings.enable_reasoning}, "
            f"프롬프트={'상세' if settings.enable_reasoning else '간소화'}"
        )

    async def _run_evaluation_chain(
        self,
        chain,
        input_data: dict,
        original_score: float,
        evaluation_type: str,
    ) -> float:
        """
        LLM 평가 체인을 실행하고 에러를 처리하는 내부 메서드.

        Args:
            chain: 실행할 LCEL 체인
            input_data: 체인에 전달할 입력 데이터
            original_score: 오류 시 폴백할 원본 점수
            evaluation_type: 평가 유형 (예: "청크", "파일명")

        Returns:
            평가 점수 (0.0-1.0)
        """
        start_time = time.time()

        # DEBUG 레벨: 요청 payload 로깅 (parent_text는 길이 제한)
        debug_input = input_data.copy()
        if "parent_text" in debug_input and len(debug_input["parent_text"]) > 200:
            debug_input["parent_text"] = debug_input["parent_text"][:200] + "...(생략)"
        logger.debug(
            f"[{evaluation_type}] LLM 요청 payload: {json.dumps(debug_input, ensure_ascii=False, indent=2)}"
        )

        try:
            result: RelevanceScore = await chain.ainvoke(input_data)
            elapsed_time = time.time() - start_time

            # DEBUG 레벨: 응답 payload 로깅
            logger.debug(
                f"[{evaluation_type}] LLM 응답 payload: {json.dumps(result.model_dump(), ensure_ascii=False, indent=2)}"
            )

            reasoning_text = result.reasoning if result.reasoning else "(없음)"
            logger.info(
                f"{evaluation_type} 평가 완료: "
                f"score={result.score:.3f}, "
                f"reasoning='{reasoning_text}', "
                f"소요시간={elapsed_time:.2f}초"
            )

            return result.score

        except json.JSONDecodeError as e:
            logger.error(
                f"{evaluation_type} 평가 - JSON 파싱 오류: {e}. "
                f"원본 점수 유지={original_score:.3f}"
            )
            return original_score

        except Exception as e:
            logger.error(
                f"{evaluation_type} 평가 실패: {type(e).__name__}: {e}. "
                f"원본 점수 유지={original_score:.3f}"
            )
            return original_score

    async def evaluate_hierarchical(
        self,
        query: str,
        filename: str,
        parent_text: str,
        original_score: float,
        query_type_result: Optional[QueryTypeClassification] = None,
        doc_type_result: Optional[DocTypeClassification] = None,
    ) -> float:
        """
        3단계 계층적 평가를 수행합니다.
        1단계: 질의 유형 분류 (규정형/운영형)
        2단계: 문서 유형 분류 (9가지 중 하나)
        3단계: 최종 점수 계산 (0~1)

        Args:
            query: 사용자의 질문
            filename: 문서 파일 이름
            parent_text: 상위 컨텍스트 텍스트
            original_score: 원본 rerank 점수 (오류 시 폴백)

        Returns:
            업데이트된 연관성 점수 (0.0-1.0)
        """
        start_time = time.time()

        try:
            # 1단계: 질의 유형 분류
            if query_type_result is None:
                step1_input = {"query": query}
                logger.debug(
                    f"[1단계] 질의 유형 분류 - 요청 payload: {json.dumps(step1_input, ensure_ascii=False, indent=2)}"
                )
                query_type_result = await self.query_classifier_chain.ainvoke(
                    step1_input
                )
                logger.debug(
                    f"[1단계] 질의 유형 분류 - 응답 payload: {json.dumps(query_type_result.model_dump(), ensure_ascii=False, indent=2)}"
                )

            query_type = query_type_result.query_type
            logger.info(f"1단계 완료: 질의 유형 = {query_type.value}")

            # 2단계: 문서 유형 분류
            if doc_type_result is None:
                step2_input = {"filename": filename}
                logger.debug(
                    f"[2단계] 문서 유형 분류 - 요청 payload: {json.dumps(step2_input, ensure_ascii=False, indent=2)}"
                )
                doc_type_result = await self.doc_classifier_chain.ainvoke(step2_input)
                logger.debug(
                    f"[2단계] 문서 유형 분류 - 응답 payload: {json.dumps(doc_type_result.model_dump(), ensure_ascii=False, indent=2)}"
                )

            doc_type = doc_type_result.doc_type
            logger.info(f"2단계 완료: 문서 유형 = {doc_type.value}")

            # 3단계: 최종 점수 계산
            step3_input = {
                "query_type": query_type.value,
                "doc_type": doc_type.value,
                "query": query,
                "filename": filename,
                "parent_text": parent_text[: settings.parent_text_max_length],
            }
            # DEBUG 로깅 시 parent_text는 일부만 표시
            debug_step3_input = step3_input.copy()
            if len(debug_step3_input["parent_text"]) > 200:
                debug_step3_input["parent_text"] = (
                    debug_step3_input["parent_text"][:200] + "...(생략)"
                )
            logger.debug(
                f"[3단계] 최종 점수 계산 - 요청 payload: {json.dumps(debug_step3_input, ensure_ascii=False, indent=2)}"
            )
            score_result: RelevanceScore = await self.scorer_chain.ainvoke(step3_input)
            logger.debug(
                f"[3단계] 최종 점수 계산 - 응답 payload: {json.dumps(score_result.model_dump(), ensure_ascii=False, indent=2)}"
            )

            elapsed_time = time.time() - start_time
            reasoning_text = (
                score_result.reasoning if score_result.reasoning else "(없음)"
            )
            logger.info(
                f"3단계 계층적 평가 완료: "
                f"질의유형={query_type.value}, "
                f"문서유형={doc_type.value}, "
                f"score={score_result.score:.4f}, "
                f"reasoning='{reasoning_text}', "
                f"소요시간={elapsed_time:.2f}초"
            )

            return score_result.score

        except json.JSONDecodeError as e:
            logger.error(
                f"3단계 평가 - JSON 파싱 오류: {e}. 원본 점수 유지={original_score:.3f}"
            )
            return original_score

        except Exception as e:
            logger.error(
                f"3단계 평가 실패: {type(e).__name__}: {e}. "
                f"원본 점수 유지={original_score:.3f}"
            )
            return original_score

    async def evaluate_documents(
        self,
        query: str,
        documents: List[RetrievedDocument],
    ) -> List[RetrievedDocument]:
        """
        검색된 모든 문서를 비동기 병렬로 평가합니다.
        hierarchical 평가 방식으로 모든 문서를 비동기 병렬 평가합니다.

        Args:
            query: 사용자의 질문
            documents: rerank 점수가 포함된 검색된 문서 목록

        Returns:
            LLM 기반으로 업데이트된 점수를 가진 문서 목록
        """
        total_start_time = time.time()
        updated_documents: List[RetrievedDocument] = []
        semaphore = asyncio.Semaphore(settings.llm_max_concurrency)

        logger.info(
            f"{len(documents)}개 문서 평가 시작 - "
            f"질문: '{query}', reasoning: {settings.enable_reasoning}"
        )

        async def _run_with_limit(coro):
            async with semaphore:
                return await coro

        def _weighted_score(original_score: float, llm_score: float) -> float:
            return (
                settings.original_score_weight * original_score
                + settings.llm_score_weight * llm_score
            )

        query_type_cache: Dict[str, QueryTypeClassification] = {}
        query_type_inflight: Dict[str, asyncio.Task] = {}
        doc_type_cache: Dict[str, DocTypeClassification] = {}
        doc_type_inflight: Dict[str, asyncio.Task] = {}
        query_type_lock = asyncio.Lock()
        doc_type_lock = asyncio.Lock()
        doc_type_db_hit = 0
        doc_type_db_miss = 0
        doc_type_db_error = 0
        doc_type_llm_fallback = 0

        async def _get_query_type_cached() -> Optional[QueryTypeClassification]:
            async with query_type_lock:
                if query in query_type_cache:
                    cached = query_type_cache[query]
                    logger.debug(
                        f"[1단계] 질의 유형 분류 - 캐시 히트: query='{query}', query_type={cached.query_type.value}"
                    )
                    return cached

                task = query_type_inflight.get(query)
                if task is None:
                    task = asyncio.create_task(
                        _run_with_limit(
                            self.query_classifier_chain.ainvoke({"query": query})
                        )
                    )
                    query_type_inflight[query] = task

            try:
                result = await task
                logger.debug(
                    f"[1단계] 질의 유형 분류 - 응답 payload: {json.dumps(result.model_dump(), ensure_ascii=False, indent=2)}"
                )
            except Exception as e:
                logger.error(
                    f"[1단계] 질의 유형 분류 실패: {type(e).__name__}: {e}. 원본 점수 유지"
                )
                async with query_type_lock:
                    query_type_inflight.pop(query, None)
                return None

            async with query_type_lock:
                query_type_cache[query] = result
                query_type_inflight.pop(query, None)

            return result

        async def _get_doc_type_cached(
            filename: str,
        ) -> Optional[DocTypeClassification]:
            nonlocal doc_type_db_hit
            nonlocal doc_type_db_miss
            nonlocal doc_type_db_error
            nonlocal doc_type_llm_fallback

            async with doc_type_lock:
                if filename in doc_type_cache:
                    cached = doc_type_cache[filename]
                    logger.debug(
                        f"[2단계] 문서 유형 분류 - 캐시 히트: filename='{filename}', doc_type={cached.doc_type.value}"
                    )
                    return cached

                task = doc_type_inflight.get(filename)
            if task is not None:
                try:
                    result = await task
                    logger.debug(
                        f"[2단계] 문서 유형 분류 - in-flight 재사용: filename='{filename}', doc_type={result.doc_type.value}"
                    )
                    return result
                except Exception as e:
                    logger.error(
                        f"[2단계] 문서 유형 분류 실패(in-flight): filename='{filename}', {type(e).__name__}: {e}. 원본 점수 유지"
                    )
                    async with doc_type_lock:
                        doc_type_inflight.pop(filename, None)
                    return None

            if self.doc_type_cache_repo is not None:
                try:
                    cached_doc_type = await self.doc_type_cache_repo.get_doc_type(
                        filename
                    )
                    if cached_doc_type is not None:
                        db_cached_result = DocTypeClassification(
                            doc_type=DocType(cached_doc_type)
                        )
                        doc_type_db_hit += 1
                        logger.debug(
                            f"[2단계] 문서 유형 분류 - DB 캐시 히트: filename='{filename}', doc_type={db_cached_result.doc_type.value}"
                        )
                        async with doc_type_lock:
                            doc_type_cache[filename] = db_cached_result
                        return db_cached_result

                    doc_type_db_miss += 1
                    logger.debug(
                        f"[2단계] 문서 유형 분류 - DB 캐시 미스: filename='{filename}'"
                    )
                except ValueError as e:
                    doc_type_db_error += 1
                    logger.warning(
                        f"[2단계] 문서 유형 분류 - DB 캐시 값 파싱 실패: filename='{filename}', error={e}"
                    )
                except Exception as e:
                    doc_type_db_error += 1
                    logger.warning(
                        f"[2단계] 문서 유형 분류 - DB 캐시 조회 실패: filename='{filename}', {type(e).__name__}: {e}"
                    )

            async with doc_type_lock:
                task = doc_type_inflight.get(filename)
                if task is None:
                    task = asyncio.create_task(
                        _run_with_limit(
                            self.doc_classifier_chain.ainvoke({"filename": filename})
                        )
                    )
                    doc_type_inflight[filename] = task

            try:
                result = await task
                logger.debug(
                    f"[2단계] 문서 유형 분류 - 응답 payload: {json.dumps(result.model_dump(), ensure_ascii=False, indent=2)}"
                )
            except Exception as e:
                doc_type_llm_fallback += 1
                logger.error(
                    f"[2단계] 문서 유형 분류 실패: filename='{filename}', {type(e).__name__}: {e}. 원본 점수 유지"
                )
                async with doc_type_lock:
                    doc_type_inflight.pop(filename, None)
                return None

            if self.doc_type_cache_repo is not None:
                try:
                    await self.doc_type_cache_repo.upsert_doc_type(
                        filename=filename,
                        doc_type=result.doc_type.value,
                    )
                except Exception:
                    doc_type_db_error += 1

            async with doc_type_lock:
                doc_type_cache[filename] = result
                doc_type_inflight.pop(filename, None)

            return result

        async def _evaluate_hier_doc(doc: RetrievedDocument) -> float:
            current_query_type = await _get_query_type_cached()
            if current_query_type is None:
                return doc.score

            current_doc_type = await _get_doc_type_cached(doc.payload.file)
            if current_doc_type is None:
                return doc.score

            return await _run_with_limit(
                self.evaluate_hierarchical(
                    query=query,
                    filename=doc.payload.file,
                    parent_text=doc.payload.parent_text,
                    original_score=doc.score,
                    query_type_result=current_query_type,
                    doc_type_result=current_doc_type,
                )
            )

        llm_scores = await asyncio.gather(
            *(asyncio.create_task(_evaluate_hier_doc(doc)) for doc in documents)
        )

        for idx, (doc, new_score) in enumerate(
            zip(documents, llm_scores, strict=False), 1
        ):
            original_score = doc.score
            final_score = _weighted_score(original_score, new_score)
            updated_doc = doc.model_copy(update={"score": final_score})
            updated_documents.append(updated_doc)

            logger.debug(
                f"문서 {idx} 점수 업데이트: "
                f"원본={original_score:.3f}, LLM={new_score:.3f}, "
                f"최종={final_score:.3f} "
                f"(가중치: {settings.original_score_weight:.1f}/{settings.llm_score_weight:.1f})"
            )

        total_elapsed = time.time() - total_start_time
        logger.info(
            f"{len(documents)}개 문서 평가 완료 - "
            f"소요시간: {total_elapsed:.2f}초 "
            f"(평균: {total_elapsed / len(documents):.2f}초/문서)"
        )

        unique_filename_count = len(set(doc.payload.file for doc in documents))
        logger.info(
            "요청 단위 캐시 통계 - "
            f"hier_query_type={1 if documents else 0}, "
            f"hier_doc_type={unique_filename_count}, "
            f"doc_type_db_hit={doc_type_db_hit}, "
            f"doc_type_db_miss={doc_type_db_miss}, "
            f"doc_type_db_error={doc_type_db_error}, "
            f"doc_type_llm_fallback={doc_type_llm_fallback}"
        )

        return updated_documents

    async def evaluate_documents_nuclear(
        self,
        query: str,
        documents: List[RetrievedDocument],
    ) -> List[RetrievedDocument]:
        """
        원자력 안전 분야용 프롬프트로 검색된 문서들을 비동기 병렬 평가합니다.

        Args:
            query: 사용자의 질문
            documents: 평가할 문서 청크 목록

        Returns:
            최종 점수가 업데이트된 문서 목록 (순서 보존)
        """
        total_start_time = time.time()
        updated_documents: List[RetrievedDocument] = []
        semaphore = asyncio.Semaphore(settings.llm_max_concurrency)

        logger.info(
            f"[원자력 평가] {len(documents)}개 청크 평가 시작 - "
            f"질문: '{query}', reasoning: {settings.enable_reasoning}"
        )

        async def _run_with_limit(coro):
            async with semaphore:
                return await coro

        def _weighted_score(original_score: float, llm_score: float) -> float:
            return (
                settings.original_score_weight * original_score
                + settings.llm_score_weight * llm_score
            )

        async def _evaluate_single(doc: RetrievedDocument) -> float:
            # evaluate_reasoning_selector.py처럼 content의 앞부분 300글자만 사용하도록 자름
            truncated_content = doc.payload.parent_text[:300]

            input_data = {
                "query": query,
                "filename": doc.payload.file,
                "title": doc.payload.title if doc.payload.title is not None else "N/A",
                "content": truncated_content,
            }

            return await _run_with_limit(
                self._run_evaluation_chain(
                    chain=self.nuclear_scorer_chain,
                    input_data=input_data,
                    original_score=doc.score,
                    evaluation_type="원자력 청크",
                )
            )

        llm_scores = await asyncio.gather(
            *(asyncio.create_task(_evaluate_single(doc)) for doc in documents)
        )

        for doc, new_score in zip(documents, llm_scores, strict=False):
            original_score = doc.score
            final_score = _weighted_score(original_score, new_score)
            updated_doc = doc.model_copy(update={"score": final_score})
            updated_documents.append(updated_doc)

        total_elapsed = time.time() - total_start_time
        logger.info(
            f"[원자력 평가] {len(documents)}개 청크 평가 완료 - "
            f"소요시간: {total_elapsed:.2f}초 "
            f"(평균: {total_elapsed / len(documents):.2f}초/청크)"
        )

        return updated_documents

