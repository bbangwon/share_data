"""요청/응답 검증을 위한 Pydantic 모델"""

from enum import Enum
from typing import List, Optional, Union

from pydantic import BaseModel, Field, field_validator


class QueryType(str, Enum):
    """질의 유형"""

    REGULATION = "규정형"
    OPERATION = "운영형"


class DocType(str, Enum):
    """문서 유형"""

    REGULATION_GENERAL = "규정_일반"
    REGULATION_SPECIFIC = "규정_특정"
    ORDINANCE = "조례"
    PLAN = "계획"
    REGULATION_GUIDELINE = "규정_지침"
    OPERATION_GUIDELINE = "운영_지침"
    MANUAL = "매뉴얼"
    OFFICIAL_DOCUMENT = "공문"
    STATUTE = "법령"


class DocumentPayload(BaseModel):
    """메타데이터와 컨텐츠를 포함하는 문서 페이로드"""

    file: str
    page_num: int
    group: Optional[str] = None
    title: Optional[str] = None
    parent_text: str
    text: str
    chunk_index: int
    parent_id: Optional[str] = None
    parent_idx: int
    parent_table_statuses: List[int]
    child_idx: int
    child_table_statuses: List[int]
    dept: Optional[str] = None
    service: Optional[List[str]] = None
    ner: bool
    summary: Optional[str] = None
    file_path: str
    boost_keywords: Optional[str] = None
    parent_chunk_length: int
    child_chunk_length: int
    file_index: Optional[Union[str, int]] = None


class RetrievedDocument(BaseModel):
    """점수와 페이로드를 포함하는 검색된 문서"""

    id: str
    score: float = Field(
        ..., ge=0.0, le=1.0, description="0.0에서 1.0 사이의 연관성 점수"
    )
    payload: DocumentPayload


class EvaluationRequest(BaseModel):
    """청크 평가를 위한 요청 모델"""

    query: str = Field(..., min_length=1, description="사용자의 질문")
    retrieved_documents: List[RetrievedDocument] = Field(
        ...,
        min_items=1,
        max_items=100,
        description="RAG+Rerank 파이프라인에서 검색된 문서 목록",
    )

    @field_validator("query")
    @classmethod
    def validate_query(cls, v: str) -> str:
        """쿼리 문자열 검증"""
        if not v.strip():
            raise ValueError("질문은 공백만으로 이루어질 수 없습니다")
        return v.strip()


class EvaluationResponse(BaseModel):
    """업데이트된 점수를 포함하는 응답 모델"""

    query: str
    retrieved_documents: List[RetrievedDocument]


class SimpleChunk(BaseModel):
    """간단한 청크 평가용 요청/응답 단위"""

    content: str = Field(..., min_length=1, description="평가할 청크 본문")
    filename: str = Field(..., min_length=1, description="문서 파일명")
    title: Optional[str] = Field(None, description="섹션 타이틀 (Title)")
    score: float = Field(
        ..., ge=0.0, le=1.0, description="0.0에서 1.0 사이의 원본 연관성 점수"
    )

    @field_validator("content", "filename")
    @classmethod
    def validate_text_fields(cls, value: str) -> str:
        """문자열 필드 검증"""
        if not value.strip():
            raise ValueError("문자열 필드는 공백만으로 이루어질 수 없습니다")
        return value.strip()

    @field_validator("title")
    @classmethod
    def validate_title(cls, value: Optional[str]) -> Optional[str]:
        """타이틀 필드 검증"""
        if value is not None and not value.strip():
            raise ValueError("타이틀 필드는 공백만으로 이루어질 수 없습니다")
        return value.strip() if value is not None else None


class SimpleEvaluationRequest(BaseModel):
    """간단한 청크 평가를 위한 요청 모델"""

    query: str = Field(..., min_length=1, description="사용자의 질문")
    chunks: List[SimpleChunk] = Field(
        ...,
        min_items=1,
        max_items=100,
        description="파일명, 본문, 점수만 포함한 간단한 청크 목록",
    )

    @field_validator("query")
    @classmethod
    def validate_query(cls, value: str) -> str:
        """쿼리 문자열 검증"""
        if not value.strip():
            raise ValueError("질문은 공백만으로 이루어질 수 없습니다")
        return value.strip()


class SimpleEvaluationResponse(BaseModel):
    """간단한 포맷의 평가 응답 모델"""

    query: str
    chunks: List[SimpleChunk]


class RelevanceScore(BaseModel):
    """연관성 점수를 위한 LLM 출력 모델"""

    score: float = Field(
        ..., ge=0.0, le=1.0, description="0.0에서 1.0 사이의 연관성 점수"
    )
    reasoning: Optional[str] = Field(
        None, description="점수에 대한 간단한 설명 (enable_reasoning=false일 때 None)"
    )


class QueryTypeClassification(BaseModel):
    """질의 유형 분류 결과"""

    query_type: QueryType = Field(..., description="질의 유형 (규정형/운영형)")


class DocTypeClassification(BaseModel):
    """문서 유형 분류 결과"""

    doc_type: DocType = Field(..., description="문서 유형")


class HierarchicalScore(BaseModel):
    """3단계 계층적 평가 결과"""

    query_type: QueryType = Field(..., description="1단계: 질의 유형")
    doc_type: DocType = Field(..., description="2단계: 문서 유형")
    score: float = Field(..., ge=0.0, le=1.0, description="3단계: 최종 점수 (0.0~1.0)")
    reasoning: Optional[str] = Field(
        None, description="점수 부여 근거 (enable_reasoning=false일 때 None)"
    )
