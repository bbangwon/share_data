"""RAG 청크 평가를 위한 FastAPI 애플리케이션"""

import asyncio
import json
import logging
import logging.handlers
import os
from contextlib import asynccontextmanager
from typing import Awaitable, Callable, Optional, TypeVar

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.db import DocTypeCacheRepository, close_db, get_session, init_db
from app.models import (
    EvaluationRequest,
    EvaluationResponse,
    SimpleEvaluationRequest,
    SimpleEvaluationResponse,
)
from app.services import LLMEvaluator, SimpleEvaluationAdapter

ResponseModelT = TypeVar("ResponseModelT")

if not os.path.exists(settings.log_dir):
    os.makedirs(settings.log_dir)

log_file_path = os.path.join(settings.log_dir, "reasoning-selector-was.log")
logging.basicConfig(
    level=settings.log_level,
    format="[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s",
    handlers=[
        logging.StreamHandler(),  # 콘솔에 로그 출력
        logging.handlers.TimedRotatingFileHandler(
            log_file_path,
            when="midnight",  # 매일 자정에 로그 파일을 새로 만듭니다.
            interval=1,  # 1일마다 새 로그 파일 생성
            backupCount=settings.log_backup_count,  # 최대 7개의 백업 로그 파일 유지
            encoding="utf-8",
            utc=False,  # 로컬 시간 사용
        ),
    ],
)

logger = logging.getLogger(__name__)

# 전역 LLM 평가기 인스턴스
evaluator: Optional[LLMEvaluator] = None

# 요청 대기열 제어 변수
request_semaphore: Optional[asyncio.Semaphore] = None
waiting_count: int = 0
active_count: int = 0


async def _run_with_request_slot(
    operation: Callable[[], Awaitable[ResponseModelT]],
) -> ResponseModelT:
    """요청 대기열 제한을 적용하여 작업을 실행한다."""

    if request_semaphore is None:
        raise HTTPException(
            status_code=503, detail="요청 대기열이 초기화되지 않았습니다"
        )

    global waiting_count, active_count
    if waiting_count >= settings.max_queue_size:
        logger.warning(
            f"요청 대기열 초과. waiting={waiting_count}, active={active_count}, "
            f"max_queue={settings.max_queue_size}"
        )
        raise HTTPException(
            status_code=503,
            detail=(
                f"서버가 처리할 수 있는 요청 한도를 초과했습니다. 잠시 후 재시도해주세요. "
                f"(대기 중={waiting_count}, 처리 중={active_count})"
            ),
        )

    waiting_count += 1
    acquired = False
    try:
        await request_semaphore.acquire()
        acquired = True
    finally:
        if not acquired:
            waiting_count -= 1

    waiting_count -= 1
    active_count += 1
    try:
        return await operation()
    finally:
        active_count -= 1
        request_semaphore.release()


def _truncate_debug_text(value: str, max_length: int = 200) -> str:
    if len(value) <= max_length:
        return value
    return value[:max_length] + "...(생략)"


@asynccontextmanager
async def lifespan(app: FastAPI):
    """시작/종료 이벤트를 위한 Lifespan 컨텍스트 매니저"""
    # 시작
    global evaluator, request_semaphore
    logger.info("LLM 평가기 초기화 중...")
    try:
        await init_db()
        logger.info("SQLite 캐시 DB 초기화 완료")

        doc_type_cache_repo = DocTypeCacheRepository(get_session)
        evaluator = LLMEvaluator(doc_type_cache_repo=doc_type_cache_repo)
        logger.info(
            f"LLM 평가기 초기화 성공. "
            f"reasoning={settings.enable_reasoning}, "
            f"max_tokens={settings.response_max_tokens if not settings.enable_reasoning else 'unlimited'}"
        )
        request_semaphore = asyncio.Semaphore(settings.max_concurrent_requests)
        logger.info(
            f"요청 대기열 초기화 완료. "
            f"max_concurrent={settings.max_concurrent_requests}, "
            f"max_queue={settings.max_queue_size}"
        )
    except Exception as e:
        logger.error(f"LLM 평가기 초기화 실패: {e}")
        raise

    yield

    # 종료
    await close_db()
    logger.info("애플리케이션 종료 중...")


# FastAPI 앱 생성
app = FastAPI(
    title=settings.app_title,
    version=settings.app_version,
    description=settings.app_description,
    lifespan=lifespan,
)


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    # 빈 응답
    return Response(status_code=404)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health_check():
    """
    서비스 상태와 LLM 연결을 확인하는 헬스체크 엔드포인트.

    Returns:
        dict: LLM 연결 상태를 포함한 헬스 상태

    Raises:
        HTTPException: LLM 평가기가 초기화되지 않았을 경우
    """
    if evaluator is None:
        raise HTTPException(
            status_code=503, detail="LLM 평가기가 초기화되지 않았습니다"
        )

    try:
        # 간단한 호출로 LLM 연결 테스트
        _ = await asyncio.wait_for(
            evaluator.llm.ainvoke("test"), timeout=settings.health_check_timeout
        )
        llm_connected = True
    except Exception as e:
        logger.warning(f"LLM 헬스체크 실패: {e}")
        llm_connected = False

    return {
        "status": "healthy" if llm_connected else "degraded",
        "llm_connected": llm_connected,
        "model": settings.model,
        "base_url": settings.base_url,
        "queue": {
            "waiting": waiting_count,
            "active": active_count,
            "max_concurrent": settings.max_concurrent_requests,
            "max_queue": settings.max_queue_size,
        },
    }


@app.post("/evaluate", response_model=EvaluationResponse)
async def evaluate_chunks(request: EvaluationRequest):
    """
    LLM을 사용하여 쿼리에 대한 문서 청크의 연관성을 평가합니다.

    Args:
        request: 쿼리와 검색된 문서를 포함하는 EvaluationRequest

    Returns:
        EvaluationResponse: 업데이트된 연관성 점수가 포함된 동일한 구조

    Raises:
        HTTPException: 평가 실패 시 또는 LLM 평가기가 초기화되지 않았을 경우
    """
    if evaluator is None:
        raise HTTPException(
            status_code=503, detail="LLM 평가기가 초기화되지 않았습니다"
        )

    async def _evaluate() -> EvaluationResponse:
        logger.info(
            f"평가 요청 수신: query='{request.query}', "
            f"문서 수={len(request.retrieved_documents)}"
        )

        # DEBUG 레벨: 전체 요청 payload 로깅 (문서 내용은 간소화)
        if logger.isEnabledFor(logging.DEBUG):
            debug_request = request.model_dump()
            # 문서 내용이 길 수 있으므로 parent_text 길이 제한
            for doc in debug_request.get("retrieved_documents", []):
                if "payload" in doc and "parent_text" in doc["payload"]:
                    doc["payload"]["parent_text"] = _truncate_debug_text(
                        doc["payload"]["parent_text"]
                    )
            logger.debug(
                f"[API 요청] 전체 payload: {json.dumps(debug_request, ensure_ascii=False, indent=2)}"
            )

        # 모든 문서 평가
        updated_documents = await evaluator.evaluate_documents(
            query=request.query,
            documents=request.retrieved_documents,
        )

        # 응답 생성
        response = EvaluationResponse(
            query=request.query,
            retrieved_documents=updated_documents,
        )

        logger.info(f"{len(updated_documents)}개 문서에 대한 평가 완료")

        # DEBUG 레벨: 전체 응답 payload 로깅 (문서 내용은 간소화)
        if logger.isEnabledFor(logging.DEBUG):
            debug_response = response.model_dump()
            # 문서 내용이 길 수 있으므로 parent_text 길이 제한
            for doc in debug_response.get("retrieved_documents", []):
                if "payload" in doc and "parent_text" in doc["payload"]:
                    doc["payload"]["parent_text"] = _truncate_debug_text(
                        doc["payload"]["parent_text"]
                    )
            logger.debug(
                f"[API 응답] 전체 payload: {json.dumps(debug_response, ensure_ascii=False, indent=2)}"
            )

        return response

    try:
        return await _run_with_request_slot(_evaluate)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"평가 실패: {type(e).__name__}: {e}")
        raise HTTPException(status_code=500, detail=f"평가 실패: {str(e)}")


@app.post("/evaluate-simple", response_model=SimpleEvaluationResponse)
async def evaluate_simple_chunks(request: SimpleEvaluationRequest):
    """간단한 포맷의 청크 목록을 기존 평가기로 재평가한다."""
    if evaluator is None:
        raise HTTPException(
            status_code=503, detail="LLM 평가기가 초기화되지 않았습니다"
        )

    adapter = SimpleEvaluationAdapter(evaluator)

    async def _evaluate() -> SimpleEvaluationResponse:
        logger.info(
            f"간단 평가 요청 수신: query='{request.query}', "
            f"청크 수={len(request.chunks)}"
        )

        if logger.isEnabledFor(logging.DEBUG):
            debug_request = request.model_dump()
            for chunk in debug_request.get("chunks", []):
                if "content" in chunk:
                    chunk["content"] = _truncate_debug_text(chunk["content"])
            logger.debug(
                f"[Simple API 요청] 전체 payload: {json.dumps(debug_request, ensure_ascii=False, indent=2)}"
            )

        response = await adapter.evaluate(request)

        logger.info(f"{len(response.chunks)}개 청크에 대한 간단 평가 완료")

        if logger.isEnabledFor(logging.DEBUG):
            debug_response = response.model_dump()
            for chunk in debug_response.get("chunks", []):
                if "content" in chunk:
                    chunk["content"] = _truncate_debug_text(chunk["content"])
            logger.debug(
                f"[Simple API 응답] 전체 payload: {json.dumps(debug_response, ensure_ascii=False, indent=2)}"
            )

        return response

    try:
        return await _run_with_request_slot(_evaluate)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"간단 평가 실패: {type(e).__name__}: {e}")
        raise HTTPException(status_code=500, detail=f"간단 평가 실패: {str(e)}")


@app.post("/evaluate-simple-nuclear", response_model=SimpleEvaluationResponse)
async def evaluate_simple_nuclear_chunks(request: SimpleEvaluationRequest):
    """원자력 안전 분야 특화 프롬프트로 간단한 포맷의 청크 목록을 재평가한다."""
    if evaluator is None:
        raise HTTPException(
            status_code=503, detail="LLM 평가기가 초기화되지 않았습니다"
        )

    adapter = SimpleEvaluationAdapter(evaluator)

    async def _evaluate() -> SimpleEvaluationResponse:
        logger.info(
            f"원자력 간단 평가 요청 수신: query='{request.query}', "
            f"청크 수={len(request.chunks)}"
        )

        if logger.isEnabledFor(logging.DEBUG):
            debug_request = request.model_dump()
            for chunk in debug_request.get("chunks", []):
                if "content" in chunk:
                    chunk["content"] = _truncate_debug_text(chunk["content"])
            logger.debug(
                f"[Nuclear Simple API 요청] 전체 payload: {json.dumps(debug_request, ensure_ascii=False, indent=2)}"
            )

        response = await adapter.evaluate_nuclear(request)

        logger.info(f"{len(response.chunks)}개 청크에 대한 원자력 간단 평가 완료")

        if logger.isEnabledFor(logging.DEBUG):
            debug_response = response.model_dump()
            for chunk in debug_response.get("chunks", []):
                if "content" in chunk:
                    chunk["content"] = _truncate_debug_text(chunk["content"])
            logger.debug(
                f"[Nuclear Simple API 응답] 전체 payload: {json.dumps(debug_response, ensure_ascii=False, indent=2)}"
            )

        return response

    try:
        return await _run_with_request_slot(_evaluate)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"원자력 간단 평가 실패: {type(e).__name__}: {e}")
        raise HTTPException(status_code=500, detail=f"원자력 간단 평가 실패: {str(e)}")



@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """예기치 않은 오류를 위한 전역 예외 핸들러"""
    logger.error(f"처리되지 않은 예외: {type(exc).__name__}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "내부 서버 오류",
            "error_type": type(exc).__name__,
        },
    )
