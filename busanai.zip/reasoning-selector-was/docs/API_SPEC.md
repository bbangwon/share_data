# reasoning-selector-was API 규격서

## 1. 개요

- 서비스명: `reasoning-selector-was`
- 기본 목적: RAG 파이프라인에서 검색된 문서 청크의 연관성 점수를 LLM으로 재평가
- 기본 URL: `http://99.1.82.183:38080`
- 보조 URL: `http://99.1.82.184:38000`
- 콘텐츠 타입: `application/json`

## 2. 공통 사항

### 2.1 버전/메타

- App title: `RAG Chunk Evaluator`
- App version: `0.1.0`

### 2.2 CORS

- `allow_origins = ["*"]`
- `allow_methods = ["*"]`
- `allow_headers = ["*"]`

### 2.3 에러 응답 형식

#### FastAPI 기본 HTTPException 형식

```json
{
  "detail": "에러 메시지"
}
```

#### 전역 예외 핸들러 형식 (예기치 않은 오류)

```json
{
  "detail": "내부 서버 오류",
  "error_type": "ExceptionClassName"
}
```

### 2.4 상태 코드 요약

- `200 OK`: 정상 처리
- `422 Unprocessable Entity`: 요청 바디 검증 실패
- `500 Internal Server Error`: 서버 내부 오류
- `503 Service Unavailable`: 초기화 미완료 또는 큐 초과

## 3. API 목록

## 3.1 `GET /health`

서비스 상태와 LLM 연결 상태를 확인한다.

### 요청

- Method: `GET`
- Path: `/health`
- Body: 없음

### 응답 (`200`)

```json
{
  "status": "healthy",
  "llm_connected": true,
  "model": "gpt-oss:20b-cloud",
  "base_url": "https://example-llm-endpoint/v1",
  "queue": {
    "waiting": 0,
    "active": 0,
    "max_concurrent": 3,
    "max_queue": 10
  }
}
```

### 필드 설명

- `status`: `healthy` 또는 `degraded`
- `llm_connected`: 헬스체크 시점 LLM 호출 가능 여부
- `model`: 현재 설정된 모델명
- `base_url`: 현재 설정된 LLM base URL
- `queue.waiting`: 현재 대기 중인 요청 수
- `queue.active`: 현재 처리 중인 요청 수
- `queue.max_concurrent`: 동시 처리 제한
- `queue.max_queue`: 최대 대기열 제한

### 오류

- `503`: LLM 평가기 미초기화

---

## 3.2 `POST /evaluate`

질문(`query`)과 검색 문서 목록(`retrieved_documents`)을 입력받아 각 문서의 `score`를 재평가한다.

### 요청

- Method: `POST`
- Path: `/evaluate`
- Headers: `Content-Type: application/json`

### 요청 바디 스키마

```json
{
  "query": "질문 문자열",
  "retrieved_documents": [
    {
      "id": "문서 ID",
      "score": 0.92,
      "payload": {
        "file": "문서 파일명",
        "page_num": 1,
        "group": "내부자료",
        "parent_text": "상위 청크 본문",
        "text": "현재 청크 본문",
        "chunk_index": 10,
        "parent_id": "상위 청크 ID",
        "parent_idx": 2,
        "parent_table_statuses": [0],
        "child_idx": 1,
        "child_table_statuses": [0],
        "dept": "인사과",
        "service": ["복무"],
        "ner": false,
        "summary": "요약",
        "file_path": "/data/path/file.pdf",
        "boost_keywords": "휴직, 신청",
        "parent_chunk_length": 1200,
        "child_chunk_length": 320,
        "file_index": "12345"
      }
    }
  ]
}
```

### 요청 필드 상세

- `query`:
  - 타입: `string`
  - 필수
  - 제약: 공백만 입력 불가, 최소 길이 1

- `retrieved_documents`:
  - 타입: `array`
  - 필수
  - 제약: 최소 1개, 최대 100개

- `retrieved_documents[].id`:
  - 타입: `string`
  - 필수

- `retrieved_documents[].score`:
  - 타입: `number`
  - 필수
  - 제약: `0.0 <= score <= 1.0`

- `retrieved_documents[].payload`:
  - 타입: `object`
  - 필수

#### `payload` 필드

- 필수: `file`, `page_num`, `parent_text`, `text`, `chunk_index`, `parent_idx`, `parent_table_statuses`, `child_idx`, `child_table_statuses`, `ner`, `file_path`, `parent_chunk_length`, `child_chunk_length`
- 선택: `group`, `parent_id`, `dept`, `service`, `summary`, `boost_keywords`, `file_index`

`file_index`는 `string` 또는 `number`를 허용한다.

### 응답 (`200`)

요청과 동일한 구조를 반환하며, 각 문서의 `score`가 재평가 결과로 업데이트된다.

```json
{
  "query": "질문 문자열",
  "retrieved_documents": [
    {
      "id": "문서 ID",
      "score": 0.85,
      "payload": {
        "file": "문서 파일명",
        "page_num": 1,
        "group": "내부자료",
        "parent_text": "상위 청크 본문",
        "text": "현재 청크 본문",
        "chunk_index": 10,
        "parent_id": "상위 청크 ID",
        "parent_idx": 2,
        "parent_table_statuses": [0],
        "child_idx": 1,
        "child_table_statuses": [0],
        "dept": "인사과",
        "service": ["복무"],
        "ner": false,
        "summary": "요약",
        "file_path": "/data/path/file.pdf",
        "boost_keywords": "휴직, 신청",
        "parent_chunk_length": 1200,
        "child_chunk_length": 320,
        "file_index": "12345"
      }
    }
  ]
}
```

### 오류

- `422`: 요청 바디 검증 실패
- `503`: 아래 경우
  - LLM 평가기 미초기화
  - 요청 대기열 초과 (`max_queue_size`)
- `500`: 평가 중 내부 오류

### 동시성/큐 처리 규칙

- 서버는 요청 처리 시 다음 제한을 적용한다.
  - 동시 처리 제한: `max_concurrent_requests`
  - 대기열 제한: `max_queue_size`
- 대기열이 가득 차면 즉시 `503`을 반환한다.

---

## 3.3 `POST /evaluate-simple`

질문(`query`)과 간단한 청크 목록(`chunks`)을 입력받아 각 청크의 `score`를 재평가한다.

### 요청

- Method: `POST`
- Path: `/evaluate-simple`
- Headers: `Content-Type: application/json`

### 요청 바디 스키마

```json
{
  "query": "질문 문자열",
  "chunks": [
    {
      "content": "청크 본문",
      "filename": "문서 파일명",
      "score": 0.92
    }
  ]
}
```

### 요청 필드 상세

- `query`:
  - 타입: `string`
  - 필수
  - 제약: 공백만 입력 불가, 최소 길이 1

- `chunks`:
  - 타입: `array`
  - 필수
  - 제약: 최소 1개, 최대 100개

- `chunks[].content`:
  - 타입: `string`
  - 필수
  - 제약: 공백만 입력 불가

- `chunks[].filename`:
  - 타입: `string`
  - 필수
  - 제약: 공백만 입력 불가

- `chunks[].score`:
  - 타입: `number`
  - 필수
  - 제약: `0.0 <= score <= 1.0`

### 응답 (`200`)

요청과 동일한 구조를 반환하며, 각 청크의 `score`가 재평가 결과로 업데이트된다.

```json
{
  "query": "질문 문자열",
  "chunks": [
    {
      "content": "청크 본문",
      "filename": "문서 파일명",
      "score": 0.85
    }
  ]
}
```

### 처리 규칙

- `request`와 `response`의 포맷은 동일하다.
- `chunks`의 순서는 입력 순서를 그대로 유지한다.
- 내부적으로는 기존 `/evaluate`의 평가 엔진과 가중합 로직을 재사용한다.

### 오류

- `422`: 요청 바디 검증 실패
- `503`: 아래 경우
  - LLM 평가기 미초기화
  - 요청 대기열 초과 (`max_queue_size`)
- `500`: 평가 중 내부 오류

## 4. 예시 호출

### 4.1 헬스체크

```bash
curl -X GET "http://localhost:8000/health"
```

### 4.2 평가 요청

```bash
curl -X POST "http://localhost:8000/evaluate" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "질병 휴직 신청 서류는 무엇인가요?",
    "retrieved_documents": [
      {
        "id": "4dd76483-87bf-48f6-9aba-010f654b29b4",
        "score": 0.9926728606,
        "payload": {
          "file": "지방공무원_인사제도_운영지침.pdf",
          "page_num": 22,
          "group": "내부자료",
          "parent_text": "...",
          "text": "질병휴직은 신체·정신상의 장애...",
          "chunk_index": 43,
          "parent_id": "parent-21",
          "parent_idx": 21,
          "parent_table_statuses": [0],
          "child_idx": 1,
          "child_table_statuses": [0],
          "dept": "인사과",
          "service": ["법령", "직원복지"],
          "ner": false,
          "summary": "",
          "file_path": "/data/uploads/internal/example.pdf",
          "boost_keywords": "휴직 신청 절차",
          "parent_chunk_length": 1607,
          "child_chunk_length": 315,
          "file_index": "1261913"
        }
      }
    ]
  }'
```

### 4.3 간단 평가 요청

```bash
curl -X POST "http://localhost:8000/evaluate-simple" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "질병 휴직을 신청할 때 필요한 서류가 무엇인지 알려주세요.",
    "chunks": [
      {
        "content": "질병휴직은 신체·정신상의 장애, 불임 또는 난임 치료가 필요한 경우 가능하며, 진단서 또는 휴직 사유를 증빙할 수 있는 자료를 통해 휴직여부를 판단한다.",
        "filename": "지방공무원_인사제도_운영지침.pdf",
        "score": 0.9926728606
      }
    ]
  }'
```

## 5. 참고

- Swagger UI: `/docs`
- ReDoc: `/redoc`
