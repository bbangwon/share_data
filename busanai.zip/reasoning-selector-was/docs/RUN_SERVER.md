# reasoning-selector-was 서버 실행 가이드

## 1. 개요

- 서비스명: `reasoning-selector-was`
- 기본 목적: RAG 파이프라인에서 검색된 문서 청크의 연관성 점수를 LLM으로 재평가
- 서버 IP: `99.1.82.183`, `99.1.82.184`

## 2. 환경설정파일

- .env.reasoning

```
# Model Configuration

BASE_URL=http://99.1.2.97:10080/v1
MODEL=HCX-SEED-THINK-14B
TEMPERATURE=0.0
TIMEOUT=60
API_KEY=none

# Reasoning & Evaluation Configuration
ENABLE_REASONING=false  # reasoning 활성화 (true/false). false이면 답변 속도 향상
RESPONSE_MAX_TOKENS=4096  # 응답 토큰 제한 (답변 속도 향상)

# Score Weight Configuration
# 최종점수 = (ORIGINAL_SCORE_WEIGHT × 원본점수) + (LLM_SCORE_WEIGHT × LLM점수)
# 두 가중치의 합은 1.0이어야 함
ORIGINAL_SCORE_WEIGHT=0.1  # 원본 rerank 점수 가중치
LLM_SCORE_WEIGHT=0.9  # LLM 평가 점수 가중치
PARENT_TEXT_MAX_LENGTH=-1  # parent text 최대 길이 (토큰 수 기준) -1로 설정하면 전체 사용
LLM_MAX_CONCURRENCY=8  # LLM 최대 동시 처리 수

# Request Queue Configuration
MAX_CONCURRENT_REQUESTS=5  # HTTP 요청 레벨 동시 처리 수
MAX_QUEUE_SIZE=20  # 최대 대기 요청 수 (초과 시 503 반환)

# Application Configuration
LOG_LEVEL=INFO
LOG_DIR=./logs
LOG_BACKUP_COUNT=7
```

## 2. 실행

```
/home/naver/sh start_reasoning.sh
```

## 3. 종료

```
/home/naver/sh stop_reasoning.sh
```
