#!/bin/bash

docker-compose -f docker-compose.prod.yml build --no-cache

# Remove unused images
docker rmi -f $(docker images -f "dangling=true" -q)

# Create dist
rm -rf ./dist
mkdir -p ./dist

# copy env files
cp .env.prod ./dist/.env
cp docker-compose.prod.yml ./dist/docker-compose.yml

docker save -o ./dist/reasoning-selector-was.tar reasoning-selector-was
