"""원자력 안전 Rerank API (/evaluate-simple-nuclear)를 검증하기 위한 테스트 스크립트"""

import asyncio
import sys
import os
from unittest.mock import AsyncMock, patch

# 프로젝트 루트 디렉토리를 path에 추가
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient
from app.main import app
from app.models import RelevanceScore, SimpleEvaluationRequest

def test_evaluate_simple_nuclear():
    """/evaluate-simple-nuclear 엔드포인트의 입력 처리, 모킹된 LLM 호출 및 가중치 합산 동작 검증"""
    print("\n[테스트 시작] /evaluate-simple-nuclear API 테스트를 시작합니다...")

    # 요청 데이터 구성 (filename, title, content, score 포함)
    request_payload = {
        "query": "코로나19 감염병 의심자가 발생했을 때 대피소 방역 대책은?",
        "chunks": [
            {
                "content": "대피소 내부 감염병 의심자 발생 시 즉시 격리 공간을 구성하고, 관할 보건소와 협의하여 방역 조치를 취한다.",
                "filename": "원자력재난_대비매뉴얼.pdf",
                "title": "제4장 대피소 운영 및 방역 지침",
                "score": 0.5
            }
        ]
    }

    # Mock RelevanceScore 응답 객체 정의
    mock_llm_response = RelevanceScore(
        score=0.9,
        reasoning="감염병 의심자 발생 시 격리 공간 구성 및 보건소 협의 등 구체적인 방역 대책이 상세히 나와 있어 관련성이 매우 높음."
    )

    # TestClient의 lifespan을 트리거하기 위해 context manager를 사용합니다.
    with TestClient(app) as client:
        # lifespan이 완료된 후 main에서 evaluator를 가져옵니다.
        import app.main as main
        
        if main.evaluator is None:
            print("에러: app.main.evaluator 인스턴스가 생성되지 않았습니다.")
            sys.exit(1)

        # RunnableSequence object has no field "ainvoke" Pydantic 에러를 우회하기 위해
        # nuclear_scorer_chain을 mock_chain으로 통째로 대체합니다.
        mock_chain = AsyncMock()
        mock_chain.ainvoke = AsyncMock(return_value=mock_llm_response)
        main.evaluator.nuclear_scorer_chain = mock_chain

        # API 호출
        print("API 호출 시도 중...")
        response = client.post("/evaluate-simple-nuclear", json=request_payload)

        # 응답 검증
        assert response.status_code == 200, f"API 호출 실패: {response.text}"
        response_data = response.json()
        
        print("응답 수신 성공! 결과 데이터 검증 중...")
        assert response_data["query"] == request_payload["query"]
        assert len(response_data["chunks"]) == 1
        
        chunk = response_data["chunks"][0]
        assert chunk["filename"] == "원자력재난_대비매뉴얼.pdf"
        assert chunk["title"] == "제4장 대피소 운영 및 방역 지침"
        assert chunk["content"] == request_payload["chunks"][0]["content"]
        
        # 가중치 결합 검증
        # 최종 점수 = original_score_weight * original_score + llm_score_weight * llm_score
        # settings.original_score_weight = 0.1, settings.llm_score_weight = 0.9 (기본값)
        # 0.1 * 0.5 + 0.9 * 0.9 = 0.05 + 0.81 = 0.86
        expected_score = 0.86
        assert abs(chunk["score"] - expected_score) < 1e-4, f"점수 계산 불일치: 기대값={expected_score}, 실제값={chunk['score']}"
        
        # LLM ainvoke 호출 파라미터 검증
        main.evaluator.nuclear_scorer_chain.ainvoke.assert_called_once()
        called_args = main.evaluator.nuclear_scorer_chain.ainvoke.call_args[0][0]
        
        # 프롬프트 매핑 파라미터 검증
        assert called_args["query"] == request_payload["query"]
        assert called_args["filename"] == "원자력재난_대비매뉴얼.pdf"
        assert called_args["title"] == "제4장 대피소 운영 및 방역 지침"
        assert called_args["content"] == request_payload["chunks"][0]["content"][:300]

        print(f"✅ 테스트 통과! 계산된 최종 스코어: {chunk['score']:.4f} (기대값: {expected_score})")

if __name__ == "__main__":
    test_evaluate_simple_nuclear()
