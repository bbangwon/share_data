#!/usr/bin/env python3
"""Evaluate API 테스트용 스크립트.

입력 로그 JSON에서 "06_05. RAG 검색 API 요청" 단계의
BODY.detail.total_docs.results[0]를 추출해 /evaluate API를 호출하고,
응답으로 해당 result를 교체한 전체 JSON을 output.json으로 저장한다.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from copy import deepcopy
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

TARGET_STEP = "06_05. RAG 검색 API 요청"


class TimingStats:
    """단계별 수행시간을 기록하는 클래스."""

    def __init__(self) -> None:
        self.stages: dict[str, float] = {}
        self.stage_times: dict[str, list[float]] = {}
        self.start_time: float | None = None

    def start(self) -> None:
        """전체 수행시간 측정 시작."""
        self.start_time = time.time()

    def end_stage(self, stage_name: str) -> float:
        """단계 완료 및 소요시간 기록."""
        elapsed = time.time() - (self.stages.get(stage_name, time.time()))
        if stage_name not in self.stage_times:
            self.stage_times[stage_name] = []
        self.stage_times[stage_name].append(elapsed)
        return elapsed

    def start_stage(self, stage_name: str) -> None:
        """단계 시작하기."""
        self.stages[stage_name] = time.time()

    def get_total_time(self) -> float:
        """전체 소요시간 반환."""
        if self.start_time is None:
            return 0.0
        return time.time() - self.start_time

    def get_summary(self) -> str:
        """수행시간 통계 요약 반환."""
        lines = ["=" * 60, "[수행시간 통계]"]
        total = self.get_total_time()

        for stage_name in self.stage_times:
            times = self.stage_times[stage_name]
            count = len(times)
            total_s = sum(times)
            avg_s = total_s / count if count else 0
            lines.append(
                f"  {stage_name}: {total_s:.2f}초 (횟수: {count}, 평균: {avg_s:.2f}초)"
            )

        lines.append("-" * 60)
        lines.append(f"  총 수행시간: {total:.2f}초")
        lines.append("=" * 60)
        return "\n".join(lines)


def _progress(message: str, elapsed: float | None = None) -> None:
    """처리 진행 상황을 즉시 출력한다. elapsed가 주어지면 소요시간도 함께 출력."""
    if elapsed is not None:
        print(f"{message} [{elapsed:.2f}초]", flush=True)
    else:
        print(message, flush=True)


def _load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _save_json(path: Path, data: Any) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _find_target_result_in_root(
    root: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    logs = root.get("logs")
    if not isinstance(logs, list):
        raise ValueError("루트 항목에 logs 배열이 없습니다.")

    for log in logs:
        if log.get("STEP") != TARGET_STEP:
            continue
        body = log.get("BODY", {})
        detail = body.get("detail", {})
        total_docs = detail.get("total_docs", {})
        results = total_docs.get("results", [])

        if not isinstance(results, list) or not results:
            raise ValueError(
                f"'{TARGET_STEP}' 단계의 BODY.detail.total_docs.results[0]를 찾지 못했습니다."
            )

        first_result = results[0]
        if not isinstance(first_result, dict):
            raise ValueError("results[0]가 객체 형태가 아닙니다.")
        return log, first_result

    raise ValueError(f"STEP='{TARGET_STEP}' 항목을 찾지 못했습니다.")


def _call_evaluate_api(
    api_url: str, payload: dict[str, Any], timeout: float
) -> dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = Request(
        api_url,
        data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )

    try:
        with urlopen(req, timeout=timeout) as resp:
            resp_bytes = resp.read()
    except HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP 오류({e.code}): {error_body}") from e
    except URLError as e:
        raise RuntimeError(f"API 연결 실패: {e.reason}") from e

    try:
        parsed = json.loads(resp_bytes.decode("utf-8"))
    except json.JSONDecodeError as e:
        raise RuntimeError("API 응답 JSON 파싱 실패") from e

    if not isinstance(parsed, dict):
        raise RuntimeError("API 응답이 객체(JSON object) 형식이 아닙니다.")
    if "retrieved_documents" not in parsed or "query" not in parsed:
        raise RuntimeError("API 응답에 query/retrieved_documents 필드가 없습니다.")

    return parsed


def main() -> int:
    parser = argparse.ArgumentParser(
        description="로그 JSON에서 샘플을 추출해 reasoning-selector evaluate API를 테스트합니다."
    )
    parser.add_argument(
        "-i",
        "--input",
        default="log_db.logs.json",
        help="입력 로그 JSON 경로 (기본값: log_db.logs.json)",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="output.json",
        help="출력 JSON 경로 (기본값: output.json)",
    )
    parser.add_argument(
        "-u",
        "--api-url",
        default="http://localhost:8010/evaluate",
        help="evaluate API URL (기본값: http://localhost:8010/evaluate)",
    )
    parser.add_argument(
        "-t",
        "--timeout",
        type=float,
        default=60.0,
        help="API 호출 타임아웃(초) (기본값: 60)",
    )

    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)

    if not input_path.exists():
        print(f"입력 파일이 없습니다: {input_path}", file=sys.stderr)
        return 1

    timing = TimingStats()
    timing.start()

    try:
        # [1/5] 입력 JSON 로드
        timing.start_stage("입력 JSON 로드")
        _progress("[1/5] 입력 JSON 로드 중...")
        original_data = _load_json(input_path)
        updated_data = deepcopy(original_data)
        elapsed = timing.end_stage("입력 JSON 로드")
        _progress("[1/5] 입력 JSON 로드 완료", elapsed)

        if not isinstance(updated_data, list) or not updated_data:
            raise ValueError("입력 JSON은 최소 1개 원소를 가진 리스트여야 합니다.")

        total_roots = len(updated_data)
        _progress(f"[2/5] 루트 항목 순차 처리 시작... (총 {total_roots}건)")

        processed = 0
        skipped = 0

        for idx, root in enumerate(updated_data, start=1):
            # 각 항목 처리 시간 측정
            timing.start_stage("항목별 처리")
            _progress(f"  - [{idx}/{total_roots}] 대상 STEP 및 results[0] 추출 중...")
            try:
                target_log, first_result = _find_target_result_in_root(root)
            except ValueError as e:
                skipped += 1
                elapsed = timing.end_stage("항목별 처리")
                _progress(f"    스킵: {e}", elapsed)
                continue

            # API 호출 시간 측정
            timing.start_stage("evaluate API 호출")
            _progress(f"    evaluate API 호출 중... ({args.api_url})")
            response_result = _call_evaluate_api(
                args.api_url, first_result, args.timeout
            )
            elapsed = timing.end_stage("evaluate API 호출")
            _progress("    evaluate API 호출 완료", elapsed)

            timing.start_stage("JSON 교체")
            _progress("    응답 결과로 JSON 교체 중...")
            target_log["BODY"]["detail"]["total_docs"]["results"][0] = response_result
            elapsed = timing.end_stage("JSON 교체")
            _progress("    JSON 교체 완료", elapsed)
            processed += 1

        if processed == 0:
            raise ValueError("처리된 항목이 없습니다. 입력 JSON 구조를 확인해주세요.")

        # [5/5] 결과 파일 저장
        timing.start_stage("결과 파일 저장")
        _progress(f"[5/5] 결과 파일 저장 중... ({output_path})")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        _save_json(output_path, updated_data)
        elapsed = timing.end_stage("결과 파일 저장")
        _progress("[5/5] 결과 파일 저장 완료", elapsed)

        # 최종 결과 출력
        print()
        print("evaluate API 호출 성공")
        print(f"입력: {input_path}")
        print(f"출력: {output_path}")
        print(f"처리: {processed}건, 스킵: {skipped}건")
        print(f"변경: '{TARGET_STEP}' -> BODY.detail.total_docs.results[0] 교체 완료")
        print()
        print(timing.get_summary())
        return 0
    except Exception as e:
        print(f"오류: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
