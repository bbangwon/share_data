import logging
import time

from fastapi import APIRouter, Depends

from app.core import settings
from app.handlers import (
    CollectionHandler,
    PointHandler,
    RerankingHandler,
    RetrievalHandler,
    SnapshotHandler,
    TuningHandler,
)
from app.schemas import qdrant
from app.vectordb import get_long_qdrant_client, get_qdrant_client

router = APIRouter()

logger = logging.getLogger("rag-was.api.v1.qdrant")


@router.post(
    "/retrieve",
    response_model=qdrant.RetrieveResponse,
    description="문서검색",
    tags=["Retrieve by Query"],
)
async def retrieve_documents(
    search_info: qdrant.SearchInfo, client=Depends(get_qdrant_client)
):
    retrieval_handler = RetrievalHandler()
    reranking_handler = RerankingHandler()
    point_handler = PointHandler()

    # 1. Retrieval
    retrieval_result = await retrieval_handler.retrieve(client, search_info)
    retrieved_docs = retrieval_result["retrieved_docs"]
    t_start_total = retrieval_result["t_start_total"]
    t_embed_latency = retrieval_result["t_embed_latency"]
    t_retrieval_latency = retrieval_result["t_retrieval_latency"]

    # 2. Reranking
    reranking = search_info.reranking or qdrant.Reranking(
        is_active=settings.RERANK_IS_ACTIVE,
        target=settings.RERANK_TARGET,
        include_file_name=settings.RERANK_INCLUDE_FILE_NAME,
        include_boost_keywords=settings.RERANK_INCLUDE_BOOST_KEYWORDS,
        include_summary=settings.RERANK_INCLUDE_SUMMARY,
    )
    penalty = search_info.penalty or qdrant.Penalty(
        is_active=settings.PENALTY_IS_ACTIVE,
        criteria=settings.PENALTY_CRITERIA,
        insenstivity=settings.PENALTY_INSENSTIVITY,
        min_length=settings.PENALTY_MIN_LENGTH,
        noise_weight=settings.PENALTY_NOISE_WEIGHT,
    )
    final_limit = search_info.final_limit or settings.FINAL_LIMIT
    add_next_point = (
        search_info.add_next_point
        if search_info.add_next_point is not None
        else settings.ADD_NEXT_POINT
    )
    added_chunk_max_size = (
        search_info.added_chunk_max_size or settings.ADDED_CHUNK_MAX_SIZE
    )
    service_type = search_info.service_type  # >> qdrant.ServiceType

    reranked_docs = []
    t_rerank_latency = 0
    if reranking.is_active:
        t_start_rerank = time.perf_counter()
        reranked_docs = await reranking_handler.execute_reranking(
            queries=search_info.queries,
            base_query=search_info.base_query,
            documents=retrieved_docs,
            target=reranking.target,
            include_file_name=reranking.include_file_name,
            include_boost_keywords=reranking.include_boost_keywords,
            include_summary=reranking.include_summary,
            top_n=final_limit,
            penalty=penalty,
        )
        t_end_rerank = time.perf_counter()
        t_rerank_latency = t_end_rerank - t_start_rerank

    final_docs = (
        reranked_docs if (reranking.is_active and reranked_docs) else retrieved_docs
    )

    # 3. Add Points
    t_add_latency = 0
    if (
        service_type == qdrant.ServiceType.generate
        and settings.ADD_POINTS_FOR_GENERATE_SERVICE
    ):
        t_start_add = time.perf_counter()
        generate_top_k = settings.GENERATE_TOP_K
        generate_pre_points_cnt = settings.GENERATE_PRE_POINTS_CNT
        generate_next_points_cnt = settings.GENERATE_NEXT_POINTS_CNT
        await point_handler.add_points_for_generate_service(
            [final_docs[0][:generate_top_k]],
            search_info.collection_name or settings.COLLECTION_NAME,
            generate_pre_points_cnt,
            generate_next_points_cnt,
            client,
        )
        t_end_add = time.perf_counter()
        t_add_latency = t_end_add - t_start_add
    else:
        if add_next_point:
            t_start_add = time.perf_counter()
            await point_handler.add_next_points(
                final_docs,
                search_info.collection_name or settings.COLLECTION_NAME,
                added_chunk_max_size,
                client,
            )
            t_end_add = time.perf_counter()
            t_add_latency = t_end_add - t_start_add

    # 4. Format Results
    results = await retrieval_handler.get_results(
        queries=search_info.queries,
        base_query=search_info.base_query,
        documents=final_docs,
    )

    t_end_total = time.perf_counter()

    logger.debug(
        f"Retrieved {len(search_info.queries) * final_limit} documents. ({len(search_info.queries)} queries X {final_limit} docs)"
    )
    latency_details = [
        {"desc": "전체 검색 시간", "latency": t_end_total - t_start_total},
        {"desc": "쿼리 임베딩 시간", "latency": t_embed_latency},
        {"desc": "VDB 검색 시간", "latency": t_retrieval_latency},
        {"desc": "문서 재정렬(rerank) 시간", "latency": t_rerank_latency},
        {"desc": "추가 포인트 검색 시간", "latency": t_add_latency},
    ]
    return {"results": results, "latency_details": latency_details}


@router.get(
    "/collections",
    description="collection 목록 확인",
    tags=["Collections"],
)
async def fetch_collections(client=Depends(get_qdrant_client)):
    handler = CollectionHandler()
    return await handler.fetch_collections(client)


@router.get(
    "/collections/{collection_name}",
    description="collection 상세 정보 확인",
    tags=["Collections"],
)
async def get_collection_info(collection_name: str, client=Depends(get_qdrant_client)):
    handler = CollectionHandler()
    return await handler.get_collection_info(collection_name, client)


@router.delete(
    "/collections/{collection_name}",
    description="collection 삭제",
    tags=["Collections"],
)
async def delete_collection(collection_name: str, client=Depends(get_qdrant_client)):
    handler = CollectionHandler()
    return await handler.delete_collection(collection_name, client)


@router.put(
    "/collections/{collection_name}/index",
    description="Payload(filed_name) Index 생성",
    tags=["Index Payload"],
)
async def create_payload_index(
    collection_name: str,
    field_info: qdrant.FieldInfo,
    client=Depends(get_long_qdrant_client),
):
    handler = CollectionHandler()
    return await handler.create_payload_index(collection_name, field_info, client)


@router.delete(
    "/collections/{collection_name}/index/{field_name}",
    description="Payload(filed_name) Index 삭제",
    tags=["Index Payload"],
)
async def delete_payload_index(
    collection_name: str, field_name: str, client=Depends(get_qdrant_client)
):
    handler = CollectionHandler()
    return await handler.delete_payload_index(collection_name, field_name, client)


@router.post(
    "/collections/{collection_name}/points",
    description="파일명(file)에 해당하는 모든 포인트(청크) 조회",
    tags=["Point Operations"],
)
async def scroll_points_by_file(
    collection_name: str,
    search_info: qdrant.FileSearchInfo,
    client=Depends(get_long_qdrant_client),
):
    handler = PointHandler()
    return await handler.scroll_points_by_file(collection_name, search_info, client)


@router.get(
    "/collections/{collection_name}/points/{point_id}",
    description="ID 기반 특정 포인트(청크) 정보 조회",
    tags=["Point Operations"],
)
async def retrieve_a_point(
    collection_name: str, point_id: str, client=Depends(get_qdrant_client)
):
    handler = PointHandler()
    return await handler.retrieve_a_point(collection_name, point_id, client)


@router.delete(
    "/collections/{collection_name}/points",
    description="파일명 기준 모든 포인트 또는 ID 기반 특정 포인트(청크) 삭제",
    tags=["Point Operations"],
)
async def delete_points(
    collection_name: str,
    delete_info: qdrant.DeletePoints,
    client=Depends(get_long_qdrant_client),
):
    handler = PointHandler()
    return await handler.delete_points(collection_name, delete_info, client)


@router.post(
    "/collections/{collection_name}/points/{point_id}/payload",
    description="ID 기반 포인트(청크)의 페이로드 추가 및 수정",
    tags=["Point Operations"],
)
async def update_a_point_payload(
    collection_name: str,
    point_id: str,
    update_data: qdrant.UpdatePoint,
    client=Depends(get_qdrant_client),
):
    handler = PointHandler()
    return await handler.update_a_point_payload(
        collection_name, point_id, update_data, client
    )


@router.put(
    "/collections/{collection_name}/points/{point_id}/vectors",
    description="ID 기반 포인트(청크)의 벡터 수정",
    tags=["Point Operations"],
)
async def update_a_point_vectors(
    collection_name: str,
    point_id: str,
    update_data: qdrant.UpdatePoint,
    client=Depends(get_qdrant_client),
):
    handler = PointHandler()
    return await handler.update_a_point_vectors(
        collection_name, point_id, update_data, client
    )


@router.get(
    "/embedding/sparse/bm25", description="bm25 sparse 임베딩", tags=["Embedding"]
)
async def embed_sparse_bm25(text: str):
    handler = RetrievalHandler()
    return await handler.embed_sparse_bm25(text)


@router.get(
    "/collections/{collection_name}/snapshots",
    description="해당 Collection의 스냅샷 조회",
    tags=["Snapshots"],
)
async def get_snapshots(collection_name: str, client=Depends(get_qdrant_client)):
    handler = SnapshotHandler()
    return await handler.get_snapshots(collection_name, client)


@router.post(
    "/collections/{collection_name}/snapshots",
    description="해당 Collection의 현재상태의 Snapshot 생성",
    tags=["Snapshots"],
)
async def create_snapshot(collection_name: str, client=Depends(get_long_qdrant_client)):
    handler = SnapshotHandler()
    return await handler.create_snapshot(collection_name, client)


@router.delete(
    "/collections/{collection_name}/snapshots/{snapshot_name}",
    description="해당 Collection의 Snapshot 삭제",
    tags=["Snapshots"],
)
async def delete_snapshot(
    collection_name: str, snapshot_name: str, client=Depends(get_qdrant_client)
):
    handler = SnapshotHandler()
    return await handler.delete_snapshot(collection_name, snapshot_name, client)


@router.put(
    "/collections/{target_collection}/snapshots/recover",
    description="해당 Collection의 Snapshot 으로 Target Collection 업데이트(없는 경우 생성)",
    tags=["Snapshots"],
)
async def recover_snapshot(
    target_collection: str,
    recover_info: qdrant.CollectionRecoverInfo,
    client=Depends(get_long_qdrant_client),
):
    handler = SnapshotHandler()
    return await handler.recover_snapshot(target_collection, recover_info, client)


@router.put(
    "/collections/{collection_name}/points",
    description="Point의 Sparse Embedding 값 변경 및 Payload 추가",
    tags=["Tunning"],
)
async def process_points_tunning(
    collection_name: str,
    tunning_info: qdrant.TunningInfo,
    client=Depends(get_long_qdrant_client),
):
    handler = TuningHandler()
    return await handler.process_points_tunning(collection_name, tunning_info, client)
