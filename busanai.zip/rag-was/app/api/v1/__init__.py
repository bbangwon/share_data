from fastapi import APIRouter

from . import qdrant

router = APIRouter()

router.include_router(qdrant.router, prefix="/qdrant")
