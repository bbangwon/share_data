from dotenv import load_dotenv

load_dotenv(
    ".env.hf"
)  # Huggingface 캐시 디렉토리를 사용하는 JinaEmbeddingsV3 모델 선언 이전에 호출

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.staticfiles import StaticFiles

from app import api
from app.services.embedding import (
    # BgeM3OnnxEmbedding, # 미사용 Dense Embedding 모델
    # JinaEmbeddingsV3, # GPU 서버로 이관
    KiwiBm25Embedding,
)
from app.state import AppState

# 로깅 기본 설정
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("rag-was.main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("App lifespan 시작 - 임베딩 모델 초기화")
    # AppState.bge_embedder = await BgeM3OnnxEmbedding.create()
    # AppState.jini_embeeder = await JinaEmbeddingsV3.create()
    AppState.bm25_embedder = await KiwiBm25Embedding.create()

    logger.info("임베딩 모델 초기화 완료")
    yield
    logger.info("App lifespan 종료")


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None)
logger.info("FastAPI 앱 인스턴스 생성")

app.mount("/static", StaticFiles(directory="static"), name="static")
logger.info("정적파일(static) 마운트 완료")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
logger.info("CORS 미들웨어 추가 완료")


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    # 빈 응답
    return Response(status_code=404)


@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title=f"[TEST UI] {app.title}",
        # 로컬 정적 경로로 교체
        swagger_js_url="/static/swagger-ui/swagger-ui-bundle.js",
        swagger_css_url="/static/swagger-ui/swagger-ui.css",
        swagger_favicon_url="/static/swagger-ui/favicon-32x32.png",
    )


@app.get("/health-check")
def health_check():
    logger.info("health_check 엔드포인트 호출")
    return {"RAG-WAS OK": True}


app.include_router(api.router, prefix="/api")
logger.info("API 라우터 등록 완료")
