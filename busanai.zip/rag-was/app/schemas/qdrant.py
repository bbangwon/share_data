from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from app.core import settings


class RetrieveType(str, Enum):
    semantic = "semantic"
    lexical = "lexical"
    hybrid = "hybrid"


class DenseType(str, Enum):
    bge = "bge"
    jina = "jina"


class SparseType(str, Enum):
    bm25 = "bm25"


class RerankTarget(str, Enum):
    text = "text"
    parent_text = "parent_text"


class FieldSchema(str, Enum):
    keyword = "keyword"
    integer = "integer"
    float = "float"
    geo = "geo"
    text = "text"
    bool = "bool"
    datetime = "datetime"
    uuid = "uuid"


class EmbedType(str, Enum):
    sparse = "sparse"
    dense = "dense"


class DelPointsCriteria(str, Enum):
    ids = "ids"
    files = "files"


class FilterType(str, Enum):
    must = "must"
    must_not = "must_not"


class ServiceType(str, Enum):
    general = "general"
    internal = "internal"
    external = "external"
    generate = "generate"


class DenseEmbedding(BaseModel):
    type: DenseType | None = Field(
        default=None,
        description="Dense 임베딩 타입 (bge | jina)",
        examples=[settings.DENSE_TYPE],
    )
    name: str | None = Field(
        default=None,
        description="Dense Vector 이름",
        examples=[settings.DENSE_NAME],
    )


class SparseEmbedding(BaseModel):
    type: SparseType | None = Field(
        default=None,
        description="Sparse 임베딩 타입 (bm25)",
        examples=[settings.SPARSE_TYPE],
    )
    name: str | None = Field(
        default=None,
        description="Sparse Vector 이름",
        examples=[settings.SPARSE_NAME],
    )


class Reranking(BaseModel):
    is_active: bool | None = Field(
        default=None,
        description="리랭크 모델 사용 여부",
        examples=[settings.RERANK_IS_ACTIVE],
    )
    target: RerankTarget | None = Field(
        default=None,
        description="리랭크 기준 텍스트 (text | parent_text)",
        examples=[settings.RERANK_TARGET],
    )
    include_file_name: bool | None = Field(
        default=None,
        description="리랭크시 파일명 참조 여부",
        examples=[settings.RERANK_INCLUDE_FILE_NAME],
    )
    include_boost_keywords: bool | None = Field(
        default=None,
        description="리랭크시 부스트 키워드 참조 여부",
        examples=[settings.RERANK_INCLUDE_BOOST_KEYWORDS],
    )
    include_summary: bool | None = Field(
        default=None,
        description="리랭크시 요약내용 참조 여부",
        examples=[settings.RERANK_INCLUDE_SUMMARY],
    )


class Penalty(BaseModel):
    is_active: bool | None = Field(
        default=None,
        description="문장 길이에 따른 패널티 적용 여부",
        examples=[settings.PENALTY_IS_ACTIVE],
    )
    criteria: int | None = Field(
        default=None,
        description="패널티를 적용할 문장의 기준 길이(50%가 적용되는 길이)",
        examples=[settings.PENALTY_CRITERIA],
    )
    insenstivity: int | None = Field(
        default=None,
        description="패널티 가중치 계산시 둔감도(값이 클수록 완만하게 증감)",
        examples=[settings.PENALTY_INSENSTIVITY],
    )
    min_length: int | None = Field(
        default=None,
        description="텍스트 최소 길이(해당 길이보다 짧은 경우 최소 가중치 적용)",
        examples=[settings.PENALTY_MIN_LENGTH],
    )
    noise_weight: int | float | None = Field(
        default=None,
        description="텍스트 최소 길이 미달일 경우 적용할 가중치(0~1 사이 설정)",
        examples=[settings.PENALTY_NOISE_WEIGHT],
        ge=0,
        le=1,
    )


class QueryFilter(BaseModel):
    type: FilterType | None = Field(
        default=None,
        description="필터링 타입 (must | must_not)",
        examples=[
            settings.DEFAULT_FILTER_TYPES[0]
            if settings.DEFAULT_FILTER_TYPES
            else "must"
        ],
    )
    key: str | None = Field(
        default=None,
        description="필터링할 페이로드(메타) 필드명",
        examples=[
            settings.DEFAULT_FILTER_KEYS[0]
            if settings.USE_DEFAULT_FILTER
            else "field_name"
        ],
    )
    values: list[str] | None = Field(
        default=None,
        description="필터링에 포함할 도메인값",
        examples=[
            settings.DEFAULT_FILTER_VALUES[0] if settings.USE_DEFAULT_FILTER else []
        ],
    )


class SearchInfo(BaseModel):
    queries: list[str] = Field(..., description="문서 검색에 사용할 문장")
    base_query: str | None = Field(
        default=None,
        description="재정렬(rerank)시 기준이 되는 문장 | None인 경우 queries 문장 각각의 내용으로 검색",
        examples=[None],
    )
    collection_name: str | None = Field(
        default=None,
        description="검색 대상 콜렉션명",
        examples=[settings.COLLECTION_NAME],
    )
    retrieve_type: RetrieveType | None = Field(
        default=None,
        description="검색 타입 (semantic | lexical | hybrid)",
        examples=[settings.RETRIEVE_TYPE],
    )
    dense_limit: int | None = Field(
        default=None,
        description="Hybrid Search 시 Semantic Search 로 찾을 문서의 수",
        examples=[settings.DENSE_LIMIT],
        ge=1,
        le=500,
    )
    sparse_limit: int | None = Field(
        default=None,
        description="Hybrid Search 시 Lexical Search 로 찾을 문서의 수",
        examples=[settings.SPARSE_LIMIT],
        ge=1,
        le=500,
    )
    final_limit: int | None = Field(
        default=None,
        description="최종 검색 결과로 반환할 문서 단락(청크) 개수",
        examples=[settings.FINAL_LIMIT],
        ge=1,
        le=100,
    )
    dense_embedding: DenseEmbedding | None = Field(
        default=None,
        description="Dense Embedding 설정",
        examples=[{"type": settings.DENSE_TYPE, "name": settings.DENSE_NAME}],
    )
    sparse_embedding: SparseEmbedding | None = Field(
        default=None,
        description="Sparse Embedding 설정",
        examples=[{"type": settings.SPARSE_TYPE, "name": settings.SPARSE_NAME}],
    )
    reranking: Reranking | None = Field(
        default=None,
        description="Reranking 설정",
        examples=[
            {
                "is_active": settings.RERANK_IS_ACTIVE,
                "target": settings.RERANK_TARGET,
                "include_file_name": settings.RERANK_INCLUDE_FILE_NAME,
                "include_boost_keywords": settings.RERANK_INCLUDE_BOOST_KEYWORDS,
                "include_summary": settings.RERANK_INCLUDE_SUMMARY,
            }
        ],
    )
    penalty: Penalty | None = Field(
        default=None,
        description="Penalty 설정",
        examples=[
            {
                "is_active": settings.PENALTY_IS_ACTIVE,
                "criteria": settings.PENALTY_CRITERIA,
                "insenstivity": settings.PENALTY_INSENSTIVITY,
                "min_length": settings.PENALTY_MIN_LENGTH,
                "noise_weight": settings.PENALTY_NOISE_WEIGHT,
            }
        ],
    )
    filters: list[QueryFilter] | None = Field(
        default=None,
        description="검색 필터링 설정",
    )
    add_next_point: bool | None = Field(
        default=None,
        description="최종 검색 결과에서 다음 포인트(청크) 추가 여부",
        examples=[settings.ADD_NEXT_POINT],
    )
    added_chunk_max_size: int | None = Field(
        default=None,
        description="다음 포인트를 더하는 경우 parent_text 최대 크기 조건",
        examples=[settings.ADDED_CHUNK_MAX_SIZE],
    )
    service_type: ServiceType | None = Field(
        default=None,
        description="서비스 타입 (internal | external | generate | general)",
        examples=[ServiceType.internal],
    )


class Payload(BaseModel):
    model_config = ConfigDict(extra="allow")

    file: str = Field(..., description="파일명")
    page_num: int = Field(..., description="페이지 정보")
    group: str = Field(
        ..., description="파일출처(내부자료, 온나라, 부산시홈페이지, BDI...)"
    )
    parent_text: str = Field(
        ..., description="답변 생성에 활용될 텍스트(최대 2048토큰)"
    )
    text: str = Field(..., description="검색에 활용된 텍스트(최대 512토큰)")
    chunk_index: int | None = Field(default=None, description="파일 내 청크 순서값")
    parent_id: str | None = Field(default=None, description="부모 청크 식별값")
    parent_idx: int | None = Field(default=None, description="파일 내 부모 청크 순서값")
    parent_table_statuses: list[int] | None = Field(
        default=None, description="페이지 내 부모 청크의 테이블 상태값"
    )
    parent_chunk_length: int | None = Field(default=None, description="부모 청크 길이")
    child_idx: int | None = Field(
        default=None, description="부모 청크 내 자식 청크 인덱스"
    )
    child_table_statuses: list[int] | None = Field(
        default=None, description="부모 청크 자식 테이블의 상태값"
    )
    child_chunk_length: int | None = Field(default=None, description="자식 청크 길이")
    dept: str | None = Field(default=None, description="부서")
    service: list[str] | None = Field(default=None, description="서비스 카테고리")
    ner: bool | None = Field(default=False, description="비식별화 여부")
    summary: str | None = Field(default=None, description="파일 전체에 대한 요약")
    file_path: str | None = Field(default=None, description="내부망 파일 주소")
    boost_keywords: str | None = Field(default=None, description="검색 키워드(or 문구)")


class DocumentInfo(BaseModel):
    id: str = Field(..., description="검색된 문서(포인트, 청크) 식별값")
    score: float = Field(..., description="질의와 문서(포인트, 청크) 간의 유사도 점수")
    payload: Payload


class RetrieveResult(BaseModel):
    query: str
    retrieved_documents: list[DocumentInfo | None] = Field(default=None)


class RetrieveResponse(BaseModel):
    results: list[RetrieveResult | None] = Field(default=None)
    latency_details: list[dict] | None = Field(default=None)


class FieldInfo(BaseModel):
    field_name: str = Field(default="group")
    field_schema: FieldSchema = Field(default="keyword")


class FileSearchInfo(BaseModel):
    file_name: str
    limit: int | None = Field(
        default=0,
        ge=0,
        description="검색할 포인트 수 (0인 경우 해당 조건의 포인트 수 만큼 자동설정)",
    )
    page_num: int | None = Field(default=None, ge=1, examples=[None])
    parent_idx: int | None = Field(default=None, ge=0, examples=[None])
    offset: str | None = Field(
        default=None,
        description="`point_id` 값으로 해당 포인트부터 검색",
        examples=[None],
    )


class UpdatePoint(BaseModel):
    payload: dict[str, Any] | None = Field(
        default=None, examples=[{"filed_name": "values"}]
    )
    embed_type: EmbedType | None = Field(default=None)
    vector: dict[str, Any] | None = Field(
        default=None,
        examples=[
            # CASE01 - sparse vecteor
            {
                "vector_name": {
                    "indices": [123, 456],
                    "values": [1, 1],
                },
            },
            # CASE02 - dense vector
            {
                "vector_name": [0.1, 0.2],
            },
        ],
    )


class DeletePoints(BaseModel):
    del_criteria: DelPointsCriteria
    ids: list[str] | None = Field(default=None)
    files: list[str] | None = Field(default=None)


class CollectionRecoverInfo(BaseModel):
    location: str


class TunningInfo(BaseModel):
    point_ids: list
    boost_keywords: str
