# 전역 상태 저장소
class AppState:
    # bge_embedder = None
    # jini_embeeder = None
    bm25_embedder = None
