import logging

from fastapi import HTTPException, status
from qdrant_client.http.exceptions import UnexpectedResponse

from app.schemas import qdrant

logger = logging.getLogger("rag-was.handlers.collection")


class CollectionHandler:
    async def fetch_collections(self, client) -> dict:
        logger.info("fetch_collections called")
        try:
            res = await client.get_collections()
            return {
                "collections": [
                    collection.model_dump() for collection in res.collections
                ]
            }
        except UnexpectedResponse as e:
            logger.warning(f"Qdrant returned an unexpected response: {e}")
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant service",
            )
        except Exception as e:
            logger.exception(f"Failed to fetch collections: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to fetch collections from Qdrant",
            )

    async def get_collection_info(self, collection_name: str, client) -> dict:
        logger.info(f"get_collection_info called | {collection_name=}")
        try:
            res = await client.get_collection(collection_name)
            return {"collection_info": res.model_dump()}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant returned unexpected response for collection '{collection_name}': {e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Invalid response from Qdrant service for collection '{collection_name}'",
            )
        except Exception as e:
            logger.exception(
                f"Failed to fetch collection '{collection_name}' info: {e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to fetch collection '{collection_name}' info from Qdrant",
            )

    async def delete_collection(self, collection_name: str, client) -> dict:
        logger.info(f"delete_collection called | {collection_name=}")
        try:
            res: bool = await client.delete_collection(collection_name=collection_name)
            return {"result": res}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on delete_collection | {collection_name=} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant while deleting collection",
            )
        except Exception as e:
            logger.exception(
                f"Failed to delete collection | {collection_name=} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to delete collection '{collection_name}'",
            )

    async def create_payload_index(
        self,
        collection_name: str,
        field_info: qdrant.FieldInfo,
        client,
    ) -> dict:
        logger.info(f"delete_payload_index called | {collection_name=} | {field_info=}")
        try:
            res = await client.create_payload_index(
                collection_name, field_info.field_name, field_info.field_schema
            )
            return {"status": res.status.value}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response during index creation: collection={collection_name}, field={field_info.field_name}, error={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Invalid response from Qdrant while creating index '{field_info.field_name}' in collection '{collection_name}'",
            )
        except Exception as e:
            logger.exception(
                f"Failed to create payload index: collection={collection_name}, field={getattr(field_info, 'field_name', None)}, err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to create index '{getattr(field_info, 'field_name', None)}' in collection '{collection_name}'",
            )

    async def delete_payload_index(
        self, collection_name: str, field_name: str, client
    ) -> dict:
        logger.info(f"delete_payload_index called | {collection_name=} | {field_name=}")
        try:
            res = await client.delete_payload_index(collection_name, field_name)
            return {"status": res.status.value}
        except UnexpectedResponse as e:
            logger.warning(f"Qdrant unexpected response during index delete: {e}")
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Invalid response from Qdrant while deleting index '{field_name}' in collection '{collection_name}'",
            )
        except Exception as e:
            logger.exception(
                f"Failed to delete payload index: collection={collection_name}, field={field_name}, err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to delete index '{field_name}' from collection '{collection_name}'",
            )
