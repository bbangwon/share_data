import logging

from fastapi import HTTPException, status
from qdrant_client.http.exceptions import UnexpectedResponse

from app.schemas import qdrant

logger = logging.getLogger("rag-was.handlers.snapshot")


class SnapshotHandler:
    async def get_snapshots(self, collection_name: str, client) -> dict:
        logger.info(f"get_snapshots called | collection={collection_name}")
        try:
            res = await client.list_snapshots(collection_name=collection_name)
            results = (
                sorted(
                    [snapshot.model_dump() for snapshot in res],
                    key=lambda x: x["creation_time"],
                    reverse=True,
                )
                if len(res) > 0
                else []
            )
            return {"snapshots": results}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on get_snapshots | collection={collection_name} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant while retrieving snapshots",
            )
        except Exception as e:
            logger.exception(
                f"Failed to get snapshots | collection={collection_name} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to list snapshots for collection '{collection_name}'",
            )

    async def create_snapshot(self, collection_name: str, client) -> dict:
        logger.info(f"create_snapshot called | collection={collection_name}")
        try:
            res = await client.create_snapshot(collection_name=collection_name)
            return {"snapshot": res.model_dump()}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on create_snapshot | "
                f"collection={collection_name} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant while creating snapshot",
            )
        except Exception as e:
            logger.exception(
                f"Failed to create snapshot | collection={collection_name} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to create snapshot for collection '{collection_name}'",
            )

    async def delete_snapshot(
        self, collection_name: str, snapshot_name: str, client
    ) -> dict:
        logger.info(
            f"delete_snapshot called | collection={collection_name} | snapshot={snapshot_name}"
        )
        try:
            res: bool = await client.delete_snapshot(
                collection_name=collection_name, snapshot_name=snapshot_name
            )
            return {"result": res}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on delete_snapshot | "
                f"collection={collection_name} | snapshot={snapshot_name} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant while deleting snapshot",
            )
        except Exception as e:
            logger.exception(
                f"Failed to delete snapshot | collection={collection_name} | "
                f"snapshot={snapshot_name} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to delete snapshot '{snapshot_name}' from collection '{collection_name}'",
            )

    async def recover_snapshot(
        self,
        target_collection: str,
        recover_info: qdrant.CollectionRecoverInfo,
        client,
    ) -> dict:
        logger.info(f"recover_snapshot called | {target_collection=} | {recover_info=}")
        try:
            location = f"{recover_info.location}"
            res: bool = await client.recover_snapshot(
                collection_name=target_collection, location=location
            )
            return {"result": res}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on recover_snapshot | {target_collection=} | {recover_info=} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant while recovering snapshot",
            )
        except Exception as e:
            logger.exception(
                f"Failed to recover snapshot | {target_collection=} | {recover_info=} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to recover snapshot | {target_collection=} | {recover_info=}",
            )
