import logging
import math
from typing import Literal

from app.core import settings
from app.schemas import qdrant
from app.services import Reranker

logger = logging.getLogger("rag-was.handlers.reranking")


class RerankingHandler:
    async def deduplicate_rerank_target(
        self,
        documents: list[qdrant.DocumentInfo],
        target: Literal["text", "parent_text"] = "text",
    ) -> list[qdrant.DocumentInfo]:
        """Rerank Target Text의 중복제거"""
        included_values: set[str] = set()
        dedup_docs: list[qdrant.DocumentInfo] = []
        for doc in documents:
            checker = (
                doc.get("id")
                if target == "text"
                else doc.get("payload").get("parent_id")
            )
            if checker in included_values:
                continue
            included_values.add(checker)
            dedup_docs.append(doc)

        return dedup_docs

    async def calculate_sigmoid_penalty(
        self,
        length: int,
        L0: int,
        tau: int,
        min_length: int,
        noise_wight: int | float,
    ) -> float:
        """문장의 길이에 따른 패널티 부여 함수
        - length: 문장의 길이
        - L0: 점수를 50%로 만드는 기준 길이(이보다 짧은 경우 점수 급락)
        - tau: 점수 변화 민감도 (값이 클수록 완만하게 변화함)
        """
        # 노이즈 제거 / 길이가 매우 짧은 경우
        if length < min_length:
            return noise_wight

        x = (length - L0) / tau
        return 1 / (1 + math.exp(-x))

    async def execute_reranking(
        self,
        queries: list[str],
        base_query: str | None,
        documents: list[list[qdrant.DocumentInfo]],
        target: str,
        include_file_name: bool,
        include_boost_keywords: bool,
        include_summary: bool,
        top_n: int,
        penalty: qdrant.Penalty,
    ) -> list[list[qdrant.DocumentInfo]]:
        reranked_docs = []  # 최종 재정렬 문서(포인트, 청크) 리스트
        reranker = Reranker()

        # base_query를 사용하는 경우 documents 평탄화 작업(내부 리스트 하나로 합치기)
        if base_query:
            documents = [[item for doc in documents for item in doc]]

        for idx, _documents in enumerate(documents):
            _reranked_docs = []
            if len(_documents) > 0:
                # Hybrid 검색결과 중복 문서 제거
                _dedup_docs = await self.deduplicate_rerank_target(_documents)

                # Rerank전 문서 전처리(검색키워드, 요약정보 등 추가)
                _preproc_docs = []
                for doc in _dedup_docs:
                    _payload = doc.get("payload")
                    _file_name = _payload.get("file") if include_file_name else None
                    _keyword = (
                        _payload.get("boost_keywords")
                        if include_boost_keywords
                        else None
                    )
                    _summary = _payload.get("summary") if include_summary else None
                    _content = _payload.get(target)

                    parts = [_file_name, _keyword, _summary, _content]
                    content = "\n".join([p.strip() for p in parts if p])
                    _preproc_docs.append(content)

                # Rerank API(GPU-vLLM) 요청
                ## 리랭크 모델 최대 토큰 사이즈 초과 방지를 위한 배치작업
                rerank_batch_size = settings.RERANK_BATCH_SIZE
                rerank_results: list = []
                for s_idx in range(0, len(_preproc_docs), rerank_batch_size):
                    batch_docs = _preproc_docs[s_idx : s_idx + rerank_batch_size]
                    rerank_response = await reranker.arerank(
                        query=base_query if base_query else queries[idx],
                        documents=batch_docs,
                        top_n=len(batch_docs),
                    )
                    batch_results = rerank_response.get("results", [])
                    for _result in batch_results:
                        _result["index"] = _result.get("index") + s_idx
                    rerank_results.extend(batch_results)

                # 짧은 문장에 대한 패널티 적용여부
                if penalty.is_active:
                    L0 = penalty.criteria
                    tau = penalty.insenstivity
                    min_length = penalty.min_length
                    noise_wight = penalty.noise_weight

                    _rerank_results = []
                    for _result in rerank_results:
                        score = _result.get("relevance_score")
                        penalty_weight = await self.calculate_sigmoid_penalty(
                            _dedup_docs[_result.get("index")]
                            .get("payload")
                            .get("child_chunk_length"),
                            L0,
                            tau,
                            min_length,
                            noise_wight,
                        )
                        _result["relevance_score"] = score * penalty_weight
                        _rerank_results.append(_result)
                    rerank_results = sorted(
                        _rerank_results,
                        key=lambda x: x.get("relevance_score"),
                        reverse=True,
                    )

                # 최종 결과 중복체크(target 이 text인 경우 재정렬 할 내용과 최종 참고할 내용이 다르므로 한 번 중복체크 필요)
                _included_values: set[str] = set()
                for result in rerank_results:
                    _idx = result.get("index")
                    _doc = _dedup_docs[_idx]

                    _parent_id = _doc.get("payload").get("parent_id")
                    if _parent_id in _included_values:
                        continue

                    _included_values.add(_parent_id)
                    # Rerank 결과의 score로 변경
                    _doc["score"] = result.get("relevance_score")
                    _reranked_docs.append(_doc)
                    if len(_reranked_docs) == top_n:
                        break
                reranked_docs.append(_reranked_docs)

        return reranked_docs
