import logging

from qdrant_client import models

from app.handlers.retrieval import RetrievalHandler
from app.schemas import qdrant

logger = logging.getLogger("rag-was.handlers.tuning")


class TuningHandler:
    def __init__(self):
        self.retrieval_handler = RetrievalHandler()

    async def process_points_tunning(
        self,
        collection_name: str,
        tunning_info: qdrant.TunningInfo,
        client,
    ) -> dict:
        logger.info(
            f"process_points_tunning called | {collection_name=} | {tunning_info=}"
        )

        result = {}
        for point_id in tunning_info.point_ids:
            # 1. Retrieve a point
            res_point = await client.retrieve(
                collection_name=collection_name,
                ids=[point_id],
                with_payload=True,
                with_vectors=True,
            )
            point = res_point[0] if res_point else None
            if not point:
                result[point_id] = "포인트를 찾지 못했습니다. ID를 확인해주세요."
                continue

            # 2. Embed Sparse Vector
            embedding_text = (
                f"{tunning_info.boost_keywords} {point.payload.get('text')}"
            )
            bm25_embeddings = await self.retrieval_handler.bm25_sparse_embed(
                queries=[embedding_text]
            )

            if len(bm25_embeddings) <= 0:
                result[point_id] = "Sparse Embedding 실패"
                continue
            sparse_vecs = bm25_embeddings[0].get("sparse_vecs")
            indices = sparse_vecs["indices"].tolist()
            values = sparse_vecs["values"].tolist()

            # 3. Update Sparse Vector
            vector_updated_point = models.PointVectors(
                id=point_id,
                vector={
                    "kiwi_bm25": models.SparseVector(indices=indices, values=values)
                },
            )
            vector_update_res = await client.update_vectors(
                collection_name=collection_name,
                points=[vector_updated_point],
            )
            if vector_update_res.status.value != "completed":
                result[point_id] = "Vector 업데이트 실패"
                continue

            # 4. Add Payload - boost_keyword
            payload_update_res = await client.set_payload(
                collection_name=collection_name,
                payload={"boost_keywords": tunning_info.boost_keywords},
                points=[point_id],
            )
            if payload_update_res.status.value != "completed":
                result[point_id] = "Payload 업데이트 실패"
                continue

            result[point_id] = "업데이트 성공"
        return result
