import logging

from fastapi import HTTPException, status
from qdrant_client import models
from qdrant_client.http.exceptions import UnexpectedResponse

from app.schemas import qdrant

logger = logging.getLogger("rag-was.handlers.point")


class PointHandler:
    async def get_must_filter(self, filter_conditions: dict):
        return models.Filter(
            must=[
                models.FieldCondition(key=k, match=models.MatchValue(value=v))
                for k, v in filter_conditions.items()
                if v is not None
            ]
        )

    async def scroll_points_by_file(
        self,
        collection_name: str,
        search_info: qdrant.FileSearchInfo,
        client,
    ) -> dict:
        logger.info(
            f"scroll_points_by_file called | {collection_name=} |{search_info=}"
        )
        # 필터 조건
        filter_conditions = {
            "file": search_info.file_name,
            "page_num": search_info.page_num,
            "parent_idx": search_info.parent_idx,
        }
        _filter = await self.get_must_filter(filter_conditions)

        # 전체 point(chunk)개수 확인
        search_limit = search_info.limit
        if search_limit == 0:
            try:
                count_res = await client.count(
                    collection_name=collection_name,
                    count_filter=_filter,
                    exact=True,
                )
                search_limit = count_res.count
            except UnexpectedResponse as e:
                logger.warning(
                    f"Qdrant unexpected response during count points. | {collection_name=} | file={search_info.file_name} | err={e}"
                )
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail="Invalid response from Qdrant service",
                )
            except Exception as e:
                logger.exception(
                    f"Failed to count points. | {collection_name=} | file={search_info.file_name} | err={e}"
                )
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Failed to count points.",
                )

        # 포인트 검색
        if search_limit == 0:
            return {
                "total_points_count": 0,
                "points": [],
                "next_offset": None,
            }
        try:
            points, next_offset = await client.scroll(
                collection_name=collection_name,
                scroll_filter=_filter,
                limit=search_limit,
                offset=search_info.offset,
            )
            return {
                "points_count": len(points),
                "points": points,
                "next_offset": next_offset,
            }
        except UnexpectedResponse as e:
            logger.exception(
                f"Qdrant unexpected response on scroll_points_by_file | {collection_name=} | file={search_info.file_name} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant service",
            )
        except Exception as e:
            logger.exception(
                f"Failed scroll_points_by_file | {collection_name=} | file={search_info.file_name} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to scroll points by file",
            )

    async def retrieve_a_point(
        self, collection_name: str, point_id: str, client
    ) -> dict:
        logger.info(f"retrieve_a_point called | {collection_name=} | {point_id=}")
        try:
            res = await client.retrieve(
                collection_name=collection_name,
                ids=[point_id],
                with_payload=True,
                with_vectors=True,
            )
            return {"result": res[0] if res else None}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on retrieve_a_point | collection={collection_name} | id={point_id} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant service",
            )
        except Exception as e:
            logger.exception(
                f"Failed to retrieve point | collection={collection_name} | id={point_id} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to retrieve point '{point_id}' from collection '{collection_name}'",
            )

    async def delete_points(
        self,
        collection_name: str,
        delete_info: qdrant.DeletePoints,
        client,
    ) -> dict:
        logger.info(f"delete_points called | {collection_name=} | {delete_info=}")
        try:
            if delete_info.del_criteria == "ids":
                if not delete_info.ids:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="When del_criteria is 'ids', 'ids' field must not be empty.",
                    )
                points_selector = models.PointIdsList(points=delete_info.ids)
            else:  # delete_info.del_criteria == "files"
                if not delete_info.files:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="When del_criteria is 'files', 'files' field must not be empty.",
                    )
                points_selector = models.FilterSelector(
                    filter=models.Filter(
                        must=[
                            models.FieldCondition(
                                key="file",
                                match=models.MatchAny(any=delete_info.files),
                            )
                        ]
                    )
                )

            res = await client.delete(
                collection_name=collection_name,
                points_selector=points_selector,
            )
            return {"status": res.status.value}
        except HTTPException:
            raise
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on delete_points | {collection_name=} | {delete_info=} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Invalid response from Qdrant service",
            )
        except Exception as e:
            logger.exception(
                f"Failed to delete points | {collection_name=} | {delete_info=} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete points",
            )

    async def add_next_points(
        self,
        final_docs: list[list[qdrant.DocumentInfo]],
        collection_name: str,
        added_chunk_max_size: int,
        client,
    ):
        logger.info(
            f"add_next_points called | {collection_name=} | {added_chunk_max_size=}"
        )
        for _docs in final_docs:
            for _doc in _docs:
                _doc_payload = _doc.get("payload")
                _filter = await self.get_must_filter(
                    {
                        "file": _doc_payload.get("file"),
                        "parent_idx": int(_doc_payload.get("parent_idx")) + 1,
                    }
                )
                add_points, next_offset = await client.scroll(
                    collection_name=collection_name,
                    scroll_filter=_filter,
                    limit=1,
                )
                # 추가 검색 결과(다음 포인트)가 없는 경우 PASS
                if not add_points:
                    continue
                add_point = add_points[0]
                logger.debug(
                    f">> Scroll add point | file={_doc_payload.get('file')}, parent_idx={_doc_payload.get('parent_idx')}"
                )

                # 사용자 설정 최대 청크 크기를 넘어가는 경우 PASS
                if (
                    parent_chunk_length := (
                        int(_doc_payload.get("parent_chunk_length"))
                        + int(add_point.payload.get("parent_chunk_length"))
                    )
                ) > added_chunk_max_size:
                    logger.debug(
                        f">> Over max chunk size | max_size({added_chunk_max_size}) < added_chunk_size({parent_chunk_length})"
                    )
                    continue
                _doc_payload["parent_text"] += add_point.payload.get("parent_text")
                _doc_payload["parent_chunk_length"] = parent_chunk_length

    async def add_points_for_generate_service(
        self,
        final_docs: list[list[qdrant.DocumentInfo]],  # TOP 1 하나만 전달
        collection_name: str,
        generate_pre_points_cnt: int,
        generate_next_points_cnt: int,
        client,
    ):
        logger.info(
            f"add_points_for_generate_service called | {collection_name=} | {generate_pre_points_cnt=} | {generate_next_points_cnt=}"
        )
        _parent_texts = []
        for _docs in final_docs:
            for _doc in _docs:
                _doc_payload = _doc.get("payload")
                _file = _doc_payload.get("file")
                _parent_idx = int(_doc_payload.get("parent_idx")) + 1
                for _idx in range(
                    _parent_idx - generate_pre_points_cnt,
                    _parent_idx + generate_next_points_cnt + 1,
                ):
                    if _idx == _parent_idx:
                        _parent_texts.append(_doc_payload.get("parent_text"))
                        logger.debug(
                            f">> Scroll add point | file={_file}, parent_idx={_idx}"
                        )
                    else:
                        _filter = await self.get_must_filter(
                            {
                                "file": _file,
                                "parent_idx": _idx,
                            }
                        )
                        _add_points, _next_offset = await client.scroll(
                            collection_name=collection_name,
                            scroll_filter=_filter,
                            limit=1,
                        )
                        # 추가 검색 결과(다음 포인트)가 없는 경우 PASS
                        if not _add_points:
                            continue
                        _add_point = _add_points[0]
                        _parent_texts.append(_add_point.payload.get("parent_text"))
                        logger.debug(
                            f">> Scroll add point | file={_file}, parent_idx={_idx}"
                        )
                # parent_text 업데이트
                _doc_payload["parent_text"] = "\n".join(_parent_texts)

    async def update_a_point_payload(
        self,
        collection_name: str,
        point_id: str,
        update_data: qdrant.UpdatePoint,
        client,
    ) -> dict:
        logger.info(
            f"update_a_point_payload called | {collection_name=} | {point_id=} | {update_data=}"
        )
        try:
            res = await client.set_payload(
                collection_name=collection_name,
                payload=update_data.payload,
                points=[point_id],
            )
            return {"status": res.status.value}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on update_a_point | collection={collection_name} | point_id={point_id} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Invalid response from Qdrant service during payload update. Check the {point_id=}",
            )
        except Exception as e:
            logger.exception(
                f"Failed to update payload | collection={collection_name} | point_id={point_id} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to update payload for point '{point_id}' in collection '{collection_name}'",
            )

    async def update_a_point_vectors(
        self,
        collection_name: str,
        point_id: str,
        update_data: qdrant.UpdatePoint,
        client,
    ) -> dict:
        logger.info(
            f"update_a_point_sparse_embedding called | {collection_name=} | {point_id=} | {update_data=}"
        )
        try:
            if update_data.embed_type == "sparse":
                vector_name = list(update_data.vector.keys())[0]
                v = update_data.vector[vector_name]
                point = models.PointVectors(
                    id=point_id,
                    vector={
                        vector_name: models.SparseVector(
                            indices=v.get("indices"), values=v.get("values")
                        )
                    },
                )
            else:  # "dense"
                point = models.PointVectors(id=point_id, vector=update_data.vector)

            res = await client.update_vectors(
                collection_name=collection_name,
                points=[point],
            )
            return {"status": res.status.value}
        except UnexpectedResponse as e:
            logger.warning(
                f"Qdrant unexpected response on update_vector | "
                f"collection={collection_name} | point_id={point_id} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Invalid response from Qdrant service during vector update. Check the {point_id=}",
            )
        except Exception as e:
            logger.exception(
                f"Failed to update point vector | collection={collection_name} | point_id={point_id} | err={e}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to update vector for point '{point_id}' in collection '{collection_name}'",
            )
