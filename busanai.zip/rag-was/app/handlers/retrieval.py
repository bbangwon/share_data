import logging
import time
from itertools import zip_longest

from fastapi import HTTPException, status
from qdrant_client import models

from app.core import settings
from app.schemas import qdrant
from app.services import JinaEmbeddingsV3
from app.state import AppState

logger = logging.getLogger("rag-was.handlers.retrieval")


class RetrievalHandler:
    async def bge_dense_embed(
        self, queries: list[str], ouptuts: list[str] | tuple[str] = ["dense"]
    ) -> list:
        logger.debug("Generating Dense(BGE-M3) Embeddings")
        bge_embeddings = [
            await AppState.bge_embedder.aquery_embed(query, ouptuts)
            for query in queries
        ]
        return bge_embeddings

    async def jina_dense_embed(self, queries: list[str]) -> list:
        # GPU 서버(vllm)로 API 요청
        logger.debug("Generating Dense(Jina-Embeddings-V3) Embeddings")
        embedder = JinaEmbeddingsV3()
        embed_response = await embedder.aembed(queries=queries)
        jina_embeddings = [
            {"dense_vecs": _data.get("embedding")}
            for _data in embed_response.get("data")
        ]
        return jina_embeddings

    async def bm25_sparse_embed(self, queries: list[str]) -> list:
        logger.debug("Generating Sparse(BM25) Embeddings")
        bm25_embeddings = [
            await AppState.bm25_embedder.aquery_embed(query) for query in queries
        ]
        return bm25_embeddings

    async def get_embedded_queries(
        self, dense_embeddings: list[dict] = [], sparse_embeddings: list[dict] = []
    ) -> list[dict]:
        return [
            {
                "dense_vecs": dense_embed.get("dense_vecs") if dense_embed else None,
                "sparse_vecs": sparse_embed.get("sparse_vecs")
                if sparse_embed
                else None,
            }
            for dense_embed, sparse_embed in zip_longest(
                dense_embeddings, sparse_embeddings
            )
        ]

    async def get_semantic_retrieve_params(
        self,
        collection_name: str,
        queries: list[str],
        final_limit: int,
        dense_type: str,
        dense_name: str,
    ) -> list[dict]:
        dense_embeddings = (
            await self.bge_dense_embed(queries)
            if dense_type == "bge"
            else await self.jina_dense_embed(queries)  # dense_type == "jina"
        )
        embedded_queries = await self.get_embedded_queries(
            dense_embeddings=dense_embeddings
        )
        retrieve_params = [
            {
                "collection_name": collection_name,
                "query": query.get("dense_vecs"),
                "using": dense_name,
                "limit": final_limit,
            }
            for query in embedded_queries
        ]
        return retrieve_params

    async def get_lexical_retrieve_params(
        self,
        collection_name: str,
        queries: list[str],
        final_limit: int,
        sparse_type: str,
        sparse_name: str,
    ) -> list[dict]:
        sparse_embeddings = (
            await self.bm25_sparse_embed(queries)
            if sparse_type == "bm25"
            else await self.bm25_sparse_embed(queries)  # 현재는 bm25만 지원
        )
        embedded_queries = await self.get_embedded_queries(
            sparse_embeddings=sparse_embeddings
        )
        retrieve_params = [
            {
                "collection_name": collection_name,
                "query": models.SparseVector(**query.get("sparse_vecs")),
                "using": sparse_name,
                "limit": final_limit,
            }
            for query in embedded_queries
        ]
        return retrieve_params

    async def get_hybrid_retrieve_params(
        self,
        collection_name: str,
        queries: list[str],
        dense_limit: int,
        sparse_limit: int,
        final_limit: int,
        dense_type: str,
        dense_name: str,
        sparse_type: str,
        sparse_name: str,
    ) -> list[dict]:
        dense_embeddings = (
            await self.bge_dense_embed(queries)
            if dense_type == "bge"
            else await self.jina_dense_embed(queries)  # dense_type == "jina"
        )
        sparse_embeddings = (
            await self.bm25_sparse_embed(queries)
            if sparse_type == "bm25"
            else await self.bm25_sparse_embed(queries)  # 현재는 bm25만 지원
        )
        embedded_queries = await self.get_embedded_queries(
            dense_embeddings, sparse_embeddings
        )

        retrieve_params = [
            {
                "collection_name": collection_name,
                "prefetch": [
                    models.Prefetch(
                        query=query.get("dense_vecs"),
                        using=dense_name,
                        limit=dense_limit,
                    ),
                    models.Prefetch(
                        query=models.SparseVector(**query.get("sparse_vecs")),
                        using=sparse_name,
                        limit=sparse_limit,
                    ),
                ],
                "query": models.FusionQuery(fusion=models.Fusion.DBSF),
                "limit": final_limit,
            }
            for query in embedded_queries
        ]
        return retrieve_params

    async def get_results(
        self,
        queries: list[str],
        base_query: str | None,
        documents: list[list[qdrant.DocumentInfo]],
    ) -> list[qdrant.RetrieveResult]:
        if base_query:
            return [{"query": base_query, "retrieved_documents": documents[0]}]
        return [
            {"query": query, "retrieved_documents": _documents}
            for query, _documents in zip(queries, documents)
        ]

    async def retrieve(
        self,
        client,
        search_info: qdrant.SearchInfo,
    ) -> dict:
        t_start_total = time.perf_counter()  # 시간측정 - 검색 전체 시작

        queries = search_info.queries
        collection_name = search_info.collection_name or settings.COLLECTION_NAME
        retrieve_type = (
            search_info.retrieve_type or settings.RETRIEVE_TYPE
        )  # >> Literal["semantic", "lexical", "hybrid"]
        dense_limit = search_info.dense_limit or settings.DENSE_LIMIT
        sparse_limit = search_info.sparse_limit or settings.SPARSE_LIMIT
        final_limit = search_info.final_limit or settings.FINAL_LIMIT
        dense_embedding = search_info.dense_embedding or qdrant.DenseEmbedding(
            type=settings.DENSE_TYPE,  # >> Literal["bge", "jina"]
            name=settings.DENSE_NAME,
        )
        sparse_embedding = search_info.sparse_embedding or qdrant.SparseEmbedding(
            type=settings.SPARSE_TYPE,  # >> Literal["bm25"]
            name=settings.SPARSE_NAME,
        )
        filters = search_info.filters or (
            [
                qdrant.QueryFilter(type=t, key=k, values=v)
                for t, k, v in zip(
                    settings.DEFAULT_FILTER_TYPES,
                    settings.DEFAULT_FILTER_KEYS,
                    settings.DEFAULT_FILTER_VALUES,
                )
            ]
            if settings.USE_DEFAULT_FILTER
            else None
        )

        # 검색 타입에 따른 문서 검색 준비
        logger.info(
            f"retrieve called | {collection_name=}, {retrieve_type=}, {final_limit=}, {queries=}"
        )

        t_start_embed = time.perf_counter()  ## 시간측정 - 임베딩 시작
        if retrieve_type == "semantic":
            retrieve_params = await self.get_semantic_retrieve_params(
                queries=queries,
                collection_name=collection_name,
                final_limit=final_limit,
                dense_type=dense_embedding.type,
                dense_name=dense_embedding.name,
            )
        elif retrieve_type == "lexical":
            retrieve_params = await self.get_lexical_retrieve_params(
                queries=queries,
                collection_name=collection_name,
                final_limit=final_limit,
                sparse_type=sparse_embedding.type,
                sparse_name=sparse_embedding.name,
            )
        else:  # elif retrieve_type == "hybrid": # (default)
            reranking = search_info.reranking or qdrant.Reranking(
                is_active=settings.RERANK_IS_ACTIVE,
                target=settings.RERANK_TARGET,
                include_file_name=settings.RERANK_INCLUDE_FILE_NAME,
                include_boost_keywords=settings.RERANK_INCLUDE_BOOST_KEYWORDS,
                include_summary=settings.RERANK_INCLUDE_SUMMARY,
            )
            retrieve_params = await self.get_hybrid_retrieve_params(
                queries=queries,
                collection_name=collection_name,
                dense_limit=dense_limit,
                sparse_limit=sparse_limit,
                final_limit=(dense_limit + sparse_limit)
                if reranking.is_active
                else final_limit,
                dense_type=dense_embedding.type,
                dense_name=dense_embedding.name,
                sparse_type=sparse_embedding.type,
                sparse_name=sparse_embedding.name,
            )
        t_end_embed = time.perf_counter()  ## 시간측정 - 임베딩 종료

        # 문서 검색
        logger.debug("Retrieving documents from Qdrant")

        t_start_retrieval = time.perf_counter()  ## 시간측정 - VDB 검색 시작

        # 필터링 조건 확인 및 추가
        must_filters = []
        must_not_filters = []
        for filter in filters:
            if filter.type == "must":
                must_filters.append(
                    models.FieldCondition(
                        key=filter.key,
                        match=models.MatchAny(any=filter.values),
                    )
                )
            else:  # filter.type == "must_not":
                must_not_filters.append(
                    models.FieldCondition(
                        key=filter.key,
                        match=models.MatchAny(any=filter.values),
                    )
                )

        retrieved_docs: list[list[qdrant.DocumentInfo]] = [
            (
                await client.query_points(
                    **retrieve_param,
                    query_filter=models.Filter(
                        must=must_filters if must_filters else None,
                        must_not=must_not_filters if must_not_filters else None,
                    ),
                )
            )
            .model_dump()
            .get("points")
            for retrieve_param in retrieve_params
        ]
        t_end_retrieval = time.perf_counter()  ## 시간측정 - VDB 검색 종료

        return {
            "retrieved_docs": retrieved_docs,
            "t_start_total": t_start_total,
            "t_embed_latency": t_end_embed - t_start_embed,
            "t_retrieval_latency": t_end_retrieval - t_start_retrieval,
        }

    async def embed_sparse_bm25(self, text: str) -> dict:
        logger.info(f"embed_sparse_bm25 called | {text=}")
        try:
            bm25_embeddings = await self.bm25_sparse_embed(queries=[text])
            result = {"values": [], "indices": []}
            if len(bm25_embeddings) > 0:
                sparse_vecs = bm25_embeddings[0].get("sparse_vecs")
                result["indices"] = sparse_vecs["indices"].tolist()
                result["values"] = sparse_vecs["values"].tolist()
            return result
        except ValueError as e:
            # 입력 형식 오류 / 사전 검증 오류 등
            logger.warning(f"bm25 embedding value error | text={text!r} | err={e}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid input for BM25 embedding: {str(e)}",
            )
        except Exception as e:
            # 예측 불가능한 모든 예외
            logger.exception(f"bm25 embedding failed | text={text!r} | err={e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to generate BM25 sparse embeddings",
            )
