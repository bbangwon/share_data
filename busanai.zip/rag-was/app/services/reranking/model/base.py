import asyncio
import logging
import os
from abc import ABC, abstractmethod
from typing import Any, Literal, Sequence


class BaseRerankigModel(ABC):
    """
    비동기 Reranker의 표준 추상 클래스.

    - 구현 필수:
        * _aload(): 모델/리소스 비동기 로딩(필요 시)
        * _acompute_score(text_pairs): (query, passage) 쌍에 대한 점수 리스트 반환
        * aget_reranked_top_k(...): 상위 K 문서 재정렬 로직

    - 제공:
        * get_reranked_top_k(...): 동기 래퍼(동기 컨텍스트에서만 사용)
        * 공용 cache_dir / logger / 디렉토리 준비
    """

    cache_dir = os.path.join(os.getcwd(), ".cache_dir")
    logger = logging.getLogger("rag-was.reranker.base")

    def __init__(self):
        self.logger.info("BaseRerankigModel 생성자 호출")
        self._mkdir_cache_dir()

    def _mkdir_cache_dir(self) -> None:
        os.makedirs(self.cache_dir, exist_ok=True)
        self.logger.info(f"캐시 디렉토리 생성 또는 존재: {self.cache_dir}")

    # ---------------------------
    # lifecycle
    # ---------------------------
    @abstractmethod
    async def _aload(self) -> None:
        """필요 시 모델/리소스 로딩을 수행 (비동기)."""
        raise NotImplementedError()

    # ---------------------------
    # abstract scoring API
    # ---------------------------
    @abstractmethod
    async def _acompute_score(
        self,
        texts: Sequence[Sequence[str]] | Sequence[tuple[str, str]],
        *,
        normalize: bool = True,
    ) -> list[tuple[int, float]]:
        """
        (query, passage) 페어 리스트에 대한 점수 계산.
        반환 형식 예시: [(origin_idx, score), ...]
        """
        raise NotImplementedError()

    # ---------------------------
    # abstract public API
    # ---------------------------
    @abstractmethod
    async def aget_reranked_top_k(
        self,
        query: str,
        documents: list[dict[str, Any]],
        k: int = 5,
        target: Literal["text", "parent_text"] = "text",
    ) -> list[list[dict[str, Any]]]:
        """
        구현체가 재정렬 로직(중복 제거, 점수 계산, 상위 k 선별)을 정의.
        반환 형식은 기존 호환성을 위해 list[list[dict]] 로 유지.
        """
        raise NotImplementedError()

    # ---------------------------
    # sync wrapper (optional)
    # ---------------------------
    def _ensure_no_running_loop(self) -> None:
        """비동기 컨텍스트에서 동기 래퍼 사용 방지."""
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return  # 이벤트 루프 없음 → 동기 OK
        raise RuntimeError(
            "get_reranked_top_k()는 동기 컨텍스트에서만 사용하세요. "
            "비동기 컨텍스트에서는 aget_reranked_top_k()를 await 하세요."
        )

    def get_reranked_top_k(
        self,
        query: str,
        documents: list[dict[str, Any]],
        k: int = 5,
        target: Literal["text", "parent_text"] = "text",
    ) -> list[list[dict[str, Any]]]:
        """동기 코드 호환용 래퍼."""
        self._ensure_no_running_loop()
        return asyncio.run(
            self.aget_reranked_top_k(query, documents, k=k, target=target)
        )
