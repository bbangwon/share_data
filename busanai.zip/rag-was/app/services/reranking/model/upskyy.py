import asyncio
import logging
import os
from functools import partial
from typing import Literal, Sequence

from FlagEmbedding import FlagReranker

MODEL_NAME = "upskyy/ko-reranker-8k"


class UpskyyReranker:
    """
    - 비동기 생성: await UpskyyReranker.create()
    - 점수 계산: await _acompute_score(...)
    - Top-K 재정렬: await aget_reranked_top_k(...)
    - compute_score는 동기 CPU/GPU 작업이므로 asyncio.to_thread로 오프로딩
    - 동일 세션 동시 접근 이슈를 피하기 위해 락 사용(환경에 따라 제거 가능)
    """

    logger = logging.getLogger("rag-was.reranker.upskyy")

    def __init__(self, cache_dir: str | None = None):
        self.model_name = MODEL_NAME
        self.cache_dir = cache_dir or os.path.join(os.getcwd(), ".cache_dir")
        os.makedirs(self.cache_dir, exist_ok=True)

        self.reranker: FlagReranker | None = None
        self._infer_lock = asyncio.Lock()

    # ---------------------------
    # Lifecycle (Async factory)
    # ---------------------------
    @classmethod
    async def create(cls, cache_dir: str | None = None) -> "UpskyyReranker":
        self = cls(cache_dir=cache_dir)
        await self._aload()
        return self

    async def _aload(self) -> None:
        """FlagReranker 로딩을 스레드로 오프로딩."""
        self.logger.info("UpskyyReranker 로딩 시작")
        load_reranker = partial(FlagReranker, self.model_name, cache_dir=self.cache_dir)
        self.reranker = await asyncio.to_thread(load_reranker)
        self.logger.info("UpskyyReranker 로딩 완료")

    # ---------------------------
    # Internal helpers
    # ---------------------------
    async def _acompute_score(
        self,
        texts: Sequence[Sequence[str]] | Sequence[tuple[str, str]],
        *,
        normalize: bool = True,
    ) -> list[tuple[int, float]]:
        """
        return: [(origin_idx, score), ...] (score 내림차순으로 정렬 X)
        """
        assert self.reranker is not None, "Reranker is not loaded."
        self.logger.debug(
            f"_acompute_score 호출 | pair 수={len(texts)}, normalize={normalize}"
        )

        compute = partial(self.reranker.compute_score, texts, normalize=normalize)
        async with self._infer_lock:
            scores = await asyncio.to_thread(compute)

        # 원본 인덱스와 함께 묶어서 반환
        return list(enumerate(scores))

    # ---------------------------
    # Public async API
    # ---------------------------
    async def aget_reranked_top_k(
        self,
        query: str,
        documents: list[dict],
        k: int = 5,
        target: Literal["text", "parent_text"] = "text",
    ) -> list[list[dict]]:
        """
        - Rerank 전: 동일 target 텍스트 중복 제거
        - Rerank: (query, target_text) 페어로 점수 계산
        - target == "text": 같은 parent_text 중복 제거하며 Top-k 축소
        - target == "parent_text": 상위 k개 선별
        - 반환 형식은 기존과 동일하게 [result] 로 래핑 유지
        """
        self.logger.debug(
            f"aget_reranked_top_k 호출 | query_len={len(query)}, docs={len(documents)}, k={k}, target={target}"
        )

        # 1) Rerank 전 중복 제거 (target 텍스트 기준)
        seen_texts: set[str] = set()
        dedup_docs: list[dict] = []
        for doc in documents:
            payload = doc.get("payload", {}) or {}
            text = payload.get(target)
            if not text or text in seen_texts:
                continue
            seen_texts.add(text)
            dedup_docs.append(doc)

        # 2) (query, text) 페어 생성 후 점수 계산
        pairs = [(query, d.get("payload", {}).get(target)) for d in dedup_docs]
        idxs_scores = await self._acompute_score(pairs, normalize=True)

        # 점수 내림차순 정렬
        idxs_scores.sort(key=lambda x: x[1], reverse=True)

        # 3) 최종 중복 제거 및 상위 k 선택
        result: list[dict] = []
        if target == "text":
            seen_parent: set[str] = set()
            for idx, score in idxs_scores:
                doc = dedup_docs[idx]
                parent_text = (doc.get("payload", {}) or {}).get("parent_text")
                if parent_text in seen_parent:
                    continue
                # 원본 doc 변조 방지를 원하면 shallow copy 사용
                out = dict(doc)
                out["score"] = float(score)
                result.append(out)
                if parent_text:
                    seen_parent.add(parent_text)
                if len(result) == k:
                    break
        else:  # target == "parent_text"
            for idx, score in idxs_scores[:k]:
                doc = dedup_docs[idx]
                out = dict(doc)
                out["score"] = float(score)
                result.append(out)

        return [result]
