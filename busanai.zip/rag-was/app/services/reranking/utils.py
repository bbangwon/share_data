import logging
from typing import Any

import httpx

from app.core import settings

from . import schemas

logger = logging.getLogger("rag-was.reranking.utils")


class Reranker:
    BASE_URL = settings.GPU_SERVER_URL

    def __init__(self, timeout: int | None = None):
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        self.timeout = timeout or settings.GPU_TIMEOUT

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.BASE_URL}{endpoint}"
        logger.info(f"Request: {method} {url}")
        logger.debug(f"Request: {method} {url} | params={params} | json={json}")
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=self.headers,
                    params=params,
                    json=json,
                )
                logger.info(f"Response: {response.status_code} {url}")
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(
                f"HTTP error for {method} {url}: {e.response.status_code} - {e.response.text}"
            )
            raise
        except Exception as e:
            logger.exception(f"Unexpected error during {method} {url}: {e}")
            raise

    async def arerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
        model: str = settings.RERANK_MODEL_NAME,  # "bge-reranker-v2-m3-ko"
    ):
        logger.info(f"rerank called | {query=}")
        response = await self._request(
            method="POST",
            endpoint="/v1/rerank",
            json=schemas.RequestVllmRerank(
                query=query,
                documents=documents,
                top_n=top_n,
                model=model,
            ).model_dump(exclude_none=True),
        )

        return schemas.ResponseVllmRerank.model_validate(response).model_dump()
