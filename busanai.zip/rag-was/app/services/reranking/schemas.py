from pydantic import BaseModel


class RequestVllmRerank(BaseModel):
    model: str
    query: str
    documents: list[str]
    top_n: int


class Usage(BaseModel):
    total_tokens: int


class Document(BaseModel):
    text: str
    multi_modal: None


class RerankResult(BaseModel):
    index: int
    document: Document
    relevance_score: float


class ResponseVllmRerank(BaseModel):
    id: str
    model: str
    usage: Usage
    results: list[RerankResult]
