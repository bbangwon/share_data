from typing import Any

from pydantic import BaseModel


class RequestVllmEmbed(BaseModel):
    model: str
    input: list[str]


class Usage(BaseModel):
    prompt_tokens: int
    total_tokens: int
    completion_tokens: int
    prompt_tokens_details: Any


class EmbeddingResult(BaseModel):
    index: int
    object: str
    embedding: list[float]


class ResponseVllmEmbed(BaseModel):
    id: str
    object: str
    created: int
    model: str
    data: list[EmbeddingResult]
    usage: Usage
