import asyncio
import logging
import os
from abc import ABC, abstractmethod
from typing import Any, Dict


class BaseEmbeddingModel(ABC):
    """
    - 표준 비동기 API: aembed(), aquery_embed()  (반드시 구현)
    - 동기 호환 래퍼: embed(), query_embed()     (이벤트 루프가 없을 때만 사용)
    """

    cache_dir = os.path.join(os.getcwd(), ".cache_dir")
    logger = logging.getLogger("rag-was.embedding.base")

    def __init__(self):
        self.logger.info("BaseEmbeddingModel 생성자 호출")
        self._mkdir_cache_dir()

    def _mkdir_cache_dir(self):
        os.makedirs(self.cache_dir, exist_ok=True)
        self.logger.info(f"캐시 디렉토리 생성 또는 존재: {self.cache_dir}")

    # ---------------------------
    # Abstract async APIs
    # ---------------------------
    @abstractmethod
    async def aembed(self, text: str) -> Dict[str, Any]:
        """
        비동기 임베딩 API.
        - 구현체는 CPU-bound 동기 작업(토큰화/추론 등)을 asyncio.to_thread(...)로 오프로딩하여
          이벤트 루프를 블로킹하지 않도록 해야 합니다.
        """
        raise NotImplementedError()

    @abstractmethod
    async def aquery_embed(self, text: str) -> Dict[str, Any]:
        """
        비동기 쿼리 임베딩 API (검색 쿼리용).
        """
        raise NotImplementedError()

    # ---------------------------
    # Sync wrappers (optional)
    # ---------------------------
    def _ensure_no_running_loop(self):
        """
        현재 컨텍스트에 실행 중인 이벤트 루프가 있으면 동기 래퍼 사용을 금지.
        (FastAPI 등의 async 핸들러 내부에서 embed()/query_embed() 호출을 방지)
        """
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            # 이벤트 루프 없음 (동기 컨텍스트) → OK
            return
        # 이벤트 루프가 이미 돌고 있음 → 동기 래퍼 사용 금지
        raise RuntimeError(
            "embed()/query_embed()는 동기 컨텍스트에서만 사용하세요. "
            "비동기 컨텍스트에서는 aembed()/aquery_embed()를 await 하세요."
        )

    def embed(self, text: str) -> Dict[str, Any]:
        """
        동기 코드 호환용 래퍼.
        - 스크립트/워커 등 동기 환경에서만 사용
        - 웹 서버의 async 핸들러 내부에서는 aembed()를 await 하세요.
        """
        self._ensure_no_running_loop()
        return asyncio.run(self.aembed(text))

    def query_embed(self, text: str) -> Dict[str, Any]:
        """
        동기 코드 호환용 래퍼.
        """
        self._ensure_no_running_loop()
        return asyncio.run(self.aquery_embed(text))
