import asyncio
import logging
from functools import partial
from typing import Any, Dict

import numpy as np
from sentence_transformers import SentenceTransformer

from .base import BaseEmbeddingModel

MODEL_NAME = "jinaai/jina-embeddings-v3"


class JinaEmbeddingsV3(BaseEmbeddingModel):
    """
    - 비동기 생성: await JinaEmbeddingsV3.create()
    - 문서 임베딩: await aembed(text)           -> task="retrieval.passage"
    - 쿼리 임베딩: await aquery_embed(text)     -> task="retrieval.query"
    - 반환 포맷: {"dense_vecs": np.ndarray}
    """

    logger = logging.getLogger("rag-was.embedding.jina_v3")

    def __init__(self):
        super().__init__()
        self.model: SentenceTransformer | None = None
        self._infer_lock = asyncio.Lock()

    @classmethod
    async def create(cls) -> "JinaEmbeddingsV3":
        self = cls()
        await self._aload()
        return self

    async def _aload(self) -> None:
        self.logger.info("JinaEmbeddingsV3 생성자 호출 - 모델 로딩 시작")
        load_model = partial(
            SentenceTransformer,
            MODEL_NAME,
            trust_remote_code=True,
            device="cpu",
            cache_folder=self.cache_dir,
            local_files_only=True,
        )
        self.model = await asyncio.to_thread(load_model)
        self.logger.info("SentenceTransformer 로딩 완료")

    async def _aencode(
        self,
        text: str,
        *,
        task: str,
        normalize: bool = True,
    ) -> np.ndarray:
        """
        SentenceTransformer.encode를 스레드로 오프로딩.
        Jina v3는 task별 LoRA 어댑터를 사용하므로 task & prompt_name을 함께 지정.
        """
        assert self.model is not None, "Model is not loaded."
        self.logger.debug(
            f"_aencode 호출 | len={len(text)}, task={task}, normalize={normalize}"
        )

        encode_call = partial(
            self.model.encode,
            [text],  # sentence-transformers는 리스트 입력을 권장
            task=task,
            prompt_name=task,  # 문서화된 샘플과 동일하게 지정
            batch_size=1,
            convert_to_numpy=True,
            normalize_embeddings=normalize,  # 코사인 유사도 검색에 유리
            show_progress_bar=False,
        )

        async with self._infer_lock:
            vecs = await asyncio.to_thread(encode_call)

        # 단일 텍스트 입력이므로 1 x d -> d 로 변환
        return np.asarray(vecs).squeeze()

    # ---------------------------
    # Async public APIs
    # ---------------------------
    async def aembed(self, text: str) -> Dict[str, Any]:
        """인덱싱/문서 임베딩: retrieval.passage 어댑터 사용."""
        self.logger.debug(f"aembed 호출 | text 길이: {len(text)}")
        dense = await self._aencode(text, task="retrieval.passage", normalize=True)
        result = {"dense_vecs": dense}
        self.logger.debug(
            f"aembed 결과 keys: {list(result.keys())}, dense shape: {getattr(dense, 'shape', None)}"
        )
        return result

    async def aquery_embed(self, text: str) -> Dict[str, Any]:
        """검색 쿼리 임베딩: retrieval.query 어댑터 사용."""
        self.logger.debug(f"aquery_embed 호출 | text 길이: {len(text)}")
        dense = await self._aencode(text, task="retrieval.query", normalize=True)
        result = {"dense_vecs": dense}
        self.logger.debug(
            f"aquery_embed 결과 keys: {list(result.keys())}, dense shape: {getattr(dense, 'shape', None)}"
        )
        return result
