import asyncio
import logging
from functools import partial
from typing import Any, Dict

from fastembed import SparseTextEmbedding
from kiwipiepy import Kiwi

from .base import BaseEmbeddingModel

MODEL_NAME = "Qdrant/bm25"


class KiwiBm25Embedding(BaseEmbeddingModel):
    """
    - 비동기 생성: await KiwiBm25Embedding.create()
    - 비동기 임베딩: await aembed(text), await aquery_embed(text)
    - 동기 호환: embed(text), query_embed(text)  (동기 컨텍스트에서만 사용)
    """

    logger = logging.getLogger("rag-was.embedding.kiwi_bm25")

    def __init__(self):
        # 무거운 로딩은 _aload에서 처리
        self.tokenizer: Kiwi | None = None
        self.embed_model: SparseTextEmbedding | None = None
        self._infer_lock = asyncio.Lock()

    # ---------------------------
    # Lifecycle (Async factory)
    # ---------------------------
    @classmethod
    async def create(cls) -> "KiwiBm25Embedding":
        self = cls()
        await self._aload()
        return self

    async def _aload(self) -> None:
        """Kiwi / fastembed 로딩을 스레드로 오프로딩."""
        self.logger.info("KiwiBm25Embedding 생성자 호출")

        # partial로 인자 바인딩을 미리 해두면 가독성이 좋아집니다.
        load_tokenizer = partial(Kiwi)  # 인자 없지만 형태 일관성 유지
        load_embed_model = partial(
            SparseTextEmbedding,
            model_name=MODEL_NAME,
            cache_dir=self.cache_dir,
            export=False,
            local_files_only=True,
        )

        tok_task = asyncio.to_thread(load_tokenizer)
        fe_task = asyncio.to_thread(load_embed_model)

        self.tokenizer, self.embed_model = await asyncio.gather(tok_task, fe_task)
        self.logger.info("Kiwi 토크나이저 로딩 완료")
        self.logger.info("SparseTextEmbedding 모델 로딩 완료")

    # ---------------------------
    # Internal helpers
    # ---------------------------
    async def _atokenize(self, text: str) -> str:
        """품사 필터링 토큰화를 스레드로 오프로딩."""
        assert self.tokenizer is not None, "Tokenizer is not loaded."
        self.logger.debug(f"_tokenize 호출 | text 길이: {len(text)}")

        # tokenize 호출 자체만 스레드로 넘기고, 후처리는 메인에서 수행
        tokenize_call = partial(self.tokenizer.tokenize, text)
        tokens = await asyncio.to_thread(tokenize_call)

        tokenize_result = " ".join(
            [t.form for t in tokens if t.tag in ("NNG", "NNP", "SN", "SL")]
        )
        self.logger.debug(f"_tokenize 결과: {tokenize_result}")
        return tokenize_result

    async def _aembed_once(self, text_for_bm25: str, is_query: bool) -> Dict[str, Any]:
        """
        fastembed의 .embed/.query_embed는 제너레이터를 반환 → next(...) 호출 필요.
        메서드 선택 분기를 partial로 감싸 가독성을 높입니다.
        """
        assert self.embed_model is not None, "Embed model is not loaded."
        self.logger.debug(
            f"_aembed_once 호출 | len={len(text_for_bm25)}, is_query={is_query}"
        )

        # 호출할 메서드 선택 후, 인자 바인딩
        method = self.embed_model.query_embed if is_query else self.embed_model.embed
        call_embed_gen = partial(method, text_for_bm25)

        def _work():
            gen = call_embed_gen()  # generator 얻고
            emb = next(gen)  # 첫 결과만 사용
            return {"sparse_vecs": emb.as_object()}

        # 환경에 따라 세션 동시 접근 이슈를 예방하기 위해 락 사용(필요 없으면 제거 가능)
        async with self._infer_lock:
            return await asyncio.to_thread(_work)

    # ---------------------------
    # Async public APIs
    # ---------------------------
    async def aembed(self, text: str) -> Dict[str, Any]:
        self.logger.debug(f"aembed 호출 | text 길이: {len(text)}")
        tok = await self._atokenize(text)
        result = await self._aembed_once(tok, is_query=False)
        self.logger.debug(f"aembed 결과 keys: {list(result.keys())}")
        return result

    async def aquery_embed(self, text: str) -> Dict[str, Any]:
        self.logger.debug(f"aquery_embed 호출 | text 길이: {len(text)}")
        tok = await self._atokenize(text)
        result = await self._aembed_once(tok, is_query=True)
        self.logger.debug(f"aquery_embed 결과 keys: {list(result.keys())}")
        return result

    # ---------------------------
    # Sync wrappers (optional)
    # ---------------------------
    def embed(self, text: str) -> Dict[str, Any]:
        # 부모(BaseEmbeddingModel)의 정책을 따르려면 여기 제거하고 부모 래퍼만 써도 됩니다.
        try:
            asyncio.get_running_loop()
            raise RuntimeError(
                "embed()는 동기 컨텍스트에서만 사용하세요. 비동기 컨텍스트에서는 aembed()를 await 하세요."
            )
        except RuntimeError:
            # 이벤트 루프 없음 → OK
            return asyncio.run(self.aembed(text))

    def query_embed(self, text: str) -> Dict[str, Any]:
        try:
            asyncio.get_running_loop()
            raise RuntimeError(
                "query_embed()는 동기 컨텍스트에서만 사용하세요. 비동기 컨텍스트에서는 aquery_embed()를 await 하세요."
            )
        except RuntimeError:
            return asyncio.run(self.aquery_embed(text))
