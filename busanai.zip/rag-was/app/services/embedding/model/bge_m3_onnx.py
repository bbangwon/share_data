import asyncio
import logging
from collections import defaultdict
from functools import partial
from typing import Iterable

import numpy as np
from optimum.onnxruntime import ORTModelForCustomTasks
from transformers import AutoTokenizer

from .base import BaseEmbeddingModel

MODEL_NAME = "philipchung/bge-m3-onnx"


class BgeM3OnnxEmbedding(BaseEmbeddingModel):
    """
    - async 팩토리: await BgeM3OnnxEmbedding.create()
    - 비동기 임베딩: await aembed(...), await aquery_embed(...)
    - 동기 호환: embed(...), query_embed(...) (내부에서 to_thread 사용)
    """

    logger = logging.getLogger("rag-was.embedding.bge_m3_onnx")

    def __init__(self):
        # 무거운 로딩은 여기서 하지 않음 (비동기 로딩 메서드에서 처리)
        self.model_name = MODEL_NAME
        self.embed_model: ORTModelForCustomTasks | None = None
        self.tokenizer: AutoTokenizer | None = None
        # 동시 추론 안전을 위한 락 (필수는 아님, 환경에 따라 유용)
        self._infer_lock = asyncio.Lock()

    # ---------------------------
    # Lifecycle
    # ---------------------------
    @classmethod
    async def create(cls) -> "BgeM3OnnxEmbedding":
        """비동기 로딩을 포함한 생성자 대용 팩토리."""
        self = cls()
        await self._aload()
        return self

    async def _aload(self) -> None:
        """모델/토크나이저 비동기 로딩 (스레드 오프로딩)."""
        self.logger.info(f"BgeM3OnnxEmbedding 생성자 호출 - 모델명: {self.model_name}")

        # 로컬 캐시 디렉토리는 BaseEmbeddingModel에서 self.cache_dir 제공된다고 가정
        # (없다면 적절히 수정하세요)
        load_model = partial(
            ORTModelForCustomTasks.from_pretrained,
            self.model_name,
            provider="CPUExecutionProvider",
            cache_dir=self.cache_dir,
            export=False,
            local_files_only=True,
        )
        load_tokenizer = partial(
            AutoTokenizer.from_pretrained,
            self.model_name,
            cache_dir=self.cache_dir,
            local_files_only=True,
        )

        # 병렬 로딩
        model_task = asyncio.to_thread(load_model)
        tok_task = asyncio.to_thread(load_tokenizer)
        self.embed_model, self.tokenizer = await asyncio.gather(model_task, tok_task)

        self.logger.info("ORTModelForCustomTasks 모델 로딩 완료")
        self.logger.info("AutoTokenizer 로딩 완료")

    # ---------------------------
    # Internal helpers
    # ---------------------------
    def _process_sparse(
        self, input_ids: Iterable[int], token_weights: np.ndarray
    ) -> dict:
        assert self.tokenizer is not None, "Tokenizer is not loaded."
        _temp_result = defaultdict(float)
        unused = {
            self.tokenizer.cls_token_id,
            self.tokenizer.eos_token_id,
            self.tokenizer.pad_token_id,
            self.tokenizer.unk_token_id,
        }
        for idx, w in zip(input_ids, token_weights):
            if idx not in unused and w > 0 and w > _temp_result[idx]:
                _temp_result[idx] = float(w)
        return {
            "indices": list(dict(_temp_result).keys()),
            "values": list(dict(_temp_result).values()),
        }

    async def _atokenize(self, text: str) -> dict:
        """토큰화를 스레드로 오프로딩."""
        assert self.tokenizer is not None, "Tokenizer is not loaded."
        fn = partial(
            self.tokenizer,
            text,
            padding="longest",
            truncation=True,
            max_length=8192,
            return_tensors="np",
        )
        return await asyncio.to_thread(fn)

    async def _ainfer(self, tokenize_result: dict):
        """ONNX 추론을 스레드로 오프로딩 (+선택적 락)."""
        assert self.embed_model is not None, "Model is not loaded."
        # ORT는 멀티스레드를 잘 사용하지만, 환경에 따라 락이 유리할 수 있음
        async with self._infer_lock:
            fn = partial(self.embed_model.forward, **tokenize_result)
            return await asyncio.to_thread(fn)

    # ---------------------------
    # Async public APIs
    # ---------------------------
    async def aembed(
        self,
        text: str,
        outputs: list[str] | tuple[str, ...] = ("dense", "sparse", "colbert"),
    ) -> dict:
        self.logger.debug(f"aembed 호출 | text 길이: {len(text)}, outputs: {outputs}")
        tokenize_result = await self._atokenize(text)
        embed_result = await self._ainfer(tokenize_result)

        final_result = {}
        for output in outputs:
            if output == "dense":
                final_result["dense_vecs"] = embed_result.dense_vecs.astype(
                    np.float32
                ).squeeze()
            elif output == "sparse":
                final_result["sparse_vecs"] = self._process_sparse(
                    tokenize_result["input_ids"].squeeze().tolist(),
                    embed_result.sparse_vecs.astype(np.float32).squeeze(),
                )
            elif output == "colbert":
                final_result["colbert_vecs"] = embed_result.colbert_vecs.astype(
                    np.float32
                ).squeeze()

        self.logger.debug(
            f"aembed 결과 keys: {list(final_result.keys())}, "
            f"dense shape: {getattr(final_result.get('dense_vecs'), 'shape', None)}"
        )
        return final_result

    async def aquery_embed(
        self,
        text: str,
        outputs: list[str] | tuple[str, ...] = ("dense", "sparse", "colbert"),
    ) -> dict:
        self.logger.debug(
            f"aquery_embed 호출 | text 길이: {len(text)}, outputs: {outputs}"
        )
        return await self.aembed(text, outputs)

    # ---------------------------
    # Sync wrappers (optional)
    # ---------------------------
    def embed(
        self, text: str, outputs: list[str] = ["dense", "sparse", "colbert"]
    ) -> dict:
        """동기 코드와의 호환을 위해 제공. 내부에서 to_thread로 논블로킹 실행."""
        if self.embed_model is None or self.tokenizer is None:
            # 동기 컨텍스트에서 최초 사용 시 로딩 수행
            asyncio.run(self._aload())
        return asyncio.run(self.aembed(text, outputs))

    def query_embed(
        self, text: str, outputs: list[str] = ["dense", "sparse", "colbert"]
    ) -> dict:
        if self.embed_model is None or self.tokenizer is None:
            asyncio.run(self._aload())
        return asyncio.run(self.aquery_embed(text, outputs))
