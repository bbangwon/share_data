import logging
from typing import Any

import httpx

from app.core import settings

from . import schemas  # // TODO: vllm 임베딩 모델 io 확인 후 정의

logger = logging.getLogger("rag-was.embedding.utils")


class JinaEmbeddingsV3:
    BASE_URL = settings.GPU_SERVER_URL

    def __init__(self, timeout: int | None = None):
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        self.timeout = timeout or settings.GPU_TIMEOUT

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.BASE_URL}{endpoint}"
        logger.info(f"Request: {method} {url} | params={params} | json={json}")
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=self.headers,
                    params=params,
                    json=json,
                )
                logger.info(f"Response: {response.status_code} {url}")
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(
                f"HTTP error for {method} {url}: {e.response.status_code} - {e.response.text}"
            )
            raise
        except Exception as e:
            logger.exception(f"Unexpected error during {method} {url}: {e}")
            raise

    async def aembed(
        self,
        queries: list[str],
        model: str = settings.EMBED_MODEL_NAME,  # "jina-embeddings-v3"
    ):
        logger.info(f"embed called | {queries=}")
        response = await self._request(
            method="POST",
            endpoint="/v1/embeddings",
            json=schemas.RequestVllmEmbed(
                input=queries,
                model=model,
            ).model_dump(exclude_none=True),
        )

        return schemas.ResponseVllmEmbed.model_validate(response).model_dump()
