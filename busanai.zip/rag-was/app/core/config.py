import os
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

DEFAULT_ENV = "rag"


class Settings(BaseSettings):
    ENV: str = DEFAULT_ENV

    QDRANT_HOST: str
    QDRANT_PORT: int

    COLLECTION_NAME: str
    RETRIEVE_TYPE: str
    DENSE_LIMIT: int
    SPARSE_LIMIT: int
    FINAL_LIMIT: int

    DENSE_TYPE: str
    DENSE_NAME: str

    SPARSE_TYPE: str
    SPARSE_NAME: str

    GPU_SERVER_URL: str
    GPU_TIMEOUT: int
    EMBED_MODEL_NAME: str
    RERANK_MODEL_NAME: str
    RERANK_IS_ACTIVE: bool
    RERANK_TARGET: str
    RERANK_INCLUDE_FILE_NAME: bool
    RERANK_INCLUDE_BOOST_KEYWORDS: bool
    RERANK_INCLUDE_SUMMARY: bool
    RERANK_BATCH_SIZE: int

    PENALTY_IS_ACTIVE: bool
    PENALTY_CRITERIA: int
    PENALTY_INSENSTIVITY: int
    PENALTY_MIN_LENGTH: int
    PENALTY_NOISE_WEIGHT: int | float

    USE_DEFAULT_FILTER: bool
    DEFAULT_FILTER_TYPES: list
    DEFAULT_FILTER_KEYS: list
    DEFAULT_FILTER_VALUES: list

    ADD_NEXT_POINT: bool
    ADDED_CHUNK_MAX_SIZE: int
    ADD_POINTS_FOR_GENERATE_SERVICE: bool
    GENERATE_TOP_K: int
    GENERATE_PRE_POINTS_CNT: int
    GENERATE_NEXT_POINTS_CNT: int

    model_config = SettingsConfigDict(
        env_file=f".env.{os.getenv('ENV', DEFAULT_ENV)}",
        env_file_encoding="utf-8",
        extra="allow",
    )


@lru_cache
def get_settings():
    return Settings()


settings = get_settings()
