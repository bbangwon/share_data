import logging

from qdrant_client import AsyncQdrantClient

from app.core import settings

logger = logging.getLogger("rag-was.vectordb.qdrant_session")


async def _create_qdrant_client(timeout: int) -> AsyncQdrantClient:
    logger.info(
        f"QdrantClient 생성 | host={settings.QDRANT_HOST} | port={settings.QDRANT_PORT}, timeout={timeout}"
    )
    return AsyncQdrantClient(
        host=settings.QDRANT_HOST,
        port=settings.QDRANT_PORT,
        timeout=timeout,
    )


async def get_qdrant_client():
    """Qdrant 기본 클라이언트 (timeout=60s)"""
    timeout = 60
    client = await _create_qdrant_client(timeout=timeout)
    try:
        logger.info(f"AsyncQdrantClient({timeout}s) 세션 반환 (yield)")
        yield client
    finally:
        await client.close()
        logger.info(f"AsyncQdrantClient({timeout}s) 세션 종료 (close)")


async def get_long_qdrant_client():
    """Qdrant 롱텀 클라이언트 (timeout=180s)"""
    timeout = 180
    client = await _create_qdrant_client(timeout=timeout)
    try:
        logger.info(f"AsyncQdrantClient({timeout}s) 세션 반환 (yield)")
        yield client
    finally:
        await client.close()
        logger.info(f"AsyncQdrantClient({timeout}s) 세션 종료 (close)")
