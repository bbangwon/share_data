#!/bin/bash

: "${WORKERS:=4}"
exec gunicorn -w "$WORKERS" -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:8000 --reload
