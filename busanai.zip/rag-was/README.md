# README

#### Management
- 개발환경: `ENV=rag.test` / `.env.rag.test` 파일에 환경변수 관리
- 운영환경: `ENV=rag` / `.env.rag` 파일에 환경변수 관리

#### Running Command
- Uvicorn 실행
    ```sh
    ENV=rag.test uvicorn app.main:app --host 0.0.0.0 --port 18080 --reload

    ENV=rag uvicorn app.main:app --host 0.0.0.0 --port 18080 --reload
    ```
- Gunicorn + Uvicorn 실행
    ```sh
    # 워커 노드 수는 .env 파일에 `WORKER_COUNT` 환경변수로 세팅 권장
    ENV=rag.test gunicorn -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:18080 --reload

    ENV=rag gunicorn -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:18080 --reload
    ```
- `uv` 사용시 `ur run` 커맨드 사용 가능