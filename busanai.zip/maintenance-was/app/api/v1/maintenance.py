import logging
from datetime import datetime
from typing import Annotated
from urllib.parse import urlparse

from busan_bot_ui import BusanBotUIManager
from dotenv import load_dotenv
from fastapi import APIRouter, Body, Depends, Request, Response, status
from naver_works_bot import (
    ReceiveMessage,
    TextContent,
)
from request_queue import RequestQueueItem

from app.schemas.maintenance_request import MaintenanceRequest

load_dotenv()
# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/maintenance",
)


@router.post("")
async def maintenance(
    bot_manager: Annotated[BusanBotUIManager, Depends(BusanBotUIManager)],
    request: Request,
    received_message: Annotated[ReceiveMessage, Body(...)],
    start: datetime | None = None,  # 쿼리 파라미터로 받음
    end: datetime | None = None,  # 쿼리 파라미터로 받음
):
    # 유지보수 작업 수행
    headers = dict(request.headers)
    body_json = received_message.model_dump(exclude_none=True)

    # 헤더 정보
    logger.debug(f"[maintenance] 수신 헤더: {headers}")
    logger.debug(f"[maintenance] 수신 메시지: {body_json}")

    request_item = RequestQueueItem(headers=headers, body=body_json)

    bot_id = request_item.get_bot_id()
    user_id = request_item.get_user_id()

    logger.info(
        f"[maintenance] 수신 봇 ID: {bot_id}, 사용자 ID: {user_id}, 메시지: {body_json}"
    )

    # 서명, 봇 ID, 사용자 ID가 모두 존재하는지 확인 (잘못된 패킷이므로 사용자에게 에러를 보낼필요 없음)
    if not bot_id or not user_id:
        logger.error(
            "[maintenance] 서명(signature) 또는 봇 ID(bot_id) 또는 사용자 ID(user_id)가 누락되었습니다."
        )
        return Response(
            status_code=status.HTTP_400_BAD_REQUEST,
            content="Bad Request: Missing signature or bot_id or user_id",
        )

    if start and end:
        format_starttime = start.strftime("%m월 %d일 %H시 %M분")

        # endtime과 starttime이 같은 날짜라면 날짜는 빼고 시간만 표시
        if start.date() == end.date():
            format_endtime = end.strftime("%H시 %M분")
        else:
            format_endtime = end.strftime("%m월 %d일 %H시 %M분")

        message = f"서비스 안정화를 위한 서버 점검이 진행 중입니다.\n⏰ 점검 시간 : {format_starttime} ~ {format_endtime}\n점검 중에는 서비스 이용이 일시적으로 제한될 수 있습니다.\n불편을 드려 죄송하며, 더 나은 서비스를 위해 최선을 다하겠습니다."
    else:
        message = "서비스 안정화를 위한 서버 점검이 진행 중입니다.\n점검 중에는 서비스 이용이 일시적으로 제한될 수 있습니다.\n불편을 드려 죄송하며, 더 나은 서비스를 위해 최선을 다하겠습니다."

    await bot_manager.send_message(
        bot_id=bot_id,
        user_id=user_id,
        content=TextContent.from_text(message),
    )


@router.post("/{bot_id}/enable")
async def enable_maintenance(
    bot_id: str,
    maintenance_request: Annotated[MaintenanceRequest, Body(...)],
    bot_manager: Annotated[BusanBotUIManager, Depends(BusanBotUIManager)],
):
    bot_info = await bot_manager.get_bot_info(bot_id=bot_id)

    if not bot_info:
        return Response(
            status_code=status.HTTP_404_NOT_FOUND,
            content=f"봇 ID '{bot_id}'에 해당하는 봇 정보를 찾을 수 없습니다.",
        )

    parsed_url = urlparse(bot_info.callback_url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"

    if maintenance_request.start and maintenance_request.end:
        start_str = (
            maintenance_request.start.strftime("%Y-%m-%dT%H:%M")
            if maintenance_request.start
            else None
        )
        end_str = (
            maintenance_request.end.strftime("%Y-%m-%dT%H:%M")
            if maintenance_request.end
            else None
        )

        bot_info.callback_url = (
            f"{base_url}/maintenance?start={start_str}&end={end_str}"
        )
    else:
        bot_info.callback_url = f"{base_url}/maintenance"

    result = await bot_manager.update_bot(bot_id=bot_id, bot_update_info=bot_info)

    if result:
        return Response(
            status_code=status.HTTP_200_OK,
            content=f"봇 ID '{bot_id}'에 대한 점검 모드가 활성화되었습니다.",
        )
    else:
        return Response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=f"봇 ID '{bot_id}'에 대한 점검 모드 활성화에 실패했습니다.",
        )


@router.post("/{bot_id}/disable")
async def disable_maintenance(
    bot_id: str,
    bot_manager: Annotated[BusanBotUIManager, Depends(BusanBotUIManager)],
):
    bot_info = await bot_manager.get_bot_info(bot_id=bot_id)

    # 봇의 역할 가져오기
    bot_role = next(
        (bot for bot in bot_manager.config.service.bots if bot.id == int(bot_id)), None
    )

    if not bot_info:
        return Response(
            status_code=status.HTTP_404_NOT_FOUND,
            content=f"봇 ID '{bot_id}'에 해당하는 봇 정보를 찾을 수 없습니다.",
        )

    parsed_url = urlparse(bot_info.callback_url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"

    if bot_role and bot_role.role == "dev":
        # 개발 봇인 경우, 콜백 URL을 개발용으로 설정
        bot_info.callback_url = f"{base_url}/dev/message-callback"
    else:
        bot_info.callback_url = f"{base_url}/message-callback"

    result = await bot_manager.update_bot(bot_id=bot_id, bot_update_info=bot_info)

    if result:
        return Response(
            status_code=status.HTTP_200_OK,
            content=f"봇 ID '{bot_id}'에 대한 점검 모드가 비활성화되었습니다.",
        )
    else:
        return Response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=f"봇 ID '{bot_id}'에 대한 점검 모드 비활성화에 실패했습니다.",
        )
