from datetime import datetime, timedelta

from pydantic import BaseModel, Field


class MaintenanceRequest(BaseModel):
    start: datetime | None = Field(
        None,
        description="점검 시작 시간",
        example=(datetime.now().strftime("%Y-%m-%dT%H:%M")),
    )
    end: datetime | None = Field(
        None,
        description="점검 종료 시간",
        example=((datetime.now() + timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M")),
    )
