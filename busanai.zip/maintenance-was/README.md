# maintenance was

## maintenance was 로컬 테스트

- maintenance was를 로컬에서 실행
- 스웨거에서 maintenance 설정
- 설정되었는지 네이버 웍스에서 확인
