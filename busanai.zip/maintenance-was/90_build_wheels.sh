#!/bin/bash

uv export --no-dev --no-hashes --no-annotate --no-header \
    --no-emit-package naver-works-bot \
    --no-emit-package busan-bot-ui \
    --no-emit-package request-queue > requirements.txt

rm -rf ./wheels
mkdir ./wheels
cp requirements.txt ./wheels/

docker run --rm -v "$(pwd)/wheels:/app" whl-downloader

rm -rf ./wheels/requirements.txt 

pip wheel -w ./wheels \
    ../packages/naver-works-bot \
    ../packages/busan-bot-ui \
    ../packages/request-queue
