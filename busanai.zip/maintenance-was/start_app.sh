#!/bin/bash

: "${WORKERS:=$(nproc)}"   # WORKERS 환경변수 없으면 CPU 코어 수에 따라 자동 설정
: "${PORT:=8080}"  # PORT 환경변수 없으면 8080 사용

exec gunicorn app.main:app \
-k uvicorn.workers.UvicornWorker \
--bind 0.0.0.0:$PORT \
--workers $WORKERS