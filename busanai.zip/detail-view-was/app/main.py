import logging
import logging.handlers
import os
from typing import Annotated

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.api.v1 import stream, test_stream_server

load_dotenv()
LOG_LEVEL = os.getenv("LOG_LEVEL", "ERROR").upper()
if LOG_LEVEL not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
    raise ValueError(f"Invalid LOG_LEVEL: {LOG_LEVEL}")

LOG_DIR = os.getenv("LOG_DIR", "./logs")
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", 7))

log_file_path = os.path.join(LOG_DIR, "detail-view-was.log")
logging.basicConfig(
    level=LOG_LEVEL,
    format="[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s",
    handlers=[
        logging.StreamHandler(),  # 콘솔에 로그 출력
        logging.handlers.TimedRotatingFileHandler(
            log_file_path,
            when="midnight",  # 매일 자정에 로그 파일을 새로 만듭니다.
            interval=1,  # 1일마다 새 로그 파일 생성
            backupCount=LOG_BACKUP_COUNT,  # 최대 7개의 백업 로그 파일 유지
            encoding="utf-8",
            utc=False,  # 로컬 시간 사용
        ),
    ],
)

logger = logging.getLogger(__name__)

app = FastAPI()


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    # 빈 응답
    return Response(status_code=404)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(stream.router)

if os.getenv("ENV", "") == "local":
    app.include_router(test_stream_server.router)


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


def get_jinja2_templates():
    return Jinja2Templates(directory="templates")


@app.get("/views/detail")
async def show_detail_view(
    token: str,
    service: str,
    request: Request,
    templates: Annotated[Jinja2Templates, Depends(get_jinja2_templates)],
):
    return templates.TemplateResponse(
        "detail-view.html", {"request": request, "token": token, "service": service}
    )


@app.get("/views/guide")
async def guide_view(
    request: Request,
    templates: Annotated[Jinja2Templates, Depends(get_jinja2_templates)],
):
    service = request.query_params.get("service", "").strip()
    if not service:  # 페이지를 찾을수 없음 처리
        return Response(status_code=404)

    html_file = "guide-view"
    if service:
        html_file = f"guide-view-{service.lower()}"
    html_file += ".html"

    if not os.path.exists(os.path.join("templates", html_file)):
        logger.warning(f"서비스에 맞는 페이지를 찾을수 없음: {service}")
        return Response(status_code=404)

    return templates.TemplateResponse(html_file, {"request": request})


# 정적 파일을 /views 경로로 서빙 (html=True 옵션 추가)
app.mount("/views/assets", StaticFiles(directory="./static", html=True), name="static")
