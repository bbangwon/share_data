import asyncio
import base64
import json
import logging
import re

from fastapi import APIRouter
from fastapi.responses import JSONResponse, Response, StreamingResponse

router = APIRouter(
    prefix="/views/test_api/v1",
)

logger = logging.getLogger(__name__)


ServerIP = "0.0.0.0"
ServerPort = 8002


original_answer = """
# 마크다운 테스트  

## 인공지능  
  
**인공지능** 경쟁이 2라운드에 접어든 이유는 주로 **보안 이슈** 때문입니다.  
* 1라운드가 오픈AI의 챗GPT, 구글 바드와 같이 누구나 접속해 이용할 수 있는 퍼블릭 서비스였다면,  
* 2라운드는 기업 대상 프라이빗 서비스로 전환되었습니다. 

1. 기업용 생성 AI 서비스가 주목받는 이유
    1. 기업들은 내부 기밀 정보 보호가 필수적입니다.
    2. 퍼블릭 AI 서비스는 데이터 수집 및 활용에 대한 우려가 큽니다.
2. 주요 기업들의 대응
    1. 삼성전자, 애플 등 주요 기업들은 내부 기밀 정보 유출을 막기 위해 사내 챗GPT 사용을 금지하고 있습니다.
    2. 마이크로소프트, 구글 등은 기업용 생성 AI 솔루션을 강화하고 있습니다.

이는 기업의 내부 기밀 정보가 유출될 수 있는 위험을 방지하기 위해서입니다.  
생성 AI는 이용자가 입력한 정보를 AI 모델 개선을 위한 데이터로 활용하는데, 이 과정에서 기업의 내부 정보가 다른 사람의 답변에 노출될 가능성이 있기 때문에, 삼성전자, 애플 등 주요 기업들은 내부 기밀 정보 유출을 막기 위해 _사내 챗GPT 사용을 금지_ 하고 있습니다.

ㆍ브라우저가 단어 하나로 보고 줄바꿈을 거의 하지 않는 URL
https://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.com

📌 참고링크
ㆍ169_페이지17_문서9_162355_부산광역시의회_공무원_복무_조례.pdf (p.3)
https://busanai.busan.go.kr/download/169_페이지17_문서9_162355_부산광역시의회_공무원_복무_조례.pdf
ㆍ214_2501_예산담당관_업무매뉴얼_행정안전부_지방공무원보수업무_등_처리지침.pdf (p.349)
https://busanai.busan.go.kr/download/214_2501_예산담당관_업무매뉴얼_행정안전부_지방공무원보수업무_등_처리지침.pdf
"""

original_answer_markdown = """
# Markdown syntax guide

## Headers

# This is a Heading h1
## This is a Heading h2
###### This is a Heading h6

## Emphasis

*This text will be italic*  
_This will also be italic_

**This text will be bold**  
__This will also be bold__

_You **can** combine them_

## Lists

### Unordered

* Item 1
* Item 2
* Item 2a
* Item 2b
    * Item 3a
    * Item 3b

### Ordered

1. Item 1
2. Item 2
3. Item 3
    1. Item 3a
    2. Item 3b

## Images

![This is an alt text.](/views/images/bugi.png "This is a sample image.")

## Links

You may be using [Markdown Live Preview](https://markdownlivepreview.com/).

## Blockquotes

> Markdown is a lightweight markup language with plain-text-formatting syntax, created in 2004 by John Gruber with Aaron Swartz.
>
>> Markdown is often used to format readme files, for writing messages in online discussion forums, and to create rich text using a plain text editor.

## Tables

| Left columns  | Right columns |
| ------------- |:-------------:|
| left foo      | right foo     |
| left bar      | right bar     |
| left baz      | right baz     |

## Blocks of code

```
let message = 'Hello world';
alert(message);
```

## Inline code

This web site is using `markedjs/marked`.
"""

# 공백도 포함하여 토큰화
tokens = re.findall(r"\S+|\s+", original_answer)


# tokens = tokens[:20]  # 테스트용으로 토큰 수 제한

response_format = {
    "response_code": "C20000",
    "response_message": "OK",
    "llm_result": {
        "answer": None,
        "finish_reason": None,
        "annotations": None,
        "token_count": 0,
        "processing_time": 0.0,
    },
}


class DataProducer:
    def __init__(self):
        self.reset()
        self.sleep_time = 0.1

    def reset(self):
        self.buffer = []
        self.condition = asyncio.Condition()
        self.start = False
        self.end = False
        self.reference_count = 0

    # def to_oneline(self, s: str) -> str:
    #     return " ".join(line.strip() for line in s.splitlines())

    def to_oneline(self, s: str) -> str:
        return "\\n".join(line.strip() for line in s.splitlines())

    # 데이터 생성 예시 (실제 환경에서는 별도 Task에서 동작)
    async def data_producer(self, post_producing_callback=None):
        i = 0
        while i <= len(tokens):
            token = tokens[i] if i < len(tokens) else "null"
            finish_reason = "null" if i < len(tokens) else "stop"
            if finish_reason == "stop":
                token = "".join(tokens)  # 마지막에 전체 답변을 한 번에 보내기 위해 수정

            response_format["llm_result"]["answer"] = token
            response_format["llm_result"]["finish_reason"] = finish_reason

            msg = json.dumps(
                response_format, ensure_ascii=False
            )  # JSON 문자열 이스케이프 처리

            self.buffer.append(msg)
            logger.info(f"생성된 메시지: {msg}")
            if finish_reason == "stop":
                self.end = True

            async with self.condition:
                self.condition.notify_all()

            if self.end:
                if post_producing_callback:
                    post_producing_callback()
                break

            i += 1
            await asyncio.sleep(self.sleep_time)

    def start_producing(self, post_producing_callback=None):
        if self.start and self.end:
            logger.info("데이터 제공자를 재시작합니다.")
            self.reset()

        if not self.start:
            self.start = True
            asyncio.create_task(self.data_producer(post_producing_callback))
            return True
        else:
            logger.warning("데이터 제공자가 이미 시작되었습니다...")
            return False

    async def event_generator(self):
        try:
            last_idx = 0
            while last_idx < len(self.buffer):
                yield f"data: {self.buffer[last_idx]}\n\n"
                last_idx += 1

            while True:
                async with self.condition:
                    await self.condition.wait()
                    while last_idx < len(self.buffer):
                        yield f"data: {self.buffer[last_idx]}\n\n"
                        last_idx += 1

                    if self.end:
                        break
        except Exception as e:
            logger.error(e)


data_producer: dict[int, DataProducer] = {}

waittime_test = 1  # 1초후 스트림 진행. 서버가 준비되지 않은 상태를 시뮬레이션
start_time = None


@router.get("/stream")
async def stream(chat_session_id: int):
    # 테스트용: 일정 시간 동안은 404 응답.. 서버가 준비되지 않은 상태를 시뮬레이션
    global start_time
    if not start_time:
        start_time = asyncio.get_event_loop().time()
        logger.info("서버가 준비되지 않은 상태 시뮬레이션. 시작 시간 : %s", start_time)

    check_time = asyncio.get_event_loop().time() - start_time
    logger.info("대기 중인 시간: %d 초", check_time)
    if check_time < waittime_test:
        return Response(status_code=404, content="Not Implemented")
    # 여기까지 테스트용

    data_producer_instance = data_producer.get(chat_session_id)

    if not data_producer_instance:
        data_producer_instance = DataProducer()
        data_producer[chat_session_id] = data_producer_instance

    def post_generator():
        global start_time
        start_time = None
        logging.info("called post_generator")
        data_producer.pop(chat_session_id, None)

    data_producer_instance.start_producing(post_generator)

    return StreamingResponse(
        data_producer_instance.event_generator(),
        media_type="text/event-stream",
    )


@router.get("/get-token-url")
async def get_token_url(chat_session_id: int, chat_number: int):
    token_info = {
        "chat_session_id": chat_session_id,
        "chat_number": chat_number,
        "stream_url": f"http://{ServerIP}:{ServerPort}/views/test_api/v1/stream?chat_session_id={chat_session_id}",
    }

    logger.info("토큰 정보: %s", str(token_info))

    encoded_token = base64.b64encode(json.dumps(token_info).encode("utf-8")).decode(
        "utf-8"
    )

    logger.info("인코딩된 토큰: %s", encoded_token)

    return JSONResponse(
        content={
            "token": encoded_token,
            "page_url": f"http://{ServerIP}:{ServerPort}/views/detail?token={encoded_token}",
        },
    )
