import asyncio
import base64
import json
import logging
from typing import Annotated

import httpx
from db_manager import ChatHistory, DBManager, get_db_manager_using_env
from dotenv import load_dotenv
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

load_dotenv()
# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/views/api/v1",
)


def get_db_manager():
    return get_db_manager_using_env()


async def get_bot_message_from_db(
    chat_session_id: int,
    chat_number: int,
    db_manager: Annotated[DBManager, Depends(get_db_manager)],
) -> str | None:
    chat_history: ChatHistory = (
        await db_manager.get_chat_history_by_session_and_chat_number(
            chat_session_id=chat_session_id, chat_number=chat_number
        )
    )
    if chat_history:
        return chat_history.bot_message
    else:
        raise ValueError(
            "해당 chat_session_id와 chat_number에 해당하는 채팅 기록이 없습니다."
        )


@router.get("/request-stream")
async def request_stream(
    token: str, db_manager: Annotated[DBManager, Depends(get_db_manager)]
):
    logger.info(f"스트리밍 요청. 토큰 정보 : {token}")

    async def event_generator():
        try:
            # eyJjaGF0X3Nlc3Npb25faWQiOjEsImNoYXRfbnVtYmVyIjozLCJzdHJlYW1fdXJsIjoiaHR0cDovLzAuMC4wLjA6ODAwMi92aWV3cy90ZXN0X2FwaS92MS9zdHJlYW0/Y2hhdF9zZXNzaW9uX2lkPTEifQ==
            # {
            #     "chat_session_id" : 1,
            #     "chat_number": 3,
            #     "stream_url" : "http://0.0.0.0:8002/views/test_api/v1/stream?chat_session_id=1"
            # }

            token_info = base64.urlsafe_b64decode(token).decode("utf-8")
            token_data = json.loads(token_info)

            chat_session_id = token_data.get("chat_session_id")
            chat_number = token_data.get("chat_number")
            stream_url = token_data.get("stream_url", "")

            logger.debug(f"디코딩된 토큰 데이터: {token_data}")

            only_check_db = False
            checked_db_count = 0

            if not stream_url:
                logger.debug("stream_url이 없으므로, 봇 메시지 DB 확인만 수행합니다.")
                only_check_db = True

            while True:
                try:
                    bot_message = await get_bot_message_from_db(
                        chat_session_id=chat_session_id,
                        chat_number=chat_number,
                        db_manager=db_manager,
                    )
                    # bot_message = ""  # 봇 메시지가 없을때를 가정 (스트리밍 테스트용)

                    logger.debug(f"DB에서 가져온 bot_message: {bot_message}")

                    if bot_message:
                        logger.debug(
                            "DB에서 가져온 bot_message가 존재하여 스트리밍 없이 바로 전송합니다."
                        )
                        bot_message_json = json.dumps(
                            {
                                "llm_result": {
                                    "answer": f"{bot_message}",
                                    "finish_reason": "stop",
                                },
                                "status": "end",  # end는 스트리밍 종료 의미
                            },
                            ensure_ascii=False,
                        )

                        yield f"data: {bot_message_json}\n\n"
                        return  # 스트리밍 진짜 종료
                    elif only_check_db:
                        logger.debug(
                            "봇 메시지가 아직 없고, DB 확인만 하는 모드이므로 2초 후 다시 확인합니다."
                        )
                        checked_db_count += 1
                        if checked_db_count >= 5:  # 최대 10초 대기
                            logger.debug(
                                "봇 메시지가 10초 이내에 생성되지 않아 스트리밍 종료합니다."
                            )
                            end_message = json.dumps(
                                {
                                    "llm_result": {
                                        "finish_reason": "stop",
                                    },
                                    "status": "end",  # end는 스트리밍 종료 의미
                                },
                                ensure_ascii=False,
                            )
                            yield f"data: {end_message}\n\n"
                            return  # 스트리밍 진짜 종료
                        await asyncio.sleep(2)  # 2초 대기 후 DB 재확인
                    else:
                        logger.debug("bot_message가 없어 스트리밍을 시작합니다.")
                        async with httpx.AsyncClient(timeout=None) as client:
                            async with client.stream(
                                "GET",
                                url=stream_url,
                            ) as response:
                                response.raise_for_status()

                                async for line in response.aiter_lines():
                                    if line.startswith("data: "):
                                        yield line + "\n\n"

                                logger.info("서버가 스트림을 종료했습니다.")
                                only_check_db = True
                                await asyncio.sleep(2)  # 2초 대기 후 DB 재확인

                except httpx.HTTPStatusError as e:
                    logger.error(f"HTTP 요청 중 에러 발생: {e}")
                    if e.response.status_code == 404:  # 아직 서버가 준비되지 않은 경우
                        logger.error(
                            "에러가 404입니다. 서버가 준비되지 않은 것 같습니다. 2초 후 재시도합니다."
                        )
                        await asyncio.sleep(2)  # 2초 대기 후 재시도
                        continue
                    raise e  # 다른 HTTP 에러는 상위로 예외 전달
        except (GeneratorExit, asyncio.CancelledError):
            logger.info("클라이언트 연결이 끊어졌으므로 event_generator를 종료합니다.")
            return
        except Exception as e:
            logger.error(f"에러 발생: {e}")
            raise e
        finally:
            logger.info("event_generator finally: 클라이언트 연결 종료 또는 함수 종료")

    return StreamingResponse(event_generator(), media_type="text/event-stream")
