# Detail View WAS

## 로컬에서 스트리밍 테스트

- detail view WAS를 로컬에서 실행
- database에서 1번 채팅세션, chat_number 1번의 bot_message를 빈 문자열인지 확인
- 스웨거 API 중 get-token-url 로 chat_session_id와 chat_number를 1, 1로 설정
- 반환된 URL을 웹브라우저에서 열기
- 잠시 기다리면 스트리밍 테스트 진행됨
