#!/bin/bash

# 각종 설정파일들을 동기화함

TARGET_DIRS=(
    "../task-was"
    "../maintenance-was"
)

# TARGET_DIRS_ALL은 TARGET_DIRS의 값 + 추가 값
TARGET_DIRS_ENV=(
    "${TARGET_DIRS[@]}"
    "../detail-view-was"
)

# TARGET_DIRS_ALL은 TARGET_DIRS의 값 + 추가 값
TARGET_DIRS_ALL=(
    "${TARGET_DIRS_ENV[@]}"
    "../log-was"
)

for dir in "${TARGET_DIRS_ALL[@]}"; do
    cp .gitignore  "$dir"
done

for dir in "${TARGET_DIRS_ENV[@]}"; do
    cp .env*  "$dir"
done

for dir in "${TARGET_DIRS[@]}"; do
    cp busan-config*.yaml "$dir"
    cp busan-static-messages.yaml "$dir"
    cp private*.key "$dir"
done