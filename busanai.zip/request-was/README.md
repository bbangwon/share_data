# FastAPI 프로젝트 구조 예시

```plain
myapp/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI 인스턴스 생성 및 include_router
│   ├── api/                    # 라우터들을 모은 디렉터리
│   │   ├── __init__.py
│   │   ├── v1/                 # 버전별 API 관리
│   │   │   ├── __init__.py
│   │   │   ├── user.py
│   │   │   └── item.py
│   ├── core/                   # 설정, 보안, 중간 처리 등 핵심 기능
│   │   ├── __init__.py
│   │   ├── config.py           # 환경변수 설정
│   │   ├── security.py         # 인증, JWT 등
│   │   └── middleware.py
│   ├── models/                 # Pydantic 모델 및 ORM 모델
│   │   ├── __init__.py
│   │   ├── user.py
│   │   └── item.py
│   ├── crud/                   # DB 조작 로직
│   │   ├── __init__.py
│   │   ├── user.py
│   │   └── item.py
│   ├── db/                     # 데이터베이스 초기화 및 연결
│   │   ├── __init__.py
│   │   ├── session.py
│   │   └── base.py
│   ├── schemas/                # 요청/응답을 위한 Pydantic 스키마
│   │   ├── __init__.py
│   │   ├── user.py
│   │   └── item.py
│   └── services/               # 외부 API 연동, 비즈니스 로직 등
│       ├── __init__.py
│       └── email.py
├── tests/                      # 테스트 코드
│   ├── __init__.py
│   ├── test_user.py
│   └── test_item.py
├── .env                        # 환경변수 설정
├── requirements.txt            # 패키지 목록
├── Dockerfile
├── docker-compose.yml
└── README.md
```
