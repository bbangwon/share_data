import asyncio

from busan_bot_ui import BusanBotUIManager
from busan_bot_ui.utils import get_service_url
from dotenv import load_dotenv


async def main():
    service_url = get_service_url(env="local")
    if not service_url:
        return

    # 현재 server
    load_dotenv()

    busan_bot_manager = BusanBotUIManager()
    try:
        for (
            bot_id
        ) in busan_bot_manager.get_all_bot_ids():  # 등록된 봇 id를 가져오기 위해
            bot_info = await busan_bot_manager.get_bot_info(bot_id)  # 봇 정보 갱신
            if not bot_info.callback_url:
                print(f"봇 ID: {bot_id}는 콜백 URL이 없습니다. 건너뜁니다.")
                continue

            # 봇의 역할 가져오기
            bot_role = next(
                (
                    bot
                    for bot in busan_bot_manager.config.service.bots
                    if bot.id == int(bot_id)
                ),
                None,
            )

            if bot_role and bot_role.role == "dev":
                bot_info.callback_url = f"{service_url}/dev/message-callback"
            else:
                bot_info.callback_url = f"{service_url}/message-callback"
            result = await busan_bot_manager.update_bot(
                bot_id=bot_id, bot_update_info=bot_info
            )
            print(f"봇 ID: {bot_id}, 새로운 콜백 URL: {bot_info.callback_url}")

            if result:
                print(
                    f"Callback URL({service_url}/message-callback)이 성공적으로 설정되었습니다."
                )
            else:
                print("Callback URL 설정에 실패했습니다.")

    except Exception as e:
        print("봇 정보를 가져오거나 업데이트하는 중 오류가 발생했습니다:", e)


if __name__ == "__main__":
    asyncio.run(main())
