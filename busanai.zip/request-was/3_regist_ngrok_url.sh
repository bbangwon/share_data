#!/bin/bash

uv run ./tests/update_callback_url_from_ngrok.py