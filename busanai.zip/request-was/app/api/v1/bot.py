import logging
from typing import Annotated

from busan_bot_ui import BusanBotUIManager
from dotenv import load_dotenv
from fastapi import APIRouter, Body, Depends, Request, Response, status
from naver_works_bot import (
    ReceiveMessage,
)
from request_queue import AsyncRedisQueue, RequestQueueItem, get_redis_queue_using_env

load_dotenv()

QUEUE_NAME_REQUEST = "request_queue"

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/message-callback",
)


# 요청 큐 설정
def get_redis_queue():
    return get_redis_queue_using_env(
        item_class=RequestQueueItem,
        publish_enqueue=True,
    )


@router.post("")
async def message_callback(
    request: Request,
    received_message: Annotated[ReceiveMessage, Body(...)],
    bot_manager: Annotated[BusanBotUIManager, Depends(BusanBotUIManager)],
    request_queue: Annotated[AsyncRedisQueue, Depends(get_redis_queue)],
):
    headers = dict(request.headers)
    body_json = received_message.model_dump(exclude_none=True)

    # 헤더 정보
    logger.debug(f"[message-callback] 수신 헤더: {headers}")
    logger.debug(f"[message-callback] 수신 메시지: {body_json}")

    request_item = RequestQueueItem(headers=headers, body=body_json)

    bot_id = request_item.get_bot_id()
    user_id = request_item.get_user_id()

    logger.info(
        f"[message-callback] 수신 봇 ID: {bot_id}, 사용자 ID: {user_id}, 메시지: {body_json}"
    )

    # 서명, 봇 ID, 사용자 ID가 모두 존재하는지 확인 (잘못된 패킷이므로 사용자에게 에러를 보낼필요 없음)
    if not bot_id or not user_id:
        logger.error(
            "[message-callback] 서명(signature) 또는 봇 ID(bot_id) 또는 사용자 ID(user_id)가 누락되었습니다."
        )
        return Response(
            status_code=status.HTTP_400_BAD_REQUEST,
            content="Bad Request: Missing signature or bot_id or user_id",
        )

    # 서명검증
    if bot_manager.config.service.use_verify_signature:
        signature = request_item.get_signature()
        if not signature:
            logger.error("[message-callback] 서명(signature)가 누락되었습니다.")
            return Response(
                status_code=status.HTTP_400_BAD_REQUEST,
                content="Bad Request: Missing signature",
            )

        body = await request.body()
        if not bot_manager.verify_signature(bot_id, signature, body):
            logger.error("[message-callback] 서명 검증 실패")
            return Response(status_code=403, content="Forbidden: Invalid signature")
        else:
            logger.info("[message-callback] 서명 검증 성공")

    await request_queue.enqueue(QUEUE_NAME_REQUEST, request_item)

    logger.info(f"[message-callback] {QUEUE_NAME_REQUEST} 큐에 추가됨")

    headers = {
        "Content-Type": "application/json; charset=UTF-8",
        "Server": "AI-Bot-Server",
        "X-Task-Id": request_item.id,
    }

    return Response(status_code=status.HTTP_200_OK, headers=headers)
