from pydantic import BaseModel, Field


class SendContent(BaseModel):
    bot_id: str = Field(..., description="봇 ID", examples=["10242846"])
    user_id: str = Field(
        ..., description="사용자 ID", examples=["95fe2166-112c-4597-1115-032ccd8f293c"]
    )
    content: dict = Field(
        ...,
        description="전송할 메시지",
        examples=[{"type": "text", "text": "안녕하세요, 챗봇입니다!"}],
    )
