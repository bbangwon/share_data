# PostgreSQL

- appuser 일반 사용자는 직접 만들어야 합니다.

# PGBouncer

- /pgbouncer 폴더에 pgbouncer 설정 파일이 있습니다.
- postgresql.conf 파일은 튜닝된 설정이 포함되어 있습니다.
- docker-compose.yml 파일에서 pgbouncer 서비스가 정의되어 있습니다.

# Replica

- /primary 폴더와 /replica 폴더에 각각의 설정 파일이 있습니다.
- docker-compose.replica.yml 파일에서 복제본 설정이 정의되어 있습니다.
- 최초 볼륨시에만 command를 통해 pg_basebackup이 실행되도록 주석 처리되어 있습니다. => 주석을 풀고 1회 실행 후, 다시 주석 처리 필요
- service이름과 ip, port를 주의해서 설정해야 합니다.
- postgresql.conf 파일과 pg_hba.conf 파일은 primary와 replica 동일하게 가져가도 됩니다.

## Replica 설정 방법

- docker-compose.yml : primary db 설정
- docker-compose.replica.yml : replica db 설정
- docker-compose.replica.init.yml : 최초 replica db 설정 (1회성)
