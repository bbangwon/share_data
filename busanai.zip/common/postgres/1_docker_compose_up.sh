#!/bin/zsh

docker-compose -f docker-compose.postgres.yml up -d
docker-compose -f docker-compose.postgres.replica.yml up -d