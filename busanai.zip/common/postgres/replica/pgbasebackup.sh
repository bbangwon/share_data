#!/bin/bash

# 최초 볼륨 설정 시, primary 서버에서 복제본을 생성
rm -rf /var/lib/postgresql/data/*
pg_basebackup -h 127.0.0.1 -U replicauser -D /var/lib/postgresql/data -Fp -Xs -P -R

# pg_basebackup -R 옵션시 아래 내용은 자동 생성됨 (host, password 설정 주의)
# echo "primary_conninfo = 'host=127.0.0.1 port=5432 user=replicauser password=password'" > /var/lib/postgresql/data/postgresql.auto.conf
# touch /var/lib/postgresql/data/standby.signal