#!/bin/zsh

docker-compose -f docker-compose.postgres.yml down
docker-compose -f docker-compose.postgres.replica.yml down