# 로컬 테스트를 위한 Nginx 설정

- local에서 테스트 하기 위한 docker-compose 설정, default.conf 설정 파일이 포함되어 있습니다.

## docker 이미지 다운로드

```bash
docker pull nginx
```

## docker compose 실행

```bash
docker compose -f tests/nginx/docker-compose.yml up -d
```
