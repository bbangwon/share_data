#!/bin/bash

docker build --platform linux/amd64 -t busan-python-base .