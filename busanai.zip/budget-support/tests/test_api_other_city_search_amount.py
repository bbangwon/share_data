import unittest
from unittest.mock import AsyncMock, MagicMock, patch
from app.api.v1.ai_search import search_other_city

class TestApiOtherCitySearchAmount(unittest.IsolatedAsyncioTestCase):
    async def test_search_other_city_amount_conversion(self):
        # Mock session
        mock_session = AsyncMock()
        mock_result = MagicMock()
        
        # Mock database row with sum_amt in Won (e.g., 1,500,000 Won)
        mock_row = MagicMock()
        mock_row.la_cd = "6110000"
        mock_row.la_nm = "본청"
        mock_row.w_city_nm = "서울특별시"
        mock_row.dtl_prj_nm = "테스트사업"
        mock_row.stat_mok_nm = "테스트통계목"
        mock_row.adj_basis = "테스트산출근거"
        mock_row.sum_amt = 1500000 # 1,500,000 Won
        
        mock_result.all.return_value = [mock_row]
        mock_session.execute.return_value = mock_result

        # Call with min_amt/max_amt in 1000 Won units (e.g., 1000 ~ 2000)
        min_amt = 1000
        max_amt = 2000
        
        # We need to mock open for local_governments.json
        with patch("builtins.open", MagicMock()):
            with patch("json.load", return_value={"6110000": {"w_city_nm": "서울특별시"}}):
                results = await search_other_city(
                    session=mock_session, 
                    min_amt=min_amt, 
                    max_amt=max_amt
                )

        # 1. Verify filters were multiplied by 1000
        stmt = mock_session.execute.call_args[0][0]
        params = stmt.compile().params
        # The parameter names might be sum_amt_1, sum_amt_2 etc.
        # Let's find params that match our values
        self.assertIn(min_amt * 1000, params.values())
        self.assertIn(max_amt * 1000, params.values())

        # 2. Verify result was divided by 1000
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].budget_amt, 1500) # 1,500,000 // 1000

if __name__ == "__main__":
    unittest.main()
