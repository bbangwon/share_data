import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from app.models import BudgetLocalGovernment
from app.schemas.imports import BudgetOutLv1ImportRequest
from app.services.budget_out_lv1_importer import BudgetOutLv1ImportService
from app.services.excel_parser_lv1 import (
    ParsedBudgetOutLv1Row,
    ParsedBudgetOutLv1Workbook,
    ParsedBudgetOutLv1Version,
)


class BudgetOutLv1ImportServiceTests(unittest.IsolatedAsyncioTestCase):
    async def test_import_excel_calls_persist_rows(self) -> None:
        # Mock parser
        mock_parser = MagicMock()
        mock_parser.parse.return_value = ParsedBudgetOutLv1Workbook(
            sheet_name="Sheet1",
            fiscal_year=2025,
            la_cd="6110000",
            la_nm="본청",
            w_city_nm="서울특별시",
            budget_versions=[ParsedBudgetOutLv1Version(budget_type="본예산", row_count=1)],
            rows=[
                ParsedBudgetOutLv1Row(
                    fiscal_year=2025, la_cd="6110000", la_nm="본청",
                    w_city_nm="서울특별시",
                    policy_proj_nm="정책", unit_prj_nm="단위",
                    dtl_prj_cd="DETAIL_CD", dtl_prj_nm="세부",
                    nat_sub_prj_nm=None, budget_type="본예산",
                    self_sub_type="자체", not_prj_type="정책사업",
                    budg_mok_nm="목", stat_mok_nm="통계",
                    adj_basis="근거",
                    sum_amt=100,
                    adj_details={"시도비보조금": 100},
                )
            ]
        )
        
        service = BudgetOutLv1ImportService(parser=mock_parser)
        
        # Mock session
        mock_session = AsyncMock()
        mock_session.begin = MagicMock()
        mock_session.begin.return_value.__aenter__ = AsyncMock()
        mock_session.begin.return_value.__aexit__ = AsyncMock()
        
        # Mocking _resolve_local_government
        with patch.object(service, '_resolve_local_government', return_value=BudgetLocalGovernment(la_cd="6110000", la_nm="본청", w_city_nm="서울특별시")):
            # Mocking _persist_rows to avoid DB logic
            with patch.object(service, '_persist_rows', return_value=None) as mock_persist:
                with patch.object(service, '_delete_existing_fact', return_value=None):
                    request = BudgetOutLv1ImportRequest(
                        fiscal_year=2025
                    )
                    
                    response = await service.import_excel(
                        mock_session, request, "test.xlsx", b"dummy_content"
                    )
                    
                    self.assertEqual(response.la_cd, "6110000")
                    self.assertEqual(response.fiscal_year, 2025)
                    self.assertEqual(response.rows_processed, 1)
                    mock_persist.assert_called_once()

    async def test_import_excel_with_multiple_la(self) -> None:
        # Mock parser returning multiple LAs
        mock_parser = MagicMock()
        mock_parser.parse.return_value = ParsedBudgetOutLv1Workbook(
            sheet_name="Sheet1",
            fiscal_year=2025,
            la_cd="6110000, 6260000",
            la_nm="본청, 부산본청",
            w_city_nm="부산광역시, 서울특별시",
            budget_versions=[
                ParsedBudgetOutLv1Version(budget_type="본예산", row_count=2)
            ],
            rows=[
                ParsedBudgetOutLv1Row(
                    fiscal_year=2025, la_cd="6110000", la_nm="본청",
                    w_city_nm="서울특별시",
                    policy_proj_nm="정책1", unit_prj_nm="단위1",
                    dtl_prj_cd="CD1", dtl_prj_nm="세부1",
                    nat_sub_prj_nm=None, budget_type="본예산",
                    self_sub_type="자체", not_prj_type="정책사업",
                    budg_mok_nm="목1", stat_mok_nm="통계1",
                    adj_basis="근거1",
                    sum_amt=100,
                    adj_details={"시도비보조금": 100},
                ),
                ParsedBudgetOutLv1Row(
                    fiscal_year=2025, la_cd="6260000", la_nm="부산본청",
                    w_city_nm="부산광역시",
                    policy_proj_nm="정책2", unit_prj_nm="단위2",
                    dtl_prj_cd="CD2", dtl_prj_nm="세부2",
                    nat_sub_prj_nm=None, budget_type="본예산",
                    self_sub_type="자체", not_prj_type="정책사업",
                    budg_mok_nm="목2", stat_mok_nm="통계2",
                    adj_basis="근거2",
                    sum_amt=200,
                    adj_details={"시도비보조금": 200},
                )
            ]
        )
        
        service = BudgetOutLv1ImportService(parser=mock_parser)
        
        # Mock session
        mock_session = AsyncMock()
        mock_session.begin = MagicMock()
        mock_session.begin.return_value.__aenter__ = AsyncMock()
        mock_session.begin.return_value.__aexit__ = AsyncMock()
        
        # Mocking _resolve_local_government
        la_map = {
            "6110000": BudgetLocalGovernment(la_cd="6110000", la_nm="본청", w_city_nm="서울특별시"),
            "6260000": BudgetLocalGovernment(la_cd="6260000", la_nm="부산본청", w_city_nm="부산광역시"),
        }
        async def mock_resolve(session, la_cd, la_nm, w_city_nm):
            return la_map[la_cd]

        with patch.object(service, '_resolve_local_government', side_effect=mock_resolve):
            with patch.object(service, '_persist_rows', return_value=None) as mock_persist:
                with patch.object(service, '_delete_existing_fact', return_value=None):
                    request = BudgetOutLv1ImportRequest(fiscal_year=2025)
                    
                    response = await service.import_excel(
                        mock_session, request, "test.xlsx", b"dummy_content"
                    )
                    
                    self.assertEqual(response.la_cd, "6110000, 6260000")
                    self.assertEqual(response.la_nm, "본청, 부산본청")
                    self.assertEqual(response.rows_processed, 2)
                    self.assertEqual(mock_persist.call_count, 2)

    async def test_resolve_local_government_creates_new_one(self) -> None:
        service = BudgetOutLv1ImportService()
        # Use MagicMock for session because add/flush are often sync in mocks or we need to avoid AsyncMock overhead for sync calls
        mock_session = MagicMock() 
        
        # Mock session.execute as async
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_result)
        mock_session.flush = AsyncMock()
        
        la_cd = "9999999"
        la_nm = "신규지자체"
        w_city_nm = "가상광역시"
        
        local_government = await service._resolve_local_government(
            mock_session, la_cd, la_nm, w_city_nm
        )
        
        self.assertEqual(local_government.la_cd, la_cd)
        self.assertEqual(local_government.la_nm, la_nm)
        self.assertEqual(local_government.w_city_nm, w_city_nm)
        mock_session.add.assert_called_once_with(local_government)
        mock_session.flush.assert_called_once()


if __name__ == "__main__":
    unittest.main()
