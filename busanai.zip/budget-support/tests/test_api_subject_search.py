import unittest
from unittest.mock import AsyncMock, MagicMock, patch
from app.api.v1.budget_out_lv1 import search_account_subjects
from app.models import BudgetOutAccountSubject
from sqlalchemy import and_, or_

class TestApiSubjectSearch(unittest.IsolatedAsyncioTestCase):
    async def test_search_account_subjects_with_fiscal_year(self):
        # Mock session
        mock_session = AsyncMock()
        mock_result = MagicMock()
        mock_result.all.return_value = []
        mock_session.execute.return_value = mock_result

        # Call the function
        q = "test_query"
        fiscal_year = 2024
        await search_account_subjects(session=mock_session, q=q, fiscal_year=fiscal_year)

        # Verify execute was called
        mock_session.execute.assert_called_once()
        stmt = mock_session.execute.call_args[0][0]
        
        # Verify the statement contains the fiscal year filter
        # stmt is a Select object. We can check its where clause.
        where_clause = str(stmt.whereclause)
        self.assertIn("fiscal_year = :fiscal_year_1", where_clause)
        self.assertIn("budg_mok_nm LIKE", where_clause)
        self.assertIn("stat_mok_nm LIKE", where_clause)

    async def test_search_account_subjects_without_fiscal_year(self):
        # Mock session
        mock_session = AsyncMock()
        mock_result = MagicMock()
        mock_result.all.return_value = []
        mock_session.execute.return_value = mock_result

        # Call the function
        q = "test_query"
        await search_account_subjects(session=mock_session, q=q, fiscal_year=None)

        # Verify execute was called
        mock_session.execute.assert_called_once()
        stmt = mock_session.execute.call_args[0][0]
        
        # Verify the statement does NOT contain the fiscal year filter
        where_clause = str(stmt.whereclause)
        self.assertNotIn("budget_out_account_subject.fiscal_year =", where_clause)

if __name__ == "__main__":
    unittest.main()
