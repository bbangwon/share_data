import unittest
from io import BytesIO

from openpyxl import Workbook

from app.services.excel_parser import BudgetImportValidationError
from app.services.excel_parser_lv1 import BudgetOutLv1ExcelParser


class BudgetOutLv1ExcelParserTests(unittest.TestCase):
    def setUp(self) -> None:
        self.parser = BudgetOutLv1ExcelParser()

    def test_parse_ignores_subtotal_rows_and_propagates_headers(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws.title = "Sheet1"

        headers = [
            "회계연도",
            "정렬순서",
            "광역시도명",
            "지방자치단체명",
            "지방자치단체코드",
            "정책사업명",
            "단위사업명",
            "세부사업코드",
            "세부사업명",
            "국고보조사업명",
            "예산편성구분",
            "보조예산구분명",
            "비사업구분명",
            "편성목",
            "통계목",
            "산출근거내용",
            "세출예산마감일련번호",
            "예산합계",
            "국고보조금",
            "균특보조금",
            "기금보조금",
            "기타",
            "소방안전교부세",
            "시군구비",
            "시도비",
            "지방소멸대응기금",
            "지방채",
            "특별교부금",
            "특별교부세",
        ]
        for col, header in enumerate(headers, 1):
            ws.cell(row=5, column=col, value=header)

        row6 = [
            "2025",
            "1",
            "서울특별시",
            "본청",
            "6110000",
            "정책1",
            "단위1",
            "CD001",
            "세부1 소계",
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            1000,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
        ]
        for col, val in enumerate(row6, 1):
            ws.cell(row=6, column=col, value=val)

        row7 = [
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            "세부1",
            "국고사업",
            "본예산",
            "자체",
            "정책사업",
            "목1",
            "통계1",
            "산출근거1",
            "1",
            500,
            100,
            0,
            0,
            0,
            0,
            0,
            400,
            0,
            0,
            0,
            0,
        ]
        for col, val in enumerate(row7, 1):
            ws.cell(row=7, column=col, value=val)

        row8 = [
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            "통계2",
            "산출근거2",
            "1",
            500,
            0,
            0,
            0,
            0,
            0,
            0,
            500,
            0,
            0,
            0,
            0,
        ]
        for col, val in enumerate(row8, 1):
            ws.cell(row=8, column=col, value=val)

        buffer = BytesIO()
        wb.save(buffer)
        file_bytes = buffer.getvalue()

        parsed = self.parser.parse(file_bytes)

        self.assertEqual(len(parsed.rows), 2)
        self.assertEqual(parsed.la_cd, "6110000")
        self.assertEqual(parsed.la_nm, "본청")
        self.assertEqual(parsed.w_city_nm, "서울특별시")

        self.assertEqual(parsed.rows[0].dtl_prj_cd, "CD001")
        self.assertEqual(parsed.rows[0].dtl_prj_nm, "세부1")
        self.assertEqual(parsed.rows[0].la_nm, "본청")
        self.assertEqual(parsed.rows[0].w_city_nm, "서울특별시")
        self.assertEqual(parsed.rows[0].adj_basis, "산출근거1")
        self.assertEqual(parsed.rows[0].sum_amt, 500)
        self.assertEqual(parsed.rows[0].nat_sub_amt, 100)

        self.assertEqual(parsed.rows[1].dtl_prj_cd, "CD001")
        self.assertEqual(parsed.rows[1].dtl_prj_nm, "세부1")
        self.assertEqual(parsed.rows[1].budg_mok_nm, "목1")
        self.assertEqual(parsed.rows[1].stat_mok_nm, "통계2")
        self.assertEqual(parsed.rows[1].adj_basis, "산출근거2")

    def test_parse_multiple_local_governments(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws.title = "Sheet1"

        headers = [
            "회계연도",
            "정렬순서",
            "광역시도명",
            "지방자치단체명",
            "지방자치단체코드",
            "정책사업명",
            "단위사업명",
            "세부사업코드",
            "세부사업명",
            "국고보조사업명",
            "예산편성구분",
            "보조예산구분명",
            "비사업구분명",
            "편성목",
            "통계목",
            "산출근거내용",
            "세출예산마감일련번호",
            "예산합계",
            "국고보조금",
            "균특보조금",
            "기금보조금",
            "기타",
            "소방안전교부세",
            "시군구비",
            "시도비",
            "지방소멸대응기금",
            "지방채",
            "특별교부금",
            "특별교부세",
        ]
        for col, header in enumerate(headers, 1):
            ws.cell(row=5, column=col, value=header)

        # Row 6: LA 1
        row6 = [
            "2025",
            "1",
            "서울특별시",
            "본청",
            "6110000",
            "정책1",
            "단위1",
            "CD001",
            "세부1",
            "국고사업",
            "본예산",
            "자체",
            "정책사업",
            "목1",
            "통계1",
            "산출근거1",
            "1",
            500,
            100,
            0,
            0,
            0,
            0,
            0,
            400,
            0,
            0,
            0,
            0,
        ]
        for col, val in enumerate(row6, 1):
            ws.cell(row=6, column=col, value=val)

        # Row 7: LA 2
        row7 = [
            "2025",
            "1",
            "부산광역시",
            "부산본청",
            "6260000",
            "정책2",
            "단위2",
            "CD002",
            "세부2",
            "국고사업2",
            "본예산",
            "자체",
            "정책사업",
            "목2",
            "통계2",
            "산출근거2",
            "1",
            500,
            100,
            0,
            0,
            0,
            0,
            0,
            400,
            0,
            0,
            0,
            0,
        ]
        for col, val in enumerate(row7, 1):
            ws.cell(row=7, column=col, value=val)

        buffer = BytesIO()
        wb.save(buffer)
        file_bytes = buffer.getvalue()

        parsed = self.parser.parse(file_bytes)

        self.assertEqual(len(parsed.rows), 2)
        self.assertEqual(parsed.la_cd, "6110000, 6260000")
        self.assertEqual(parsed.la_nm, "본청, 부산본청")
        self.assertEqual(parsed.w_city_nm, "부산광역시, 서울특별시")
        self.assertEqual(parsed.rows[0].la_cd, "6110000")
        self.assertEqual(parsed.rows[0].w_city_nm, "서울특별시")
        self.assertEqual(parsed.rows[1].la_cd, "6260000")
        self.assertEqual(parsed.rows[1].w_city_nm, "부산광역시")

    def test_parse_rejects_missing_headers(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws.cell(row=5, column=1, value="Wrong Header")

        buffer = BytesIO()
        wb.save(buffer)

        with self.assertRaises(BudgetImportValidationError) as cm:
            self.parser.parse(buffer.getvalue())
        self.assertIn("기본 헤더 형식이 예상과 다릅니다.", cm.exception.message)


if __name__ == "__main__":
    unittest.main()
