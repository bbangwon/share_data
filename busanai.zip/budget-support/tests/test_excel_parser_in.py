import unittest
from io import BytesIO

from openpyxl import Workbook

from app.services.excel_parser import BudgetInExcelParser


class BudgetInExcelParserTests(unittest.TestCase):
    def setUp(self) -> None:
        self.parser = BudgetInExcelParser()

    def test_parse_allows_multiple_confirm_dates_for_same_budget_type(self) -> None:
        # 동일한 예산구분명("본예산")에 서로 다른 예산확정일자가 있는 데이터
        workbook_bytes = self._build_workbook(
            [
                self._make_row_in(budget_confirm_date="2026-01-01", budget_type="본예산", dept_cd="D001"),
                self._make_row_in(budget_confirm_date="2026-02-01", budget_type="본예산", dept_cd="D002"),
            ]
        )

        parsed = self.parser.parse(workbook_bytes)

        # 수정된 로직에 의해 두 버전이 모두 파싱되어야 함
        self.assertEqual(
            [
                (item.budget_type, item.budget_confirm_date, item.row_count)
                for item in parsed.budget_versions
            ],
            [("본예산", "2026-01-01", 1), ("본예산", "2026-02-01", 1)],
        )

    def _build_workbook(self, rows: list[dict[str, object]]) -> bytes:
        workbook = Workbook()
        worksheet = workbook.active

        # 1행: 헤더
        headers = list(BudgetInExcelParser.PRIMARY_FIELD_HEADERS.values())
        for col, header in enumerate(headers, start=1):
            worksheet.cell(row=1, column=col, value=header)

        # 2행부터: 데이터
        for row_idx, row_data in enumerate(rows, start=2):
            for col, header in enumerate(headers, start=1):
                # 헤더명을 기반으로 데이터 매핑 (일부 필드는 _make_row_in에서 생성됨)
                worksheet.cell(row=row_idx, column=col, value=row_data.get(header))

        output = BytesIO()
        workbook.save(output)
        return output.getvalue()

    def _make_row_in(
        self,
        *,
        budget_confirm_date: str,
        budget_type: str,
        dept_cd: str,
    ) -> dict[str, object]:
        # PRIMARY_FIELD_HEADERS에 정의된 한국어 헤더명으로 구성
        return {
            "회계연도": 2026,
            "예산구분명": budget_type,
            "예산확정일자": budget_confirm_date,
            "부서코드": dept_cd,
            "부서명": f"부서-{dept_cd}",
            "회계구분": "FUND1",
            "회계명": "일반회계",
            "장": "01",
            "장명": "장명",
            "관": "011",
            "관명": "관명",
            "항": "0111",
            "항명": "항명",
            "목": "01111",
            "목명": "목명",
            "산출근거": "산출근거",
            "산출근거식": None,
            "레벨금액": 1000,
            "예산액": 1000,
            "기정액": 0,
            "증감액": 1000,
        }


if __name__ == "__main__":
    unittest.main()
