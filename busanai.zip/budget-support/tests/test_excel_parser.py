import unittest
from io import BytesIO

from openpyxl import Workbook

from app.services.excel_parser import BudgetImportValidationError, BudgetOutExcelParser


class BudgetOutExcelParserTests(unittest.TestCase):
    def setUp(self) -> None:
        self.parser = BudgetOutExcelParser()

    def test_parse_allows_multiple_budget_types_with_one_seq_each(self) -> None:
        workbook_bytes = self._build_workbook(
            [
                self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001"),
                self._make_row(budget_seq=2, budget_type="추경", dtl_prj_cd="DTL002"),
            ]
        )

        parsed = self.parser.parse(workbook_bytes)

        self.assertEqual(parsed.fiscal_year, 2026)
        self.assertEqual(
            [
                (item.budget_type, item.budget_seq, item.row_count)
                for item in parsed.budget_versions
            ],
            [("본예산", 1, 1), ("추경", 2, 1)],
        )

    def test_parse_allows_multiple_budget_seqs_for_same_budget_type(self) -> None:
        workbook_bytes = self._build_workbook(
            [
                self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001"),
                self._make_row(budget_seq=2, budget_type="본예산", dtl_prj_cd="DTL002"),
            ]
        )

        parsed = self.parser.parse(workbook_bytes)

        self.assertEqual(
            [
                (item.budget_type, item.budget_seq, item.row_count)
                for item in parsed.budget_versions
            ],
            [("본예산", 1, 1), ("본예산", 2, 1)],
        )

    def test_parse_allows_inserted_column_and_shifted_order(self) -> None:
        primary_layout = [
            (column_index if column_index < 4 else column_index + 1, header)
            for column_index, header in BudgetOutExcelParser.PRIMARY_HEADERS.items()
        ]
        primary_layout.insert(3, (4, "추가컬럼"))
        funding_layout = [
            (column_index + 1, header)
            for column_index, header in BudgetOutExcelParser.FUNDING_HEADERS.items()
        ]

        workbook_bytes = self._build_workbook(
            [self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001")],
            primary_layout=primary_layout,
            funding_layout=funding_layout,
            extra_row_values={"추가컬럼": "무시됨"},
        )

        parsed = self.parser.parse(workbook_bytes)

        self.assertEqual(len(parsed.rows), 1)
        self.assertEqual(parsed.rows[0].dtl_prj_cd, "DTL001")
        self.assertEqual(parsed.rows[0].adj_details, {"자체재원": 1000})

    def test_parse_rejects_missing_required_header(self) -> None:
        primary_layout = [
            (column_index, header)
            for column_index, header in BudgetOutExcelParser.PRIMARY_HEADERS.items()
            if header != "부서코드"
        ]

        workbook_bytes = self._build_workbook(
            [self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001")],
            primary_layout=primary_layout,
        )

        with self.assertRaises(BudgetImportValidationError) as context:
            self.parser.parse(workbook_bytes)

        self.assertEqual(context.exception.message, "기본 헤더 형식이 예상과 다릅니다.")
        self.assertIn("부서코드", context.exception.errors[0])

    def test_parse_allows_missing_optional_nullable_header(self) -> None:
        primary_layout = [
            (column_index, header)
            for column_index, header in BudgetOutExcelParser.PRIMARY_HEADERS.items()
            if header != "재난관리단계"
        ]

        workbook_bytes = self._build_workbook(
            [self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001")],
            primary_layout=primary_layout,
        )

        parsed = self.parser.parse(workbook_bytes)

        self.assertEqual(len(parsed.rows), 1)
        self.assertIsNone(parsed.rows[0].disaster_man_step)

    def test_parse_removes_hyphen_from_dept_cd(self) -> None:
        row = self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001")
        row["부서코드"] = "10-20-060"

        workbook_bytes = self._build_workbook([row])
        parsed = self.parser.parse(workbook_bytes)

        self.assertEqual(parsed.rows[0].dept_cd, "1020060")

    def test_parse_removes_hyphen_from_stat_mok_cd(self) -> None:
        row = self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001")
        row["통계목코드"] = "101-02"

        workbook_bytes = self._build_workbook([row])
        parsed = self.parser.parse(workbook_bytes)

        self.assertEqual(parsed.rows[0].stat_mok_cd, "10102")

    def test_parse_rejects_loc_trans_step_without_flag(self) -> None:
        row = self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001")
        row["지방전환사업단계"] = "2-2단계(2023년)"

        workbook_bytes = self._build_workbook([row])

        with self.assertRaises(BudgetImportValidationError) as context:
            self.parser.parse(workbook_bytes)

        self.assertEqual(context.exception.message, "엑셀 데이터 검증에 실패했습니다.")
        self.assertIn("지방전환사업단계", context.exception.errors[0])

    # def test_parse_rejects_partial_disaster_fields(self) -> None:
    #     row = self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001")
    #     row["재난안전법적분류"] = "1호"
    #     row["재난안전분야"] = "안전사고"
    #
    #     workbook_bytes = self._build_workbook([row])
    #
    #     with self.assertRaises(BudgetImportValidationError) as context:
    #         self.parser.parse(workbook_bytes)
    #
    #     self.assertEqual(context.exception.message, "엑셀 데이터 검증에 실패했습니다.")
    #     self.assertIn("재난안전 관련 값", context.exception.errors[0])

    def test_parse_rejects_job_type_when_job_flag_is_n(self) -> None:
        row = self._make_row(budget_seq=1, budget_type="본예산", dtl_prj_cd="DTL001")
        row["일자리사업구분"] = "직접일자리"

        workbook_bytes = self._build_workbook([row])

        with self.assertRaises(BudgetImportValidationError) as context:
            self.parser.parse(workbook_bytes)

        self.assertEqual(context.exception.message, "엑셀 데이터 검증에 실패했습니다.")
        self.assertIn("일자리사업구분", context.exception.errors[0])

    def _build_workbook(
        self,
        rows: list[dict[str, object]],
        primary_layout: list[tuple[int, str]] | None = None,
        funding_layout: list[tuple[int, str]] | None = None,
        extra_row_values: dict[str, object] | None = None,
    ) -> bytes:
        workbook = Workbook()
        worksheet = workbook.active

        primary_layout = primary_layout or list(
            BudgetOutExcelParser.PRIMARY_HEADERS.items()
        )
        funding_layout = funding_layout or list(
            BudgetOutExcelParser.FUNDING_HEADERS.items()
        )
        extra_row_values = extra_row_values or {}

        for column_index, header in primary_layout:
            worksheet.cell(row=1, column=column_index, value=header)

        for column_index, header in funding_layout:
            worksheet.cell(row=2, column=column_index, value=header)

        for row_index, row_values in enumerate(rows, start=3):
            for column_index, header in primary_layout:
                if header in row_values:
                    worksheet.cell(
                        row=row_index, column=column_index, value=row_values[header]
                    )
                elif header in extra_row_values:
                    worksheet.cell(
                        row=row_index,
                        column=column_index,
                        value=extra_row_values[header],
                    )
            for column_index, header in funding_layout:
                if header in row_values:
                    worksheet.cell(
                        row=row_index, column=column_index, value=row_values[header]
                    )
                elif header in extra_row_values:
                    worksheet.cell(
                        row=row_index,
                        column=column_index,
                        value=extra_row_values[header],
                    )

        buffer = BytesIO()
        workbook.save(buffer)
        return buffer.getvalue()

    def _make_row(
        self,
        *,
        budget_seq: int,
        budget_type: str,
        dtl_prj_cd: str,
    ) -> dict[str, object]:
        return {
            "회계연도": 2026,
            "예산차수": budget_seq,
            "예산구분": budget_type,
            "실국정렬순서": 1,
            "실국코드": "B001",
            "실국명": "실국",
            "부서순위": 1,
            "부서코드": "D001",
            "부서명": "부서",
            "분야코드": "F01",
            "분야명": "분야",
            "부문코드": "S01",
            "부문명": "부문",
            "비사업구분": "정책사업",
            "정책순위": 1,
            "정책사업코드": "P001",
            "정책이력순번": 1,
            "정책사업명": "정책사업명",
            "위원회코드": "C001",
            "위원회명": "위원회",
            "단위순위": 1,
            "단위사업코드": "U001",
            "단위이력순번": 1,
            "단위사업명": "단위사업명",
            "회계코드": "FUND1",
            "회계구분명": "일반회계",
            "세부순위": 1,
            "세부사업코드": dtl_prj_cd,
            "세부이력순번": 1,
            "세부사업명": f"세부사업명-{dtl_prj_cd}",
            "사업형태구분명": "계속",
            "성인지대상여부": "N",
            "계속비": "N",
            "자체보조구분명": "자체",
            "직접지원구분명": "직접",
            "국가직접사업": "N",
            "주민참여예산": "N",
            "지방보조금한도액제외사업": "N",
            "일자리사업여부": "N",
            "일자리사업구분": None,
            "일자리사업목표인원": 0,
            "행사축제성사업": "N",
            "지방전환사업": "N",
            "지방전환사업단계": None,
            "추진여부": "Y",
            "재난안전법적분류": None,
            "재난안전분야": None,
            "재난안전유형": None,
            "재난관리단계": None,
            "편성목코드": "205",
            "편성목명": "편성목명",
            "통계목코드": f"205-{budget_seq:02d}",
            "통계목명": "통계목명",
            "조정레벨": 1,
            "조정산출근거": "산출근거",
            "조정산출근거식": None,
            "경정조정액": 1000,
            "조정액(증감)": 0,
            "조정의무재량구분": None,
            "국고보조금": 0,
            "균특보조금": 0,
            "기금보조금": 0,
            "특별교부세": 0,
            "소방안전교부세": 0,
            "지방소멸대응기금": 0,
            "자체재원": 1000,
            "지방채": 0,
            "기타": 0,
        }


if __name__ == "__main__":
    unittest.main()
