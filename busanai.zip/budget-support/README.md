# budget-support

세입·세출 엑셀 파일을 업로드해 예산 지원용 DB에 적재하고, 적재된 데이터를 검색 및 관리하는 FastAPI 애플리케이션이다.

## 주요 기능

- **데이터 적재**: 세출 상세, 세출 Lv1, 세입 엑셀 파일 업로드 및 DB 적재
- **현황 관리**: 적재된 데이터의 지자체별·회계연도별 현황 조회 및 삭제
- **AI 검색**: 적재된 예산 데이터를 조건별(부서, 과목, 키워드 등)로 상세 검색
- **타시도 검색**: 타 지자체의 예산 데이터와 비교 검색

## 기술 스택

- Python 3.11+
- FastAPI
- SQLAlchemy (Asyncio)
- PostgreSQL (Asyncpg)
- Alembic
- openpyxl
- Jinja2 (UI Templates)

## 주요 엔드포인트

### 화면 (UI)
- `GET /`: 메인 대시보드 (사이드바 메뉴 제공)
- `GET /api/v1/budget-out/upload`: 세출 상세 업로드 화면
- `GET /api/v1/budget-out-lv1/upload`: 세출 Lv1 업로드 화면
- `GET /api/v1/budget-in/upload`: 세입 업로드 화면
- `GET /api/v1/status/page/ai-search`: AI 검색 화면
- `GET /api/v1/status/page/other-city-search`: 타시도 검색 화면
- `GET /api/v1/status/page/{type}`: 데이터 현황 관리 화면 (`budget-out`, `budget-out-lv1`, `budget-in`)
- `GET /api/v1/page/import-jobs`: 업로드 작업 상태 화면 (세입/세출Lv1 통합)

### API
- `GET /health`: 애플리케이션 상태 확인
- `POST /api/v1/budget-out/import`: 세출 상세 데이터 적재
- `POST /api/v1/budget-out-lv1/import-async`: 세출 Lv1 데이터 비동기 적재 작업 접수
- `GET /api/v1/budget-out-lv1/import-jobs/{job_id}`: 세출 Lv1 비동기 작업 상태 조회
- `GET /api/v1/budget-out-lv1/import-jobs`: 세출 Lv1 비동기 작업 목록 조회
- `POST /api/v1/budget-in/import-async`: 세입 데이터 비동기 적재 작업 접수
- `GET /api/v1/budget-in/import-jobs/{job_id}`: 세입 비동기 작업 상태 조회
- `GET /api/v1/budget-in/import-jobs`: 세입 비동기 작업 목록 조회
- `GET /api/v1/import-jobs`: 업로드 작업 목록 통합 조회 (import_type 필터 지원)
- `POST /api/v1/budget-in/import`: 세입 데이터 적재
- `GET /api/v1/ai-search/out`: 세출 데이터 상세 검색
- `GET /api/v1/ai-search/in`: 세입 데이터 상세 검색
- `GET /api/v1/ai-search/other-city`: 타시도 데이터 검색
- `DELETE /api/v1/status/{type}/{la_cd}/{fiscal_year}`: 특정 적재 데이터 삭제

## 디렉터리 구조

- `app/main.py`: FastAPI 앱 엔트리포인트 및 라우터 등록
- `app/api/v1/`: API 라우터 구현
  - `budget_out.py`: 세출 상세 업로드 및 적재
  - `budget_out_lv1.py`: 세출 Lv1 업로드 및 적재
  - `budget_in.py`: 세입 업로드 및 적재
  - `status.py`: 데이터 현황 조회, 삭제 및 페이지 렌더링
  - `ai_search.py`: 세입·세출·타시도 상세 검색 API
- `app/core/`: 데이터베이스 설정 및 공통 모듈
- `app/models/`: SQLAlchemy DB 모델 정의
- `app/services/`: 엑셀 파싱 및 데이터 적재 비즈니스 로직
- `app/schemas/`: Pydantic 모델 (요청/응답 스키마)
- `app/templates/`: HTML 템플릿 파일
- `app/static/`: CSS, JS 등 정적 자산
- `app/data/`: 지자체 마스터 데이터 (`local_governments.json`)
- `scripts/`: 배치 임포트 및 DB 초기화 스크립트

## 실행 가이드

### 1. 환경 준비

의존성 관리를 위해 `uv`를 사용한다.

```bash
uv sync
```

### 2. 데이터베이스 실행

Docker를 사용하여 PostgreSQL을 실행한다. (기본 DB명: `budgetdb`, 포트: `5432`)

```bash
./start_postgres.sh
```

### 3. DB 마이그레이션 적용

테이블 스키마를 생성한다.

```bash
.venv/bin/alembic upgrade head
```

### 4. 애플리케이션 실행

애플리케이션을 8099 포트로 실행한다.

```bash
./start_local_app.sh
```

또는 직접 실행:
```bash
.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8099
```

세출 Lv1/세입 비동기 임포트 워커 실행:
```bash
./start_import_worker.sh
```

실행 후 브라우저에서 `http://127.0.0.1:8099`에 접속한다.

## 데이터 적재 규칙

### 공통 규칙
- 파일 형식: `.xlsx` (Excel)
- 동일한 기준키(`la_cd`, `fiscal_year`, `budget_type` 등)로 재업로드 시 기존 데이터를 전체 교체한다.
- 엑셀 내부의 회계연도와 업로드 시 입력한 회계연도가 일치해야 한다.

### 파일별 특이사항
- **세출 상세**: 1행 기본 헤더, 2행 재원 헤더를 사용하며 3행부터 데이터가 시작된다.
- **세출 Lv1**: 5행 헤더를 사용하며 6행부터 데이터가 시작된다. (계층형 데이터 해석 포함)
- **세입**: 지자체 정보와 회계연도를 기준으로 적재된다.

## 개발 및 주의사항

- **DB 연결**: 기본적으로 `postgresql+asyncpg://postgres:postgres@localhost:5432/budgetdb`를 사용한다. 환경변수 `DATABASE_URL`로 변경 가능하다.
- **지자체 검증**: 업로드 시 입력한 지자체 코드가 마스터 데이터에 없으면 자동으로 신규 생성한다.
- **에러 대응**: 헤더 명칭이 불일치하거나 회계연도가 다를 경우 422 에러가 발생하므로 엑셀 포맷을 확인해야 한다.
