import json
import logging
import sys
from pathlib import Path

import httpx

# 로그 설정
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "batch_import.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger(__name__)

BASE_URL = "http://127.0.0.1:8099/api/v1"
CONFIG_PATH = Path("scripts/embedding_excel.json")


def validate_config_paths(config: dict):
    """모든 엑셀 파일 경로가 존재하는지 미리 검증합니다."""
    missing_files = []

    for section in ["out", "in", "out_lv1"]:
        for item in config.get(section, []):
            file_format = item.get("file_format")
            fiscal_years = item.get("fiscal_years", [])

            if not file_format:
                logger.error(f"{section} 설정 항목에 'file_format'이 누락되었습니다: {item}")
                sys.exit(1)

            if not fiscal_years:
                logger.warning(f"{section} 설정 항목에 'fiscal_years' 리스트가 비어있습니다: {item}")
                continue

            for year in fiscal_years:
                try:
                    path_str = file_format.format(fiscal_year=year)
                    path = Path(path_str)
                    if not path.exists():
                        missing_files.append(path_str)
                except Exception as e:
                    logger.error(f"경로 생성 중 오류 발생 (year={year}, format={file_format}): {str(e)}")
                    sys.exit(1)

    if missing_files:
        logger.error("다음 엑셀 파일들을 찾을 수 없습니다:")
        for f in missing_files:
            logger.error(f"  - {f}")
        logger.error("배치 작업을 시작하지 않고 중단합니다.")
        sys.exit(1)

    logger.info("모든 설정 파일 경로 검증 완료.")


def upload_file(endpoint: str, data: dict, file_path: str):
    url = f"{BASE_URL}{endpoint}/import-async"
    path = Path(file_path)

    if not path.exists():
        logger.error(f"파일을 찾을 수 없습니다: {file_path}")
        sys.exit(1)

    logger.info(f"업로드 시작: {url} (파일: {path.name})")

    try:
        with open(path, "rb") as f:
            files = {
                "file": (
                    path.name,
                    f,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
            }
            # httpx.post with files and data
            # data values should be strings for multipart/form-data
            form_data = {k: str(v) for k, v in data.items() if v is not None}

            response = httpx.post(url, data=form_data, files=files, timeout=None)

            if response.status_code == 200:
                logger.info(f"업로드 성공: {response.json()}")
            else:
                logger.error(
                    f"업로드 실패 (HTTP {response.status_code}): {response.text}"
                )
                sys.exit(1)
    except Exception as e:
        logger.error(f"요청 중 오류 발생: {str(e)}")
        sys.exit(1)


def main():
    if not CONFIG_PATH.exists():
        logger.error(f"설정 파일을 찾을 수 없습니다: {CONFIG_PATH}")
        sys.exit(1)

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        config = json.load(f)

    # 엑셀 파일 경로 검증 먼저 수행
    validate_config_paths(config)

    # 세출 (out)
    for item in config.get("out", []):
        file_format = item.get("file_format")
        for year in item.get("fiscal_years", []):
            data = {
                "la_cd": item.get("la_cd"),
                "w_city_nm": item.get("w_city_nm"),
                "la_nm": item.get("la_nm"),
                "fiscal_year": year,
            }
            file_path = file_format.format(fiscal_year=year)
            upload_file("/budget-out", data, file_path)

    # 세입 (in)
    for item in config.get("in", []):
        file_format = item.get("file_format")
        for year in item.get("fiscal_years", []):
            data = {
                "la_cd": item.get("la_cd"),
                "w_city_nm": item.get("w_city_nm"),
                "la_nm": item.get("la_nm"),
                "fiscal_year": year,
            }
            file_path = file_format.format(fiscal_year=year)
            upload_file("/budget-in", data, file_path)

    # 세출_lv1 (out_lv1)
    for item in config.get("out_lv1", []):
        file_format = item.get("file_format")
        for year in item.get("fiscal_years", []):
            data = {"fiscal_year": year}
            file_path = file_format.format(fiscal_year=year)
            upload_file("/budget-out-lv1", data, file_path)

    logger.info("모든 배치 작업이 완료되었습니다.")


if __name__ == "__main__":
    main()
