import asyncio
import sys

from sqlalchemy import text

# app 모듈 가져오도록
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

from app.core.database import dispose_engine, get_engine
from app.models import Base


async def reset_database():
    """
    모든 테이블의 데이터를 삭제하고 증분 ID를 1로 초기화합니다. (TRUNCATE ... RESTART IDENTITY CASCADE)
    """
    engine = get_engine()

    # Base.metadata.tables.keys()를 통해 모든 테이블 이름을 가져옵니다.
    table_names = list(Base.metadata.tables.keys())

    if not table_names:
        print("초기화할 테이블이 정의되어 있지 않습니다.")
        return

    # PostgreSQL용 TRUNCATE 쿼리 생성
    # CASCADE 옵션으로 외래 키 관계가 있는 테이블들도 함께 처리하며,
    # RESTART IDENTITY로 시퀀스(ID)를 1로 초기화합니다.
    tables_str = ", ".join([f'"{name}"' for name in table_names])
    truncate_query = f"TRUNCATE TABLE {tables_str} RESTART IDENTITY CASCADE;"

    print(f"다음 테이블들을 초기화합니다: {', '.join(table_names)}")

    try:
        async with engine.begin() as conn:
            await conn.execute(text(truncate_query))
        print("\n데이터베이스 초기화가 성공적으로 완료되었습니다.")
    except Exception as e:
        print(f"\n데이터베이스 초기화 중 오류가 발생했습니다: {e}", file=sys.stderr)
    finally:
        await dispose_engine()


if __name__ == "__main__":
    asyncio.run(reset_database())
