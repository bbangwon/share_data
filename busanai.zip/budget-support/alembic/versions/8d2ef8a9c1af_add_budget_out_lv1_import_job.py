"""add budget out lv1 import job

Revision ID: 8d2ef8a9c1af
Revises: 04a02ea94551
Create Date: 2026-05-28 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "8d2ef8a9c1af"
down_revision: Union[str, Sequence[str], None] = "04a02ea94551"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "TB_BUDGET_OUT_LV1_IMPORT_JOB",
        sa.Column("job_id", sa.String(length=36), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("stage", sa.String(length=20), nullable=True),
        sa.Column("progress_pct", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("rows_total", sa.Integer(), nullable=True),
        sa.Column("rows_processed", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("request_fiscal_year", sa.Integer(), nullable=False),
        sa.Column("request_la_cd", sa.String(length=10), nullable=True),
        sa.Column("source_filename", sa.String(length=255), nullable=False),
        sa.Column("stored_file_path", sa.String(length=500), nullable=False),
        sa.Column("error_summary", sa.String(length=500), nullable=True),
        sa.Column("error_detail", sa.Text(), nullable=True),
        sa.Column("worker_id", sa.String(length=100), nullable=True),
        sa.Column("retry_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("inserted_counts", sa.JSON(), nullable=True),
        sa.Column("warnings", sa.JSON(), nullable=True),
        sa.Column("budget_versions", sa.JSON(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("job_id"),
    )
    op.create_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_STATUS",
        "TB_BUDGET_OUT_LV1_IMPORT_JOB",
        ["status"],
        unique=False,
    )
    op.create_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_CREATED_AT",
        "TB_BUDGET_OUT_LV1_IMPORT_JOB",
        ["created_at"],
        unique=False,
    )
    op.create_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_UPDATED_AT",
        "TB_BUDGET_OUT_LV1_IMPORT_JOB",
        ["updated_at"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_UPDATED_AT",
        table_name="TB_BUDGET_OUT_LV1_IMPORT_JOB",
    )
    op.drop_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_CREATED_AT",
        table_name="TB_BUDGET_OUT_LV1_IMPORT_JOB",
    )
    op.drop_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_STATUS",
        table_name="TB_BUDGET_OUT_LV1_IMPORT_JOB",
    )
    op.drop_table("TB_BUDGET_OUT_LV1_IMPORT_JOB")
