"""unify budget import job

Revision ID: c5bd4f3a1102
Revises: 8d2ef8a9c1af
Create Date: 2026-05-29 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "c5bd4f3a1102"
down_revision: Union[str, Sequence[str], None] = "8d2ef8a9c1af"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.drop_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_UPDATED_AT",
        table_name="TB_BUDGET_OUT_LV1_IMPORT_JOB",
    )
    op.drop_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_CREATED_AT",
        table_name="TB_BUDGET_OUT_LV1_IMPORT_JOB",
    )
    op.drop_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_STATUS",
        table_name="TB_BUDGET_OUT_LV1_IMPORT_JOB",
    )
    op.rename_table("TB_BUDGET_OUT_LV1_IMPORT_JOB", "TB_BUDGET_IMPORT_JOB")
    op.add_column(
        "TB_BUDGET_IMPORT_JOB",
        sa.Column("import_type", sa.String(length=50), nullable=True),
    )
    op.add_column(
        "TB_BUDGET_IMPORT_JOB",
        sa.Column("request_payload", sa.JSON(), nullable=True),
    )
    op.execute(
        sa.text(
            """
            UPDATE \"TB_BUDGET_IMPORT_JOB\"
            SET import_type = 'budget_out_lv1',
                request_payload = json_build_object('fiscal_year', request_fiscal_year)
            """
        )
    )
    op.alter_column("TB_BUDGET_IMPORT_JOB", "import_type", nullable=False)
    op.alter_column("TB_BUDGET_IMPORT_JOB", "request_payload", nullable=False)
    op.create_index(
        "IDX_BUDGET_IMPORT_JOB_STATUS",
        "TB_BUDGET_IMPORT_JOB",
        ["status"],
        unique=False,
    )
    op.create_index(
        "IDX_BUDGET_IMPORT_JOB_IMPORT_TYPE_STATUS",
        "TB_BUDGET_IMPORT_JOB",
        ["import_type", "status"],
        unique=False,
    )
    op.create_index(
        "IDX_BUDGET_IMPORT_JOB_CREATED_AT",
        "TB_BUDGET_IMPORT_JOB",
        ["created_at"],
        unique=False,
    )
    op.create_index(
        "IDX_BUDGET_IMPORT_JOB_UPDATED_AT",
        "TB_BUDGET_IMPORT_JOB",
        ["updated_at"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        "IDX_BUDGET_IMPORT_JOB_UPDATED_AT",
        table_name="TB_BUDGET_IMPORT_JOB",
    )
    op.drop_index(
        "IDX_BUDGET_IMPORT_JOB_CREATED_AT",
        table_name="TB_BUDGET_IMPORT_JOB",
    )
    op.drop_index(
        "IDX_BUDGET_IMPORT_JOB_IMPORT_TYPE_STATUS",
        table_name="TB_BUDGET_IMPORT_JOB",
    )
    op.drop_index(
        "IDX_BUDGET_IMPORT_JOB_STATUS",
        table_name="TB_BUDGET_IMPORT_JOB",
    )
    op.drop_column("TB_BUDGET_IMPORT_JOB", "request_payload")
    op.drop_column("TB_BUDGET_IMPORT_JOB", "import_type")
    op.rename_table("TB_BUDGET_IMPORT_JOB", "TB_BUDGET_OUT_LV1_IMPORT_JOB")
    op.create_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_STATUS",
        "TB_BUDGET_OUT_LV1_IMPORT_JOB",
        ["status"],
        unique=False,
    )
    op.create_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_CREATED_AT",
        "TB_BUDGET_OUT_LV1_IMPORT_JOB",
        ["created_at"],
        unique=False,
    )
    op.create_index(
        "IDX_BUDGET_OUT_LV1_IMPORT_JOB_UPDATED_AT",
        "TB_BUDGET_OUT_LV1_IMPORT_JOB",
        ["updated_at"],
        unique=False,
    )
