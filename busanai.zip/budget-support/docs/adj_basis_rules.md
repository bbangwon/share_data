# 산출근거내용 및 산출근거내용(full) 주입 규칙
## 공통
- 레벨별 텍스트를 기억하기 위한 스택이나 맵 구조의 캐시를 사용한다.
- 새로운 예산서 파일을 읽기 시작할 때마다 이전 파일의 레벨/들여쓰기 캐시가 있다면 초기화한다.

## 세입예산서(BudgetOutFact)
- adj_basis_org은 엑셀 자료의 산출근거를 그대로 저장한다.
- 조정레벨이 1인 경우에는 adj_basis_full에 adj_basis_org을 그대로 저장한다.
- 조정레벨이 1 초과일 경우에는 조정레벨을 확인하여 1이 될때까지 최근에 주입된 레코드를 기반으로 산출근거를 조합하여 adj_basis_full에 저장한다.
- 산출근거내용을 조합할때 공백을 한칸 추가하여 조합한다.
    - 예시) adj_formula가 "100원"이고, 현재 추가하는 자료의 adj_basis_org가 "B"이고 조정레벨이 2인 경우, 최근에 주입된 레코드 중에서 조정레벨이 1인 레코드의 adj_basis_org가 "A"라면, 현재 레코드의 adj_basis_full은 "A B"가 된다.

## 세출예산서(BudgetInFact)
- adj_basis_org은 엑셀 자료의 산출근거를 그대로 저장한다.
- adj_basis_org에 들여쓰기가 없는 경우에는 adj_basis_org을 그대로 adj_basis_full에 저장한다.
- adj_basis_org에 들여쓰기가 있는 경우, 최근에 주입된 레코드에서 adj_basis_org의 들여쓰기를 하지 않은 레코드까지 확인하여 산출근거를 조합하여 adj_basis_full에 저장한다.
- 들여쓰기는 레벨마다 2칸씩 증가한다.
- adj_basis_full 에 저장시에는 들여쓰기 수준을 확인하는 공백을 제거하여 저장한다.
- 산출근거내용을 조합할때 공백을 한칸 추가하여 조합한다.
    - 예시) adj_formula가 "100원"이고, 이번에 추가되는 자료의 adj_basis_org가 "  B"이고 최근에 주입된 레코드 중에서 adj_basis_org의 들여쓰기 수준이 낮은 "A" 라면, 현재 레코드의 adj_basis_full은 "A B"가 된다. 
  
## 세출예산서Lv1(BudgetOutFactLv1)
- 여기는 수준 개념이 없으므로 adj_basis에 엑셀 자료 산출근거를 그대로 저장한다.