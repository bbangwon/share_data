#!/bin/bash

set -euo pipefail

python -m app.workers.budget_import_worker
