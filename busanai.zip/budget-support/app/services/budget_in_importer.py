import logging
from dataclasses import dataclass

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import (
    BudgetInAccountSubject,
    BudgetInFact,
    BudgetInFundAccount,
    BudgetInOrganization,
    BudgetInVersion,
    BudgetLocalGovernment,
)
from app.schemas.imports import (
    BudgetInImportRequest,
    BudgetInImportResponse,
    BudgetInImportVersionResponse,
)

from .adj_basis_builder import BudgetInAdjBasisBuilder
from .excel_parser import (
    BudgetImportValidationError,
    BudgetInExcelParser,
    ParsedBudgetInRow,
)

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class BudgetInImportCounters:
    local_government: int = 0
    budget_version: int = 0
    organization: int = 0
    fund_account: int = 0
    account_subject: int = 0
    budget_fact: int = 0

    def to_dict(self) -> dict[str, int]:
        return {
            "local_government": self.local_government,
            "budget_version": self.budget_version,
            "organization": self.organization,
            "fund_account": self.fund_account,
            "account_subject": self.account_subject,
            "budget_fact": self.budget_fact,
        }


class BudgetInImportService:
    def __init__(self, parser: BudgetInExcelParser | None = None):
        self.parser = parser or BudgetInExcelParser()

    async def import_excel(
        self,
        session: AsyncSession,
        request: BudgetInImportRequest,
        source_filename: str,
        file_bytes: bytes,
    ) -> BudgetInImportResponse:
        """엑셀 파일을 파싱하여 세입 예산 데이터를 데이터베이스에 저장한다."""
        parsed = self.parser.parse(file_bytes)

        if parsed.fiscal_year != request.fiscal_year:
            raise BudgetImportValidationError(
                "요청한 회계연도와 엑셀의 회계연도가 다릅니다.",
                [
                    f"요청 회계연도: {request.fiscal_year}",
                    f"엑셀 회계연도: {parsed.fiscal_year}",
                ],
            )

        async with session.begin():
            (
                local_government,
                created_local_government,
            ) = await self._resolve_local_government(
                session,
                request,
            )
            counters = BudgetInImportCounters(
                local_government=1 if created_local_government else 0,
            )

            await self._delete_existing_budget_fact(
                session,
                local_government.la_cd,
                parsed.fiscal_year,
            )

            await self._persist_rows(
                session,
                local_government.la_cd,
                parsed.rows,
                counters,
            )

        return BudgetInImportResponse(
            la_cd=local_government.la_cd,
            la_nm=local_government.la_nm,
            fiscal_year=parsed.fiscal_year,
            budget_versions=[
                BudgetInImportVersionResponse(
                    budget_type=budget_version.budget_type,
                    budget_confirm_date=budget_version.budget_confirm_date,
                    row_count=budget_version.row_count,
                )
                for budget_version in parsed.budget_versions
            ],
            source_filename=source_filename,
            rows_processed=len(parsed.rows),
            inserted_counts=counters.to_dict(),
            warnings=[],
        )

    async def _resolve_local_government(
        self,
        session: AsyncSession,
        request: BudgetInImportRequest,
    ) -> tuple[BudgetLocalGovernment, bool]:
        """지자체 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        if request.la_cd:
            local_government = (
                await session.execute(
                    select(BudgetLocalGovernment).where(
                        BudgetLocalGovernment.la_cd == request.la_cd
                    )
                )
            ).scalar_one_or_none()

            if local_government is not None:
                if (
                    request.la_nm != local_government.la_nm
                    or request.w_city_nm != local_government.w_city_nm
                ):
                    raise BudgetImportValidationError(
                        "입력한 지자체 코드와 명칭이 일치하지 않습니다.",
                        [
                            f"입력 la_cd={request.la_cd}",
                            f"입력 la_nm={request.la_nm}",
                            f"입력 w_city_nm={request.w_city_nm}",
                            f"기존 la_nm={local_government.la_nm}",
                            f"기존 w_city_nm={local_government.w_city_nm}",
                        ],
                    )
                return local_government, False

        if request.la_cd and request.la_nm and request.w_city_nm:
            local_government = BudgetLocalGovernment(
                la_cd=request.la_cd,
                w_city_nm=request.w_city_nm,
                la_nm=request.la_nm,
            )
            session.add(local_government)
            await session.flush()
            return local_government, True

        raise BudgetImportValidationError(
            "지자체 정보를 확인할 수 없습니다.",
            [
                "기존 지자체 마스터에 la_cd 또는 la_nm 또는 w_city_nm이 존재하지 않습니다."
            ],
        )

    async def _delete_existing_budget_fact(
        self,
        session: AsyncSession,
        la_cd: str,
        fiscal_year: int,
    ) -> None:
        """기존에 저장된 세입 예산 데이터를 삭제한다."""
        await session.execute(
            delete(BudgetInFact).where(
                BudgetInFact.la_cd == la_cd,
                BudgetInFact.fiscal_year == fiscal_year,
            )
        )

    async def _persist_rows(
        self,
        session: AsyncSession,
        la_cd: str,
        rows: list[ParsedBudgetInRow],
        counters: BudgetInImportCounters,
    ) -> None:
        """엑셀 파일을 파싱하여 세입 예산 데이터를 데이터베이스에 저장한다."""
        total_rows = len(rows)
        logger.info(
            f"[BudgetIn] 데이터 적재 시작: {total_rows}행 ({la_cd})..."
        )  # 데이터 적재 시작
        adj_basis_builder = BudgetInAdjBasisBuilder()

        version_cache = {
            item.budget_confirm_date: item
            for item in (
                await session.execute(
                    select(BudgetInVersion).where(
                        BudgetInVersion.la_cd == la_cd,
                        BudgetInVersion.fiscal_year == rows[0].fiscal_year,
                    )
                )
            ).scalars()
        }

        organization_cache = {
            item.dept_cd: item
            for item in (
                await session.execute(
                    select(BudgetInOrganization).where(
                        BudgetInOrganization.la_cd == la_cd,
                        BudgetInOrganization.fiscal_year == rows[0].fiscal_year,
                    )
                )
            ).scalars()
        }
        fund_account_cache = {
            item.fund_cd: item
            for item in (await session.execute(select(BudgetInFundAccount))).scalars()
        }
        account_subject_cache = {
            self._account_subject_key(
                item.fiscal_year,
                item.mok_cd,
                item.mok_nm,
                item.jang_cd,
                item.jang_nm,
                item.gwan_cd,
                item.gwan_nm,
                item.hang_cd,
                item.hang_nm,
            ): item
            for item in (
                await session.execute(
                    select(BudgetInAccountSubject).where(
                        BudgetInAccountSubject.fiscal_year == rows[0].fiscal_year
                    )
                )
            ).scalars()
        }

        for i, row in enumerate(rows, 1):
            await self._upsert_version(
                session,
                version_cache,
                la_cd,
                row,
                counters,
            )

            await self._upsert_organization(
                session,
                organization_cache,
                la_cd,
                row,
                counters,
            )
            await self._upsert_fund_account(session, fund_account_cache, row, counters)
            account_subject = await self._upsert_account_subject(
                session,
                account_subject_cache,
                row,
                counters,
            )

            session.add(
                BudgetInFact(
                    la_cd=la_cd,
                    fiscal_year=row.fiscal_year,
                    budget_confirm_date=row.budget_confirm_date,
                    dept_cd=row.dept_cd,
                    fund_cd=row.fund_cd,
                    acc_sub_id=account_subject.acc_sub_id,
                    adj_basis_org=row.adj_basis_org,
                    adj_basis_full=adj_basis_builder.compute(row.adj_basis_org),
                    adj_formula=row.adj_formula,
                    level_amt=row.level_amt,
                    budget_amt=row.budget_amt,
                    prev_amt=row.prev_amt,
                    diff_amt=row.diff_amt,
                )
            )
            counters.budget_fact += 1

            if i % 1000 == 0 or i == total_rows:
                logger.info(
                    f"[BudgetIn] 진행중 {i} / {total_rows} 행..."
                )  # 진행 상황 로그

        await session.flush()

    async def _upsert_version(
        self,
        session: AsyncSession,
        cache: dict[str, BudgetInVersion],
        la_cd: str,
        row: ParsedBudgetInRow,
        counters: BudgetInImportCounters,
    ) -> BudgetInVersion:
        """버전 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        version = cache.get(row.budget_confirm_date)
        if version is None:
            version = BudgetInVersion(
                la_cd=la_cd,
                fiscal_year=row.fiscal_year,
                budget_type=row.budget_type,
                budget_confirm_date=row.budget_confirm_date,
            )
            session.add(version)
            await session.flush()
            cache[row.budget_confirm_date] = version
            counters.budget_version += 1
        return version

    async def _upsert_organization(
        self,
        session: AsyncSession,
        cache: dict[str, BudgetInOrganization],
        la_cd: str,
        row: ParsedBudgetInRow,
        counters: BudgetInImportCounters,
    ) -> BudgetInOrganization:
        organization = cache.get(row.dept_cd)
        if organization is None:
            organization = BudgetInOrganization(
                la_cd=la_cd,
                fiscal_year=row.fiscal_year,
                dept_cd=row.dept_cd,
                dept_nm=row.dept_nm,
            )
            session.add(organization)
            await session.flush()
            cache[row.dept_cd] = organization
            counters.organization += 1
        else:
            organization.dept_nm = row.dept_nm
        return organization

    async def _upsert_fund_account(
        self,
        session: AsyncSession,
        cache: dict[str, BudgetInFundAccount],
        row: ParsedBudgetInRow,
        counters: BudgetInImportCounters,
    ) -> BudgetInFundAccount:
        fund_account = cache.get(row.fund_cd)
        if fund_account is None:
            fund_account = BudgetInFundAccount(
                fund_cd=row.fund_cd,
                fund_nm=row.fund_nm,
            )
            session.add(fund_account)
            await session.flush()
            cache[row.fund_cd] = fund_account
            counters.fund_account += 1
        else:
            fund_account.fund_nm = row.fund_nm
        return fund_account

    async def _upsert_account_subject(
        self,
        session: AsyncSession,
        cache: dict[tuple, BudgetInAccountSubject],
        row: ParsedBudgetInRow,
        counters: BudgetInImportCounters,
    ) -> BudgetInAccountSubject:
        key = self._account_subject_key(
            row.fiscal_year,
            row.mok_cd,
            row.mok_nm,
            row.jang_cd,
            row.jang_nm,
            row.gwan_cd,
            row.gwan_nm,
            row.hang_cd,
            row.hang_nm,
        )
        account_subject = cache.get(key)
        if account_subject is None:
            account_subject = BudgetInAccountSubject(
                fiscal_year=row.fiscal_year,
                mok_cd=row.mok_cd,
                mok_nm=row.mok_nm,
                jang_cd=row.jang_cd,
                jang_nm=row.jang_nm,
                gwan_cd=row.gwan_cd,
                gwan_nm=row.gwan_nm,
                hang_cd=row.hang_cd,
                hang_nm=row.hang_nm,
            )
            session.add(account_subject)
            await session.flush()
            cache[key] = account_subject
            counters.account_subject += 1
        return account_subject

    def _account_subject_key(
        self,
        fiscal_year: int,
        mok_cd: str,
        mok_nm: str,
        jang_cd: str,
        jang_nm: str,
        gwan_cd: str,
        gwan_nm: str,
        hang_cd: str,
        hang_nm: str,
    ) -> tuple:
        return (
            fiscal_year,
            mok_cd,
            mok_nm,
            jang_cd,
            jang_nm,
            gwan_cd,
            gwan_nm,
            hang_cd,
            hang_nm,
        )
