import logging
import re
from dataclasses import dataclass
from io import BytesIO
from typing import Any

from openpyxl import load_workbook

from .excel_parser import BudgetImportValidationError, BudgetOutExcelParser

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class ParsedBudgetOutLv1Row:
    fiscal_year: int
    la_cd: str
    la_nm: str
    w_city_nm: str
    policy_proj_nm: str
    unit_prj_nm: str
    dtl_prj_cd: str
    dtl_prj_nm: str
    nat_sub_prj_nm: str | None
    budget_type: str
    self_sub_type: str
    not_prj_type: str
    budg_mok_nm: str
    stat_mok_nm: str
    adj_basis: str
    sum_amt: int
    adj_details: dict[str, int]


@dataclass(slots=True)
class ParsedBudgetOutLv1Version:
    budget_type: str
    row_count: int


@dataclass(slots=True)
class ParsedBudgetOutLv1Workbook:
    sheet_name: str
    fiscal_year: int
    la_cd: str
    la_nm: str
    w_city_nm: str
    budget_versions: list[ParsedBudgetOutLv1Version]
    rows: list[ParsedBudgetOutLv1Row]


class BudgetOutLv1ExcelParser(BudgetOutExcelParser):
    PRIMARY_FIELD_HEADERS = {
        "fiscal_year": "회계연도",
        "la_cd": "지방자치단체코드",
        "la_nm": "지방자치단체명",
        "w_city_nm": "광역시도명",
        "policy_proj_nm": "정책사업명",
        "unit_prj_nm": "단위사업명",
        "dtl_prj_cd": "세부사업코드",
        "dtl_prj_nm": "세부사업명",
        "nat_sub_prj_nm": "국고보조사업명",
        "budget_type": "예산편성구분",
        "self_sub_type": "보조예산구분명",
        "not_prj_type": "비사업구분명",
        "budg_mok_nm": "편성목",
        "stat_mok_nm": "통계목",
        "adj_basis": "산출근거내용",
    }

    FUNDING_FIELD_HEADERS = {
        "sum_amt": "예산합계",
    }

    OPTIONAL_PRIMARY_FIELDS = {
        "nat_sub_prj_nm",
    }

    OPTIONAL_FUNDING_FIELDS: set[str] = set()

    def parse(self, file_bytes: bytes) -> ParsedBudgetOutLv1Workbook:
        workbook = load_workbook(BytesIO(file_bytes), data_only=True)
        worksheet = workbook[workbook.sheetnames[0]]
        header_columns, adj_columns = self._validate_headers_lv1(worksheet)

        total_rows = worksheet.max_row
        logger.info(f"[BudgetOutLv1] 엑셀 분석 시작: {total_rows}행 (헤더 포함)")

        errors: list[str] = []
        rows: list[ParsedBudgetOutLv1Row] = []

        # 계층형 엑셀에서 비어 있는 셀을 이전 값으로 보완하기 위한 현재 상태
        current_policy = ""
        current_unit = ""
        current_dtl_cd = ""
        current_dtl_nm = ""
        current_la_cd = ""
        current_la_nm = ""
        current_w_city_nm = ""
        current_fiscal_year = None
        current_budget_type = ""
        current_self_sub_type = ""
        current_not_prj_type = ""
        current_budg_mok = ""
        current_stat_mok = ""

        # 5행 헤더 다음인 6행부터 실제 데이터를 읽는다.
        for row_index in range(6, total_rows + 1):
            row_values = {
                field_name: worksheet.cell(row=row_index, column=column_index).value
                if column_index is not None
                else None
                for field_name, column_index in header_columns.items()
            }
            adj_values = {
                nm: worksheet.cell(row=row_index, column=col_idx).value
                for nm, col_idx in adj_columns.items()
            }

            # 완전히 비어 있는 행은 건너뛴다.
            if not any(self._normalize_text(val) for val in row_values.values()):
                continue

            # 상위 행에서 내려오는 계층 상태를 갱신한다.
            fy = self._optional_int(row_values["fiscal_year"])
            if fy:
                current_fiscal_year = fy

            la_cd = self._normalize_text(row_values["la_cd"])
            if la_cd:
                current_la_cd = la_cd

            la_nm = self._normalize_text(row_values["la_nm"])
            if la_nm:
                current_la_nm = la_nm

            w_city_nm = self._normalize_text(row_values["w_city_nm"])
            if w_city_nm:
                current_w_city_nm = w_city_nm

            policy = self._normalize_text(row_values["policy_proj_nm"])
            if policy:
                current_policy = policy

            unit = self._normalize_text(row_values["unit_prj_nm"])
            if unit:
                current_unit = unit

            dtl_cd = self._normalize_text(row_values["dtl_prj_cd"])
            if dtl_cd:
                current_dtl_cd = dtl_cd

            dtl_nm = self._normalize_text(row_values["dtl_prj_nm"])
            if dtl_nm:
                # 소계 행은 실제 적재 대상이 아니므로 건너뛴다.
                if dtl_nm.endswith("소계"):
                    continue
                current_dtl_nm = dtl_nm

            budget_type = self._normalize_text(row_values["budget_type"])
            if budget_type:
                current_budget_type = budget_type

            self_sub_type = self._normalize_text(row_values["self_sub_type"])
            if self_sub_type:
                current_self_sub_type = self_sub_type

            not_prj_type = self._normalize_text(row_values["not_prj_type"])
            if not_prj_type:
                current_not_prj_type = not_prj_type

            budg_mok = self._normalize_text(row_values["budg_mok_nm"])
            if budg_mok:
                current_budg_mok = budg_mok

            stat_mok = self._normalize_text(row_values["stat_mok_nm"])
            if stat_mok:
                current_stat_mok = stat_mok

            # 세부사업명이 아직 확정되지 않은 구간은 적재하지 않는다.
            if not current_dtl_nm:
                continue

            # 산출근거가 비어 있으면 실제 데이터 행이 아닌 구간으로 보고 건너뛴다.
            if not self._normalize_text(row_values["adj_basis"]):
                continue

            try:
                # 누락된 셀은 현재 계층 상태로 보완한 뒤 행 파싱을 수행한다.
                effective_values = row_values.copy()
                effective_values["fiscal_year"] = current_fiscal_year
                effective_values["la_cd"] = current_la_cd
                effective_values["la_nm"] = current_la_nm
                effective_values["w_city_nm"] = current_w_city_nm
                effective_values["policy_proj_nm"] = current_policy
                effective_values["unit_prj_nm"] = current_unit
                effective_values["dtl_prj_cd"] = current_dtl_cd
                effective_values["dtl_prj_nm"] = current_dtl_nm
                effective_values["budget_type"] = current_budget_type
                effective_values["self_sub_type"] = current_self_sub_type
                effective_values["not_prj_type"] = current_not_prj_type
                effective_values["budg_mok_nm"] = current_budg_mok
                effective_values["stat_mok_nm"] = current_stat_mok

                rows.append(
                    self._parse_row_lv1(row_index, effective_values, adj_values)
                )
            except ValueError as exc:
                errors.append(f"{row_index}행: {exc}")

            if row_index % 1000 == 0 or row_index == total_rows:
                logger.info(
                    f"[BudgetOutLv1] 엑셀 분석 진행: {row_index} / {total_rows}행..."
                )

        if errors:
            raise BudgetImportValidationError(
                "엑셀 데이터 검증에 실패했습니다.",
                errors,
            )

        if not rows:
            raise BudgetImportValidationError("적재할 데이터 행이 없습니다.")

        fiscal_years = {row.fiscal_year for row in rows}
        if len(fiscal_years) != 1:
            raise BudgetImportValidationError(
                "엑셀 내 회계연도 값이 하나로 고정되어야 합니다."
            )

        la_codes = sorted(list({row.la_cd for row in rows}))
        la_names = sorted(list({row.la_nm for row in rows}))
        w_city_names = sorted(list({row.w_city_nm for row in rows}))

        budget_versions = self._collect_budget_versions_lv1(rows)

        return ParsedBudgetOutLv1Workbook(
            sheet_name=worksheet.title,
            fiscal_year=fiscal_years.pop(),
            la_cd=", ".join(la_codes),
            la_nm=", ".join(la_names),
            w_city_nm=", ".join(w_city_names),
            budget_versions=budget_versions,
            rows=rows,
        )

    def _collect_budget_versions_lv1(
        self,
        rows: list[ParsedBudgetOutLv1Row],
    ) -> list[ParsedBudgetOutLv1Version]:
        row_counts: dict[str, int] = {}
        for row in rows:
            row_counts[row.budget_type] = row_counts.get(row.budget_type, 0) + 1

        return [
            ParsedBudgetOutLv1Version(
                budget_type=budget_type,
                row_count=row_count,
            )
            for budget_type, row_count in sorted(row_counts.items())
        ]

    def _validate_headers_lv1(
        self, worksheet
    ) -> tuple[dict[str, int | None], dict[str, int]]:
        # Lv1 포맷은 5행을 헤더 행으로 사용한다.
        headers = self._extract_row_headers(worksheet, row_index=5)

        field_to_column: dict[str, int | None] = {}
        missing = []

        for field_name, header_val in self.PRIMARY_FIELD_HEADERS.items():
            expected_headers = (
                header_val if isinstance(header_val, tuple) else (header_val,)
            )
            matched_header = next((h for h in expected_headers if h in headers), None)

            if matched_header:
                field_to_column[field_name] = headers[matched_header]
            else:
                field_to_column[field_name] = None
                if field_name not in self.OPTIONAL_PRIMARY_FIELDS:
                    missing.append(expected_headers[0])

        for field_name, header_val in self.FUNDING_FIELD_HEADERS.items():
            expected_headers = (
                header_val if isinstance(header_val, tuple) else (header_val,)
            )
            matched_header = next((h for h in expected_headers if h in headers), None)

            if matched_header:
                field_to_column[field_name] = headers[matched_header]
            else:
                field_to_column[field_name] = None
                if field_name not in self.OPTIONAL_FUNDING_FIELDS:
                    missing.append(expected_headers[0])

        if missing:
            raise BudgetImportValidationError(
                "기본 헤더 형식이 예상과 다릅니다.",
                [f"누락된 5행 헤더: {header}" for header in missing],
            )

        # 예산합계 컬럼 우측의 모든 컬럼을 조정증감 항목으로 수집한다.
        # 헤더 셀 값이 없는 컬럼은 "이름없음_N" 형태로 명명한다.
        sum_amt_col = field_to_column.get("sum_amt")
        adj_columns: dict[str, int] = {}
        if sum_amt_col is not None:
            unnamed_count = 0
            for col_idx in range(sum_amt_col + 1, worksheet.max_column + 1):
                cell_val = self._normalize_text(
                    worksheet.cell(row=5, column=col_idx).value
                )
                if cell_val:
                    nm = cell_val
                else:
                    unnamed_count += 1
                    nm = f"이름없음_{unnamed_count}"
                adj_columns[nm] = col_idx

        return field_to_column, adj_columns

    def _parse_row_lv1(
        self, row_index: int, values: dict[str, Any], adj_values: dict[str, Any]
    ) -> ParsedBudgetOutLv1Row:
        return ParsedBudgetOutLv1Row(
            fiscal_year=self._parse_int(values["fiscal_year"], "회계연도", row_index),
            la_cd=self._require_code(values["la_cd"], "지방자치단체코드", row_index),
            la_nm=self._require_text(values["la_nm"], "지방자치단체명", row_index),
            w_city_nm=self._require_text(values["w_city_nm"], "광역시도명", row_index),
            policy_proj_nm=self._require_text(
                values["policy_proj_nm"], "정책사업명", row_index
            ),
            unit_prj_nm=self._require_text(
                values["unit_prj_nm"], "단위사업명", row_index
            ),
            dtl_prj_cd=self._require_code(
                values["dtl_prj_cd"], "세부사업코드", row_index
            ),
            dtl_prj_nm=self._require_text(
                values["dtl_prj_nm"], "세부사업명", row_index
            ),
            nat_sub_prj_nm=self._optional_text(values["nat_sub_prj_nm"]),
            budget_type=self._require_text(
                values["budget_type"], "예산편성구분", row_index
            ),
            self_sub_type=self._require_text(
                values["self_sub_type"], "보조예산구분명", row_index
            ),
            not_prj_type=self._require_text(
                values["not_prj_type"], "비사업구분명", row_index
            ),
            budg_mok_nm=self._require_text(
                values["budg_mok_nm"], "예산목명", row_index
            ),
            stat_mok_nm=self._require_text(
                values["stat_mok_nm"], "통계목명", row_index
            ),
            adj_basis=self._require_text(
                values["adj_basis"], "산출근거내용", row_index
            ),
            sum_amt=self._parse_int(
                values["sum_amt"], "예산합계", row_index, default=0
            ),
            adj_details={
                nm: amt
                for nm, raw_val in adj_values.items()
                if (amt := self._parse_int(raw_val, nm, row_index, default=0)) != 0
            },
        )

    def _optional_int(self, value: Any) -> int | None:
        if value is None:
            return None
        try:
            if isinstance(value, str):
                cleaned = re.sub(r"[^0-9-]", "", value)
                return int(cleaned) if cleaned else None
            return int(value)
        except (ValueError, TypeError):
            return None
