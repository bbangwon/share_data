import logging
import re
from dataclasses import dataclass
from io import BytesIO
from typing import Any

from openpyxl import load_workbook

logger = logging.getLogger(__name__)


class BudgetImportValidationError(ValueError):
    def __init__(self, message: str, errors: list[str] | None = None):
        super().__init__(message)
        self.message = message
        self.errors = errors or []


@dataclass(slots=True)
class ParsedBudgetOutRow:
    fiscal_year: int
    budget_seq: int
    budget_type: str
    bureau_order: int
    bureau_cd: str
    bureau_nm: str
    dept_order: int
    dept_cd: str
    dept_nm: str
    field_cd: str
    field_nm: str
    sector_cd: str
    sector_nm: str
    not_prj_type: str
    policy_order: int
    policy_proj_cd: str
    policy_hist_seq: int
    policy_proj_nm: str
    cmte_cd: str
    cmte_nm: str
    unit_order: int
    unit_prj_cd: str
    unit_hist_seq: int
    unit_prj_nm: str
    fund_cd: str
    fund_nm: str
    detail_order: int
    dtl_prj_cd: str
    dtl_hist_seq: int
    dtl_prj_nm: str
    prj_type_nm: str | None
    gender_yn: str
    cont_exp_yn: str
    self_sub_type: str
    dir_sup_type: str | None
    nat_dir_prj: str
    citizen_budget_yn: str
    loc_sub_exc: str
    job_prj_yn: str
    job_prj_type: str | None
    job_target_cnt: int
    event_prj_yn: str
    loc_trans_prj: str
    loc_trans_step: str | None
    promote_yn: str
    disaster_law_cl: str | None
    disaster_field: str | None
    disaster_type: str | None
    disaster_man_step: str | None
    budg_mok_cd: str | None
    budg_mok_nm: str
    stat_mok_cd: str | None
    stat_mok_nm: str
    adj_level: int
    adj_basis_org: str
    adj_formula: str
    rev_adj_amt: int
    adj_amt_diff: int
    adj_obj_type: str | None
    adj_details: dict[str, int]


@dataclass(slots=True)
class ParsedBudgetOutVersion:
    budget_type: str
    budget_seq: int
    row_count: int


@dataclass(slots=True)
class ParsedBudgetOutWorkbook:
    sheet_name: str
    fiscal_year: int
    budget_versions: list[ParsedBudgetOutVersion]
    rows: list[ParsedBudgetOutRow]


class BudgetOutExcelParser:
    PRIMARY_HEADERS = {
        1: "회계연도",
        2: "예산차수",
        3: "예산구분",
        4: "실국정렬순서",
        5: "실국코드",
        6: "실국명",
        7: "부서순위",
        8: "부서코드",
        9: "부서명",
        10: "분야코드",
        11: "분야명",
        12: "부문코드",
        13: "부문명",
        14: "비사업구분",
        15: "정책순위",
        16: "정책사업코드",
        17: "정책이력순번",
        18: "정책사업명",
        19: "위원회코드",
        20: "위원회명",
        21: "단위순위",
        22: "단위사업코드",
        23: "단위이력순번",
        24: "단위사업명",
        25: "회계코드",
        26: "회계구분명",
        27: "세부순위",
        28: "세부사업코드",
        29: "세부이력순번",
        30: "세부사업명",
        31: "사업형태구분명",
        32: "성인지대상여부",
        33: "계속비",
        34: "자체보조구분명",
        35: "직접지원구분명",
        36: "국가직접사업",
        37: "주민참여예산",
        38: "지방보조금한도액제외사업",
        39: "일자리사업여부",
        40: "일자리사업구분",
        41: "일자리사업목표인원",
        42: "행사축제성사업",
        43: "지방전환사업",
        44: "지방전환사업단계",
        45: "추진여부",
        46: "재난안전법적분류",
        47: "재난안전분야",
        48: "재난안전유형",
        49: "재난관리단계",
        50: "편성목코드",
        51: "편성목명",
        52: "통계목코드",
        53: "통계목명",
        54: "조정레벨",
        55: "조정산출근거",
        56: "조정산출근거식",
        57: "경정조정액",
        58: "조정액(증감)",
        59: "조정의무재량구분",
        60: "조정증감",
    }

    FUNDING_HEADERS = {
        60: "국고보조금",
        61: "균특보조금",
        62: "기금보조금",
        63: "특별교부세",
        64: "소방안전교부세",
        65: "지방소멸대응기금",
        66: "자체재원",
        67: "지방채",
        68: "기타",
    }

    PRIMARY_FIELD_HEADERS = {
        "fiscal_year": "회계연도",
        "budget_seq": "예산차수",
        "budget_type": "예산구분",
        "bureau_order": "실국정렬순서",
        "bureau_cd": "실국코드",
        "bureau_nm": "실국명",
        "dept_order": "부서순위",
        "dept_cd": "부서코드",
        "dept_nm": "부서명",
        "field_cd": "분야코드",
        "field_nm": "분야명",
        "sector_cd": "부문코드",
        "sector_nm": "부문명",
        "not_prj_type": "비사업구분",
        "policy_order": "정책순위",
        "policy_proj_cd": "정책사업코드",
        "policy_hist_seq": "정책이력순번",
        "policy_proj_nm": "정책사업명",
        "cmte_cd": "위원회코드",
        "cmte_nm": "위원회명",
        "unit_order": "단위순위",
        "unit_prj_cd": "단위사업코드",
        "unit_hist_seq": "단위이력순번",
        "unit_prj_nm": "단위사업명",
        "fund_cd": "회계코드",
        "fund_nm": "회계구분명",
        "detail_order": "세부순위",
        "dtl_prj_cd": "세부사업코드",
        "dtl_hist_seq": "세부이력순번",
        "dtl_prj_nm": "세부사업명",
        "prj_type_nm": "사업형태구분명",
        "gender_yn": "성인지대상여부",
        "cont_exp_yn": "계속비",
        "self_sub_type": "자체보조구분명",
        "dir_sup_type": "직접지원구분명",
        "nat_dir_prj": "국가직접사업",
        "citizen_budget_yn": "주민참여예산",
        "loc_sub_exc": "지방보조금한도액제외사업",
        "job_prj_yn": "일자리사업여부",
        "job_prj_type": "일자리사업구분",
        "job_target_cnt": "일자리사업목표인원",
        "event_prj_yn": "행사축제성사업",
        "loc_trans_prj": "지방전환사업",
        "loc_trans_step": "지방전환사업단계",
        "promote_yn": "추진여부",
        "disaster_law_cl": "재난안전법적분류",
        "disaster_field": "재난안전분야",
        "disaster_type": "재난안전유형",
        "disaster_man_step": "재난관리단계",
        "budg_mok_cd": "편성목코드",
        "budg_mok_nm": "편성목명",
        "stat_mok_cd": "통계목코드",
        "stat_mok_nm": "통계목명",
        "adj_level": "조정레벨",
        "adj_basis": "조정산출근거",
        "adj_formula": "조정산출근거식",
        "rev_adj_amt": "경정조정액",
        "adj_amt_diff": "조정액(증감)",
        "adj_obj_type": "조정의무재량구분",
    }

    OPTIONAL_PRIMARY_FIELDS = {
        "job_prj_type",
        "prj_type_nm",
        "dir_sup_type",
        "loc_trans_step",
        "disaster_law_cl",
        "disaster_field",
        "disaster_type",
        "disaster_man_step",
        "budg_mok_cd",
        "stat_mok_cd",
        "adj_formula",
        "adj_obj_type",
    }

    def parse(self, file_bytes: bytes) -> ParsedBudgetOutWorkbook:
        workbook = load_workbook(BytesIO(file_bytes), data_only=True)
        worksheet = workbook[workbook.sheetnames[0]]
        header_columns, adj_columns = self._validate_headers(worksheet)

        total_rows = worksheet.max_row
        logger.info(f"[BudgetOut] 엑셀 분석 시작: {total_rows}행 (헤더 포함)")

        errors: list[str] = []
        rows: list[ParsedBudgetOutRow] = []

        for row_index in range(3, total_rows + 1):
            row_values = {
                header_name: (
                    worksheet.cell(row=row_index, column=column_index).value
                    if column_index is not None
                    else None
                )
                for header_name, column_index in header_columns.items()
            }
            if not any(self._normalize_text(value) for value in row_values.values()):
                continue

            adj_values = {
                nm: worksheet.cell(row=row_index, column=col_idx).value
                for nm, col_idx in adj_columns.items()
            }

            try:
                rows.append(self._parse_row(row_index, row_values, adj_values))
            except ValueError as exc:
                errors.append(f"{row_index}행: {exc}")

            if row_index % 1000 == 0 or row_index == total_rows:
                logger.info(
                    f"[BudgetOut] 엑셀 분석 진행: {row_index} / {total_rows}행..."
                )

        if errors:
            raise BudgetImportValidationError(
                "엑셀 데이터 검증에 실패했습니다.",
                errors,
            )

        if not rows:
            raise BudgetImportValidationError("적재할 데이터 행이 없습니다.")

        fiscal_years = {row.fiscal_year for row in rows}

        if len(fiscal_years) != 1:
            raise BudgetImportValidationError(
                "엑셀 내 회계연도 값이 하나로 고정되어야 합니다."
            )

        budget_versions = self._collect_budget_versions(rows)

        return ParsedBudgetOutWorkbook(
            sheet_name=worksheet.title,
            fiscal_year=fiscal_years.pop(),
            budget_versions=budget_versions,
            rows=rows,
        )

    def _collect_budget_versions(
        self,
        rows: list[ParsedBudgetOutRow],
    ) -> list[ParsedBudgetOutVersion]:
        version_keys: set[tuple[str, int]] = set()
        row_counts: dict[tuple[str, int], int] = {}

        for row in rows:
            version_key = (row.budget_type, row.budget_seq)
            version_keys.add(version_key)
            row_counts[version_key] = row_counts.get(version_key, 0) + 1

        return [
            ParsedBudgetOutVersion(
                budget_type=budget_type,
                budget_seq=budget_seq,
                row_count=row_counts[(budget_type, budget_seq)],
            )
            for budget_type, budget_seq in sorted(version_keys)
        ]

    def _validate_headers(
        self, worksheet
    ) -> tuple[dict[str, int | None], dict[str, int]]:
        primary_headers = self._extract_row_headers(worksheet, row_index=1)

        header_columns = {}
        missing_primary_headers = []
        for field_name, header_val in self.PRIMARY_FIELD_HEADERS.items():
            expected_headers = (
                header_val if isinstance(header_val, tuple) else (header_val,)
            )
            matched_header = next(
                (h for h in expected_headers if h in primary_headers), None
            )

            primary_name = expected_headers[0]
            if matched_header:
                header_columns[primary_name] = primary_headers[matched_header]
            else:
                header_columns[primary_name] = None
                if field_name not in self.OPTIONAL_PRIMARY_FIELDS:
                    missing_primary_headers.append(primary_name)

        if missing_primary_headers:
            raise BudgetImportValidationError(
                "기본 헤더 형식이 예상과 다릅니다.",
                [f"누락된 1행 헤더: {header}" for header in missing_primary_headers],
            )

        # 조정증감 그룹 헤더 위치를 기준으로 2행의 adj 컬럼명을 동적 수집
        funding_headers = self._extract_row_headers(worksheet, row_index=2)
        adj_group_col = primary_headers.get("조정증감")
        adj_columns: dict[str, int] = {}
        if adj_group_col is not None:
            for nm, col_idx in funding_headers.items():
                if col_idx >= adj_group_col:
                    adj_columns[nm] = col_idx

        return header_columns, adj_columns

    def _extract_row_headers(self, worksheet, row_index: int) -> dict[str, int]:
        headers: dict[str, int] = {}

        for column_index in range(1, worksheet.max_column + 1):
            header_name = self._normalize_text(
                worksheet.cell(row=row_index, column=column_index).value
            )
            if not header_name:
                continue
            if header_name in headers:
                raise BudgetImportValidationError(
                    f"{row_index}행 헤더에 중복된 이름이 있습니다.",
                    [f"중복 헤더: {header_name}"],
                )
            headers[header_name] = column_index

        return headers

    def _parse_row(
        self, row_index: int, values: dict[str, Any], adj_values: dict[str, Any]
    ) -> ParsedBudgetOutRow:
        row = ParsedBudgetOutRow(
            fiscal_year=self._parse_int(values["회계연도"], "회계연도", row_index),
            budget_seq=self._parse_int(values["예산차수"], "예산차수", row_index),
            budget_type=self._require_text(values["예산구분"], "예산구분", row_index),
            bureau_order=self._parse_int(
                values["실국정렬순서"], "실국정렬순서", row_index
            ),
            bureau_cd=self._require_code(values["실국코드"], "실국코드", row_index),
            bureau_nm=self._require_text(values["실국명"], "실국명", row_index),
            dept_order=self._parse_int(values["부서순위"], "부서순위", row_index),
            dept_cd=self._require_code(values["부서코드"], "부서코드", row_index).replace(
                "-", ""
            ),
            dept_nm=self._require_text(values["부서명"], "부서명", row_index),
            field_cd=self._require_code(values["분야코드"], "분야코드", row_index),
            field_nm=self._require_text(values["분야명"], "분야명", row_index),
            sector_cd=self._require_code(values["부문코드"], "부문코드", row_index),
            sector_nm=self._require_text(values["부문명"], "부문명", row_index),
            not_prj_type=self._require_text(
                values["비사업구분"], "비사업구분", row_index
            ),
            policy_order=self._parse_int(values["정책순위"], "정책순위", row_index),
            policy_proj_cd=self._require_code(
                values["정책사업코드"], "정책사업코드", row_index
            ),
            policy_hist_seq=self._parse_int(
                values["정책이력순번"], "정책이력순번", row_index
            ),
            policy_proj_nm=self._require_text(
                values["정책사업명"], "정책사업명", row_index
            ),
            cmte_cd=self._require_code(values["위원회코드"], "위원회코드", row_index),
            cmte_nm=self._require_text(values["위원회명"], "위원회명", row_index),
            unit_order=self._parse_int(values["단위순위"], "단위순위", row_index),
            unit_prj_cd=self._require_code(
                values["단위사업코드"], "단위사업코드", row_index
            ),
            unit_hist_seq=self._parse_int(
                values["단위이력순번"], "단위이력순번", row_index
            ),
            unit_prj_nm=self._require_text(
                values["단위사업명"], "단위사업명", row_index
            ),
            fund_cd=self._require_code(values["회계코드"], "회계코드", row_index),
            fund_nm=self._require_text(values["회계구분명"], "회계구분명", row_index),
            detail_order=self._parse_int(values["세부순위"], "세부순위", row_index),
            dtl_prj_cd=self._require_code(
                values["세부사업코드"], "세부사업코드", row_index
            ),
            dtl_hist_seq=self._parse_int(
                values["세부이력순번"], "세부이력순번", row_index
            ),
            dtl_prj_nm=self._require_text(
                values["세부사업명"], "세부사업명", row_index
            ),
            prj_type_nm=self._optional_text(values["사업형태구분명"]),
            gender_yn=self._parse_ynr(
                values["성인지대상여부"], "성인지대상여부", row_index, default="N"
            ),
            cont_exp_yn=self._parse_ynr(
                values["계속비"], "계속비", row_index, default="N"
            ),
            self_sub_type=self._require_text(
                values["자체보조구분명"], "자체보조구분명", row_index
            ),
            dir_sup_type=self._optional_text(values["직접지원구분명"]),
            nat_dir_prj=self._parse_ynr(
                values["국가직접사업"], "국가직접사업", row_index, default="N"
            ),
            citizen_budget_yn=self._parse_ynr(
                values["주민참여예산"], "주민참여예산", row_index, default="N"
            ),
            loc_sub_exc=self._parse_ynr(
                values["지방보조금한도액제외사업"],
                "지방보조금한도액제외사업",
                row_index,
                default="N",
            ),
            job_prj_yn=self._parse_ynr(
                values["일자리사업여부"], "일자리사업여부", row_index, default="N"
            ),
            job_prj_type=self._optional_text(values["일자리사업구분"]),
            job_target_cnt=self._parse_int(
                values["일자리사업목표인원"], "일자리사업목표인원", row_index, default=0
            ),
            event_prj_yn=self._parse_ynr(
                values["행사축제성사업"], "행사축제성사업", row_index, default="N"
            ),
            loc_trans_prj=self._parse_ynr(
                values["지방전환사업"], "지방전환사업", row_index, default="N"
            ),
            loc_trans_step=self._optional_text(values["지방전환사업단계"]),
            promote_yn=self._parse_ynr(
                values["추진여부"], "추진여부", row_index, default="Y"
            ),
            disaster_law_cl=self._optional_text(values["재난안전법적분류"]),
            disaster_field=self._optional_text(values["재난안전분야"]),
            disaster_type=self._optional_text(values["재난안전유형"]),
            disaster_man_step=self._optional_text(values["재난관리단계"]),
            budg_mok_cd=self._optional_code(values["편성목코드"]),
            budg_mok_nm=self._require_text(values["편성목명"], "편성목명", row_index),
            stat_mok_cd=(
                val.replace("-", "")
                if (val := self._optional_code(values["통계목코드"]))
                else None
            ),
            stat_mok_nm=self._require_text(values["통계목명"], "통계목명", row_index),
            adj_level=self._parse_int(values["조정레벨"], "조정레벨", row_index),
            adj_basis_org=self._require_text(
                values["조정산출근거"], "조정산출근거", row_index
            ),
            adj_formula=self._optional_text(values["조정산출근거식"]),
            rev_adj_amt=self._parse_int(
                values["경정조정액"], "경정조정액", row_index, default=0
            ),
            adj_amt_diff=self._parse_int(
                values["조정액(증감)"], "조정액(증감)", row_index, default=0
            ),
            adj_obj_type=self._optional_text(values["조정의무재량구분"]),
            adj_details={
                nm: amt
                for nm, raw_val in adj_values.items()
                if (amt := self._parse_int(raw_val, nm, row_index, default=0)) != 0
            },
        )
        self._validate_row_consistency(row)
        return row

    def _validate_row_consistency(self, row: ParsedBudgetOutRow) -> None:
        if row.job_prj_yn == "N" and row.job_prj_type:
            raise ValueError(
                "일자리사업여부가 N이면 일자리사업구분 값은 비어 있어야 합니다."
            )

        if row.loc_trans_prj == "N" and row.loc_trans_step:
            raise ValueError(
                "지방전환사업이 N이면 지방전환사업단계 값은 비어 있어야 합니다."
            )

    def _original_text(self, value: Any) -> str:
        if value is None:
            return ""
        return str(value)

    def _normalize_text(self, value: Any) -> str:
        return self._original_text(value).strip()

    def _optional_text(self, value: Any) -> str | None:
        normalized = self._normalize_text(value)
        return normalized or None

    def _normalize_code(self, value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            return str(int(value)) if value.is_integer() else str(value)
        return self._original_text(value).strip()

    def _optional_code(self, value: Any) -> str | None:
        normalized = self._normalize_code(value)
        return normalized or None

    def _required_original_text(
        self, value: Any, field_name: str, row_index: int
    ) -> str:
        original = self._original_text(value)
        if not original.strip():
            raise ValueError(f"{field_name} 값이 비어 있습니다.")
        return original

    def _require_text(self, value: Any, field_name: str, row_index: int) -> str:
        normalized = self._normalize_text(value)
        if not normalized:
            raise ValueError(f"{field_name} 값이 비어 있습니다.")
        return normalized

    def _require_code(self, value: Any, field_name: str, row_index: int) -> str:
        normalized = self._normalize_code(value)
        if not normalized:
            raise ValueError(f"{field_name} 값이 비어 있습니다.")
        return normalized

    def _parse_int(
        self,
        value: Any,
        field_name: str,
        row_index: int,
        default: int | None = None,
    ) -> int:
        if value is None or (isinstance(value, str) and not value.strip()):
            if default is not None:
                return default
            raise ValueError(f"{field_name} 값이 비어 있습니다.")

        if isinstance(value, bool):
            raise ValueError(f"{field_name} 값이 숫자가 아닙니다.")

        if isinstance(value, int):
            return value

        if isinstance(value, float):
            return int(value)

        cleaned = re.sub(r"[^0-9-]", "", str(value))
        if cleaned in {"", "-"}:
            if default is not None:
                return default
            raise ValueError(f"{field_name} 값을 숫자로 변환할 수 없습니다.")

        return int(cleaned)

    def _parse_ynr(
        self,
        value: Any,
        field_name: str,
        row_index: int,
        default: str,
    ) -> str:
        normalized = self._normalize_text(value).upper()
        if not normalized:
            return default
        if normalized not in {"Y", "N", "R"}:
            raise ValueError(f"{field_name} 값은 Y, N 또는 R 이어야 합니다.")
        return normalized


@dataclass(slots=True)
class ParsedBudgetInRow:
    fiscal_year: int
    budget_type: str
    budget_confirm_date: str
    dept_cd: str
    dept_nm: str
    fund_cd: str
    fund_nm: str
    jang_cd: str
    jang_nm: str
    gwan_cd: str
    gwan_nm: str
    hang_cd: str
    hang_nm: str
    mok_cd: str
    mok_nm: str
    adj_basis_org: str
    adj_formula: str | None
    level_amt: int
    budget_amt: int
    prev_amt: int
    diff_amt: int


@dataclass(slots=True)
class ParsedBudgetInVersion:
    budget_type: str
    budget_confirm_date: str
    row_count: int


@dataclass(slots=True)
class ParsedBudgetInWorkbook:
    sheet_name: str
    fiscal_year: int
    budget_versions: list[ParsedBudgetInVersion]
    rows: list[ParsedBudgetInRow]


class BudgetInExcelParser(BudgetOutExcelParser):
    PRIMARY_FIELD_HEADERS = {
        "fiscal_year": "회계연도",
        "budget_type": "예산구분명",
        "budget_confirm_date": "예산확정일자",
        "dept_cd": "부서코드",
        "dept_nm": "부서명",
        "fund_cd": "회계구분",
        "fund_nm": "회계명",
        "jang_cd": "장",
        "jang_nm": "장명",
        "gwan_cd": "관",
        "gwan_nm": "관명",
        "hang_cd": "항",
        "hang_nm": "항명",
        "mok_cd": "목",
        "mok_nm": "목명",
        "adj_basis": "산출근거",
        "adj_formula": "산출근거식",
        "level_amt": "레벨금액",
        "budget_amt": "예산액",
        "prev_amt": "기정액",
        "diff_amt": "증감액",
    }

    OPTIONAL_PRIMARY_FIELDS = {
        "adj_formula",
    }

    def parse(self, file_bytes: bytes) -> ParsedBudgetInWorkbook:
        workbook = load_workbook(BytesIO(file_bytes), data_only=True)
        worksheet = workbook[workbook.sheetnames[0]]
        header_columns = self._validate_headers(worksheet)

        total_rows = worksheet.max_row
        logger.info(f"[BudgetIn] Starting to parse Excel with {total_rows} rows")

        errors: list[str] = []
        rows: list[ParsedBudgetInRow] = []

        for row_index in range(2, total_rows + 1):
            row_values = {
                header_name: (
                    worksheet.cell(row=row_index, column=column_index).value
                    if column_index is not None
                    else None
                )
                for header_name, column_index in header_columns.items()
            }
            if not any(self._normalize_text(value) for value in row_values.values()):
                continue

            try:
                rows.append(self._parse_row_in(row_index, row_values))
            except ValueError as exc:
                errors.append(f"{row_index}행: {exc}")

            if row_index % 1000 == 0 or row_index == total_rows:
                logger.info(f"[BudgetIn] 분석 진행: {row_index} / {total_rows} 행...")

        if errors:
            raise BudgetImportValidationError(
                "엑셀 데이터 검증에 실패했습니다.",
                errors,
            )

        if not rows:
            raise BudgetImportValidationError("적재할 데이터 행이 없습니다.")

        fiscal_years = {row.fiscal_year for row in rows}
        if len(fiscal_years) != 1:
            raise BudgetImportValidationError(
                "엑셀 내 회계연도 값이 하나로 고정되어야 합니다."
            )

        budget_versions = self._collect_budget_versions_in(rows)

        return ParsedBudgetInWorkbook(
            sheet_name=worksheet.title,
            fiscal_year=fiscal_years.pop(),
            budget_versions=budget_versions,
            rows=rows,
        )

    def _validate_headers(self, worksheet) -> dict[str, int | None]:
        primary_headers = self._extract_row_headers(worksheet, row_index=1)

        header_columns = {}
        missing_primary_headers = []
        for field_name, header_val in self.PRIMARY_FIELD_HEADERS.items():
            expected_headers = (
                header_val if isinstance(header_val, tuple) else (header_val,)
            )
            matched_header = next(
                (h for h in expected_headers if h in primary_headers), None
            )

            primary_name = expected_headers[0]
            if matched_header:
                header_columns[primary_name] = primary_headers[matched_header]
            else:
                header_columns[primary_name] = None
                if field_name not in self.OPTIONAL_PRIMARY_FIELDS:
                    missing_primary_headers.append(primary_name)

        if missing_primary_headers:
            raise BudgetImportValidationError(
                "기본 헤더 형식이 예상과 다릅니다.",
                [f"누락된 1행 헤더: {header}" for header in missing_primary_headers],
            )

        return header_columns

    def _parse_row_in(
        self, row_index: int, values: dict[str, Any]
    ) -> ParsedBudgetInRow:
        return ParsedBudgetInRow(
            fiscal_year=self._parse_int(values["회계연도"], "회계연도", row_index),
            budget_type=self._require_text(
                values["예산구분명"], "예산구분명", row_index
            ),
            budget_confirm_date=self._require_text(
                values["예산확정일자"], "예산확정일자", row_index
            ),
            dept_cd=self._require_code(values["부서코드"], "부서코드", row_index).replace(
                "-", ""
            ),
            dept_nm=self._require_text(values["부서명"], "부서명", row_index),
            fund_cd=self._require_code(values["회계구분"], "회계구분", row_index),
            fund_nm=self._require_text(values["회계명"], "회계명", row_index),
            jang_cd=self._require_code(values["장"], "장", row_index),
            jang_nm=self._require_text(values["장명"], "장명", row_index),
            gwan_cd=self._require_code(values["관"], "관", row_index),
            gwan_nm=self._require_text(values["관명"], "관명", row_index),
            hang_cd=self._require_code(values["항"], "항", row_index),
            hang_nm=self._require_text(values["항명"], "항명", row_index),
            mok_cd=self._require_code(values["목"], "목", row_index),
            mok_nm=self._require_text(values["목명"], "목명", row_index),
            adj_basis_org=self._required_original_text(
                values["산출근거"], "산출근거", row_index
            ),  # 들여쓰기 내용이 중요하므로 원본 텍스트 그대로 필수로 요구
            adj_formula=self._optional_text(values["산출근거식"]),
            level_amt=self._parse_int(values["레벨금액"], "레벨금액", row_index),
            budget_amt=self._parse_int(values["예산액"], "예산액", row_index),
            prev_amt=self._parse_int(values["기정액"], "기정액", row_index),
            diff_amt=self._parse_int(values["증감액"], "증감액", row_index),
        )

    def _collect_budget_versions_in(
        self,
        rows: list[ParsedBudgetInRow],
    ) -> list[ParsedBudgetInVersion]:
        version_keys: set[tuple[str, str]] = set()
        row_counts: dict[tuple[str, str], int] = {}

        for row in rows:
            version_key = (row.budget_type, row.budget_confirm_date)
            version_keys.add(version_key)
            row_counts[version_key] = row_counts.get(version_key, 0) + 1

        return [
            ParsedBudgetInVersion(
                budget_type=budget_type,
                budget_confirm_date=confirm_date,
                row_count=row_counts[(budget_type, confirm_date)],
            )
            for budget_type, confirm_date in sorted(version_keys)
        ]
