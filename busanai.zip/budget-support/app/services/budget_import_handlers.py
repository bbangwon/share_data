from dataclasses import dataclass
from typing import Any, Protocol

from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.imports import (
    BudgetInImportRequest,
    BudgetOutImportRequest,
    BudgetOutLv1ImportRequest,
)

from .budget_out_importer import BudgetOutImportService
from .budget_in_importer import BudgetInImportService
from .budget_out_lv1_importer import BudgetOutLv1ImportService


@dataclass(slots=True)
class BudgetImportJobResult:
    rows_processed: int
    inserted_counts: dict[str, int]
    warnings: list[str]
    budget_versions: list[dict[str, Any]]


class BudgetImportJobHandler(Protocol):
    import_type: str

    async def process(
        self,
        session: AsyncSession,
        request_payload: dict[str, Any],
        source_filename: str,
        file_bytes: bytes,
    ) -> BudgetImportJobResult: ...


class BudgetInImportJobHandler:
    import_type = "budget_in"

    def __init__(self, service: BudgetInImportService | None = None) -> None:
        self.service = service or BudgetInImportService()

    async def process(
        self,
        session: AsyncSession,
        request_payload: dict[str, Any],
        source_filename: str,
        file_bytes: bytes,
    ) -> BudgetImportJobResult:
        request = BudgetInImportRequest.model_validate(request_payload)
        result = await self.service.import_excel(
            session=session,
            request=request,
            source_filename=source_filename,
            file_bytes=file_bytes,
        )
        return BudgetImportJobResult(
            rows_processed=result.rows_processed,
            inserted_counts=result.inserted_counts,
            warnings=result.warnings,
            budget_versions=[
                {
                    "budget_type": item.budget_type,
                    "budget_confirm_date": item.budget_confirm_date,
                    "row_count": item.row_count,
                }
                for item in result.budget_versions
            ],
        )


class BudgetOutLv1ImportJobHandler:
    import_type = "budget_out_lv1"

    def __init__(self, service: BudgetOutLv1ImportService | None = None) -> None:
        self.service = service or BudgetOutLv1ImportService()

    async def process(
        self,
        session: AsyncSession,
        request_payload: dict[str, Any],
        source_filename: str,
        file_bytes: bytes,
    ) -> BudgetImportJobResult:
        request = BudgetOutLv1ImportRequest.model_validate(request_payload)
        result = await self.service.import_excel(
            session=session,
            request=request,
            source_filename=source_filename,
            file_bytes=file_bytes,
        )
        return BudgetImportJobResult(
            rows_processed=result.rows_processed,
            inserted_counts=result.inserted_counts,
            warnings=result.warnings,
            budget_versions=[
                {
                    "budget_type": item.budget_type,
                    "row_count": item.row_count,
                }
                for item in result.budget_versions
            ],
        )


class BudgetOutImportJobHandler:
    import_type = "budget_out"

    def __init__(self, service: BudgetOutImportService | None = None) -> None:
        self.service = service or BudgetOutImportService()

    async def process(
        self,
        session: AsyncSession,
        request_payload: dict[str, Any],
        source_filename: str,
        file_bytes: bytes,
    ) -> BudgetImportJobResult:
        request = BudgetOutImportRequest.model_validate(request_payload)
        result = await self.service.import_excel(
            session=session,
            request=request,
            source_filename=source_filename,
            file_bytes=file_bytes,
        )
        return BudgetImportJobResult(
            rows_processed=result.rows_processed,
            inserted_counts=result.inserted_counts,
            warnings=result.warnings,
            budget_versions=[
                {
                    "budget_type": item.budget_type,
                    "budget_seq": item.budget_seq,
                    "row_count": item.row_count,
                }
                for item in result.budget_versions
            ],
        )


def get_import_job_handlers() -> dict[str, BudgetImportJobHandler]:
    handlers: list[BudgetImportJobHandler] = [
        BudgetOutImportJobHandler(),
        BudgetInImportJobHandler(),
        BudgetOutLv1ImportJobHandler(),
    ]
    return {handler.import_type: handler for handler in handlers}
