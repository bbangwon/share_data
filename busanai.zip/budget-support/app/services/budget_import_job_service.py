import math
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4

from fastapi import UploadFile
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models import BudgetImportJob
from app.schemas.imports import (
    BudgetImportJobListResponse,
    BudgetImportJobStatusResponse,
)


class BudgetImportJobService:
    STATUS_QUEUED = "queued"
    STATUS_PROCESSING = "processing"
    STATUS_SUCCEEDED = "succeeded"
    STATUS_FAILED = "failed"

    STAGE_PARSING = "parsing"
    STAGE_IMPORTING = "importing"
    STAGE_CLEANUP = "cleanup"

    async def enqueue_from_upload(
        self,
        session: AsyncSession,
        file: UploadFile,
        import_type: str,
        request_payload: dict,
        request_fiscal_year: int,
        request_la_cd: str | None,
    ) -> BudgetImportJob:
        settings = get_settings()
        job_id = str(uuid4())

        safe_filename = Path(file.filename or "upload.xlsx").name
        extension = Path(safe_filename).suffix.lower() or ".xlsx"
        destination = Path(settings.upload_dir) / import_type / f"{job_id}{extension}"
        await self._save_upload_file(file, destination, settings.import_max_file_mb)

        job = BudgetImportJob(
            job_id=job_id,
            import_type=import_type,
            status=self.STATUS_QUEUED,
            stage=None,
            progress_pct=0,
            rows_total=None,
            rows_processed=0,
            request_fiscal_year=request_fiscal_year,
            request_la_cd=request_la_cd,
            request_payload=request_payload,
            source_filename=safe_filename,
            stored_file_path=str(destination),
        )
        async with session.begin():
            session.add(job)

        return job

    async def get_status(
        self,
        session: AsyncSession,
        job_id: str,
        import_type: str | None = None,
    ) -> BudgetImportJobStatusResponse | None:
        stmt = select(BudgetImportJob).where(BudgetImportJob.job_id == job_id)
        if import_type is not None:
            stmt = stmt.where(BudgetImportJob.import_type == import_type)
        job = (await session.execute(stmt)).scalar_one_or_none()
        if job is None:
            return None
        return self._to_status_response(job)

    async def list_jobs(
        self,
        session: AsyncSession,
        page: int,
        size: int,
        status: str | None,
        fiscal_year: int | None,
        recent_days: int | None = None,
        import_type: str | None = None,
    ) -> BudgetImportJobListResponse:
        where_clause = []
        if status:
            where_clause.append(BudgetImportJob.status == status)
        if fiscal_year is not None:
            where_clause.append(BudgetImportJob.request_fiscal_year == fiscal_year)
        if recent_days is not None:
            threshold = datetime.now(timezone.utc) - timedelta(days=recent_days)
            where_clause.append(BudgetImportJob.created_at >= threshold)
        if import_type is not None:
            where_clause.append(BudgetImportJob.import_type == import_type)

        stmt = select(BudgetImportJob)
        count_stmt = select(func.count()).select_from(BudgetImportJob)

        if where_clause:
            stmt = stmt.where(*where_clause)
            count_stmt = count_stmt.where(*where_clause)

        total = (await session.execute(count_stmt)).scalar_one()
        result = await session.execute(
            stmt.order_by(BudgetImportJob.created_at.desc())
            .offset((page - 1) * size)
            .limit(size)
        )
        jobs = result.scalars().all()

        return BudgetImportJobListResponse(
            items=[self._to_status_response(item) for item in jobs],
            total=total,
            page=page,
            size=size,
            total_pages=math.ceil(total / size) if total > 0 else 1,
        )

    async def claim_next_queued_job(
        self,
        session: AsyncSession,
        worker_id: str,
    ) -> BudgetImportJob | None:
        async with session.begin():
            job = (
                await session.execute(
                    select(BudgetImportJob)
                    .where(BudgetImportJob.status == self.STATUS_QUEUED)
                    .order_by(BudgetImportJob.created_at.asc())
                    .with_for_update(skip_locked=True)
                    .limit(1)
                )
            ).scalar_one_or_none()
            if job is None:
                return None
            now = datetime.now(timezone.utc)
            job.status = self.STATUS_PROCESSING
            job.stage = self.STAGE_PARSING
            job.started_at = now
            job.updated_at = now
            job.worker_id = worker_id
            return job

    async def mark_stage(
        self,
        session: AsyncSession,
        job_id: str,
        stage: str,
        progress_pct: int | None = None,
        rows_total: int | None = None,
        rows_processed: int | None = None,
    ) -> None:
        async with session.begin():
            job = (
                await session.execute(
                    select(BudgetImportJob).where(BudgetImportJob.job_id == job_id)
                )
            ).scalar_one()
            job.stage = stage
            if progress_pct is not None:
                job.progress_pct = progress_pct
            if rows_total is not None:
                job.rows_total = rows_total
            if rows_processed is not None:
                job.rows_processed = rows_processed
            job.updated_at = datetime.now(timezone.utc)

    async def mark_succeeded(
        self,
        session: AsyncSession,
        job_id: str,
        rows_processed: int,
        inserted_counts: dict[str, int],
        warnings: list[str],
        budget_versions: list[dict],
    ) -> None:
        async with session.begin():
            job = (
                await session.execute(
                    select(BudgetImportJob).where(BudgetImportJob.job_id == job_id)
                )
            ).scalar_one()
            now = datetime.now(timezone.utc)
            job.status = self.STATUS_SUCCEEDED
            job.stage = self.STAGE_CLEANUP
            job.progress_pct = 100
            job.rows_total = rows_processed
            job.rows_processed = rows_processed
            job.inserted_counts = inserted_counts
            job.warnings = warnings
            job.budget_versions = budget_versions
            job.updated_at = now
            job.finished_at = now

    async def mark_failed(
        self,
        session: AsyncSession,
        job_id: str,
        error_summary: str,
        error_detail: str,
    ) -> None:
        async with session.begin():
            job = (
                await session.execute(
                    select(BudgetImportJob).where(BudgetImportJob.job_id == job_id)
                )
            ).scalar_one_or_none()
            if job is None:
                return
            now = datetime.now(timezone.utc)
            job.status = self.STATUS_FAILED
            job.error_summary = error_summary[:500]
            job.error_detail = error_detail
            job.updated_at = now
            job.finished_at = now

    async def _save_upload_file(
        self,
        file: UploadFile,
        destination: Path,
        import_max_file_mb: int,
    ) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        max_bytes = import_max_file_mb * 1024 * 1024
        written = 0
        with destination.open("wb") as output:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                written += len(chunk)
                if written > max_bytes:
                    raise ValueError(
                        f"업로드 파일 크기는 최대 {import_max_file_mb}MB까지 허용됩니다."
                    )
                output.write(chunk)
        await file.close()
        if written == 0:
            raise ValueError("빈 파일은 업로드할 수 없습니다.")

    def _to_status_response(
        self,
        job: BudgetImportJob,
    ) -> BudgetImportJobStatusResponse:
        return BudgetImportJobStatusResponse(
            job_id=job.job_id,
            import_type=job.import_type,
            status=job.status,
            stage=job.stage,
            progress_pct=job.progress_pct,
            rows_total=job.rows_total,
            rows_processed=job.rows_processed,
            request_fiscal_year=job.request_fiscal_year,
            request_la_cd=job.request_la_cd,
            source_filename=job.source_filename,
            inserted_counts=job.inserted_counts,
            budget_versions=job.budget_versions,
            warnings=job.warnings,
            error_summary=job.error_summary,
            created_at=job.created_at,
            updated_at=job.updated_at,
            started_at=job.started_at,
            finished_at=job.finished_at,
        )
