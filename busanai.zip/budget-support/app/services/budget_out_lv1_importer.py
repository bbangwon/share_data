import logging
from dataclasses import dataclass
from itertools import islice
from typing import Iterable

from sqlalchemy import delete, insert, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import (
    BudgetLocalGovernment,
    BudgetOutAccountSubjectLv1,
    BudgetOutAdjSubjectDetailLv1,
    BudgetOutAdjSubjectLv1,
    BudgetOutFactLv1,
    BudgetOutProjectDetailLv1,
    BudgetOutProjectPolicyLv1,
    BudgetOutProjectUnitLv1,
)
from app.schemas.imports import (
    BudgetOutImportLv1Response,
    BudgetOutImportLv1VersionResponse,
    BudgetOutLv1ImportRequest,
)

from .excel_parser import BudgetImportValidationError
from .excel_parser_lv1 import (
    BudgetOutLv1ExcelParser,
    ParsedBudgetOutLv1Row,
)

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class ImportCountersLv1:
    account_subject: int = 0
    project_policy: int = 0
    project_unit: int = 0
    project_detail: int = 0
    budget_fact: int = 0
    adj_subject: int = 0

    def to_dict(self) -> dict[str, int]:
        return {
            "account_subject": self.account_subject,
            "project_policy": self.project_policy,
            "project_unit": self.project_unit,
            "project_detail": self.project_detail,
            "budget_fact": self.budget_fact,
            "adj_subject": self.adj_subject,
        }


class BudgetOutLv1ImportService:
    BULK_INSERT_CHUNK_SIZE = 2000

    def __init__(self, parser: BudgetOutLv1ExcelParser | None = None):
        self.parser = parser or BudgetOutLv1ExcelParser()

    async def import_excel(
        self,
        session: AsyncSession,
        request: BudgetOutLv1ImportRequest,
        source_filename: str,
        file_bytes: bytes,
    ) -> BudgetOutImportLv1Response:
        parsed = self.parser.parse(file_bytes)

        if parsed.fiscal_year != request.fiscal_year:
            raise BudgetImportValidationError(
                "요청한 회계연도와 엑셀의 회계연도가 다릅니다.",
                [
                    f"요청 회계연도: {request.fiscal_year}",
                    f"엑셀 회계연도: {parsed.fiscal_year}",
                ],
            )

        # la_cd 기준으로 행 그룹화
        rows_by_la: dict[str, list[ParsedBudgetOutLv1Row]] = {}
        for row in parsed.rows:
            if row.la_cd not in rows_by_la:
                rows_by_la[row.la_cd] = []
            rows_by_la[row.la_cd].append(row)

        async with session.begin():
            counters = ImportCountersLv1()

            for la_cd, la_rows in rows_by_la.items():
                # 각 그룹의 첫 번째 행에서 la_nm, w_city_nm 추출
                la_nm = la_rows[0].la_nm
                w_city_nm = la_rows[0].w_city_nm
                local_government = await self._resolve_local_government(
                    session, la_cd, la_nm, w_city_nm
                )

                # 해당 연도/지자체의 기존 데이터 삭제
                await self._delete_existing_fact(
                    session, local_government.la_cd, parsed.fiscal_year
                )

                await self._persist_rows(
                    session, local_government.la_cd, la_rows, counters
                )

        return BudgetOutImportLv1Response(
            la_cd=parsed.la_cd,
            la_nm=parsed.la_nm,
            fiscal_year=parsed.fiscal_year,
            budget_versions=[
                BudgetOutImportLv1VersionResponse(
                    budget_type=v.budget_type,
                    row_count=v.row_count,
                )
                for v in parsed.budget_versions
            ],
            source_filename=source_filename,
            rows_processed=len(parsed.rows),
            inserted_counts=counters.to_dict(),
            warnings=[],
        )

    async def _resolve_local_government(
        self,
        session: AsyncSession,
        la_cd: str,
        la_nm: str,
        w_city_nm: str,
    ) -> BudgetLocalGovernment:
        # LA(지자체)가 존재해야 함
        local_government = (
            await session.execute(
                select(BudgetLocalGovernment).where(
                    BudgetLocalGovernment.la_cd == la_cd
                )
            )
        ).scalar_one_or_none()

        if local_government is None:
            # 지자체 정보 자동 생성
            logger.info(
                f"지자체 정보를 DB에서 찾을 수 없어 새로 생성합니다: {la_cd} ({la_nm}, {w_city_nm})"
            )
            local_government = BudgetLocalGovernment(
                la_cd=la_cd,
                la_nm=la_nm,
                w_city_nm=w_city_nm,
            )
            session.add(local_government)
            await session.flush()  # DB에 반영하여 ID 확보

        return local_government

    async def _delete_existing_fact(
        self,
        session: AsyncSession,
        la_cd: str,
        fiscal_year: int,
    ) -> None:
        fact_ids_result = await session.execute(
            select(BudgetOutFactLv1.budget_fact_id).where(
                BudgetOutFactLv1.la_cd == la_cd,
                BudgetOutFactLv1.fiscal_year == fiscal_year,
            )
        )
        fact_ids = fact_ids_result.scalars().all()
        if fact_ids:
            await session.execute(
                delete(BudgetOutAdjSubjectDetailLv1).where(
                    BudgetOutAdjSubjectDetailLv1.budget_fact_id.in_(fact_ids)
                )
            )
        await session.execute(
            delete(BudgetOutFactLv1).where(
                BudgetOutFactLv1.la_cd == la_cd,
                BudgetOutFactLv1.fiscal_year == fiscal_year,
            )
        )

    async def _persist_rows(
        self,
        session: AsyncSession,
        la_cd: str,
        rows: list[ParsedBudgetOutLv1Row],
        counters: ImportCountersLv1,
    ) -> None:
        total_rows = len(rows)
        logger.info(
            f"[BudgetOutLv1] 엑셀 데이터 적재 시작: {total_rows}행 ({la_cd})..."
        )

        fiscal_year = rows[0].fiscal_year

        account_subject_id_by_key = {
            (item.stat_mok_nm, item.budg_mok_nm): item.acc_sub_id
            for item in (
                await session.execute(
                    select(BudgetOutAccountSubjectLv1).where(
                        BudgetOutAccountSubjectLv1.fiscal_year == fiscal_year
                    )
                )
            ).scalars()
        }
        policy_id_by_name = {
            item.policy_proj_nm: item.policy_proj_id
            for item in (
                await session.execute(
                    select(BudgetOutProjectPolicyLv1).where(
                        BudgetOutProjectPolicyLv1.la_cd == la_cd,
                        BudgetOutProjectPolicyLv1.fiscal_year == fiscal_year,
                    )
                )
            ).scalars()
        }
        adj_subject_id_by_name = {
            item.adj_sub_nm: item.adj_sub_id
            for item in (await session.execute(select(BudgetOutAdjSubjectLv1))).scalars()
        }

        # 1) 과목/정책/조정증감 과목 선적재 (독립 엔티티)
        new_account_subject_values = self._collect_new_account_subject_values(
            rows, fiscal_year, account_subject_id_by_key
        )
        if new_account_subject_values:
            inserted_accounts = await self._bulk_insert_account_subjects(
                session, new_account_subject_values
            )
            counters.account_subject += len(inserted_accounts)
            for stat_mok_nm, budg_mok_nm, acc_sub_id in inserted_accounts:
                account_subject_id_by_key[(stat_mok_nm, budg_mok_nm)] = acc_sub_id

        new_policy_values = self._collect_new_policy_values(rows, la_cd, fiscal_year, policy_id_by_name)
        if new_policy_values:
            inserted_policies = await self._bulk_insert_policies(session, new_policy_values)
            counters.project_policy += len(inserted_policies)
            for policy_proj_nm, policy_proj_id in inserted_policies:
                policy_id_by_name[policy_proj_nm] = policy_proj_id

        new_adj_subject_values = self._collect_new_adj_subject_values(
            rows, adj_subject_id_by_name
        )
        if new_adj_subject_values:
            inserted_adj_subjects = await self._bulk_insert_adj_subjects(
                session, new_adj_subject_values
            )
            for adj_sub_nm, adj_sub_id in inserted_adj_subjects:
                adj_subject_id_by_name[adj_sub_nm] = adj_sub_id

        # 2) Unit 선조회 + 신규 bulk insert
        unit_id_by_key: dict[tuple[int, str], int] = {}
        all_policy_ids = list(policy_id_by_name.values())
        if all_policy_ids:
            for item in (
                await session.execute(
                    select(BudgetOutProjectUnitLv1).where(
                        BudgetOutProjectUnitLv1.policy_proj_id.in_(all_policy_ids)
                    )
                )
            ).scalars():
                unit_id_by_key[(item.policy_proj_id, item.unit_prj_nm)] = item.unit_prj_id

        new_unit_values = self._collect_new_unit_values(rows, policy_id_by_name, unit_id_by_key)
        if new_unit_values:
            inserted_units = await self._bulk_insert_units(session, new_unit_values)
            counters.project_unit += len(inserted_units)
            for policy_proj_id, unit_prj_nm, unit_prj_id in inserted_units:
                unit_id_by_key[(policy_proj_id, unit_prj_nm)] = unit_prj_id

        # 3) Detail 선조회 + 신규 bulk insert
        detail_id_by_key: dict[tuple[int, str, str], int] = {}
        all_unit_ids = list(unit_id_by_key.values())
        if all_unit_ids:
            for item in (
                await session.execute(
                    select(BudgetOutProjectDetailLv1).where(
                        BudgetOutProjectDetailLv1.unit_prj_id.in_(all_unit_ids),
                        BudgetOutProjectDetailLv1.la_cd == la_cd,
                        BudgetOutProjectDetailLv1.fiscal_year == fiscal_year,
                    )
                )
            ).scalars():
                detail_id_by_key[
                    (item.unit_prj_id, item.dtl_prj_cd, item.budget_type)
                ] = item.dtl_prj_id

        new_detail_values = self._collect_new_detail_values(
            rows,
            la_cd,
            fiscal_year,
            policy_id_by_name,
            unit_id_by_key,
            detail_id_by_key,
        )
        if new_detail_values:
            inserted_details = await self._bulk_insert_details(session, new_detail_values)
            counters.project_detail += len(inserted_details)
            for unit_prj_id, dtl_prj_cd, budget_type, dtl_prj_id in inserted_details:
                detail_id_by_key[(unit_prj_id, dtl_prj_cd, budget_type)] = dtl_prj_id

        # 4) Fact bulk insert + fact_id 확보
        fact_values = self._build_fact_values(
            rows,
            la_cd,
            fiscal_year,
            account_subject_id_by_key,
            policy_id_by_name,
            unit_id_by_key,
            detail_id_by_key,
        )
        inserted_fact_ids = await self._bulk_insert_facts(session, fact_values)
        counters.budget_fact += len(inserted_fact_ids)

        # 5) 조정증감 상세 bulk insert
        adj_detail_values = self._build_adj_detail_values(
            rows,
            inserted_fact_ids,
            adj_subject_id_by_name,
        )
        if adj_detail_values:
            await self._bulk_insert_adj_details(session, adj_detail_values)
        counters.adj_subject += total_rows

        logger.info("[BudgetOutLv1] 데이터 적재 완료.")

    def _collect_new_account_subject_values(
        self,
        rows: list[ParsedBudgetOutLv1Row],
        fiscal_year: int,
        existing: dict[tuple[str, str], int],
    ) -> list[dict[str, str | int]]:
        values: list[dict[str, str | int]] = []
        pending: set[tuple[str, str]] = set()
        for row in rows:
            key = (row.stat_mok_nm, row.budg_mok_nm)
            if key in existing or key in pending:
                continue
            pending.add(key)
            values.append(
                {
                    "fiscal_year": fiscal_year,
                    "stat_mok_nm": row.stat_mok_nm,
                    "budg_mok_nm": row.budg_mok_nm,
                }
            )
        return values

    async def _bulk_insert_account_subjects(
        self,
        session: AsyncSession,
        values: list[dict[str, str | int]],
    ) -> list[tuple[str, str, int]]:
        inserted: list[tuple[str, str, int]] = []
        for chunk in self._iter_chunks(values):
            result = await session.execute(
                insert(BudgetOutAccountSubjectLv1)
                .values(chunk)
                .returning(
                    BudgetOutAccountSubjectLv1.stat_mok_nm,
                    BudgetOutAccountSubjectLv1.budg_mok_nm,
                    BudgetOutAccountSubjectLv1.acc_sub_id,
                )
            )
            inserted.extend(result.all())
        return inserted

    def _collect_new_policy_values(
        self,
        rows: list[ParsedBudgetOutLv1Row],
        la_cd: str,
        fiscal_year: int,
        existing: dict[str, int],
    ) -> list[dict[str, str | int]]:
        values: list[dict[str, str | int]] = []
        pending: set[str] = set()
        for row in rows:
            key = row.policy_proj_nm
            if key in existing or key in pending:
                continue
            pending.add(key)
            values.append(
                {
                    "policy_proj_nm": row.policy_proj_nm,
                    "la_cd": la_cd,
                    "fiscal_year": fiscal_year,
                }
            )
        return values

    async def _bulk_insert_policies(
        self,
        session: AsyncSession,
        values: list[dict[str, str | int]],
    ) -> list[tuple[str, int]]:
        inserted: list[tuple[str, int]] = []
        for chunk in self._iter_chunks(values):
            result = await session.execute(
                insert(BudgetOutProjectPolicyLv1)
                .values(chunk)
                .returning(
                    BudgetOutProjectPolicyLv1.policy_proj_nm,
                    BudgetOutProjectPolicyLv1.policy_proj_id,
                )
            )
            inserted.extend(result.all())
        return inserted

    def _collect_new_adj_subject_values(
        self,
        rows: list[ParsedBudgetOutLv1Row],
        existing: dict[str, int],
    ) -> list[dict[str, str]]:
        values: list[dict[str, str]] = []
        pending: set[str] = set()
        for row in rows:
            for adj_sub_nm in row.adj_details.keys():
                if adj_sub_nm in existing or adj_sub_nm in pending:
                    continue
                pending.add(adj_sub_nm)
                values.append({"adj_sub_nm": adj_sub_nm})
        return values

    async def _bulk_insert_adj_subjects(
        self,
        session: AsyncSession,
        values: list[dict[str, str]],
    ) -> list[tuple[str, int]]:
        inserted: list[tuple[str, int]] = []
        for chunk in self._iter_chunks(values):
            result = await session.execute(
                insert(BudgetOutAdjSubjectLv1)
                .values(chunk)
                .returning(
                    BudgetOutAdjSubjectLv1.adj_sub_nm,
                    BudgetOutAdjSubjectLv1.adj_sub_id,
                )
            )
            inserted.extend(result.all())
        return inserted

    def _collect_new_unit_values(
        self,
        rows: list[ParsedBudgetOutLv1Row],
        policy_id_by_name: dict[str, int],
        existing: dict[tuple[int, str], int],
    ) -> list[dict[str, str | int]]:
        values: list[dict[str, str | int]] = []
        pending: set[tuple[int, str]] = set()
        for row in rows:
            policy_proj_id = policy_id_by_name[row.policy_proj_nm]
            key = (policy_proj_id, row.unit_prj_nm)
            if key in existing or key in pending:
                continue
            pending.add(key)
            values.append(
                {
                    "unit_prj_nm": row.unit_prj_nm,
                    "policy_proj_id": policy_proj_id,
                }
            )
        return values

    async def _bulk_insert_units(
        self,
        session: AsyncSession,
        values: list[dict[str, str | int]],
    ) -> list[tuple[int, str, int]]:
        inserted: list[tuple[int, str, int]] = []
        for chunk in self._iter_chunks(values):
            result = await session.execute(
                insert(BudgetOutProjectUnitLv1)
                .values(chunk)
                .returning(
                    BudgetOutProjectUnitLv1.policy_proj_id,
                    BudgetOutProjectUnitLv1.unit_prj_nm,
                    BudgetOutProjectUnitLv1.unit_prj_id,
                )
            )
            inserted.extend(result.all())
        return inserted

    def _collect_new_detail_values(
        self,
        rows: list[ParsedBudgetOutLv1Row],
        la_cd: str,
        fiscal_year: int,
        policy_id_by_name: dict[str, int],
        unit_id_by_key: dict[tuple[int, str], int],
        existing: dict[tuple[int, str, str], int],
    ) -> list[dict[str, str | int | None]]:
        values: list[dict[str, str | int | None]] = []
        pending: set[tuple[int, str, str]] = set()
        for row in rows:
            policy_proj_id = policy_id_by_name[row.policy_proj_nm]
            unit_prj_id = unit_id_by_key[(policy_proj_id, row.unit_prj_nm)]
            key = (unit_prj_id, row.dtl_prj_cd, row.budget_type)
            if key in existing or key in pending:
                continue
            pending.add(key)
            values.append(
                {
                    "dtl_prj_cd": row.dtl_prj_cd,
                    "dtl_prj_nm": row.dtl_prj_nm,
                    "unit_prj_id": unit_prj_id,
                    "la_cd": la_cd,
                    "fiscal_year": fiscal_year,
                    "budget_type": row.budget_type,
                    "nat_sub_prj_nm": row.nat_sub_prj_nm,
                    "not_prj_type": row.not_prj_type,
                    "self_sub_type": row.self_sub_type,
                }
            )
        return values

    async def _bulk_insert_details(
        self,
        session: AsyncSession,
        values: list[dict[str, str | int | None]],
    ) -> list[tuple[int, str, str, int]]:
        inserted: list[tuple[int, str, str, int]] = []
        for chunk in self._iter_chunks(values):
            result = await session.execute(
                insert(BudgetOutProjectDetailLv1)
                .values(chunk)
                .returning(
                    BudgetOutProjectDetailLv1.unit_prj_id,
                    BudgetOutProjectDetailLv1.dtl_prj_cd,
                    BudgetOutProjectDetailLv1.budget_type,
                    BudgetOutProjectDetailLv1.dtl_prj_id,
                )
            )
            inserted.extend(result.all())
        return inserted

    def _build_fact_values(
        self,
        rows: list[ParsedBudgetOutLv1Row],
        la_cd: str,
        fiscal_year: int,
        account_subject_id_by_key: dict[tuple[str, str], int],
        policy_id_by_name: dict[str, int],
        unit_id_by_key: dict[tuple[int, str], int],
        detail_id_by_key: dict[tuple[int, str, str], int],
    ) -> list[dict[str, str | int]]:
        values: list[dict[str, str | int]] = []
        for row in rows:
            acc_sub_id = account_subject_id_by_key[(row.stat_mok_nm, row.budg_mok_nm)]
            policy_proj_id = policy_id_by_name[row.policy_proj_nm]
            unit_prj_id = unit_id_by_key[(policy_proj_id, row.unit_prj_nm)]
            dtl_prj_id = detail_id_by_key[(unit_prj_id, row.dtl_prj_cd, row.budget_type)]
            values.append(
                {
                    "dtl_prj_id": dtl_prj_id,
                    "acc_sub_id": acc_sub_id,
                    "la_cd": la_cd,
                    "fiscal_year": fiscal_year,
                    "adj_basis": row.adj_basis,
                    "sum_amt": row.sum_amt,
                }
            )
        return values

    async def _bulk_insert_facts(
        self,
        session: AsyncSession,
        values: list[dict[str, str | int]],
    ) -> list[int]:
        inserted_fact_ids: list[int] = []
        for i, chunk in enumerate(self._iter_chunks(values), 1):
            result = await session.execute(
                insert(BudgetOutFactLv1)
                .values(chunk)
                .returning(BudgetOutFactLv1.budget_fact_id)
            )
            inserted_fact_ids.extend(result.scalars().all())
            logger.info(
                "[BudgetOutLv1] Fact bulk insert 진행중 %s / %s chunk...",
                i,
                (len(values) + self.BULK_INSERT_CHUNK_SIZE - 1)
                // self.BULK_INSERT_CHUNK_SIZE,
            )
        return inserted_fact_ids

    def _build_adj_detail_values(
        self,
        rows: list[ParsedBudgetOutLv1Row],
        fact_ids: list[int],
        adj_subject_id_by_name: dict[str, int],
    ) -> list[dict[str, int]]:
        values: list[dict[str, int]] = []
        for fact_id, row in zip(fact_ids, rows, strict=True):
            for nm, amt in row.adj_details.items():
                values.append(
                    {
                        "budget_fact_id": fact_id,
                        "adj_sub_id": adj_subject_id_by_name[nm],
                        "adj_sub_amt": amt,
                    }
                )
        return values

    async def _bulk_insert_adj_details(
        self,
        session: AsyncSession,
        values: list[dict[str, int]],
    ) -> None:
        logger.info("[BudgetOutLv1] 조정증감 상세 정보 적재 시작...")
        total_chunks = (len(values) + self.BULK_INSERT_CHUNK_SIZE - 1) // self.BULK_INSERT_CHUNK_SIZE
        for i, chunk in enumerate(self._iter_chunks(values), 1):
            await session.execute(insert(BudgetOutAdjSubjectDetailLv1).values(chunk))
            if i % 10 == 0 or i == total_chunks:
                logger.info(
                    "[BudgetOutLv1] 조정증감 상세 정보 진행중 %s / %s chunk...",
                    i,
                    total_chunks,
                )
        logger.info("[BudgetOutLv1] 조정증감 상세 정보 적재 완료.")

    def _iter_chunks(self, values: list[dict]) -> Iterable[list[dict]]:
        iterator = iter(values)
        while True:
            chunk = list(islice(iterator, self.BULK_INSERT_CHUNK_SIZE))
            if not chunk:
                break
            yield chunk

    async def _upsert_adj_subject_detail_lv1(
        self,
        session: AsyncSession,
        cache: dict[str, int],
        fact_cache: list[tuple[BudgetOutFactLv1, ParsedBudgetOutLv1Row]],
        counters: ImportCountersLv1,
    ) -> None:
        """조정증감 상세 정보를 저장한다."""
        logger.info("[BudgetOutLv1] 조정증감 상세 정보 적재 시작...")

        for i, (fact, row) in enumerate(fact_cache, 1):
            for nm, amt in row.adj_details.items():
                adj_sub_id = cache.get(nm)
                if adj_sub_id is None:
                    adj_subject = BudgetOutAdjSubjectLv1(adj_sub_nm=nm)
                    session.add(adj_subject)
                    await session.flush()
                    cache[nm] = adj_subject.adj_sub_id
                    adj_sub_id = adj_subject.adj_sub_id

                session.add(
                    BudgetOutAdjSubjectDetailLv1(
                        adj_sub_id=adj_sub_id,
                        budget_fact_id=fact.budget_fact_id,
                        adj_sub_amt=amt,
                    )
                )
            counters.adj_subject += 1
            if i % 1000 == 0 or i == len(fact_cache):
                logger.info(
                    f"[BudgetOutLv1] 조정증감 상세 정보 진행중 {i} / {len(fact_cache)} 행..."
                )
        await session.flush()
        logger.info("[BudgetOutLv1] 조정증감 상세 정보 적재 완료.")

    async def _upsert_account_subject(
        self,
        session: AsyncSession,
        cache: dict[tuple[str, str], BudgetOutAccountSubjectLv1],
        row: ParsedBudgetOutLv1Row,
        counters: ImportCountersLv1,
    ) -> BudgetOutAccountSubjectLv1:
        # In Lv1, we only have names for mok.
        key = (row.stat_mok_nm, row.budg_mok_nm)
        acc_sub = cache.get(key)
        if acc_sub is None:
            acc_sub = BudgetOutAccountSubjectLv1(
                fiscal_year=row.fiscal_year,
                stat_mok_nm=row.stat_mok_nm,
                budg_mok_nm=row.budg_mok_nm,
                # Stat/Budg mok codes are unknown here
            )
            session.add(acc_sub)
            await session.flush()
            cache[key] = acc_sub
            counters.account_subject += 1
        return acc_sub

    async def _upsert_policy(
        self,
        session: AsyncSession,
        cache: dict[str, BudgetOutProjectPolicyLv1],
        la_cd: str,
        row: ParsedBudgetOutLv1Row,
        counters: ImportCountersLv1,
    ) -> BudgetOutProjectPolicyLv1:
        policy = cache.get(row.policy_proj_nm)
        if policy is None:
            policy = BudgetOutProjectPolicyLv1(
                policy_proj_nm=row.policy_proj_nm,
                la_cd=la_cd,
                fiscal_year=row.fiscal_year,
            )
            session.add(policy)
            await session.flush()
            cache[row.policy_proj_nm] = policy
            counters.project_policy += 1
        return policy

    async def _upsert_unit(
        self,
        session: AsyncSession,
        cache: dict[tuple[int, str], BudgetOutProjectUnitLv1],
        policy_proj_id: int,
        row: ParsedBudgetOutLv1Row,
        counters: ImportCountersLv1,
    ) -> BudgetOutProjectUnitLv1:
        key = (policy_proj_id, row.unit_prj_nm)
        unit = cache.get(key)
        if unit is None:
            unit = BudgetOutProjectUnitLv1(
                unit_prj_nm=row.unit_prj_nm,
                policy_proj_id=policy_proj_id,
            )
            session.add(unit)
            await session.flush()
            cache[key] = unit
            counters.project_unit += 1
        return unit

    async def _upsert_detail(
        self,
        session: AsyncSession,
        cache: dict[tuple[int, str, str], BudgetOutProjectDetailLv1],
        unit_prj_id: int,
        la_cd: str,
        row: ParsedBudgetOutLv1Row,
        counters: ImportCountersLv1,
    ) -> BudgetOutProjectDetailLv1:
        # Detail uniquely identified by Unit ID, Detail Code, and Budget Type
        key = (unit_prj_id, row.dtl_prj_cd, row.budget_type)
        detail = cache.get(key)
        if detail is None:
            detail = BudgetOutProjectDetailLv1(
                dtl_prj_cd=row.dtl_prj_cd,
                dtl_prj_nm=row.dtl_prj_nm,
                unit_prj_id=unit_prj_id,
                la_cd=la_cd,
                fiscal_year=row.fiscal_year,
                budget_type=row.budget_type,
                nat_sub_prj_nm=row.nat_sub_prj_nm,
                not_prj_type=row.not_prj_type,
                self_sub_type=row.self_sub_type,
            )
            session.add(detail)
            await session.flush()
            cache[key] = detail
            counters.project_detail += 1
        return detail
