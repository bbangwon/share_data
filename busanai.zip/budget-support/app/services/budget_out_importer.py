import logging
from dataclasses import dataclass

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import (
    BudgetLocalGovernment,
    BudgetOutAccountSubject,
    BudgetOutAdjSubject,
    BudgetOutAdjSubjectDetail,
    BudgetOutFact,
    BudgetOutFuncCategory,
    BudgetOutFundAccount,
    BudgetOutOrganization,
    BudgetOutProjectDetail,
    BudgetOutProjectPolicy,
    BudgetOutProjectUnit,
    BudgetOutVersion,
)
from app.schemas.imports import (
    BudgetOutImportRequest,
    BudgetOutImportResponse,
    BudgetOutImportVersionResponse,
)

from .adj_basis_builder import BudgetOutAdjBasisBuilder
from .excel_parser import (
    BudgetImportValidationError,
    BudgetOutExcelParser,
    ParsedBudgetOutRow,
)

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class ImportCounters:
    local_government: int = 0
    budget_version: int = 0
    organization: int = 0
    func_category: int = 0
    fund_account: int = 0
    account_subject: int = 0
    project_policy: int = 0
    project_unit: int = 0
    project_detail: int = 0
    budget_fact: int = 0
    adj_subject: int = 0

    def to_dict(self) -> dict[str, int]:
        return {
            "local_government": self.local_government,
            "budget_version": self.budget_version,
            "organization": self.organization,
            "func_category": self.func_category,
            "fund_account": self.fund_account,
            "account_subject": self.account_subject,
            "project_policy": self.project_policy,
            "project_unit": self.project_unit,
            "project_detail": self.project_detail,
            "budget_fact": self.budget_fact,
            "adj_subject": self.adj_subject,
        }


class BudgetOutImportService:
    def __init__(self, parser: BudgetOutExcelParser | None = None):
        self.parser = parser or BudgetOutExcelParser()

    async def import_excel(
        self,
        session: AsyncSession,
        request: BudgetOutImportRequest,
        source_filename: str,
        file_bytes: bytes,
    ) -> BudgetOutImportResponse:
        """세출예산서 엑셀 파일을 처리하여 데이터베이스에 저장한다."""
        parsed = self.parser.parse(file_bytes)

        if parsed.fiscal_year != request.fiscal_year:
            raise BudgetImportValidationError(
                "요청한 회계연도와 엑셀의 회계연도가 다릅니다.",
                [
                    f"요청 회계연도: {request.fiscal_year}",
                    f"엑셀 회계연도: {parsed.fiscal_year}",
                ],
            )

        async with session.begin():
            (
                local_government,
                created_local_government,
            ) = await self._resolve_local_government(
                session,
                request,
            )
            counters = ImportCounters(
                local_government=1 if created_local_government else 0,
            )

            await self._delete_existing_budget_fact(
                session,
                local_government.la_cd,
                parsed.fiscal_year,
            )

            await self._persist_rows(
                session,
                local_government.la_cd,
                parsed.rows,
                counters,
            )

            await self._cleanup_orphans(
                session, local_government.la_cd, parsed.fiscal_year
            )

        return BudgetOutImportResponse(
            la_cd=local_government.la_cd,
            la_nm=local_government.la_nm,
            fiscal_year=parsed.fiscal_year,
            budget_versions=[
                BudgetOutImportVersionResponse(
                    budget_type=budget_version.budget_type,
                    budget_seq=budget_version.budget_seq,
                    row_count=budget_version.row_count,
                )
                for budget_version in parsed.budget_versions
            ],
            source_filename=source_filename,
            rows_processed=len(parsed.rows),
            inserted_counts=counters.to_dict(),
            warnings=[],
        )

    async def _resolve_local_government(
        self,
        session: AsyncSession,
        request: BudgetOutImportRequest,
    ) -> tuple[BudgetLocalGovernment, bool]:
        """지자체 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        if request.la_cd:
            local_government = (
                await session.execute(
                    select(BudgetLocalGovernment).where(
                        BudgetLocalGovernment.la_cd == request.la_cd
                    )
                )
            ).scalar_one_or_none()

            if local_government is not None:
                if (
                    request.la_nm != local_government.la_nm
                    or request.w_city_nm != local_government.w_city_nm
                ):
                    raise BudgetImportValidationError(
                        "입력한 지자체 코드와 명칭이 일치하지 않습니다.",
                        [
                            f"입력 la_cd={request.la_cd}",
                            f"입력 la_nm={request.la_nm}",
                            f"입력 w_city_nm={request.w_city_nm}",
                            f"기존 la_nm={local_government.la_nm}",
                            f"기존 w_city_nm={local_government.w_city_nm}",
                        ],
                    )
                return local_government, False

        if request.la_cd and request.la_nm and request.w_city_nm:
            local_government = BudgetLocalGovernment(
                la_cd=request.la_cd,
                w_city_nm=request.w_city_nm,
                la_nm=request.la_nm,
            )
            session.add(local_government)
            await session.flush()
            return local_government, True

        raise BudgetImportValidationError(
            "지자체 정보를 확인할 수 없습니다.",
            [
                "기존 지자체 마스터에 la_cd 또는 la_nm 또는 w_city_nm이 존재하지 않습니다."
            ],
        )

    async def _delete_existing_budget_fact(
        self,
        session: AsyncSession,
        la_cd: str,
        fiscal_year: int,
    ) -> None:
        """기존 TB_BUDGET_OUT_FACT 및 연관 TB_BUDGET_OUT_ADJ_DETAIL 데이터를 삭제한다."""
        fact_ids_result = await session.execute(
            select(BudgetOutFact.budget_fact_id).where(
                BudgetOutFact.la_cd == la_cd,
                BudgetOutFact.fiscal_year == fiscal_year,
            )
        )
        fact_ids = fact_ids_result.scalars().all()
        if fact_ids:
            await session.execute(
                delete(BudgetOutAdjSubjectDetail).where(
                    BudgetOutAdjSubjectDetail.budget_fact_id.in_(fact_ids)
                )
            )
        await session.execute(
            delete(BudgetOutFact).where(
                BudgetOutFact.la_cd == la_cd,
                BudgetOutFact.fiscal_year == fiscal_year,
            )
        )

    async def _persist_rows(
        self,
        session: AsyncSession,
        la_cd: str,
        rows: list[ParsedBudgetOutRow],
        counters: ImportCounters,
    ) -> None:
        """파싱된 행 데이터를 데이터베이스에 저장한다."""
        total_rows = len(rows)
        logger.info(f"[BudgetOut] 데이터 적재 시작: {total_rows}행 ({la_cd})...")
        adj_basis_builder = BudgetOutAdjBasisBuilder()

        version_cache = {
            self._version_key(item.fiscal_year, item.budget_type, item.budget_seq): item
            for item in (
                await session.execute(
                    select(BudgetOutVersion).where(
                        BudgetOutVersion.la_cd == la_cd,
                        BudgetOutVersion.fiscal_year == rows[0].fiscal_year,
                    )
                )
            ).scalars()
        }

        organization_cache = {
            item.dept_cd: item
            for item in (
                await session.execute(
                    select(BudgetOutOrganization).where(
                        BudgetOutOrganization.la_cd == la_cd,
                        BudgetOutOrganization.fiscal_year == rows[0].fiscal_year,
                    )
                )
            ).scalars()
        }
        func_category_cache = {
            item.sector_cd: item
            for item in (await session.execute(select(BudgetOutFuncCategory))).scalars()
        }
        fund_account_cache = {
            item.fund_cd: item
            for item in (await session.execute(select(BudgetOutFundAccount))).scalars()
        }
        account_subject_cache = {
            self._account_subject_key(
                item.fiscal_year,
                item.stat_mok_cd,
                item.budg_mok_cd,
                item.stat_mok_nm,
                item.budg_mok_nm,
            ): item
            for item in (
                await session.execute(
                    select(BudgetOutAccountSubject).where(
                        BudgetOutAccountSubject.fiscal_year == rows[0].fiscal_year
                    )
                )
            ).scalars()
        }
        policy_cache = {
            self._policy_key(
                item.dept_cd,
                item.policy_proj_cd,
                item.hist_seq,
                item.sector_cd,
            ): item
            for item in (
                await session.execute(
                    select(BudgetOutProjectPolicy).where(
                        BudgetOutProjectPolicy.la_cd == la_cd,
                        BudgetOutProjectPolicy.fiscal_year == rows[0].fiscal_year,
                    )
                )
            ).scalars()
        }

        unit_cache: dict[tuple[int, str, int, str], BudgetOutProjectUnit] = {}
        existing_policy_ids = [
            policy.policy_proj_id for policy in policy_cache.values()
        ]
        if existing_policy_ids:
            for item in (
                await session.execute(
                    select(BudgetOutProjectUnit).where(
                        BudgetOutProjectUnit.policy_proj_id.in_(existing_policy_ids)
                    )
                )
            ).scalars():
                unit_cache[
                    self._unit_key(
                        item.policy_proj_id,
                        item.unit_prj_cd,
                        item.hist_seq,
                        item.fund_cd,
                    )
                ] = item

        detail_cache: dict[tuple[int, str, int], BudgetOutProjectDetail] = {}
        adj_subject_cache = {
            item.adj_sub_nm: item.adj_sub_id
            for item in (await session.execute(select(BudgetOutAdjSubject))).scalars()
        }
        fact_cache: list[tuple[BudgetOutFact, ParsedBudgetOutRow]] = []

        for i, row in enumerate(rows, 1):
            await self._upsert_version(
                session,
                version_cache,
                la_cd,
                row,
                counters,
            )

            await self._upsert_organization(
                session,
                organization_cache,
                la_cd,
                row,
                counters,
            )
            self._upsert_func_category(session, func_category_cache, row, counters)
            self._upsert_fund_account(session, fund_account_cache, row, counters)
            account_subject = await self._upsert_account_subject(
                session,
                account_subject_cache,
                row,
                counters,
            )
            policy = await self._upsert_policy(
                session,
                policy_cache,
                la_cd,
                row,
                counters,
            )
            unit = await self._upsert_unit(
                session,
                unit_cache,
                policy.policy_proj_id,
                row,
                counters,
            )
            detail = await self._create_detail(
                session,
                detail_cache,
                unit.unit_prj_id,
                row,
                counters,
            )

            fact = BudgetOutFact(
                dtl_prj_id=detail.dtl_prj_id,
                acc_sub_id=account_subject.acc_sub_id,
                la_cd=la_cd,
                fiscal_year=row.fiscal_year,
                budget_seq=row.budget_seq,
                dept_cd=row.dept_cd,
                fund_cd=row.fund_cd,
                policy_proj_id=policy.policy_proj_id,
                unit_prj_id=unit.unit_prj_id,
                adj_level=row.adj_level,
                adj_basis_org=row.adj_basis_org,
                adj_basis_full=adj_basis_builder.compute(
                    row.adj_level, row.adj_basis_org
                ),
                adj_formula=row.adj_formula,
                rev_adj_amt=row.rev_adj_amt,
                adj_amt_diff=row.adj_amt_diff,
                adj_obj_type=row.adj_obj_type,
            )
            session.add(fact)
            fact_cache.append((fact, row))
            counters.budget_fact += 1

            if i % 1000 == 0 or i == total_rows:
                logger.info(f"[BudgetOut] 진행중 {i} / {total_rows} 행...")

        await session.flush()

        await self._upsert_adj_subject_detail(
            session, adj_subject_cache, fact_cache, counters
        )
        logger.info("[BudgetOut] 데이터 적재 완료.")

    async def _upsert_version(
        self,
        session: AsyncSession,
        cache: dict[str, BudgetOutVersion],
        la_cd: str,
        row: ParsedBudgetOutRow,
        counters: ImportCounters,
    ) -> BudgetOutVersion:
        """버전 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        key = self._version_key(row.fiscal_year, row.budget_type, row.budget_seq)
        version = cache.get(key)
        if version is None:
            version = BudgetOutVersion(
                la_cd=la_cd,
                fiscal_year=row.fiscal_year,
                budget_type=row.budget_type,
                budget_seq=row.budget_seq,
            )
            session.add(version)
            await session.flush()
            cache[key] = version
            counters.budget_version += 1
        else:
            version.la_cd = la_cd
            version.fiscal_year = row.fiscal_year
            version.budget_type = row.budget_type
            version.budget_seq = row.budget_seq
        return version

    async def _upsert_organization(
        self,
        session: AsyncSession,
        cache: dict[str, BudgetOutOrganization],
        la_cd: str,
        row: ParsedBudgetOutRow,
        counters: ImportCounters,
    ) -> BudgetOutOrganization:
        """조직 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        organization = cache.get(row.dept_cd)
        if organization is None:
            organization = BudgetOutOrganization(
                la_cd=la_cd,
                fiscal_year=row.fiscal_year,
                dept_cd=row.dept_cd,
                dept_nm=row.dept_nm,
                dept_order=row.dept_order,
                bureau_cd=row.bureau_cd,
                bureau_nm=row.bureau_nm,
                bureau_order=row.bureau_order,
            )
            session.add(organization)
            cache[row.dept_cd] = organization
            counters.organization += 1
        else:
            organization.dept_nm = row.dept_nm
            organization.dept_order = row.dept_order
            organization.bureau_cd = row.bureau_cd
            organization.bureau_nm = row.bureau_nm
            organization.bureau_order = row.bureau_order
        return organization

    def _upsert_func_category(
        self,
        session: AsyncSession,
        cache: dict[str, BudgetOutFuncCategory],
        row: ParsedBudgetOutRow,
        counters: ImportCounters,
    ) -> BudgetOutFuncCategory:
        """기능별 분류 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        func_category = cache.get(row.sector_cd)
        if func_category is None:
            func_category = BudgetOutFuncCategory(
                sector_cd=row.sector_cd,
                sector_nm=row.sector_nm,
                field_cd=row.field_cd,
                field_nm=row.field_nm,
            )
            session.add(func_category)
            cache[row.sector_cd] = func_category
            counters.func_category += 1
        else:
            func_category.sector_nm = row.sector_nm
            func_category.field_cd = row.field_cd
            func_category.field_nm = row.field_nm
        return func_category

    def _upsert_fund_account(
        self,
        session: AsyncSession,
        cache: dict[str, BudgetOutFundAccount],
        row: ParsedBudgetOutRow,
        counters: ImportCounters,
    ) -> BudgetOutFundAccount:
        """기금 계정 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        fund_account = cache.get(row.fund_cd)
        if fund_account is None:
            fund_account = BudgetOutFundAccount(
                fund_cd=row.fund_cd,
                fund_nm=row.fund_nm,
            )
            session.add(fund_account)
            cache[row.fund_cd] = fund_account
            counters.fund_account += 1
        else:
            fund_account.fund_nm = row.fund_nm
        return fund_account

    async def _upsert_account_subject(
        self,
        session: AsyncSession,
        cache: dict[
            tuple[int, str | None, str | None, str, str], BudgetOutAccountSubject
        ],
        row: ParsedBudgetOutRow,
        counters: ImportCounters,
    ) -> BudgetOutAccountSubject:
        """회계 과목 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        key = self._account_subject_key(
            row.fiscal_year,
            row.stat_mok_cd,
            row.budg_mok_cd,
            row.stat_mok_nm,
            row.budg_mok_nm,
        )
        account_subject = cache.get(key)
        if account_subject is None:
            account_subject = BudgetOutAccountSubject(
                fiscal_year=row.fiscal_year,
                stat_mok_cd=row.stat_mok_cd,
                stat_mok_nm=row.stat_mok_nm,
                budg_mok_cd=row.budg_mok_cd,
                budg_mok_nm=row.budg_mok_nm,
            )
            session.add(account_subject)
            await session.flush()
            cache[key] = account_subject
            counters.account_subject += 1
        return account_subject

    async def _upsert_policy(
        self,
        session: AsyncSession,
        cache: dict[tuple[str, str, int, str], BudgetOutProjectPolicy],
        la_cd: str,
        row: ParsedBudgetOutRow,
        counters: ImportCounters,
    ) -> BudgetOutProjectPolicy:
        """정책 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        key = self._policy_key(
            row.dept_cd,
            row.policy_proj_cd,
            row.policy_hist_seq,
            row.sector_cd,
        )
        policy = cache.get(key)
        if policy is None:
            policy = BudgetOutProjectPolicy(
                policy_proj_cd=row.policy_proj_cd,
                hist_seq=row.policy_hist_seq,
                policy_proj_nm=row.policy_proj_nm,
                policy_order=row.policy_order,
                la_cd=la_cd,
                fiscal_year=row.fiscal_year,
                dept_cd=row.dept_cd,
                sector_cd=row.sector_cd,
                cmte_cd=row.cmte_cd,
                cmte_nm=row.cmte_nm,
            )
            session.add(policy)
            await session.flush()
            cache[key] = policy
            counters.project_policy += 1
        else:
            policy.policy_proj_nm = row.policy_proj_nm
            policy.policy_order = row.policy_order
            policy.cmte_cd = row.cmte_cd
            policy.cmte_nm = row.cmte_nm
        return policy

    async def _upsert_unit(
        self,
        session: AsyncSession,
        cache: dict[tuple[int, str, int, str], BudgetOutProjectUnit],
        policy_proj_id: int,
        row: ParsedBudgetOutRow,
        counters: ImportCounters,
    ) -> BudgetOutProjectUnit:
        """단위 사업 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        key = self._unit_key(
            policy_proj_id,
            row.unit_prj_cd,
            row.unit_hist_seq,
            row.fund_cd,
        )
        unit = cache.get(key)
        if unit is None:
            unit = BudgetOutProjectUnit(
                unit_prj_cd=row.unit_prj_cd,
                hist_seq=row.unit_hist_seq,
                unit_prj_nm=row.unit_prj_nm,
                unit_order=row.unit_order,
                policy_proj_id=policy_proj_id,
                fund_cd=row.fund_cd,
            )
            session.add(unit)
            await session.flush()
            cache[key] = unit
            counters.project_unit += 1
        else:
            unit.unit_prj_nm = row.unit_prj_nm
            unit.unit_order = row.unit_order
        return unit

    async def _upsert_adj_subject_detail(
        self,
        session: AsyncSession,
        cache: dict[str, int],
        fact_cache: list[tuple[BudgetOutFact, ParsedBudgetOutRow]],
        counters: ImportCounters,
    ) -> None:
        """조정증감 상세 정보를 저장한다."""
        logger.info("[BudgetOut] 조정증감 상세 정보 적재 시작...")

        for i, (fact, row) in enumerate(fact_cache, 1):
            for nm, amt in row.adj_details.items():
                adj_sub_id = cache.get(nm)
                if adj_sub_id is None:
                    adj_subject = BudgetOutAdjSubject(adj_sub_nm=nm)
                    session.add(adj_subject)
                    await session.flush()
                    cache[nm] = adj_subject.adj_sub_id
                    adj_sub_id = adj_subject.adj_sub_id

                session.add(
                    BudgetOutAdjSubjectDetail(
                        adj_sub_id=adj_sub_id,
                        budget_fact_id=fact.budget_fact_id,
                        adj_sub_amt=amt,
                    )
                )
            counters.adj_subject += 1
            if i % 1000 == 0 or i == len(fact_cache):
                logger.info(
                    f"[BudgetOut] 조정증감 상세 정보 진행중 {i} / {len(fact_cache)} 행..."
                )
        await session.flush()
        logger.info("[BudgetOut] 조정증감 상세 정보 적재 완료.")

    async def _create_detail(
        self,
        session: AsyncSession,
        cache: dict[tuple[int, str, int], BudgetOutProjectDetail],
        unit_prj_id: int,
        row: ParsedBudgetOutRow,
        counters: ImportCounters,
    ) -> BudgetOutProjectDetail:
        """세부 사업 정보를 확인하여 기존 데이터와 일치하는지 검증하고, 없으면 생성한다."""
        key = self._detail_key(
            unit_prj_id,
            row.dtl_prj_cd,
            row.dtl_hist_seq,
        )
        detail = cache.get(key)
        if detail is not None:
            return detail

        detail = BudgetOutProjectDetail(
            dtl_prj_cd=row.dtl_prj_cd,
            hist_seq=row.dtl_hist_seq,
            dtl_prj_nm=row.dtl_prj_nm,
            dtl_order=row.detail_order,
            unit_prj_id=unit_prj_id,
            not_prj_type=row.not_prj_type,
            prj_type_nm=row.prj_type_nm,
            gender_yn=row.gender_yn,
            cont_exp_yn=row.cont_exp_yn,
            self_sub_type=row.self_sub_type,
            dir_sup_type=row.dir_sup_type,
            nat_dir_prj=row.nat_dir_prj,
            citizen_budget_yn=row.citizen_budget_yn,
            loc_sub_exc=row.loc_sub_exc,
            job_prj_yn=row.job_prj_yn,
            job_prj_type=row.job_prj_type,
            job_target_cnt=row.job_target_cnt,
            event_prj_yn=row.event_prj_yn,
            loc_trans_prj=row.loc_trans_prj,
            loc_trans_step=row.loc_trans_step,
            promote_yn=row.promote_yn,
            disaster_law_cl=row.disaster_law_cl,
            disaster_field=row.disaster_field,
            disaster_type=row.disaster_type,
            disaster_man_step=row.disaster_man_step,
        )
        session.add(detail)
        await session.flush()
        cache[key] = detail
        counters.project_detail += 1
        return detail

    async def _cleanup_orphans(
        self,
        session: AsyncSession,
        la_cd: str,
        fiscal_year: int,
    ) -> None:
        """정책과 단위 중에서 더 이상 세부 사업과 연결되지 않는 고아 데이터를 삭제한다."""
        unit_ids = list(
            (
                await session.execute(
                    select(BudgetOutProjectUnit.unit_prj_id)
                    .join(
                        BudgetOutProjectPolicy,
                        BudgetOutProjectUnit.policy_proj_id
                        == BudgetOutProjectPolicy.policy_proj_id,
                    )
                    .where(
                        BudgetOutProjectPolicy.la_cd == la_cd,
                        BudgetOutProjectPolicy.fiscal_year == fiscal_year,
                    )
                )
            ).scalars()
        )
        if unit_ids:
            detail_unit_ids = set(
                (
                    await session.execute(
                        select(BudgetOutProjectDetail.unit_prj_id).where(
                            BudgetOutProjectDetail.unit_prj_id.in_(unit_ids)
                        )
                    )
                ).scalars()
            )
            orphan_unit_ids = [
                unit_id for unit_id in unit_ids if unit_id not in detail_unit_ids
            ]
            if orphan_unit_ids:
                await session.execute(
                    delete(BudgetOutProjectUnit).where(
                        BudgetOutProjectUnit.unit_prj_id.in_(orphan_unit_ids)
                    )
                )

        policy_ids = list(
            (
                await session.execute(
                    select(BudgetOutProjectPolicy.policy_proj_id).where(
                        BudgetOutProjectPolicy.la_cd == la_cd,
                        BudgetOutProjectPolicy.fiscal_year == fiscal_year,
                    )
                )
            ).scalars()
        )
        if policy_ids:
            live_policy_ids = set(
                (
                    await session.execute(
                        select(BudgetOutProjectUnit.policy_proj_id).where(
                            BudgetOutProjectUnit.policy_proj_id.in_(policy_ids)
                        )
                    )
                ).scalars()
            )
            orphan_policy_ids = [
                policy_id
                for policy_id in policy_ids
                if policy_id not in live_policy_ids
            ]
            if orphan_policy_ids:
                await session.execute(
                    delete(BudgetOutProjectPolicy).where(
                        BudgetOutProjectPolicy.policy_proj_id.in_(orphan_policy_ids)
                    )
                )

    def _version_key(
        self, fiscal_year: int, budget_type: str, budget_seq: int
    ) -> tuple[int, str, int]:
        return (fiscal_year, budget_type, budget_seq)

    def _account_subject_key(
        self,
        fiscal_year: int,
        stat_mok_cd: str | None,
        budg_mok_cd: str | None,
        stat_mok_nm: str,
        budg_mok_nm: str,
    ) -> tuple[int, str | None, str | None, str, str]:
        return (fiscal_year, stat_mok_cd, budg_mok_cd, stat_mok_nm, budg_mok_nm)

    def _policy_key(
        self,
        dept_cd: str,
        policy_proj_cd: str,
        hist_seq: int,
        sector_cd: str,
    ) -> tuple[str, str, int, str]:
        return (dept_cd, policy_proj_cd, hist_seq, sector_cd)

    def _unit_key(
        self,
        policy_proj_id: int,
        unit_prj_cd: str,
        hist_seq: int,
        fund_cd: str,
    ) -> tuple[int, str, int, str]:
        return (policy_proj_id, unit_prj_cd, hist_seq, fund_cd)

    def _detail_key(
        self,
        unit_prj_id: int,
        dtl_prj_cd: str,
        hist_seq: int,
    ) -> tuple[int, str, int]:
        return (unit_prj_id, dtl_prj_cd, hist_seq)
