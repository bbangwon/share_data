"""산출근거내용(adj_basis_full) 조합 빌더

규칙: docs/adj_basis_rules.md 참조

- BudgetOutAdjBasisBuilder: 세출예산서 — adj_level 기반
- BudgetInAdjBasisBuilder: 세입예산서 — 들여쓰기(2칸 단위) 기반

새 Excel 파일을 읽을 때마다 빌더 인스턴스를 새로 생성하여 캐시를 초기화한다.
"""


class BudgetOutAdjBasisBuilder:
    """세출예산서(BudgetOutFact) adj_basis_full 계산기.

    조정레벨(adj_level) 기반으로 adj_basis_org를 레벨 캐시에 저장하고,
    레벨 1부터 현재 레벨까지 조합하여 adj_basis_full을 반환한다.
    """

    def __init__(self) -> None:
        # level → adj_basis_org 캐시
        self._cache: dict[int, str] = {}

    def compute(self, adj_level: int, adj_basis_org: str) -> str:
        """adj_basis_full 값을 계산하여 반환한다.

        Args:
            adj_level: 조정레벨 (1부터 시작)
            adj_basis_org: 원본 산출근거 텍스트

        Returns:
            adj_basis_full 문자열
        """
        # 현재 레벨의 텍스트를 캐시에 저장 (하위 레벨 캐시 무효화)
        self._cache[adj_level] = adj_basis_org
        for level in list(self._cache.keys()):
            if level > adj_level:
                del self._cache[level]

        # 조정레벨 1이면 원본 그대로
        if adj_level == 1:
            return adj_basis_org

        # 레벨 1부터 현재 레벨까지 순서대로 조합
        parts = [
            self._cache[lvl] for lvl in range(1, adj_level + 1) if lvl in self._cache
        ]
        return " ".join(parts)


class BudgetInAdjBasisBuilder:
    """세입예산서(BudgetInFact) adj_basis_full 계산기.

    들여쓰기(2칸 단위) 기반으로 adj_basis_org를 들여쓰기 레벨 캐시에 저장하고,
    들여쓰기 0 레벨부터 현재 레벨까지 조합하여 adj_basis_full을 반환한다.
    저장 시 들여쓰기 공백은 제거한다.
    """

    def __init__(self) -> None:
        # indent_level → stripped 텍스트 캐시
        self._cache: dict[int, str] = {}

    def compute(self, adj_basis_org: str) -> str:
        """adj_basis_full 값을 계산하여 반환한다.

        Args:
            adj_basis_org: 원본 산출근거 텍스트 (들여쓰기 포함 가능)

        Returns:
            adj_basis_full 문자열 (들여쓰기 공백 제거됨)
        """
        # 들여쓰기 레벨 계산 (2칸 단위)
        stripped = adj_basis_org.lstrip(" ")
        leading_spaces = len(adj_basis_org) - len(stripped)
        indent_level = leading_spaces // 2

        # 현재 레벨의 텍스트를 캐시에 저장 (하위 레벨 캐시 무효화)
        self._cache[indent_level] = stripped
        for level in list(self._cache.keys()):
            if level > indent_level:
                del self._cache[level]

        # 들여쓰기가 없으면(최상위) stripped 텍스트 그대로
        if indent_level == 0:
            return stripped

        # 레벨 0부터 현재 레벨까지 순서대로 조합
        parts = [
            self._cache[lvl] for lvl in range(0, indent_level + 1) if lvl in self._cache
        ]
        return " ".join(parts)
