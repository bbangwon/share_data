import asyncio
import logging
from pathlib import Path
from socket import gethostname

from app.core.config import get_settings
from app.core.database import get_session_maker
from app.services import BudgetImportJobService, get_import_job_handlers

logger = logging.getLogger(__name__)


class BudgetImportWorker:
    def __init__(self) -> None:
        settings = get_settings()
        self.poll_interval_seconds = settings.import_worker_poll_interval_seconds
        self.worker_id = f"{gethostname()}-budget-import-worker"
        self.session_maker = get_session_maker()
        self.job_service = BudgetImportJobService()
        self.handlers = get_import_job_handlers()

    async def run_forever(self) -> None:
        logger.info("[BudgetImportWorker] started: %s", self.worker_id)
        while True:
            processed = await self.run_once()
            if not processed:
                await asyncio.sleep(self.poll_interval_seconds)

    async def run_once(self) -> bool:
        async with self.session_maker() as session:
            job = await self.job_service.claim_next_queued_job(
                session=session,
                worker_id=self.worker_id,
            )

        if job is None:
            return False

        handler = self.handlers.get(job.import_type)
        if handler is None:
            logger.error("[BudgetImportWorker] unsupported import_type=%s", job.import_type)
            async with self.session_maker() as session:
                await self.job_service.mark_failed(
                    session=session,
                    job_id=job.job_id,
                    error_summary="지원하지 않는 임포트 유형입니다.",
                    error_detail=f"unsupported import_type: {job.import_type}",
                )
            return True

        logger.info(
            "[BudgetImportWorker] processing type=%s job=%s",
            job.import_type,
            job.job_id,
        )
        try:
            async with self.session_maker() as session:
                await self.job_service.mark_stage(
                    session=session,
                    job_id=job.job_id,
                    stage=self.job_service.STAGE_PARSING,
                    progress_pct=10,
                )

            file_bytes = Path(job.stored_file_path).read_bytes()

            async with self.session_maker() as session:
                await self.job_service.mark_stage(
                    session=session,
                    job_id=job.job_id,
                    stage=self.job_service.STAGE_IMPORTING,
                    progress_pct=30,
                )
                result = await handler.process(
                    session=session,
                    request_payload=job.request_payload,
                    source_filename=job.source_filename,
                    file_bytes=file_bytes,
                )
                await self.job_service.mark_succeeded(
                    session=session,
                    job_id=job.job_id,
                    rows_processed=result.rows_processed,
                    inserted_counts=result.inserted_counts,
                    warnings=result.warnings,
                    budget_versions=result.budget_versions,
                )

            logger.info(
                "[BudgetImportWorker] completed type=%s job=%s",
                job.import_type,
                job.job_id,
            )
            return True
        except Exception as exc:
            logger.exception(
                "[BudgetImportWorker] failed type=%s job=%s",
                job.import_type,
                job.job_id,
            )
            async with self.session_maker() as session:
                await self.job_service.mark_failed(
                    session=session,
                    job_id=job.job_id,
                    error_summary="임포트 작업이 실패했습니다.",
                    error_detail=str(exc),
                )
            return True


async def main() -> None:
    worker = BudgetImportWorker()
    await worker.run_forever()


if __name__ == "__main__":
    asyncio.run(main())
