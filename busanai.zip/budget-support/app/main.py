import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.api.v1.ai_search import router as ai_search_router
from app.api.v1.budget_in import router as budget_in_router
from app.api.v1.budget_out import router as budget_out_router
from app.api.v1.budget_out_lv1 import router as budget_out_lv1_router
from app.api.v1.import_jobs import router as import_jobs_router
from app.api.v1.page import router as page_router
from app.api.v1.status import router as status_router
from app.core import dispose_engine
from app.core.config import get_settings
from app.core.templates import templates

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield
    await dispose_engine()


settings = get_settings()
app = FastAPI(title=settings.app_name, lifespan=lifespan)

app.mount("/static", StaticFiles(directory="app/static"), name="static")


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    return Response(status_code=404)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(budget_out_router)
app.include_router(budget_out_lv1_router)
app.include_router(budget_in_router)
app.include_router(import_jobs_router)
app.include_router(page_router)
app.include_router(status_router)
app.include_router(ai_search_router)


@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")


@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "appEnv": settings.app_env,
    }
