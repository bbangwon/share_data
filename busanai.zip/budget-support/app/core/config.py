import os
from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True)
class Settings:
    database_url: str
    app_name: str = "Budget Support"
    app_env: str = "local"
    db_echo: bool = False
    upload_dir: str = "app/data/uploads"
    upload_retention_days: int = 7
    import_max_file_mb: int = 100
    import_worker_poll_interval_seconds: float = 2.0


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    database_url = os.getenv(
        "DATABASE_URL",
        "postgresql+asyncpg://postgres:postgres@localhost:5432/budgetdb",
    )
    app_name = os.getenv("APP_NAME", "Budget Support")
    app_env = os.getenv("APP_ENV", "local")
    db_echo = os.getenv("DB_ECHO", "false").lower() == "true"
    upload_dir = os.getenv("UPLOAD_DIR", "app/data/uploads")
    upload_retention_days = int(os.getenv("UPLOAD_RETENTION_DAYS", "7"))
    import_max_file_mb = int(os.getenv("IMPORT_MAX_FILE_MB", "100"))
    import_worker_poll_interval_seconds = float(
        os.getenv("IMPORT_WORKER_POLL_INTERVAL_SECONDS", "2")
    )
    return Settings(
        database_url=database_url,
        app_name=app_name,
        app_env=app_env,
        db_echo=db_echo,
        upload_dir=upload_dir,
        upload_retention_days=upload_retention_days,
        import_max_file_mb=import_max_file_mb,
        import_worker_poll_interval_seconds=import_worker_poll_interval_seconds,
    )
