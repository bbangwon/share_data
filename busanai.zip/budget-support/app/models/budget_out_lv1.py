from sqlalchemy import (
    BigInteger,
    ForeignKey,
    Index,
    Integer,
    String,
)
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class BudgetOutProjectPolicyLv1(Base):
    """세출 정책사업(레벨 1)"""

    __tablename__ = "TB_BUDGET_OUT_PROJECT_POLICY_LV1"

    policy_proj_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 정책사업 ID
    policy_proj_nm: Mapped[str] = mapped_column(String(100))  # 정책사업명
    la_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd")
    )  # 지방자치단체 코드
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도

    __table_args__ = (
        Index("IDX_BUDGET_OUT_PROJECT_POLICY_LV1_FY", "fiscal_year"),
        Index("IDX_BUDGET_OUT_PROJECT_POLICY_LV1_PROJ_NM", "policy_proj_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutProjectPolicyLv1(policy_proj_id={self.policy_proj_id}, policy_proj_nm={self.policy_proj_nm}, "
            f"la_cd={self.la_cd}, fiscal_year={self.fiscal_year})>"
        )


class BudgetOutProjectUnitLv1(Base):
    """세출 정책사업 단위(레벨 1)"""

    __tablename__ = "TB_BUDGET_OUT_PROJECT_UNIT_LV1"

    unit_prj_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 정책사업 단위 ID
    unit_prj_nm: Mapped[str] = mapped_column(String(100))  # 정책사업 단위명
    policy_proj_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("TB_BUDGET_OUT_PROJECT_POLICY_LV1.policy_proj_id")
    )  # 정책사업 ID

    __table_args__ = (
        Index("IDX_BUDGET_OUT_PROJECT_UNIT_LV1_PROJ_ID", "policy_proj_id"),
        Index("IDX_BUDGET_OUT_PROJECT_UNIT_LV1_UNIT_NM", "unit_prj_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutProjectUnitLv1(unit_prj_id={self.unit_prj_id}, unit_prj_nm={self.unit_prj_nm}, "
            f"policy_proj_id={self.policy_proj_id})>"
        )


class BudgetOutProjectDetailLv1(Base):
    """세출 정책사업 세부(레벨 1)"""

    __tablename__ = "TB_BUDGET_OUT_PROJECT_DETAIL_LV1"

    dtl_prj_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 정책사업 세부 ID
    dtl_prj_cd: Mapped[str] = mapped_column(String(30))  # 정책사업 세부 코드
    dtl_prj_nm: Mapped[str] = mapped_column(String(100))  # 정책사업 세부명
    unit_prj_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("TB_BUDGET_OUT_PROJECT_UNIT_LV1.unit_prj_id")
    )  # 정책사업 단위 ID
    la_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd")
    )  # 지방자치단체 코드
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도
    budget_type: Mapped[str] = mapped_column(
        String(20)
    )  # 예산 유형 (예: 본예산, 수정예산)
    nat_sub_prj_nm: Mapped[str] = mapped_column(
        String(100), nullable=True
    )  # 국고보조사업명
    not_prj_type: Mapped[str] = mapped_column(
        String(20), default="정책사업"
    )  # 비사업 유형 (예: 정책사업, 비사업)
    self_sub_type: Mapped[str] = mapped_column(
        String(10), default="자체"
    )  # 보조유형 (예: 자체, 보조) - 자체: 지방비만 지원, 보조: 국고보조 포함

    __table_args__ = (
        Index("IDX_BUDGET_OUT_PROJECT_DETAIL_LV1_DTL_PRJ_CD", "dtl_prj_cd"),
        Index("IDX_BUDGET_OUT_PROJECT_DETAIL_LV1_DTL_PRJ_NM", "dtl_prj_nm"),
        Index("IDX_BUDGET_OUT_PROJECT_DETAIL_LV1_UNIT_ID", "unit_prj_id"),
        Index("IDX_BUDGET_OUT_PROJECT_DETAIL_LV1_FY", "fiscal_year"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutProjectDetailLv1(dtl_prj_id={self.dtl_prj_id}, dtl_prj_cd={self.dtl_prj_cd}, "
            f"dtl_prj_nm={self.dtl_prj_nm}, unit_prj_id={self.unit_prj_id}, la_cd={self.la_cd}, "
            f"fiscal_year={self.fiscal_year}, budget_type={self.budget_type}, nat_sub_prj_nm={self.nat_sub_prj_nm}, "
            f"not_prj_type={self.not_prj_type}, self_sub_type={self.self_sub_type})>"
        )
    
class BudgetOutAccountSubjectLv1(Base):
    """예산과목"""

    __tablename__ = "TB_BUDGET_OUT_ACCOUNT_SUBJECT_LV1"

    acc_sub_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 예산과목 ID
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도    
    stat_mok_nm: Mapped[str] = mapped_column(String(30))  # 통계목명
    budg_mok_nm: Mapped[str] = mapped_column(String(30))  # 예산목명

    __table_args__ = (
        Index("IDX_BUDGET_OUT_ACCOUNT_SUBJECT_LV1_FY", "fiscal_year"),
        Index("IDX_BUDGET_OUT_ACCOUNT_SUBJECT_LV1_STAT_MOK_NM", "stat_mok_nm"),
        Index("IDX_BUDGET_OUT_ACCOUNT_SUBJECT_LV1_BUDG_MOK_NM", "budg_mok_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutAccountSubjectLv1(acc_sub_id={self.acc_sub_id}, fiscal_year={self.fiscal_year}, "
            f"stat_mok_nm={self.stat_mok_nm}, "
            f"budg_mok_nm={self.budg_mok_nm})>"
        )


class BudgetOutFactLv1(Base):
    """세출 편성(레벨 1)"""

    __tablename__ = "TB_BUDGET_OUT_FACT_LV1"

    budget_fact_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 세출 편성 ID
    dtl_prj_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("TB_BUDGET_OUT_PROJECT_DETAIL_LV1.dtl_prj_id")
    )  # 정책사업 세부 ID
    acc_sub_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("TB_BUDGET_OUT_ACCOUNT_SUBJECT_LV1.acc_sub_id")
    )  # 계정과목 ID
    la_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd")
    )  # 지방자치단체 코드
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도
    adj_basis: Mapped[str] = mapped_column(String(200))  # 산출근거내용
    sum_amt: Mapped[int] = mapped_column(BigInteger, default=0)  # 예산합계

    __table_args__ = (
        Index("IDX_BUDGET_OUT_FACT_LV1_DTL_PRJ_ID", "dtl_prj_id"),
        Index("IDX_BUDGET_OUT_FACT_LV1_ACC_SUB_ID", "acc_sub_id"),
        Index("IDX_BUDGET_OUT_FACT_LV1_FY", "fiscal_year"),
        Index("IDX_BUDGET_OUT_FACT_LV1_ADJ_BASIS", "adj_basis"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutFactLv1(budget_fact_id={self.budget_fact_id}, dtl_prj_id={self.dtl_prj_id}, "
            f"acc_sub_id={self.acc_sub_id}, la_cd={self.la_cd}, fiscal_year={self.fiscal_year}, "
            f"adj_basis={self.adj_basis}, sum_amt={self.sum_amt})>"
        )


class BudgetOutAdjSubjectLv1(Base):
    """세출예산서 조정증감 과목"""

    __tablename__ = "TB_BUDGET_OUT_ADJ_SUBJECT_LV1"

    adj_sub_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 조정증감 과목 ID
    adj_sub_nm: Mapped[str] = mapped_column(String(30))  # 조정증감 과목명

    __table_args__ = (Index("IDX_BUDGET_OUT_ADJ_SUBJECT_LV1_NM", "adj_sub_nm"),)

    def __repr__(self):
        return (
            f"<BudgetOutAdjSubjectLv1(adj_sub_id={self.adj_sub_id}, "
            f"adj_sub_nm={self.adj_sub_nm})>"
        )


class BudgetOutAdjSubjectDetailLv1(Base):
    """세출예산서 조정증감 상세 내역"""

    __tablename__ = "TB_BUDGET_OUT_ADJ_SUBJECT_DETAIL_LV1"

    budget_fact_id: Mapped[int] = mapped_column(
        ForeignKey("TB_BUDGET_OUT_FACT_LV1.budget_fact_id"), primary_key=True
    )  # 예산 편성 ID
    adj_sub_id: Mapped[int] = mapped_column(
        ForeignKey("TB_BUDGET_OUT_ADJ_SUBJECT_LV1.adj_sub_id"), primary_key=True
    )  # 조정증감 과목 ID
    adj_sub_amt: Mapped[int] = mapped_column(BigInteger)  # 조정액증감

    __table_args__ = (
        Index("IDX_BUDGET_OUT_ADJ_SUBJECT_DETAIL_LV1_BUDGET_FACT_ID", "budget_fact_id"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutAdjSubjectDetailLv1(adj_sub_id={self.adj_sub_id}, budget_fact_id={self.budget_fact_id}, "
            f"adj_sub_amt={self.adj_sub_amt})>"
        )
