from sqlalchemy import Index, String
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class BudgetLocalGovernment(Base):
    """예산 지원 대상 지방자치단체"""

    __tablename__ = "TB_BUDGET_LOCAL_GOVERNMENT"

    la_cd: Mapped[str] = mapped_column(
        String(10), primary_key=True
    )  # 지방자치단체 코드
    w_city_nm: Mapped[str] = mapped_column(String(50))  # 시군구명
    la_nm: Mapped[str] = mapped_column(String(50))  # 지방자치단체명

    __table_args__ = (
        Index("IDX_BUDGET_LOCAL_GOVERNMENT_CITY_NM", "w_city_nm"),
        Index("IDX_BUDGET_LOCAL_GOVERNMENT_LA_NM", "la_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetLocalGovernment(la_cd={self.la_cd}, w_city_nm={self.w_city_nm}, "
            f"la_nm={self.la_nm})>"
        )
