from datetime import datetime

from sqlalchemy import JSON, DateTime, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class BudgetImportJob(Base):
    __tablename__ = "TB_BUDGET_IMPORT_JOB"

    job_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    import_type: Mapped[str] = mapped_column(String(50), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="queued")
    stage: Mapped[str | None] = mapped_column(String(20), nullable=True)
    progress_pct: Mapped[int] = mapped_column(Integer, default=0)
    rows_total: Mapped[int | None] = mapped_column(Integer, nullable=True)
    rows_processed: Mapped[int] = mapped_column(Integer, default=0)
    request_fiscal_year: Mapped[int] = mapped_column(Integer)
    request_la_cd: Mapped[str | None] = mapped_column(String(10), nullable=True)
    request_payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    source_filename: Mapped[str] = mapped_column(String(255))
    stored_file_path: Mapped[str] = mapped_column(String(500))
    error_summary: Mapped[str | None] = mapped_column(String(500), nullable=True)
    error_detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    worker_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    inserted_counts: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    warnings: Mapped[list[str] | None] = mapped_column(JSON, nullable=True)
    budget_versions: Mapped[list[dict] | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        Index("IDX_BUDGET_IMPORT_JOB_STATUS", "status"),
        Index("IDX_BUDGET_IMPORT_JOB_IMPORT_TYPE_STATUS", "import_type", "status"),
        Index("IDX_BUDGET_IMPORT_JOB_CREATED_AT", "created_at"),
        Index("IDX_BUDGET_IMPORT_JOB_UPDATED_AT", "updated_at"),
    )
