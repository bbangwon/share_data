from sqlalchemy import (
    BigInteger,
    ForeignKey,
    Index,
    Integer,
    String,
)
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class BudgetOutVersion(Base):
    """상세 세출 예산 버전"""

    __tablename__ = "TB_BUDGET_OUT_VERSION"

    la_cd: Mapped[str] = mapped_column(
        ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd"), primary_key=True
    )  # 지방자치단체 코드
    fiscal_year: Mapped[int] = mapped_column(Integer, primary_key=True)  # 회계연도
    budget_seq: Mapped[int] = mapped_column(Integer, primary_key=True)  # 예산 순번
    budget_type: Mapped[str] = mapped_column(String(20))  # 예산 유형

    def __repr__(self):
        return (
            f"<BudgetOutVersion(la_cd={self.la_cd}, fiscal_year={self.fiscal_year}, budget_type={self.budget_type}, "
            f"budget_seq={self.budget_seq})>"
        )


class BudgetOutOrganization(Base):
    """상세 세출 예산 조직"""

    __tablename__ = "TB_BUDGET_OUT_ORGANIZATION"

    la_cd: Mapped[str] = mapped_column(
        ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd"), primary_key=True
    )  # 지방자치단체 코드
    fiscal_year: Mapped[int] = mapped_column(Integer, primary_key=True)  # 회계연도
    dept_cd: Mapped[str] = mapped_column(String(20), primary_key=True)  # 부서 코드
    dept_nm: Mapped[str] = mapped_column(String(50))  # 부서명
    dept_order: Mapped[int] = mapped_column(Integer)  # 부서 순서
    bureau_cd: Mapped[str] = mapped_column(String(20))  # 국 코드
    bureau_nm: Mapped[str] = mapped_column(String(50))  # 국명
    bureau_order: Mapped[int] = mapped_column(Integer)  # 국 순서

    __table_args__ = (
        Index("IDX_BUDGET_OUT_ORGANIZATION_FY", "fiscal_year"),
        Index("IDX_BUDGET_OUT_ORGANIZATION_BUREAU_DEPT", "bureau_nm", "dept_nm"),
        Index("IDX_BUDGET_OUT_ORGANIZATION_DEPT", "dept_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutOrganization(la_cd={self.la_cd}, dept_cd={self.dept_cd}, "
            f"fiscal_year={self.fiscal_year}, dept_nm={self.dept_nm}, "
            f"dept_order={self.dept_order}, bureau_cd={self.bureau_cd}, "
            f"bureau_nm={self.bureau_nm}, bureau_order={self.bureau_order})>"
        )


class BudgetOutFuncCategory(Base):
    """상세 세출 예산 기능분류"""

    __tablename__ = "TB_BUDGET_OUT_FUNC_CATEGORY"

    sector_cd: Mapped[str] = mapped_column(String(10), primary_key=True)  # 부문 코드
    sector_nm: Mapped[str] = mapped_column(String(50))  # 부문명
    field_cd: Mapped[str] = mapped_column(String(10))  # 분야 코드
    field_nm: Mapped[str] = mapped_column(String(50))  # 분야명

    __table_args__ = (
        Index("IDX_BUDGET_OUT_FUNC_CATEGORY_SECTOR", "sector_nm"),
        Index("IDX_BUDGET_OUT_FUNC_CATEGORY_FIELD", "field_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutFuncCategory(sector_cd={self.sector_cd}, sector_nm={self.sector_nm}, "
            f"field_cd={self.field_cd}, field_nm={self.field_nm})>"
        )


class BudgetOutProjectPolicy(Base):
    """상세 세출 예산 정책사업"""

    __tablename__ = "TB_BUDGET_OUT_PROJECT_POLICY"

    policy_proj_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 정책사업 ID
    policy_proj_cd: Mapped[str] = mapped_column(String(30))  # 정책사업 코드
    hist_seq: Mapped[int] = mapped_column(Integer)  # 이력 순번
    policy_proj_nm: Mapped[str] = mapped_column(String(100))  # 정책사업명
    policy_order: Mapped[int] = mapped_column(Integer)  # 정책사업 정렬우선순위
    la_cd: Mapped[str] = mapped_column(
        ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd")  # 지방자치단체 코드
    )
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도
    dept_cd: Mapped[str] = mapped_column(String(20))  # 부서 코드
    sector_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_OUT_FUNC_CATEGORY.sector_cd")
    )  # 부문 코드
    cmte_cd: Mapped[str] = mapped_column(String(10))  # 위원회 코드
    cmte_nm: Mapped[str] = mapped_column(String(50))  # 위원회명

    __table_args__ = (
        Index("IDX_BUDGET_OUT_PROJECT_POLICY_FY", "fiscal_year"),
        Index("IDX_BUDGET_OUT_PROJECT_POLICY_PROJ_NM", "policy_proj_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutProjectPolicy(policy_proj_id={self.policy_proj_id}, policy_proj_cd={self.policy_proj_cd}, "
            f"hist_seq={self.hist_seq}, policy_proj_nm={self.policy_proj_nm}, policy_order={self.policy_order}, "
            f"la_cd={self.la_cd}, fiscal_year={self.fiscal_year}, dept_cd={self.dept_cd}, "
            f"sector_cd={self.sector_cd}, cmte_cd={self.cmte_cd}, cmte_nm={self.cmte_nm})>"
        )


class BudgetOutFundAccount(Base):
    """상세 세출 회계과목"""

    __tablename__ = "TB_BUDGET_OUT_FUND_ACCOUNT"

    fund_cd: Mapped[str] = mapped_column(String(10), primary_key=True)  # 회계 코드
    fund_nm: Mapped[str] = mapped_column(String(50))  # 회계 명칭

    __table_args__ = (Index("IDX_BUDGET_OUT_FUND_ACCOUNT_NM", "fund_nm"),)

    def __repr__(self):
        return f"<BudgetOutFundAccount(fund_cd={self.fund_cd}, fund_nm={self.fund_nm})>"


class BudgetOutProjectUnit(Base):
    """상세 세출 단위 사업"""

    __tablename__ = "TB_BUDGET_OUT_PROJECT_UNIT"

    unit_prj_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 단위사업 ID
    unit_prj_cd: Mapped[str] = mapped_column(String(30))  # 단위사업 코드
    hist_seq: Mapped[int] = mapped_column(Integer)  # 이력 순번
    unit_prj_nm: Mapped[str] = mapped_column(String(100))  # 단위사업명
    unit_order: Mapped[int] = mapped_column(Integer)  # 단위사업 정렬우선순위
    policy_proj_id: Mapped[int] = mapped_column(
        ForeignKey("TB_BUDGET_OUT_PROJECT_POLICY.policy_proj_id")  # 정책사업 ID
    )
    fund_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_OUT_FUND_ACCOUNT.fund_cd")
    )  # 회계 코드

    __table_args__ = (
        Index("IDX_BUDGET_OUT_PROJECT_UNIT_PROJ_ID", "policy_proj_id"),
        Index("IDX_BUDGET_OUT_PROJECT_UNIT_FUND_CD", "fund_cd"),
        Index("IDX_BUDGET_OUT_PROJECT_UNIT_PRJ_NM", "unit_prj_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutProjectUnit(unit_prj_id={self.unit_prj_id}, unit_prj_cd={self.unit_prj_cd}, "
            f"hist_seq={self.hist_seq}, unit_prj_nm={self.unit_prj_nm}, unit_order={self.unit_order}, "
            f"policy_proj_id={self.policy_proj_id}, fund_cd={self.fund_cd})>"
        )


class BudgetOutProjectDetail(Base):
    """상세 세출 세부 사업"""

    __tablename__ = "TB_BUDGET_OUT_PROJECT_DETAIL"

    dtl_prj_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 세부사업 ID
    dtl_prj_cd: Mapped[str] = mapped_column(String(30))  # 세부사업 코드
    hist_seq: Mapped[int] = mapped_column(Integer)  # 이력 순번
    dtl_prj_nm: Mapped[str] = mapped_column(String(100))  # 세부사업명
    dtl_order: Mapped[int] = mapped_column(Integer)  # 세부사업 정렬우선순위
    unit_prj_id: Mapped[int] = mapped_column(
        ForeignKey("TB_BUDGET_OUT_PROJECT_UNIT.unit_prj_id")  # 단위사업 ID
    )
    not_prj_type: Mapped[str] = mapped_column(
        String(20), default="정책사업"
    )  # 비사업구분
    prj_type_nm: Mapped[str] = mapped_column(
        String(10), nullable=True
    )  # 사업형태구분명
    gender_yn: Mapped[str] = mapped_column(String(1), default="N")  # 성인지대상여부
    cont_exp_yn: Mapped[str] = mapped_column(String(1), default="N")  # 계속비대상여부
    self_sub_type: Mapped[str] = mapped_column(
        String(10), default="자체"
    )  # 자체보조구분
    dir_sup_type: Mapped[str] = mapped_column(String(10), nullable=True)  # 직접보조구분
    nat_dir_prj: Mapped[str] = mapped_column(String(1), default="N")  # 국가직접사업여부
    citizen_budget_yn: Mapped[str] = mapped_column(
        String(1), default="N"
    )  # 주민참여예산여부
    loc_sub_exc: Mapped[str] = mapped_column(
        String(1), default="N"
    )  # 지방보조금 한도액 제외사업
    job_prj_yn: Mapped[str] = mapped_column(String(1), default="N")  # 일자리사업여부
    job_prj_type: Mapped[str] = mapped_column(
        String(20), nullable=True
    )  # 일자리사업유형
    job_target_cnt: Mapped[int] = mapped_column(
        Integer, default=0
    )  # 일자리사업목표인원
    event_prj_yn: Mapped[str] = mapped_column(String(1), default="N")  # 행사성사업여부
    loc_trans_prj: Mapped[str] = mapped_column(String(1), default="N")  # 지방전환사업
    loc_trans_step: Mapped[str] = mapped_column(
        String(20), nullable=True
    )  # 지방전환단계
    promote_yn: Mapped[str] = mapped_column(String(1), default="Y")  # 추진여부
    disaster_law_cl: Mapped[str] = mapped_column(
        String(20), nullable=True
    )  # 재난안전법적분류
    disaster_field: Mapped[str] = mapped_column(
        String(20), nullable=True
    )  # 재난안전분야
    disaster_type: Mapped[str] = mapped_column(
        String(20), nullable=True
    )  # 재난안전유형
    disaster_man_step: Mapped[str] = mapped_column(
        String(20), nullable=True
    )  # 재난안전관리단계

    __table_args__ = (
        Index("IDX_BUDGET_OUT_PROJECT_DETAIL_UNIT_PRJ_ID", "unit_prj_id"),
        Index("IDX_BUDGET_OUT_PROJECT_DETAIL_PRJ_NM", "dtl_prj_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutProjectDetail(dtl_prj_id={self.dtl_prj_id}, dtl_prj_cd={self.dtl_prj_cd}, "
            f"hist_seq={self.hist_seq}, dtl_prj_nm={self.dtl_prj_nm}, dtl_order={self.dtl_order}, "
            f"unit_prj_id={self.unit_prj_id})>"
        )


class BudgetOutAccountSubject(Base):
    """예산과목"""

    __tablename__ = "TB_BUDGET_OUT_ACCOUNT_SUBJECT"

    acc_sub_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 예산과목 ID
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도
    stat_mok_cd: Mapped[str] = mapped_column(String(10))  # 통계목코드
    stat_mok_nm: Mapped[str] = mapped_column(String(30))  # 통계목명
    budg_mok_cd: Mapped[str] = mapped_column(String(10))  # 예산목코드
    budg_mok_nm: Mapped[str] = mapped_column(String(30))  # 예산목명

    __table_args__ = (
        Index("IDX_BUDGET_OUT_ACCOUNT_SUBJECT_FY", "fiscal_year"),
        Index("IDX_BUDGET_OUT_ACCOUNT_SUBJECT_STAT_MOK_CD", "stat_mok_cd"),
        Index("IDX_BUDGET_OUT_ACCOUNT_SUBJECT_BUDG_MOK_CD", "budg_mok_cd"),
        Index("IDX_BUDGET_OUT_ACCOUNT_SUBJECT_STAT_MOK_NM", "stat_mok_nm"),
        Index("IDX_BUDGET_OUT_ACCOUNT_SUBJECT_BUDG_MOK_NM", "budg_mok_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutAccountSubject(acc_sub_id={self.acc_sub_id}, fiscal_year={self.fiscal_year}, "
            f"stat_mok_cd={self.stat_mok_cd}, stat_mok_nm={self.stat_mok_nm}, "
            f"budg_mok_cd={self.budg_mok_cd}, budg_mok_nm={self.budg_mok_nm})>"
        )


class BudgetOutFact(Base):
    """상세 세출 예산 편성"""

    __tablename__ = "TB_BUDGET_OUT_FACT"

    budget_fact_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 예산 편성 ID
    la_cd: Mapped[str] = mapped_column(
        ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd")  # 지방자치단체 코드
    )
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도
    budget_seq: Mapped[int] = mapped_column(Integer)  # 예산 순번
    dept_cd: Mapped[str] = mapped_column(String(20))  # 부서 코드
    fund_cd: Mapped[str] = mapped_column(
        String(10),
        ForeignKey("TB_BUDGET_OUT_FUND_ACCOUNT.fund_cd"),  # 회계 코드
    )
    policy_proj_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("TB_BUDGET_OUT_PROJECT_POLICY.policy_proj_id"),  # 정책사업 ID
    )
    unit_prj_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("TB_BUDGET_OUT_PROJECT_UNIT.unit_prj_id"),  # 단위사업 ID
    )
    dtl_prj_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("TB_BUDGET_OUT_PROJECT_DETAIL.dtl_prj_id"),  # 세부사업 ID
    )
    acc_sub_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("TB_BUDGET_OUT_ACCOUNT_SUBJECT.acc_sub_id"),  # 예산과목 ID
    )
    adj_level: Mapped[int] = mapped_column(Integer)  # 조정레벨
    adj_basis_org: Mapped[str] = mapped_column(String(100))  # 조정산출근거(원본)
    adj_basis_full: Mapped[str] = mapped_column(String(500))  # 조정산출근거(full)
    adj_formula: Mapped[str] = mapped_column(String(100), nullable=True)  # 조정산출식
    rev_adj_amt: Mapped[int] = mapped_column(BigInteger)  # 경정조정액
    adj_amt_diff: Mapped[int] = mapped_column(BigInteger)  # 조정액증감
    adj_obj_type: Mapped[str] = mapped_column(
        String(10), nullable=True
    )  # 조정의무재량구분

    __table_args__ = (
        Index("IDX_BUDGET_OUT_FACT_FY_DEPT_FUND", "fiscal_year", "dept_cd", "fund_cd"),
        Index("IDX_BUDGET_OUT_FACT_LA_CD_FY", "la_cd", "fiscal_year"),
        Index("IDX_BUDGET_OUT_FACT_POLICY_PROJ_ID", "policy_proj_id"),
        Index("IDX_BUDGET_OUT_FACT_UNIT_PRJ_ID", "unit_prj_id"),
        Index("IDX_BUDGET_OUT_FACT_DTL_PRJ_ID", "dtl_prj_id"),
        Index("IDX_BUDGET_OUT_FACT_ACC_SUB_ID", "acc_sub_id"),
        Index("IDX_BUDGET_OUT_FACT_ADJ_BASIS_FULL", "adj_basis_full"),
        Index("IDX_BUDGET_OUT_FACT_ADJ_FORMULA", "adj_formula"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutFact(budget_fact_id={self.budget_fact_id}, dtl_prj_id={self.dtl_prj_id}, "
            f"acc_sub_id={self.acc_sub_id}, la_cd={self.la_cd}, fiscal_year={self.fiscal_year}, "
            f"budget_seq={self.budget_seq}, dept_cd={self.dept_cd}, fund_cd={self.fund_cd}, "
            f"policy_proj_id={self.policy_proj_id}, unit_prj_id={self.unit_prj_id}, dtl_prj_id={self.dtl_prj_id}, "
            f"adj_level={self.adj_level}, adj_basis_org={self.adj_basis_org}, adj_basis_full={self.adj_basis_full}, adj_formula={self.adj_formula})>"
        )


class BudgetOutAdjSubject(Base):
    """세출예산서 조정증감 과목"""

    __tablename__ = "TB_BUDGET_OUT_ADJ_SUBJECT"

    adj_sub_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 조정증감 과목 ID
    adj_sub_nm: Mapped[str] = mapped_column(String(30))  # 조정증감 과목명

    __table_args__ = (Index("IDX_BUDGET_OUT_ADJ_SUBJECT_NM", "adj_sub_nm"),)

    def __repr__(self):
        return (
            f"<BudgetOutAdjSubject(adj_sub_id={self.adj_sub_id}, "
            f"adj_sub_nm={self.adj_sub_nm})>"
        )


class BudgetOutAdjSubjectDetail(Base):
    """세출예산서 조정증감 상세 내역"""

    __tablename__ = "TB_BUDGET_OUT_ADJ_SUBJECT_DETAIL"

    budget_fact_id: Mapped[int] = mapped_column(
        ForeignKey("TB_BUDGET_OUT_FACT.budget_fact_id"), primary_key=True
    )  # 예산 편성 ID
    adj_sub_id: Mapped[int] = mapped_column(
        ForeignKey("TB_BUDGET_OUT_ADJ_SUBJECT.adj_sub_id"), primary_key=True
    )  # 조정증감 과목 ID
    adj_sub_amt: Mapped[int] = mapped_column(BigInteger)  # 조정액증감

    __table_args__ = (
        Index("IDX_BUDGET_OUT_ADJ_SUBJECT_DETAIL_BUDGET_FACT_ID", "budget_fact_id"),
    )

    def __repr__(self):
        return (
            f"<BudgetOutAdjSubjectDetail(adj_sub_id={self.adj_sub_id}, budget_fact_id={self.budget_fact_id}, "
            f"adj_sub_amt={self.adj_sub_amt})>"
        )
