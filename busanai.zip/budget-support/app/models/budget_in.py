from sqlalchemy import (
    BigInteger,
    ForeignKey,
    Index,
    Integer,
    String,
)
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class BudgetInVersion(Base):
    """세입 상세 버전"""

    __tablename__ = "TB_BUDGET_IN_VERSION"

    la_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd"), primary_key=True
    )  # 지방자치단체 코드
    fiscal_year: Mapped[int] = mapped_column(Integer, primary_key=True)  # 회계연도
    budget_confirm_date: Mapped[str] = mapped_column(
        String(10), primary_key=True
    )  # 예산 확정일
    budget_type: Mapped[str] = mapped_column(
        String(20)
    )  # 예산 유형 (예: 본예산, 수정예산)

    def __repr__(self):
        return (
            f"<BudgetInVersion(la_cd={self.la_cd}, fiscal_year={self.fiscal_year}, "
            f"budget_confirm_date={self.budget_confirm_date}, budget_type={self.budget_type})>"
        )


class BudgetInOrganization(Base):
    """세입 상세 조직"""

    __tablename__ = "TB_BUDGET_IN_ORGANIZATION"

    la_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd"), primary_key=True
    )  # 지방자치단체 코드
    fiscal_year: Mapped[int] = mapped_column(Integer, primary_key=True)  # 회계연도
    dept_cd: Mapped[str] = mapped_column(String(20), primary_key=True)  # 부서 코드
    dept_nm: Mapped[str] = mapped_column(String(30))  # 부서명

    __table_args__ = (
        Index("IDX_BUDGET_IN_ORGANIZATION_FY", "fiscal_year"),
        Index("IDX_BUDGET_IN_ORGANIZATION_DEPT_NM", "dept_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetInOrganization(la_cd={self.la_cd}, fiscal_year={self.fiscal_year}, "
            f"dept_cd={self.dept_cd}, dept_nm={self.dept_nm})>"
        )


class BudgetInFundAccount(Base):
    """세입 상세 회계코드"""

    __tablename__ = "TB_BUDGET_IN_FUND_ACCOUNT"

    fund_cd: Mapped[str] = mapped_column(String(10), primary_key=True)  # 회계코드
    fund_nm: Mapped[str] = mapped_column(String(30))  # 회계명

    __table_args__ = (Index("IDX_BUDGET_IN_FUND_ACCOUNT_FUND_NM", "fund_nm"),)

    def __repr__(self):
        return f"<BudgetInFundAccount(fund_cd={self.fund_cd}, fund_nm={self.fund_nm})>"


class BudgetInAccountSubject(Base):
    """세입 상세 계정과목"""

    __tablename__ = "TB_BUDGET_IN_ACCOUNT_SUBJECT"

    acc_sub_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 계정과목 ID
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도
    mok_cd: Mapped[str] = mapped_column(String(10))  # 목 코드
    mok_nm: Mapped[str] = mapped_column(String(30))  # 목 명
    jang_cd: Mapped[str] = mapped_column(String(10))  # 장 코드
    jang_nm: Mapped[str] = mapped_column(String(30))  # 장 명
    gwan_cd: Mapped[str] = mapped_column(String(10))  # 관 코드
    gwan_nm: Mapped[str] = mapped_column(String(30))  # 관 명
    hang_cd: Mapped[str] = mapped_column(String(10))  # 항 코드
    hang_nm: Mapped[str] = mapped_column(String(30))  # 항 명

    __table_args__ = (
        Index("IDX_BUDGET_IN_ACCOUNT_SUBJECT_FY", "fiscal_year"),
        Index("IDX_BUDGET_IN_ACCOUNT_SUBJECT_JANG_NM", "jang_nm"),
        Index("IDX_BUDGET_IN_ACCOUNT_SUBJECT_GWAN_NM", "gwan_nm"),
        Index("IDX_BUDGET_IN_ACCOUNT_SUBJECT_HANG_NM", "hang_nm"),
        Index("IDX_BUDGET_IN_ACCOUNT_SUBJECT_MOK_NM", "mok_nm"),
    )

    def __repr__(self):
        return (
            f"<BudgetInAccountSubject(acc_sub_id={self.acc_sub_id}, fiscal_year={self.fiscal_year}, "
            f"mok_cd={self.mok_cd}, mok_nm={self.mok_nm}, jang_cd={self.jang_cd}, jang_nm={self.jang_nm}, "
            f"gwan_cd={self.gwan_cd}, gwan_nm={self.gwan_nm}, hang_cd={self.hang_cd}, hang_nm={self.hang_nm})>"
        )


class BudgetInFact(Base):
    """세입 상세 편성"""

    __tablename__ = "TB_BUDGET_IN_FACT"

    fact_id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True
    )  # 편성 ID
    la_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_LOCAL_GOVERNMENT.la_cd")
    )  # 지방자치단체 코드
    fiscal_year: Mapped[int] = mapped_column(Integer)  # 회계연도
    budget_confirm_date: Mapped[str] = mapped_column(String(10))  # 예산 확정일
    dept_cd: Mapped[str] = mapped_column(String(20))  # 부서 코드
    fund_cd: Mapped[str] = mapped_column(
        String(10), ForeignKey("TB_BUDGET_IN_FUND_ACCOUNT.fund_cd")
    )  # 회계코드
    acc_sub_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("TB_BUDGET_IN_ACCOUNT_SUBJECT.acc_sub_id")
    )  # 계정과목 ID
    adj_basis_org: Mapped[str] = mapped_column(String(100))  # 조정산출근거(원본)
    adj_basis_full: Mapped[str] = mapped_column(String(500))  # 조정산출근거(full)
    adj_formula: Mapped[str] = mapped_column(String(100), nullable=True)  # 조정산출식
    level_amt: Mapped[int] = mapped_column(BigInteger)  # 레벨금액
    budget_amt: Mapped[int] = mapped_column(BigInteger)  # 예산금액
    prev_amt: Mapped[int] = mapped_column(BigInteger)  # 기정액
    diff_amt: Mapped[int] = mapped_column(BigInteger)  # 증감액

    __table_args__ = (
        Index("IDX_BUDGET_IN_FACT_FY_DEPT_FUND", "fiscal_year", "dept_cd", "fund_cd"),
        Index("IDX_BUDGET_IN_FACT_ACC_SUB", "acc_sub_id"),
        Index("IDX_BUDGET_IN_FACT_ADJ_BASIS_FULL", "adj_basis_full"),
        Index("IDX_BUDGET_IN_FACT_ADJ_FORMULA", "adj_formula"),
    )

    def __repr__(self):
        return (
            f"<BudgetInFact(fact_id={self.fact_id}, la_cd={self.la_cd}, fiscal_year={self.fiscal_year}, "
            f"budget_confirm_date={self.budget_confirm_date}, dept_cd={self.dept_cd}, fund_cd={self.fund_cd}, "
            f"acc_sub_id={self.acc_sub_id}, adj_basis_org={self.adj_basis_org}, adj_basis_full={self.adj_basis_full}, adj_formula={self.adj_formula}, "
            f"level_amt={self.level_amt}, budget_amt={self.budget_amt}, prev_amt={self.prev_amt}, "
            f"diff_amt={self.diff_amt})>"
        )
