from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


def to_camel(string: str) -> str:
    parts = string.split("_")
    return parts[0] + "".join(word.capitalize() for word in parts[1:])


class BudgetOutImportRequest(BaseModel):
    la_cd: str | None = Field(default=None, description="지자체 코드")
    w_city_nm: str | None = Field(default=None, description="광역시도명")
    la_nm: str | None = Field(default=None, description="지자체명")
    fiscal_year: int = Field(description="회계연도")

    @model_validator(mode="after")
    def validate_local_government_fields(self):
        if not self.la_cd or not self.la_nm or not self.w_city_nm:
            raise ValueError("la_cd, w_city_nm, la_nm 중 하나라도 누락되면 안 됩니다.")
        return self

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetOutImportResponse(BaseModel):
    la_cd: str = Field(description="적재된 지자체 코드")
    la_nm: str = Field(description="적재된 지자체명")
    fiscal_year: int = Field(description="회계연도")
    budget_versions: list["BudgetOutImportVersionResponse"] = Field(
        default_factory=list,
        description="파일에 포함된 예산구분별 예산차수와 행 수",
    )
    source_filename: str = Field(description="업로드 파일명")
    rows_processed: int = Field(description="처리한 원본 행 수")
    inserted_counts: dict[str, int] = Field(description="테이블별 반영 건수")
    warnings: list[str] = Field(default_factory=list, description="경고 목록")

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class ErrorResponse(BaseModel):
    detail: str
    errors: list[str] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetOutImportVersionResponse(BaseModel):
    budget_type: str = Field(description="예산 구분")
    budget_seq: int = Field(description="예산 차수")
    row_count: int = Field(description="해당 예산구분으로 처리한 행 수")

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetInImportRequest(BaseModel):
    la_cd: str | None = Field(default=None, description="지자체 코드")
    w_city_nm: str | None = Field(default=None, description="광역시도명")
    la_nm: str | None = Field(default=None, description="지자체명")
    fiscal_year: int = Field(description="회계연도")

    @model_validator(mode="after")
    def validate_local_government_fields(self):
        if not self.la_cd or not self.la_nm or not self.w_city_nm:
            raise ValueError("la_cd, w_city_nm, la_nm 중 하나라도 누락되면 안 됩니다.")
        return self

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetInImportResponse(BaseModel):
    la_cd: str = Field(description="적재된 지자체 코드")
    la_nm: str = Field(description="적재된 지자체명")
    fiscal_year: int = Field(description="회계연도")
    budget_versions: list["BudgetInImportVersionResponse"] = Field(
        default_factory=list,
        description="파일에 포함된 예산구분별 확정일자와 행 수",
    )
    source_filename: str = Field(description="업로드 파일명")
    rows_processed: int = Field(description="처리한 원본 행 수")
    inserted_counts: dict[str, int] = Field(description="테이블별 반영 건수")
    warnings: list[str] = Field(default_factory=list, description="경고 목록")

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetInImportVersionResponse(BaseModel):
    budget_type: str = Field(description="예산 구분")
    budget_confirm_date: str = Field(description="예산 확정일")
    row_count: int = Field(description="해당 예산구분으로 처리한 행 수")

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetOutImportLv1Response(BaseModel):
    la_cd: str = Field(description="적재된 지자체 코드")
    la_nm: str = Field(description="적재된 지자체명")
    fiscal_year: int = Field(description="회계연도")
    budget_versions: list["BudgetOutImportLv1VersionResponse"] = Field(
        default_factory=list,
        description="파일에 포함된 예산구분별 행 수",
    )
    source_filename: str = Field(description="업로드 파일명")
    rows_processed: int = Field(description="처리한 원본 행 수")
    inserted_counts: dict[str, int] = Field(description="테이블별 반영 건수")
    warnings: list[str] = Field(default_factory=list, description="경고 목록")

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetOutImportLv1VersionResponse(BaseModel):
    budget_type: str = Field(description="예산 구분")
    row_count: int = Field(description="해당 예산구분으로 처리한 행 수")

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetOutLv1ImportRequest(BaseModel):
    fiscal_year: int = Field(description="회계연도")

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetImportAsyncAcceptedResponse(BaseModel):
    job_id: str = Field(description="비동기 임포트 작업 ID")
    status: str = Field(description="작업 상태")

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetImportJobStatusResponse(BaseModel):
    job_id: str
    import_type: str
    status: str
    stage: str | None = None
    progress_pct: int = 0
    rows_total: int | None = None
    rows_processed: int = 0
    request_fiscal_year: int
    request_la_cd: str | None = None
    source_filename: str
    inserted_counts: dict[str, int] | None = None
    budget_versions: list[dict[str, Any]] | None = None
    warnings: list[str] | None = None
    error_summary: str | None = None
    created_at: datetime
    updated_at: datetime
    started_at: datetime | None = None
    finished_at: datetime | None = None

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class BudgetImportJobListResponse(BaseModel):
    items: list[BudgetImportJobStatusResponse]
    total: int
    page: int
    size: int
    total_pages: int

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )
