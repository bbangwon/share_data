/**
 * 검색 및 모달 제어를 위한 헬퍼
 */
const SearchHelper = {
  /**
   * 회계연도 목록 로드
   */
  async fetchFiscalYears(selectId, budgetType) {
    try {
      const response = await fetch(`/api/v1/budget-${budgetType}/years`);
      const years = await response.json();
      const select = document.getElementById(selectId);

      select.innerHTML = '<option value="">선택</option>';
      years.forEach((year) => {
        const option = document.createElement("option");
        option.value = year;
        option.textContent = year;
        select.appendChild(option);
      });

      if (years.length > 0) {
        select.value = years[0];
      }
    } catch (error) {
      console.error("회계연도 목록 로드 실패:", error);
    }
  },

  /**
   * 검색 모달 관련
   */
  modal: {
    open(modalId, inputId, listId) {
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.style.display = "flex";
        document.getElementById(inputId).value = "";
        document.getElementById(listId).innerHTML = "";
        document.getElementById(inputId).focus();
      }
    },

    close(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) modal.style.display = "none";
    },

    async searchSubject(config) {
      // config: { queryId, budgetTypeSelector, listId, onSelect, fiscalYear }
      const q = document.getElementById(config.queryId).value.trim();
      if (!q) {
        alert("검색어를 입력하세요.");
        return;
      }

      const budgetType = document.querySelector(
        config.budgetTypeSelector,
      ).value;
      try {
        let url = `/api/v1/budget-${budgetType}/account-subjects/search?q=${encodeURIComponent(q)}`;
        if (config.fiscalYear) {
          url += `&fiscal_year=${config.fiscalYear}`;
        }
        const response = await fetch(url);
        const data = await response.json();

        const list = document.getElementById(config.listId);
        list.innerHTML = "";

        if (data.length === 0) {
          list.innerHTML =
            '<tr><td colspan="3">검색 결과가 없습니다.</td></tr>';
          return;
        }

        data.forEach((item) => {
          const tr = document.createElement("tr");
          const safeSelectNm = (item.mok_or_stat_mok_nm || "").replace(
            /'/g,
            "\\'",
          );
          const safeCode = (item.code || "").replace(/'/g, "\\'");
          const safeId = (item.id || "").toString().replace(/'/g, "\\'");

          let displayName = `${item.hang_or_budg_mok_nm} - ${item.mok_or_stat_mok_nm}`;
          if (budgetType == "in") {
            // 세입예산서는 장-관-항-목 구조이므로 장과 관을 포함해서 표시
            displayName = `${item.jang_nm} - ${item.gwan_nm} - ` + displayName;
          }

          console.log("budgetType:", budgetType, "displayName:", displayName);

          if (budgetType === "out-lv1") {
            tr.innerHTML = `
              <td class="text-left">${displayName}</td>
              <td><button class="btn-select" onclick="${config.onSelect}('${safeId}', '${safeCode}', '${safeSelectNm}')">선택</button></td>
              `;
          } else {
            tr.innerHTML = `
              <td>${item.code}</td>
              <td class="text-left">${displayName}</td>
              <td><button class="btn-select" onclick="${config.onSelect}('${safeId}', '${safeCode}', '${safeSelectNm}')">선택</button></td>
              `;
          }
          list.appendChild(tr);
        });
      } catch (error) {
        console.error("과목 검색 실패:", error);
      }
    },
  },
};
