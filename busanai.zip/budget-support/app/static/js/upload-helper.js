/**
 * 지자체 선택 및 업로드 처리를 위한 헬퍼
 */
class UploadHelper {
  constructor(localGovernments, config) {
    this.localGovernments = localGovernments;
    this.config = config; // { formId, citySelectId, govtSelectId, laCdId, wCityNmId, laNmId, laCdPreviewId, resultId, importUrl }
    this.init();
  }

  init() {
    this.form = document.getElementById(this.config.formId);
    this.citySelect = document.getElementById(this.config.citySelectId);
    this.governmentSelect = document.getElementById(this.config.govtSelectId);
    this.laCdInput = document.getElementById(this.config.laCdId);
    this.wCityNmInput = document.getElementById(this.config.wCityNmId);
    this.laNmInput = document.getElementById(this.config.laNmId);
    this.laCdPreview = document.getElementById(this.config.laCdPreviewId);
    this.result = document.getElementById(this.config.resultId);
    this.submitButton = this.form?.querySelector('button[type="submit"]');

    this.setupCities();
    this.bindEvents();
  }

  setSubmitting(isSubmitting) {
    if (!this.submitButton) {
      return;
    }
    this.submitButton.disabled = isSubmitting;
    this.submitButton.textContent = isSubmitting
      ? "업로드 접수 중..."
      : "업로드 실행";
  }

  setupCities() {
    const cities = [
      ...new Set(this.localGovernments.map((item) => item.w_city_nm)),
    ];
    cities.forEach((cityName) => {
      const option = document.createElement("option");
      option.value = cityName;
      option.textContent = cityName;
      this.citySelect.appendChild(option);
    });
  }

  renderGovernmentOptions(cityName) {
    const governments = this.localGovernments.filter(
      (item) => item.w_city_nm === cityName,
    );

    this.governmentSelect.innerHTML = governments.length
      ? '<option value="">지자체를 선택하세요</option>'
      : '<option value="">먼저 광역시도를 선택하세요</option>';

    governments.forEach((item) => {
      const option = document.createElement("option");
      option.value = item.la_cd;
      option.textContent = `${item.la_nm} (${item.la_cd})`;
      this.governmentSelect.appendChild(option);
    });

    this.governmentSelect.disabled = governments.length === 0;
    this.resetSelection(cityName);
  }

  resetSelection(cityName) {
    this.governmentSelect.value = "";
    this.laCdInput.value = "";
    this.wCityNmInput.value = cityName || "";
    this.laNmInput.value = "";
    this.laCdPreview.value = "";
  }

  bindEvents() {
    this.citySelect.addEventListener("change", (e) => {
      this.renderGovernmentOptions(e.target.value);
    });

    this.governmentSelect.addEventListener("change", (e) => {
      const selected = this.localGovernments.find(
        (item) => item.la_cd === e.target.value,
      );
      this.laCdInput.value = selected?.la_cd || "";
      this.wCityNmInput.value =
        selected?.w_city_nm || this.citySelect.value || "";
      this.laNmInput.value = selected?.la_nm || "";
      this.laCdPreview.value = selected?.la_cd || "";
    });

    this.form.addEventListener("submit", (e) => this.handleSubmit(e));
  }

  async handleSubmit(event) {
    event.preventDefault();

    if (
      !this.laCdInput.value ||
      !this.wCityNmInput.value ||
      !this.laNmInput.value
    ) {
      this.showResult("광역시도와 지자체를 먼저 선택해 주세요.", true);
      return;
    }

    const formData = new FormData(this.form);
    this.setSubmitting(true);
    this.showResult("업로드 요청을 전송 중입니다...", false);

    try {
      const response = await fetch(this.config.importUrl, {
        method: "POST",
        body: formData,
      });
      const payload = await this.parsePayload(response);
      if (!response.ok) {
        this.showResult(this.formatError(payload), true);
        return;
      }

      if (this.config.asyncAccepted) {
        const jobId = payload?.jobId || payload?.job_id || "-";
        const status = payload?.status || "-";
        const fiscalYear = formData.get("fiscal_year") || "-";
        this.showResult(
          [
            "업로드 작업이 비동기로 접수되었습니다.",
            `- Job ID: ${jobId}`,
            `- 상태: ${status}`,
            `- 회계연도: ${fiscalYear}`,
            "",
            `진행 상황 확인: ${this.config.statusPageUrl || "-"}`,
          ].join("\n"),
          false,
        );
        return;
      }

      this.showResult(JSON.stringify(payload, null, 2), false);
    } catch (error) {
      this.showResult(
        error instanceof Error ? error.message : String(error),
        true,
      );
    } finally {
      this.setSubmitting(false);
    }
  }

  async parsePayload(response) {
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      return response.json();
    }

    return { detail: await response.text() };
  }

  formatError(payload) {
    if (!payload) {
      return "업로드 중 알 수 없는 오류가 발생했습니다.";
    }

    const detail = payload.detail;
    if (typeof detail === "string" && detail.trim()) {
      return detail;
    }

    if (detail && typeof detail === "object") {
      const message = detail.message || "업로드에 실패했습니다.";
      const errors = Array.isArray(detail.errors) ? detail.errors : [];
      if (errors.length > 0) {
        return `${message}\n${errors.map((item) => `- ${item}`).join("\n")}`;
      }
      return message;
    }

    if (
      typeof payload.errorSummary === "string" &&
      payload.errorSummary.trim()
    ) {
      return payload.errorSummary;
    }

    return "업로드 중 오류가 발생했습니다.";
  }

  showResult(message, isError) {
    this.result.textContent = message;
    this.result.classList.toggle("error", isError);
  }
}
