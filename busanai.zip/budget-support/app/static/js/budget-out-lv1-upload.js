/**
 * 세출(Lv1) 비동기 업로드 접수 전용 헬퍼
 */
class BudgetOutLv1UploadHelper {
  constructor(config) {
    this.config = config;
    this.init();
  }

  init() {
    this.form = document.getElementById(this.config.formId);
    this.result = document.getElementById(this.config.resultId);
    this.submitButton = this.form?.querySelector('button[type="submit"]');

    if (!this.form || !this.result || !this.submitButton) {
      return;
    }

    this.form.addEventListener("submit", (event) => this.handleSubmit(event));
  }

  setSubmitting(isSubmitting) {
    this.submitButton.disabled = isSubmitting;
    this.submitButton.textContent = isSubmitting
      ? "업로드 접수 중..."
      : "업로드 실행";
  }

  async handleSubmit(event) {
    event.preventDefault();

    const formData = new FormData(this.form);
    this.setSubmitting(true);
    this.showResult("업로드 접수 요청을 전송 중입니다...", false);

    try {
      const response = await fetch(this.config.importUrl, {
        method: "POST",
        body: formData,
      });

      const payload = await this.parsePayload(response);
      if (!response.ok) {
        this.showResult(this.formatError(payload), true);
        return;
      }

      const jobId = payload?.jobId || payload?.job_id || "-";
      const status = payload?.status || "-";
      const fiscalYear = formData.get("fiscal_year") || "-";

      this.showResult(
        [
          "업로드 작업이 비동기로 접수되었습니다.",
          `- Job ID: ${jobId}`,
          `- 상태: ${status}`,
          `- 회계연도: ${fiscalYear}`,
          "",
          `진행 상황 확인: ${this.config.statusPageUrl}`,
        ].join("\n"),
        false,
      );
    } catch (error) {
      this.showResult(
        error instanceof Error ? error.message : String(error),
        true,
      );
    } finally {
      this.setSubmitting(false);
    }
  }

  async parsePayload(response) {
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      return response.json();
    }

    return { detail: await response.text() };
  }

  formatError(payload) {
    if (!payload) {
      return "업로드 접수 중 알 수 없는 오류가 발생했습니다.";
    }

    const detail = payload.detail;
    if (typeof detail === "string" && detail.trim()) {
      return detail;
    }

    if (detail && typeof detail === "object") {
      const message = detail.message || "업로드 접수에 실패했습니다.";
      const errors = Array.isArray(detail.errors) ? detail.errors : [];
      if (errors.length > 0) {
        return `${message}\n${errors.map((item) => `- ${item}`).join("\n")}`;
      }
      return message;
    }

    if (
      typeof payload.errorSummary === "string" &&
      payload.errorSummary.trim()
    ) {
      return payload.errorSummary;
    }

    return "업로드 접수 중 오류가 발생했습니다.";
  }

  showResult(message, isError) {
    this.result.textContent = message;
    this.result.classList.toggle("error", isError);
  }
}
