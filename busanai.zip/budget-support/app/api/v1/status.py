import math
from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import get_session
from app.models import (
    BudgetInFact,
    BudgetInOrganization,
    BudgetInVersion,
    BudgetLocalGovernment,
    BudgetOutFact,
    BudgetOutFactLv1,
    BudgetOutOrganization,
    BudgetOutProjectDetail,
    BudgetOutProjectDetailLv1,
    BudgetOutProjectPolicy,
    BudgetOutProjectPolicyLv1,
    BudgetOutProjectUnit,
    BudgetOutProjectUnitLv1,
    BudgetOutVersion,
)

router = APIRouter(prefix="/api/v1/status", tags=["status"])


class StatusResponse(BaseModel):
    w_city_nm: str
    la_nm: str
    la_cd: str
    fiscal_year: int
    record_count: int


class PaginatedStatusResponse(BaseModel):
    items: list[StatusResponse]
    total: int
    page: int
    size: int
    total_pages: int


@router.get("/budget-out", response_model=PaginatedStatusResponse)
async def get_budget_out_status(
    session: Annotated[AsyncSession, Depends(get_session)],
    page: int = 1,
    size: int = 10,
    w_city_nm: str | None = None,
    la_nm: str | None = None,
    fiscal_year: int | None = None,
):
    stmt = (
        select(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetLocalGovernment.la_cd,
            BudgetOutFact.fiscal_year,
            func.count(BudgetOutFact.budget_fact_id).label("record_count"),
        )
        .join(BudgetOutFact, BudgetLocalGovernment.la_cd == BudgetOutFact.la_cd)
        .group_by(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetLocalGovernment.la_cd,
            BudgetOutFact.fiscal_year,
        )
    )

    if w_city_nm:
        stmt = stmt.where(BudgetLocalGovernment.w_city_nm.contains(w_city_nm))
    if la_nm:
        stmt = stmt.where(BudgetLocalGovernment.la_nm.contains(la_nm))
    if fiscal_year:
        stmt = stmt.where(BudgetOutFact.fiscal_year == fiscal_year)

    # Count total
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = await session.scalar(count_stmt) or 0

    # Apply pagination
    stmt = (
        stmt.order_by(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetOutFact.fiscal_year,
        )
        .offset((page - 1) * size)
        .limit(size)
    )

    result = await session.execute(stmt)
    items = [
        StatusResponse(
            w_city_nm=row.w_city_nm,
            la_nm=row.la_nm,
            la_cd=row.la_cd,
            fiscal_year=row.fiscal_year,
            record_count=row.record_count,
        )
        for row in result.all()
    ]

    return PaginatedStatusResponse(
        items=items,
        total=total,
        page=page,
        size=size,
        total_pages=math.ceil(total / size) if total > 0 else 1,
    )


@router.get("/budget-out-lv1", response_model=PaginatedStatusResponse)
async def get_budget_out_lv1_status(
    session: Annotated[AsyncSession, Depends(get_session)],
    page: int = 1,
    size: int = 10,
    w_city_nm: str | None = None,
    la_nm: str | None = None,
    fiscal_year: int | None = None,
):
    stmt = (
        select(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetLocalGovernment.la_cd,
            BudgetOutFactLv1.fiscal_year,
            func.count(BudgetOutFactLv1.budget_fact_id).label("record_count"),
        )
        .join(BudgetOutFactLv1, BudgetLocalGovernment.la_cd == BudgetOutFactLv1.la_cd)
        .group_by(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetLocalGovernment.la_cd,
            BudgetOutFactLv1.fiscal_year,
        )
    )

    if w_city_nm:
        stmt = stmt.where(BudgetLocalGovernment.w_city_nm.contains(w_city_nm))
    if la_nm:
        stmt = stmt.where(BudgetLocalGovernment.la_nm.contains(la_nm))
    if fiscal_year:
        stmt = stmt.where(BudgetOutFactLv1.fiscal_year == fiscal_year)

    # Count total
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = await session.scalar(count_stmt) or 0

    # Apply pagination
    stmt = (
        stmt.order_by(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetOutFactLv1.fiscal_year,
        )
        .offset((page - 1) * size)
        .limit(size)
    )

    result = await session.execute(stmt)
    items = [
        StatusResponse(
            w_city_nm=row.w_city_nm,
            la_nm=row.la_nm,
            la_cd=row.la_cd,
            fiscal_year=row.fiscal_year,
            record_count=row.record_count,
        )
        for row in result.all()
    ]

    return PaginatedStatusResponse(
        items=items,
        total=total,
        page=page,
        size=size,
        total_pages=math.ceil(total / size) if total > 0 else 1,
    )


@router.delete("/budget-out/{la_cd}/{fiscal_year}")
async def delete_budget_out(
    la_cd: str, fiscal_year: int, session: Annotated[AsyncSession, Depends(get_session)]
):
    async with session.begin():
        await session.execute(
            delete(BudgetOutFact).where(
                BudgetOutFact.la_cd == la_cd, BudgetOutFact.fiscal_year == fiscal_year
            )
        )
        await session.execute(
            delete(BudgetOutProjectDetail).where(
                BudgetOutProjectDetail.la_cd == la_cd,
                BudgetOutProjectDetail.fiscal_year == fiscal_year,
            )
        )
        policy_subq = select(BudgetOutProjectPolicy.policy_proj_id).where(
            BudgetOutProjectPolicy.la_cd == la_cd,
            BudgetOutProjectPolicy.fiscal_year == fiscal_year,
        )
        await session.execute(
            delete(BudgetOutProjectUnit).where(
                BudgetOutProjectUnit.policy_proj_id.in_(policy_subq)
            )
        )
        await session.execute(
            delete(BudgetOutProjectPolicy).where(
                BudgetOutProjectPolicy.la_cd == la_cd,
                BudgetOutProjectPolicy.fiscal_year == fiscal_year,
            )
        )
        await session.execute(
            delete(BudgetOutVersion).where(
                BudgetOutVersion.la_cd == la_cd,
                BudgetOutVersion.fiscal_year == fiscal_year,
            )
        )
        await session.execute(
            delete(BudgetOutOrganization).where(
                BudgetOutOrganization.la_cd == la_cd,
                BudgetOutOrganization.fiscal_year == fiscal_year,
            )
        )
    return {"message": "deleted"}


@router.delete("/budget-out-lv1/{la_cd}/{fiscal_year}")
async def delete_budget_out_lv1(
    la_cd: str, fiscal_year: int, session: Annotated[AsyncSession, Depends(get_session)]
):
    async with session.begin():
        # Fact 삭제
        await session.execute(
            delete(BudgetOutFactLv1).where(
                BudgetOutFactLv1.la_cd == la_cd,
                BudgetOutFactLv1.fiscal_year == fiscal_year,
            )
        )
        # Detail 삭제
        await session.execute(
            delete(BudgetOutProjectDetailLv1).where(
                BudgetOutProjectDetailLv1.la_cd == la_cd,
                BudgetOutProjectDetailLv1.fiscal_year == fiscal_year,
            )
        )
        # Policy & Unit 삭제
        policy_subq = select(BudgetOutProjectPolicyLv1.policy_proj_id).where(
            BudgetOutProjectPolicyLv1.la_cd == la_cd,
            BudgetOutProjectPolicyLv1.fiscal_year == fiscal_year,
        )
        await session.execute(
            delete(BudgetOutProjectUnitLv1).where(
                BudgetOutProjectUnitLv1.policy_proj_id.in_(policy_subq)
            )
        )
        await session.execute(
            delete(BudgetOutProjectPolicyLv1).where(
                BudgetOutProjectPolicyLv1.la_cd == la_cd,
                BudgetOutProjectPolicyLv1.fiscal_year == fiscal_year,
            )
        )

    return {"message": "deleted"}


@router.get("/budget-in", response_model=PaginatedStatusResponse)
async def get_budget_in_status(
    session: Annotated[AsyncSession, Depends(get_session)],
    page: int = 1,
    size: int = 10,
    w_city_nm: str | None = None,
    la_nm: str | None = None,
    fiscal_year: int | None = None,
):
    stmt = (
        select(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetLocalGovernment.la_cd,
            BudgetInFact.fiscal_year,
            func.count(BudgetInFact.fact_id).label("record_count"),
        )
        .join(BudgetInFact, BudgetLocalGovernment.la_cd == BudgetInFact.la_cd)
        .group_by(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetLocalGovernment.la_cd,
            BudgetInFact.fiscal_year,
        )
    )

    if w_city_nm:
        stmt = stmt.where(BudgetLocalGovernment.w_city_nm.contains(w_city_nm))
    if la_nm:
        stmt = stmt.where(BudgetLocalGovernment.la_nm.contains(la_nm))
    if fiscal_year:
        stmt = stmt.where(BudgetInFact.fiscal_year == fiscal_year)

    # Count total
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = await session.scalar(count_stmt) or 0

    # Apply pagination
    stmt = (
        stmt.order_by(
            BudgetLocalGovernment.w_city_nm,
            BudgetLocalGovernment.la_nm,
            BudgetInFact.fiscal_year,
        )
        .offset((page - 1) * size)
        .limit(size)
    )

    result = await session.execute(stmt)
    items = [
        StatusResponse(
            w_city_nm=row.w_city_nm,
            la_nm=row.la_nm,
            la_cd=row.la_cd,
            fiscal_year=row.fiscal_year,
            record_count=row.record_count,
        )
        for row in result.all()
    ]

    return PaginatedStatusResponse(
        items=items,
        total=total,
        page=page,
        size=size,
        total_pages=math.ceil(total / size) if total > 0 else 1,
    )


@router.delete("/budget-in/{la_cd}/{fiscal_year}")
async def delete_budget_in(
    la_cd: str, fiscal_year: int, session: Annotated[AsyncSession, Depends(get_session)]
):
    async with session.begin():
        await session.execute(
            delete(BudgetInFact).where(
                BudgetInFact.la_cd == la_cd, BudgetInFact.fiscal_year == fiscal_year
            )
        )
        await session.execute(
            delete(BudgetInVersion).where(
                BudgetInVersion.la_cd == la_cd,
                BudgetInVersion.fiscal_year == fiscal_year,
            )
        )
        await session.execute(
            delete(BudgetInOrganization).where(
                BudgetInOrganization.la_cd == la_cd,
                BudgetInOrganization.fiscal_year == fiscal_year,
            )
        )
    return {"message": "deleted"}
