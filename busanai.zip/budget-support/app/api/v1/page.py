from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from app.core.templates import templates

router = APIRouter(prefix="/api/v1/page", tags=["page"])


@router.get("", response_class=HTMLResponse)
async def status_page_default(request: Request):
    return RedirectResponse(url="/api/v1/page/budget-out")


@router.get("/{status_type}", response_class=HTMLResponse)
async def status_page(request: Request, status_type: str):
    if status_type == "ai-search":
        return templates.TemplateResponse(request=request, name="ai_search.html")
    elif status_type == "other-city-search":
        return templates.TemplateResponse(
            request=request, name="other_city_search.html"
        )
    elif status_type == "import-jobs":
        return templates.TemplateResponse(request=request, name="import_jobs.html")

    return templates.TemplateResponse(
        request=request,
        name="status.html",
        context={
            "status_type": status_type,
        },
    )
