from typing import Annotated

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
    status,
)
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import get_session
from app.core.templates import templates
from app.models import BudgetOutAccountSubjectLv1, BudgetOutFactLv1
from app.schemas.imports import (
    BudgetImportAsyncAcceptedResponse,
    BudgetImportJobListResponse,
    BudgetImportJobStatusResponse,
)
from app.services import BudgetImportJobService

router = APIRouter(prefix="/api/v1/budget-out-lv1", tags=["budget-out-lv1-import"])

IMPORT_TYPE = "budget_out_lv1"


def get_import_job_service() -> BudgetImportJobService:
    return BudgetImportJobService()


@router.get("/upload", response_class=HTMLResponse)
async def upload_page(request: Request) -> Response:
    return templates.TemplateResponse(
        request=request,
        name="budget_out_lv1_upload.html",
        context={},
    )


@router.post(
    "/import-async",
    response_model=BudgetImportAsyncAcceptedResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def enqueue_budget_out_lv1_import_job(
    session: Annotated[AsyncSession, Depends(get_session)],
    import_job_service: Annotated[
        BudgetImportJobService, Depends(get_import_job_service)
    ],
    file: UploadFile = File(...),
    fiscal_year: int = Form(...),
):
    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="xlsx 파일만 업로드할 수 있습니다.",
        )

    try:
        job = await import_job_service.enqueue_from_upload(
            session=session,
            file=file,
            import_type=IMPORT_TYPE,
            request_payload={"fiscal_year": fiscal_year},
            request_fiscal_year=fiscal_year,
            request_la_cd=None,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc

    return BudgetImportAsyncAcceptedResponse(
        job_id=job.job_id,
        status=job.status,
    )


@router.get(
    "/import-jobs/{job_id}",
    response_model=BudgetImportJobStatusResponse,
)
async def get_budget_out_lv1_import_job_status(
    job_id: str,
    session: Annotated[AsyncSession, Depends(get_session)],
    import_job_service: Annotated[
        BudgetImportJobService, Depends(get_import_job_service)
    ],
):
    job_status = await import_job_service.get_status(session, job_id, import_type=IMPORT_TYPE)
    if job_status is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="작업을 찾을 수 없습니다.",
        )
    return job_status


@router.get(
    "/import-jobs",
    response_model=BudgetImportJobListResponse,
)
async def list_budget_out_lv1_import_jobs(
    session: Annotated[AsyncSession, Depends(get_session)],
    import_job_service: Annotated[
        BudgetImportJobService, Depends(get_import_job_service)
    ],
    page: int = 1,
    size: int = 20,
    job_status: str | None = Query(None),
    fiscal_year: int | None = Query(None),
    recent_days: int | None = Query(None),
):
    if page < 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="page는 1 이상이어야 합니다.",
        )
    if size < 1 or size > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="size는 1 이상 100 이하여야 합니다.",
        )
    if recent_days is not None and recent_days < 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="recent_days는 1 이상이어야 합니다.",
        )

    return await import_job_service.list_jobs(
        session=session,
        page=page,
        size=size,
        status=job_status,
        fiscal_year=fiscal_year,
        recent_days=recent_days,
        import_type=IMPORT_TYPE,
    )


class SubjectSearchResponse(BaseModel):
    id: int
    code: str
    hang_or_budg_mok_nm: str | None = None
    mok_or_stat_mok_nm: str | None = None


@router.get("/account-subjects/search", response_model=list[SubjectSearchResponse])
async def search_account_subjects(
    session: Annotated[AsyncSession, Depends(get_session)],
    q: str,
    fiscal_year: int | None = Query(None),
):
    from sqlalchemy import and_, or_
    
    where_conditions = [
        or_(
            BudgetOutAccountSubjectLv1.budg_mok_nm.contains(q),
            BudgetOutAccountSubjectLv1.stat_mok_nm.contains(q),
        ),
    ]
    
    if fiscal_year is not None:
        where_conditions.append(BudgetOutAccountSubjectLv1.fiscal_year == fiscal_year)

    stmt = (
        select(
            BudgetOutAccountSubjectLv1.acc_sub_id,
            BudgetOutAccountSubjectLv1.budg_mok_nm,
            BudgetOutAccountSubjectLv1.stat_mok_nm,
        )
        .distinct()
        .where(and_(*where_conditions))
        .order_by(
            BudgetOutAccountSubjectLv1.budg_mok_nm, BudgetOutAccountSubjectLv1.stat_mok_nm
        )
    )

    result = await session.execute(stmt)
    return [
        SubjectSearchResponse(
            id=row.acc_sub_id,
            code="",  # Lv1은 코드가 없음
            hang_or_budg_mok_nm=row.budg_mok_nm,
            mok_or_stat_mok_nm=row.stat_mok_nm,
        )
        for row in result.all()
    ]


@router.get("/years", response_model=list[int])
async def get_fiscal_years(
    session: Annotated[AsyncSession, Depends(get_session)],
):
    stmt = (
        select(BudgetOutFactLv1.fiscal_year)
        .distinct()
        .order_by(BudgetOutFactLv1.fiscal_year.desc())
    )
    result = await session.execute(stmt)
    return [row[0] for row in result.all()]
