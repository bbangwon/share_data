import json
from pathlib import Path
from typing import Annotated

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
    status,
)
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import get_session
from app.core.templates import templates
from app.models import (
    BudgetInAccountSubject,
    BudgetInFact,
)
from app.schemas.imports import BudgetInImportRequest, BudgetInImportResponse
from app.schemas.imports import (
    BudgetImportAsyncAcceptedResponse,
    BudgetImportJobListResponse,
    BudgetImportJobStatusResponse,
)
from app.services import (
    BudgetImportValidationError,
    BudgetImportJobService,
    BudgetInImportService,
)

router = APIRouter(prefix="/api/v1/budget-in", tags=["budget-in-import"])

IMPORT_TYPE = "budget_in"

LOCAL_GOVERNMENTS_PATH = (
    Path(__file__).resolve().parents[2] / "data" / "local_governments.json"
)


def load_local_governments() -> list[dict[str, str]]:
    with LOCAL_GOVERNMENTS_PATH.open(encoding="utf-8") as file:
        raw_data = json.load(file)

    return [
        {
            "la_cd": item["la_cd"],
            "w_city_nm": item["w_city_nm"],
            "la_nm": item["la_nm"],
        }
        for item in raw_data.values()
    ]


def get_import_service() -> BudgetInImportService:
    return BudgetInImportService()


def get_import_job_service() -> BudgetImportJobService:
    return BudgetImportJobService()


@router.get("/upload", response_class=HTMLResponse)
async def upload_page(request: Request) -> Response:
    local_governments = json.dumps(load_local_governments(), ensure_ascii=False)

    return templates.TemplateResponse(
        request=request,
        name="budget_in_upload.html",
        context={"local_governments": local_governments},
    )


@router.post(
    "/import-async",
    response_model=BudgetImportAsyncAcceptedResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={422: {"description": "Validation error"}},
)
async def enqueue_budget_in_import_job(
    session: Annotated[AsyncSession, Depends(get_session)],
    import_job_service: Annotated[
        BudgetImportJobService, Depends(get_import_job_service)
    ],
    file: UploadFile = File(...),
    la_cd: str | None = Form(default=None),
    w_city_nm: str | None = Form(default=None),
    la_nm: str | None = Form(default=None),
    fiscal_year: int = Form(...),
):
    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="xlsx 파일만 업로드할 수 있습니다.",
        )

    try:
        request = BudgetInImportRequest(
            la_cd=la_cd.strip() if la_cd else None,
            w_city_nm=w_city_nm.strip() if w_city_nm else None,
            la_nm=la_nm.strip() if la_nm else None,
            fiscal_year=fiscal_year,
        )
        job = await import_job_service.enqueue_from_upload(
            session=session,
            file=file,
            import_type=IMPORT_TYPE,
            request_payload=request.model_dump(mode="json"),
            request_fiscal_year=request.fiscal_year,
            request_la_cd=request.la_cd,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc

    return BudgetImportAsyncAcceptedResponse(
        job_id=job.job_id,
        status=job.status,
    )


@router.get(
    "/import-jobs/{job_id}",
    response_model=BudgetImportJobStatusResponse,
)
async def get_budget_in_import_job_status(
    job_id: str,
    session: Annotated[AsyncSession, Depends(get_session)],
    import_job_service: Annotated[
        BudgetImportJobService, Depends(get_import_job_service)
    ],
):
    job_status = await import_job_service.get_status(session, job_id, import_type=IMPORT_TYPE)
    if job_status is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="작업을 찾을 수 없습니다.",
        )
    return job_status


@router.get(
    "/import-jobs",
    response_model=BudgetImportJobListResponse,
)
async def list_budget_in_import_jobs(
    session: Annotated[AsyncSession, Depends(get_session)],
    import_job_service: Annotated[
        BudgetImportJobService, Depends(get_import_job_service)
    ],
    page: int = 1,
    size: int = 20,
    job_status: str | None = Query(None),
    fiscal_year: int | None = Query(None),
    recent_days: int | None = Query(None),
):
    if page < 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="page는 1 이상이어야 합니다.",
        )
    if size < 1 or size > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="size는 1 이상 100 이하여야 합니다.",
        )
    if recent_days is not None and recent_days < 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="recent_days는 1 이상이어야 합니다.",
        )

    return await import_job_service.list_jobs(
        session=session,
        page=page,
        size=size,
        status=job_status,
        fiscal_year=fiscal_year,
        recent_days=recent_days,
        import_type=IMPORT_TYPE,
    )


@router.post(
    "/import",
    response_model=BudgetInImportResponse,
    responses={422: {"description": "Validation error"}},
)
async def import_budget_in_excel(
    session: Annotated[AsyncSession, Depends(get_session)],
    import_service: Annotated[BudgetInImportService, Depends(get_import_service)],
    file: UploadFile = File(...),
    la_cd: str | None = Form(default=None),
    w_city_nm: str | None = Form(default=None),
    la_nm: str | None = Form(default=None),
    fiscal_year: int = Form(...),
):
    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="xlsx 파일만 업로드할 수 있습니다.",
        )

    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="빈 파일은 업로드할 수 없습니다.",
        )

    try:
        request = BudgetInImportRequest(
            la_cd=la_cd.strip() if la_cd else None,
            w_city_nm=w_city_nm.strip() if w_city_nm else None,
            la_nm=la_nm.strip() if la_nm else None,
            fiscal_year=fiscal_year,
        )
        return await import_service.import_excel(
            session,
            request,
            file.filename,
            file_bytes,
        )
    except BudgetImportValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "message": exc.message,
                "errors": exc.errors,
            },
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc


class SubjectSearchResponse(BaseModel):
    id: int
    code: str
    jang_nm: str | None = None
    gwan_nm: str | None = None
    hang_or_budg_mok_nm: str | None = None
    mok_or_stat_mok_nm: str | None = None


@router.get("/account-subjects/search", response_model=list[SubjectSearchResponse])
async def search_account_subjects(
    session: Annotated[AsyncSession, Depends(get_session)],
    q: str,
    fiscal_year: int | None = Query(None),
):
    from sqlalchemy import and_, or_

    where_conditions = [
        or_(
            BudgetInAccountSubject.mok_cd.contains(q),
            BudgetInAccountSubject.jang_nm.contains(q),
            BudgetInAccountSubject.gwan_nm.contains(q),
            BudgetInAccountSubject.hang_nm.contains(q),
            BudgetInAccountSubject.mok_nm.contains(q),
        )
    ]
    
    if fiscal_year is not None:
        where_conditions.append(BudgetInAccountSubject.fiscal_year == fiscal_year)

    stmt = (
        select(
            BudgetInAccountSubject.acc_sub_id,
            BudgetInAccountSubject.jang_cd,
            BudgetInAccountSubject.gwan_cd,
            BudgetInAccountSubject.hang_cd,
            BudgetInAccountSubject.mok_cd,
            BudgetInAccountSubject.jang_nm,
            BudgetInAccountSubject.gwan_nm,
            BudgetInAccountSubject.hang_nm,
            BudgetInAccountSubject.mok_nm,
        )
        .distinct()
        .where(and_(*where_conditions))
        .order_by(BudgetInAccountSubject.mok_cd)
    )

    result = await session.execute(stmt)
    return [
        SubjectSearchResponse(
            id=row.acc_sub_id,
            code=row.mok_cd or "",
            jang_nm=row.jang_nm,
            gwan_nm=row.gwan_nm,
            hang_or_budg_mok_nm=row.hang_nm,
            mok_or_stat_mok_nm=row.mok_nm,
        )
        for row in result.all()
    ]


@router.get("/years", response_model=list[int])
async def get_fiscal_years(
    session: Annotated[AsyncSession, Depends(get_session)],
):
    stmt = (
        select(BudgetInFact.fiscal_year)
        .distinct()
        .order_by(BudgetInFact.fiscal_year.desc())
    )
    result = await session.execute(stmt)
    return [row[0] for row in result.all()]
