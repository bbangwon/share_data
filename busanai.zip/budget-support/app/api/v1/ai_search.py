from typing import Annotated

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import get_session
from app.models import (
    BudgetInAccountSubject,
    BudgetInFact,
    BudgetInFundAccount,
    BudgetInOrganization,
    BudgetLocalGovernment,
    BudgetOutAccountSubject,
    BudgetOutFact,
    BudgetOutFactLv1,
    BudgetOutFundAccount,
    BudgetOutOrganization,
    BudgetOutProjectDetail,
    BudgetOutAccountSubjectLv1,
    BudgetOutProjectDetailLv1,
    BudgetOutProjectPolicy,
    BudgetOutProjectUnit,
)

router = APIRouter(prefix="/api/v1/ai-search", tags=["ai-search"])


class AiSearchInItem(BaseModel):
    la_cd: str
    la_nm: str
    fiscal_year: int
    dept_nm: str
    adj_basis: str
    budget_amt: int
    fund_nm: str | None = None
    mok_cd: str | None = None
    mok_nm: str | None = None
    adj_formula: str | None = None


class AiSearchOutItem(BaseModel):
    la_cd: str
    la_nm: str
    fiscal_year: int
    dept_nm: str
    dtl_prj_nm: str
    adj_basis: str
    budget_amt: int
    fund_nm: str | None = None
    stat_mok_cd: str | None = None
    stat_mok_nm: str | None = None
    adj_formula: str | None = None


class AiSearchOtherCityItem(BaseModel):
    la_cd: str
    la_nm: str
    w_city_nm: str
    dtl_prj_nm: str
    stat_mok_nm: str
    adj_basis: str
    budget_amt: int


@router.get("/in", response_model=list[AiSearchInItem])
async def search_budget_in(
    session: Annotated[AsyncSession, Depends(get_session)],
    fiscal_year: int | None = None,
    fund_types: list[str] | None = Query(default=None),
    la_cd: str | None = None,
    subject_code_start: str | None = None,
    subject_code_end: str | None = None,
    min_amt: int | None = None,
    max_amt: int | None = None,
    keyword_type: str | None = None,
    keyword: str | None = None,
):
    stmt = (
        select(
            BudgetLocalGovernment.la_cd,
            BudgetLocalGovernment.la_nm,
            BudgetInFact.fiscal_year,
            BudgetInOrganization.dept_nm,
            BudgetInFundAccount.fund_nm,
            BudgetInAccountSubject.jang_cd,
            BudgetInAccountSubject.gwan_cd,
            BudgetInAccountSubject.hang_cd,
            BudgetInAccountSubject.mok_cd,
            BudgetInAccountSubject.jang_nm,
            BudgetInAccountSubject.gwan_nm,
            BudgetInAccountSubject.hang_nm,
            BudgetInAccountSubject.mok_nm,
            BudgetInFact.adj_basis_full,
            BudgetInFact.adj_formula,
            BudgetInFact.budget_amt,
        )
        .join(BudgetLocalGovernment, BudgetInFact.la_cd == BudgetLocalGovernment.la_cd)
        .join(
            BudgetInOrganization,
            (BudgetInFact.la_cd == BudgetInOrganization.la_cd)
            & (BudgetInFact.fiscal_year == BudgetInOrganization.fiscal_year)
            & (BudgetInFact.dept_cd == BudgetInOrganization.dept_cd),
        )
        .join(
            BudgetInAccountSubject,
            BudgetInFact.acc_sub_id == BudgetInAccountSubject.acc_sub_id,
        )
        .join(BudgetInFundAccount, BudgetInFact.fund_cd == BudgetInFundAccount.fund_cd)
    )

    if fiscal_year:
        stmt = stmt.where(BudgetInFact.fiscal_year == fiscal_year)
    if fund_types:
        conditions = [BudgetInFundAccount.fund_cd.startswith(ft) for ft in fund_types]
        stmt = stmt.where(or_(*conditions))
    if la_cd and la_cd != "ALL":
        stmt = stmt.where(BudgetLocalGovernment.la_cd == la_cd)
    if subject_code_start:
        stmt = stmt.where(BudgetInAccountSubject.mok_cd >= subject_code_start)
    if subject_code_end:
        stmt = stmt.where(BudgetInAccountSubject.mok_cd <= subject_code_end)
    if min_amt is not None:
        stmt = stmt.where(BudgetInFact.budget_amt >= min_amt)
    if max_amt is not None:
        stmt = stmt.where(BudgetInFact.budget_amt <= max_amt)
    if keyword:
        # 세입의 경우 키워드는 항상 산출근거 필드
        stmt = stmt.where(BudgetInFact.adj_basis_full.contains(keyword))

    # Limit results to 5000 to avoid performance issues
    # stmt = stmt.limit(5000)

    result = await session.execute(stmt)

    items = []
    for row in result.all():
        items.append(
            AiSearchInItem(
                la_cd=row.la_cd,
                la_nm=row.la_nm,
                fiscal_year=row.fiscal_year,
                dept_nm=row.dept_nm,
                adj_basis=row.adj_basis_full or "",
                budget_amt=row.budget_amt,
                fund_nm=row.fund_nm,
                mok_cd=row.mok_cd,
                mok_nm=row.mok_nm,
                adj_formula=row.adj_formula,
            )
        )

    return items


@router.get("/other-city", response_model=list[AiSearchOtherCityItem])
async def search_other_city(
    session: Annotated[AsyncSession, Depends(get_session)],
    org_cd: str = "ALL",
    fiscal_year: int | None = None,
    subject_id: int | None = None,
    min_amt: int | None = None,
    max_amt: int | None = None,
    keyword_type: str | None = None,
    keyword: str | None = None,
):
    stmt = (
        select(
            BudgetLocalGovernment.la_cd,
            BudgetLocalGovernment.la_nm,
            BudgetLocalGovernment.w_city_nm,
            BudgetOutProjectDetailLv1.dtl_prj_nm,
            BudgetOutAccountSubjectLv1.stat_mok_nm,
            BudgetOutFactLv1.adj_basis,
            BudgetOutFactLv1.sum_amt,
        )
        .join(
            BudgetLocalGovernment,
            BudgetOutFactLv1.la_cd == BudgetLocalGovernment.la_cd,
        )
        .join(
            BudgetOutProjectDetailLv1,
            BudgetOutFactLv1.dtl_prj_id == BudgetOutProjectDetailLv1.dtl_prj_id,
        )
        .join(
            BudgetOutAccountSubjectLv1,
            BudgetOutFactLv1.acc_sub_id == BudgetOutAccountSubjectLv1.acc_sub_id,
        )
    )

    if org_cd != "ALL":
        if org_cd == "6260000":
            stmt = stmt.where(BudgetLocalGovernment.w_city_nm == "부산광역시")
        else:
            stmt = stmt.where(BudgetLocalGovernment.la_cd == org_cd)        
    if fiscal_year:
        stmt = stmt.where(BudgetOutFactLv1.fiscal_year == fiscal_year)
    if subject_id:
        stmt = stmt.where(BudgetOutAccountSubjectLv1.acc_sub_id == subject_id)
    if min_amt is not None:
        stmt = stmt.where(BudgetOutFactLv1.sum_amt >= min_amt * 1000)
    if max_amt is not None:
        stmt = stmt.where(BudgetOutFactLv1.sum_amt <= max_amt * 1000)

    if keyword:
        if keyword_type == "세부사업명":
            stmt = stmt.where(
                BudgetOutProjectDetailLv1.dtl_prj_nm.contains(keyword),
            )
        elif keyword_type == "산출근거":
            stmt = stmt.where(BudgetOutFactLv1.adj_basis.contains(keyword))
        else:  # 전체
            stmt = stmt.where(
                or_(
                    BudgetOutProjectDetailLv1.dtl_prj_nm.contains(keyword),
                    BudgetOutFactLv1.adj_basis.contains(keyword),
                )
            )

    result = await session.execute(stmt)

    items = []
    for row in result.all():
        items.append(
            AiSearchOtherCityItem(
                la_cd=row.la_cd,
                la_nm=row.la_nm,
                w_city_nm=row.w_city_nm,
                dtl_prj_nm=row.dtl_prj_nm,
                stat_mok_nm=row.stat_mok_nm or "",
                adj_basis=row.adj_basis or "",
                budget_amt=row.sum_amt // 1000 if row.sum_amt else 0,
            )
        )

    return items


@router.get("/out", response_model=list[AiSearchOutItem])
async def search_budget_out(
    session: Annotated[AsyncSession, Depends(get_session)],
    fiscal_year: int | None = None,
    fund_types: list[str] | None = Query(default=None),
    la_cd: str | None = None,
    subject_code_start: str | None = None,
    subject_code_end: str | None = None,
    min_amt: int | None = None,
    max_amt: int | None = None,
    keyword_type: str | None = None,
    keyword: str | None = None,
):
    stmt = (
        select(
            BudgetLocalGovernment.la_cd,
            BudgetLocalGovernment.la_nm,
            BudgetOutFact.fiscal_year,
            BudgetOutOrganization.bureau_nm,
            BudgetOutOrganization.dept_nm,
            BudgetOutFundAccount.fund_nm,
            BudgetOutProjectDetail.dtl_prj_nm,
            BudgetOutAccountSubject.stat_mok_cd,
            BudgetOutAccountSubject.budg_mok_cd,
            BudgetOutAccountSubject.budg_mok_nm,
            BudgetOutAccountSubject.stat_mok_nm,
            BudgetOutFact.adj_basis_full,
            BudgetOutFact.adj_formula,
            BudgetOutFact.rev_adj_amt,
        )
        .join(BudgetLocalGovernment, BudgetOutFact.la_cd == BudgetLocalGovernment.la_cd)
        .join(
            BudgetOutOrganization,
            (BudgetOutFact.la_cd == BudgetOutOrganization.la_cd)
            & (BudgetOutFact.fiscal_year == BudgetOutOrganization.fiscal_year)
            & (BudgetOutFact.dept_cd == BudgetOutOrganization.dept_cd),
        )
        .join(
            BudgetOutProjectDetail,
            BudgetOutFact.dtl_prj_id == BudgetOutProjectDetail.dtl_prj_id,
        )
        .join(
            BudgetOutAccountSubject,
            BudgetOutFact.acc_sub_id == BudgetOutAccountSubject.acc_sub_id,
        )
        .join(
            BudgetOutFundAccount, BudgetOutFact.fund_cd == BudgetOutFundAccount.fund_cd
        )
    )

    if fiscal_year:
        stmt = stmt.where(BudgetOutFact.fiscal_year == fiscal_year)
    if fund_types:
        conditions = [BudgetOutFundAccount.fund_cd.startswith(ft) for ft in fund_types]
        stmt = stmt.where(or_(*conditions))
    if la_cd and la_cd != "ALL":
        stmt = stmt.where(BudgetLocalGovernment.la_cd == la_cd)
    if subject_code_start:
        stmt = stmt.where(BudgetOutAccountSubject.stat_mok_cd >= subject_code_start)
    if subject_code_end:
        stmt = stmt.where(BudgetOutAccountSubject.stat_mok_cd <= subject_code_end)
    if min_amt is not None:
        stmt = stmt.where(BudgetOutFact.rev_adj_amt >= min_amt)
    if max_amt is not None:
        stmt = stmt.where(BudgetOutFact.rev_adj_amt <= max_amt)

    if keyword:
        if keyword_type == "정책사업명":
            stmt = stmt.join(
                BudgetOutProjectPolicy,
                BudgetOutFact.policy_proj_id == BudgetOutProjectPolicy.policy_proj_id,
            )
            stmt = stmt.where(BudgetOutProjectPolicy.policy_proj_nm.contains(keyword))
        elif keyword_type == "단위사업명":
            stmt = stmt.join(
                BudgetOutProjectUnit,
                BudgetOutFact.unit_prj_id == BudgetOutProjectUnit.unit_prj_id,
            )
            stmt = stmt.where(BudgetOutProjectUnit.unit_prj_nm.contains(keyword))
        elif keyword_type == "세부사업명":
            stmt = stmt.where(BudgetOutProjectDetail.dtl_prj_nm.contains(keyword))
        elif keyword_type == "산출근거내용":
            stmt = stmt.where(BudgetOutFact.adj_basis_full.contains(keyword))
        else:  # 전체
            stmt = stmt.outerjoin(
                BudgetOutProjectPolicy,
                BudgetOutFact.policy_proj_id == BudgetOutProjectPolicy.policy_proj_id,
            )
            stmt = stmt.outerjoin(
                BudgetOutProjectUnit,
                BudgetOutFact.unit_prj_id == BudgetOutProjectUnit.unit_prj_id,
            )
            stmt = stmt.where(
                or_(
                    BudgetOutProjectPolicy.policy_proj_nm.contains(keyword),
                    BudgetOutProjectUnit.unit_prj_nm.contains(keyword),
                    BudgetOutProjectDetail.dtl_prj_nm.contains(keyword),
                    BudgetOutFact.adj_basis_full.contains(keyword),
                )
            )

    # stmt = stmt.limit(5000)

    result = await session.execute(stmt)

    items = []
    for row in result.all():
        items.append(
            AiSearchOutItem(
                la_cd=row.la_cd,
                la_nm=row.la_nm,
                fiscal_year=row.fiscal_year,
                dept_nm=row.dept_nm,
                dtl_prj_nm=row.dtl_prj_nm,
                adj_basis=row.adj_basis_full or "",
                budget_amt=row.rev_adj_amt,
                fund_nm=row.fund_nm,
                stat_mok_cd=row.stat_mok_cd,
                stat_mok_nm=row.stat_mok_nm,
                adj_formula=row.adj_formula,
            )
        )

    return items
