from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import get_session
from app.schemas.imports import BudgetImportJobListResponse
from app.services import BudgetImportJobService

router = APIRouter(prefix="/api/v1/import-jobs", tags=["import-jobs"])


def get_import_job_service() -> BudgetImportJobService:
    return BudgetImportJobService()


@router.get("", response_model=BudgetImportJobListResponse)
async def list_import_jobs(
    session: Annotated[AsyncSession, Depends(get_session)],
    import_job_service: Annotated[
        BudgetImportJobService, Depends(get_import_job_service)
    ],
    page: int = 1,
    size: int = 20,
    job_status: str | None = Query(None),
    fiscal_year: int | None = Query(None),
    recent_days: int | None = Query(7),
    import_type: str | None = Query(None),
):
    if page < 1:
        raise HTTPException(
            status_code=400,
            detail="page는 1 이상이어야 합니다.",
        )
    if size < 1 or size > 100:
        raise HTTPException(
            status_code=400,
            detail="size는 1 이상 100 이하여야 합니다.",
        )
    if recent_days is not None and recent_days < 1:
        raise HTTPException(
            status_code=400,
            detail="recent_days는 1 이상이어야 합니다.",
        )

    return await import_job_service.list_jobs(
        session=session,
        page=page,
        size=size,
        status=job_status,
        fiscal_year=fiscal_year,
        recent_days=recent_days,
        import_type=import_type,
    )
