db = db.getSiblingDB("log_db"); // log_db로 전환
db.createUser({
  user: "appuser",
  pwd: "busan12#$",
  roles: [{ role: "readWrite", db: "log_db" }],
});
