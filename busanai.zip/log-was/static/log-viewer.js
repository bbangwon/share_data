(function () {
  const state = {
    entries: [],
    expectedSteps: [],
    search: "",
    stepFilter: "",
    missingOnly: false,
    unansweredOnly: false,
    sourceLabel: "",
    intentStats: { rows: [], total: 0 },
    lastExcelUrl: "",
    lastJsonUrl: "",
  };

  const refs = {
    apiForm: document.getElementById("api-form"),
    questionInput: document.getElementById("question-input"),
    startDateInput: document.getElementById("start-date-input"),
    endDateInput: document.getElementById("end-date-input"),
    apiFetchButton: document.getElementById("api-fetch-button"),
    todayFetchButton: document.getElementById("today-fetch-button"),
    fileInput: document.getElementById("file-input"),
    loaderStatus: document.getElementById("loader-status"),
    dropzone: document.getElementById("dropzone"),
    filters: document.getElementById("filters"),
    searchInput: document.getElementById("search-input"),
    stepFilter: document.getElementById("step-filter"),
    missingOnly: document.getElementById("missing-only"),
    unansweredOnly: document.getElementById("unanswered-only"),
    filterStatus: document.getElementById("filter-status"),
    summary: document.getElementById("summary"),
    stepTable: document.getElementById("step-table"),
    intentTable: document.getElementById("intent-table"),
    entryCount: document.getElementById("entry-count"),
    entryList: document.getElementById("entry-list"),
    excelDownloadButton: document.getElementById("excel-download-button"),
    jsonDownloadButton: document.getElementById("json-download-button"),
  };

  const QUESTION_STEP = "01. Task WAS 메세지큐 수신";
  const ANSWER_STEP_FROM_DB = "08. DB 최종답변 저장";
  const ANSWER_STEP = "07_02. 참고자료있는 경우 추가";
  const LEGACY_ANSWER_STEP = "07_01. LLM WAS 최종답변 생성 API 요청";

  const INTENT_STEP = "05_02. 의도분석 API 요청 결과 파싱";
  const RAG_STEP = "06_05. RAG 검색 API 요청";
  const TASK_ID = document.body?.dataset?.taskId || null;
  const EXCEL_BUTTON_LABEL = "엑셀 다운로드";
  const EXCEL_BUTTON_LOADING_LABEL = "엑셀 준비 중...";
  const JSON_BUTTON_LABEL = "JSON 다운로드";
  const JSON_BUTTON_LOADING_LABEL = "JSON 준비 중...";

  function setStatus(message, type = "info") {
    refs.loaderStatus.textContent = message;
    refs.loaderStatus.className = "status-pill " + type;
  }

  function updateExcelButtonState() {
    if (!refs.excelDownloadButton) return;
    const hasTarget = !!state.lastExcelUrl;
    refs.excelDownloadButton.disabled = !hasTarget;
    refs.excelDownloadButton.title = hasTarget
      ? "현재 조회 조건으로 엑셀을 내려받습니다."
      : "먼저 API로 로그를 불러오세요.";
  }

  function setExcelDownloadTarget(url) {
    state.lastExcelUrl = typeof url === "string" ? url : "";
    updateExcelButtonState();
  }

  function updateJsonButtonState() {
    if (!refs.jsonDownloadButton) return;
    const hasTarget = !!state.lastJsonUrl;
    refs.jsonDownloadButton.disabled = !hasTarget;
    refs.jsonDownloadButton.title = hasTarget
      ? "현재 조회 조건으로 JSON을 내려받습니다."
      : "먼저 API로 로그를 불러오세요.";
  }

  function setJsonDownloadTarget(url) {
    state.lastJsonUrl = typeof url === "string" ? url : "";
    updateJsonButtonState();
  }

  function buildDateParam(dateString, endOfDay = false) {
    if (!dateString) return null;
    const time = endOfDay ? "23:59:59.999" : "00:00:00.000";
    const date = new Date(`${dateString}T${time}`);

    if (Number.isNaN(date.getTime())) return null;

    // yyyy-MM-ddTHH:mm:ss.sss 형식
    const pad = (n, z = 2) => String(n).padStart(z, "0");
    const yyyy = date.getFullYear();
    const mm = pad(date.getMonth() + 1);
    const dd = pad(date.getDate());
    const hh = pad(date.getHours());
    const mi = pad(date.getMinutes());
    const ss = pad(date.getSeconds());
    const ms = pad(date.getMilliseconds(), 3);

    return `${yyyy}-${mm}-${dd}T${hh}:${mi}:${ss}.${ms}`;
  }

  function extractFilenameFromHeader(headerValue) {
    if (!headerValue || typeof headerValue !== "string") return null;
    const utfMatch = headerValue.match(/filename\*=(?:UTF-8'')?([^;]+)/i);
    if (utfMatch && utfMatch[1]) {
      return decodeURIComponent(utfMatch[1].replace(/"/g, "").trim());
    }
    const asciiMatch = headerValue.match(/filename="?([^";]+)"?/i);
    return asciiMatch && asciiMatch[1] ? asciiMatch[1].trim() : null;
  }

  async function downloadExcelForLastQuery() {
    if (!state.lastExcelUrl) {
      setStatus("먼저 API로 로그를 불러와 주세요.", "warning");
      return;
    }
    const button = refs.excelDownloadButton;
    if (!button) return;
    const originalLabel = button.textContent;
    button.disabled = true;
    button.textContent = EXCEL_BUTTON_LOADING_LABEL;
    try {
      const response = await fetch(state.lastExcelUrl, { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const blob = await response.blob();
      const header = response.headers.get("content-disposition");
      const filename =
        extractFilenameFromHeader(header) ||
        `logs_${Date.now().toString()}.xlsx`;
      const downloadUrl = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = downloadUrl;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      URL.revokeObjectURL(downloadUrl);
      setStatus("엑셀 파일을 다운로드했습니다.", "success");
    } catch (err) {
      console.error(err);
      setStatus(`엑셀 다운로드 실패: ${err.message}`, "error");
    } finally {
      button.textContent = originalLabel || EXCEL_BUTTON_LABEL;
      button.disabled = !state.lastExcelUrl;
    }
  }

  async function downloadJsonForLastQuery() {
    if (!state.lastJsonUrl) {
      setStatus("먼저 API로 로그를 불러와 주세요.", "warning");
      return;
    }
    const button = refs.jsonDownloadButton;
    if (!button) return;
    const originalLabel = button.textContent;
    button.disabled = true;
    button.textContent = JSON_BUTTON_LOADING_LABEL;
    try {
      const response = await fetch(state.lastJsonUrl, { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const blob = await response.blob();
      const header = response.headers.get("content-disposition");
      const filename =
        extractFilenameFromHeader(header) || `logs_${Date.now()}.json`;
      const downloadUrl = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = downloadUrl;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      URL.revokeObjectURL(downloadUrl);
      setStatus("JSON 파일을 다운로드했습니다.", "success");
    } catch (err) {
      console.error(err);
      setStatus(`JSON 다운로드 실패: ${err.message}`, "error");
    } finally {
      button.textContent = originalLabel || JSON_BUTTON_LABEL;
      button.disabled = !state.lastJsonUrl;
    }
  }

  function getBasePath() {
    const path = window.location.pathname;
    const idx = path.indexOf("log-viewer");
    if (idx === -1) return path;
    return path.slice(0, idx + "log-viewer".length);
  }

  function escapeHTML(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function linkifyURLs(text) {
    if (!text) return text;
    const urlRegex = /(https?:\/\/[^\s<>"]+)/gi;
    return String(text).replace(urlRegex, (url) => {
      const escaped = escapeHTML(url);
      return `<a href="${escaped}" target="_blank" rel="noopener noreferrer">${escaped}</a>`;
    });
  }

  function parseDate(value) {
    if (!value) return null;
    if (value instanceof Date) return isNaN(value.getTime()) ? null : value;
    if (typeof value === "string") {
      const date = new Date(value);
      return isNaN(date.getTime()) ? null : date;
    }
    if (typeof value === "object" && "$date" in value) {
      const date = new Date(value.$date);
      return isNaN(date.getTime()) ? null : date;
    }
    return null;
  }

  function formatDate(date) {
    if (!(date instanceof Date) || isNaN(date.getTime())) return "기록 없음";
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    const hh = String(date.getHours()).padStart(2, "0");
    const mi = String(date.getMinutes()).padStart(2, "0");
    const ss = String(date.getSeconds()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${mi}:${ss}`;
  }

  function formatSeconds(value) {
    if (typeof value !== "number" || !isFinite(value)) return "미기록";
    if (value >= 60) {
      const minutes = Math.floor(value / 60);
      const seconds = value % 60;
      return `${minutes}분 ${seconds.toFixed(1)}초`;
    }
    return `${value.toFixed(3)}초`;
  }

  function formatBody(body) {
    if (body === null || body === undefined) return "null";
    if (typeof body === "string") return body;
    try {
      return JSON.stringify(body, null, 2);
    } catch (err) {
      return String(body);
    }
  }

  async function copyToClipboard(text) {
    const value = text != null ? String(text) : "";
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(value);
      return;
    }
    const textarea = document.createElement("textarea");
    textarea.value = value;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.focus({ preventScroll: true });
    textarea.select();
    const successful = document.execCommand("copy");
    document.body.removeChild(textarea);
    if (!successful) {
      throw new Error("copy command was not successful");
    }
  }

  function normalizeEntry(entry, index) {
    const logs = Array.isArray(entry.logs) ? entry.logs : [];
    const normalizedLogs = logs.map((log, logIndex) => {
      const stepName =
        typeof log?.STEP === "string" ? log.STEP : `Step ${logIndex + 1}`;
      const issued = parseDate(log?._issued_time);
      const duration =
        typeof log?._duration === "number" ? log._duration : null;
      const body = log?.BODY ?? null;
      let status = null;
      if (body && typeof body === "object" && "result" in body && body.result) {
        status = String(body.result).toLowerCase();
      }
      return {
        step: stepName,
        issued,
        duration,
        body,
        raw: log,
        status,
      };
    });
    const issued = parseDate(entry?.issued_time);
    const totalDuration =
      typeof entry?.total_duration === "number" ? entry.total_duration : null;
    return {
      id: entry?._id ?? `entry-${index + 1}`,
      botId: entry?.bot_id ?? "",
      userId: entry?.user_id ?? "",
      issued,
      totalDuration,
      logs: normalizedLogs,
      raw: entry,
    };
  }

  function deriveExpectedSteps(entries) {
    if (!entries.length) return [];
    const sorted = [...entries].sort(
      (a, b) => (b.logs.length || 0) - (a.logs.length || 0)
    );
    const ordered = sorted[0]?.logs.map((log) => log.step) ?? [];
    const seen = new Set(ordered);
    for (const entry of entries) {
      for (const log of entry.logs) {
        if (log.step && !seen.has(log.step)) {
          ordered.push(log.step);
          seen.add(log.step);
        }
      }
    }
    return ordered;
  }

  function computeMissingSteps(entry, expectedSteps) {
    const present = new Set(entry.logs.map((log) => log.step));
    return expectedSteps.filter((step) => !present.has(step));
  }

  function buildSearchText(entry) {
    const fragments = [
      entry.id,
      entry.botId,
      entry.userId,
      entry.totalDuration != null ? entry.totalDuration.toString() : "",
    ];
    entry.logs.forEach((log) => {
      fragments.push(log.step);
      if (log.status) fragments.push(log.status);
      if (log.body !== null && log.body !== undefined) {
        if (typeof log.body === "string") {
          fragments.push(log.body);
        } else {
          try {
            fragments.push(JSON.stringify(log.body));
          } catch (err) {
            fragments.push(String(log.body));
          }
        }
      }
    });
    return fragments.filter(Boolean).join(" ").toLowerCase();
  }

  function computeStepStats(entries, expected) {
    const statsMap = new Map();
    const totalEntries = entries.length || 1;
    for (const entry of entries) {
      for (const log of entry.logs) {
        const step = log.step;
        if (!step) continue;
        if (!statsMap.has(step)) {
          statsMap.set(step, {
            step,
            count: 0,
            success: 0,
            failure: 0,
            durations: [],
          });
        }
        const stat = statsMap.get(step);
        stat.count += 1;
        if (log.status === "success") {
          stat.success += 1;
        } else if (log.status && log.status !== "success") {
          stat.failure += 1;
        }
        if (typeof log.duration === "number" && isFinite(log.duration)) {
          stat.durations.push(log.duration);
        }
      }
    }

    const finalize = (stat) => {
      if (!stat) {
        return {
          step: "",
          count: 0,
          success: 0,
          failure: 0,
          coverage: 0,
          averageDuration: null,
        };
      }
      const durationAvg = stat.durations.length
        ? stat.durations.reduce((sum, v) => sum + v, 0) / stat.durations.length
        : null;
      return {
        step: stat.step,
        count: stat.count,
        success: stat.success,
        failure: stat.failure,
        coverage: stat.count / totalEntries,
        averageDuration: durationAvg,
      };
    };

    const rows = expected.map((step) => finalize(statsMap.get(step)));
    for (const [step, stat] of statsMap.entries()) {
      if (!expected.includes(step)) {
        rows.push(finalize(stat));
      }
    }
    return rows;
  }

  function computeIntentStats(entries) {
    const stats = new Map();
    let total = 0;
    for (const entry of entries) {
      const intentLog = entry.logs.find((log) => log.step === INTENT_STEP);
      if (!intentLog) continue;
      const detail = intentLog.body?.detail;
      const intentNo = detail?.no ?? "미확인";
      const intentName = detail?.intent_name ?? "미확인";
      const key = `${intentNo}||${intentName}`;
      if (!stats.has(key)) {
        stats.set(key, { no: intentNo, intentName, count: 0 });
      }
      stats.get(key).count += 1;
      total += 1;
    }
    const rows = Array.from(stats.values()).sort((a, b) => {
      if (b.count !== a.count) return b.count - a.count;
      return a.no.localeCompare(b.no);
    });
    return { rows, total };
  }

  function applyFilters(entries) {
    const keyword = state.search.trim().toLowerCase();
    return entries.filter((entry) => {
      if (state.missingOnly && entry.missingSteps.length === 0) {
        return false;
      }
      if (state.unansweredOnly) {
        const hasAnswer =
          typeof entry.finalAnswer === "string"
            ? entry.finalAnswer.trim().length > 0
            : Boolean(entry.finalAnswer);
        if (hasAnswer) {
          return false;
        }
      }
      if (state.stepFilter) {
        const hasStep = entry.logs.some((log) => log.step === state.stepFilter);
        if (!hasStep) return false;
      }
      if (keyword && !entry.searchText.includes(keyword)) {
        return false;
      }
      return true;
    });
  }

  function updateStepFilterOptions(expectedSteps) {
    refs.stepFilter.innerHTML = '<option value="">전체 단계</option>';
    expectedSteps.forEach((step) => {
      const option = document.createElement("option");
      option.value = step;
      option.textContent = step;
      refs.stepFilter.appendChild(option);
    });
  }

  function renderSummary() {
    if (!state.entries.length) {
      refs.summary.innerHTML = "<p>먼저 로그 파일을 불러와 주세요.</p>";
      return;
    }
    const totals = state.entries
      .map((entry) => entry.totalDuration)
      .filter((value) => typeof value === "number" && isFinite(value));
    const totalCount = state.entries.length;
    const missingCount = state.entries.filter(
      (entry) => entry.missingSteps.length > 0
    ).length;
    const durationsSum = totals.reduce((sum, value) => sum + value, 0);
    const averageDuration = totals.length ? durationsSum / totals.length : null;
    const minDuration = totals.length ? Math.min(...totals) : null;
    const maxDuration = totals.length ? Math.max(...totals) : null;
    const issuedDates = state.entries
      .map((entry) => entry.issued)
      .filter((date) => date instanceof Date && !isNaN(date.getTime()));
    let rangeText = "기록 없음";
    if (issuedDates.length) {
      const earliest = new Date(
        Math.min(...issuedDates.map((d) => d.getTime()))
      );
      const latest = new Date(Math.max(...issuedDates.map((d) => d.getTime())));
      rangeText = `${formatDate(earliest)} ~ ${formatDate(latest)}`;
    }

    refs.summary.innerHTML = `
      <div class="summary-grid">
        <div class="stat-card">
          <strong>${totalCount}</strong>
          <span>총 요청 수</span>
        </div>
        <div class="stat-card">
          <strong>${missingCount}</strong>
          <span>누락 단계가 있는 요청</span>
        </div>
        <div class="stat-card">
          <strong>${
            averageDuration != null
              ? averageDuration.toFixed(3) + "초"
              : "미기록"
          }</strong>
          <span>평균 총 소요 시간</span>
        </div>
        <div class="stat-card">
          <strong>${
            minDuration != null ? minDuration.toFixed(3) + "초" : "미기록"
          }</strong>
          <span>최소 / 최대 소요 (최대 ${
            maxDuration != null ? maxDuration.toFixed(3) + "초" : "미기록"
          })</span>
        </div>
        <div class="stat-card">
          <strong>${state.expectedSteps.length}</strong>
          <span>감지된 단계 종류</span>
        </div>
        <div class="stat-card">
          <strong>${escapeHTML(state.sourceLabel || "미지정")}</strong>
          <span>현재 데이터 소스</span>
        </div>
      </div>
      <p class="hint">요청 발생 시각 범위: ${rangeText}</p>
    `;
  }

  function renderStepStats() {
    if (!state.entries.length) {
      refs.stepTable.innerHTML =
        "<p>단계별 현황은 로그를 불러온 뒤 확인할 수 있습니다.</p>";
      return;
    }
    const stats = computeStepStats(state.entries, state.expectedSteps);
    const totalEntries = state.entries.length;
    const rows = stats
      .map((stat) => {
        if (!stat.step) return "";
        const coveragePercent = (stat.coverage * 100).toFixed(0);
        const successRate = stat.count
          ? Math.round((stat.success / stat.count) * 100)
          : 0;
        return `
          <tr>
            <td>${escapeHTML(stat.step)}</td>
            <td>${stat.count}</td>
            <td>${coveragePercent}%</td>
            <td>${successRate}%</td>
            <td>${
              stat.averageDuration != null
                ? stat.averageDuration.toFixed(3) + "초"
                : "미기록"
            }</td>
          </tr>
        `;
      })
      .join("");

    refs.stepTable.innerHTML = `
      <table>
        <thead>
          <tr>
            <th>단계명</th>
            <th>발생 횟수</th>
            <th>커버리지 (요청 대비)</th>
            <th>성공 비율</th>
            <th>평균 소요 시간</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
        <tfoot>
          <tr>
            <td colspan="5">총 ${totalEntries}개의 요청 기준</td>
          </tr>
        </tfoot>
      </table>
    `;
  }

  function renderIntentStats() {
    if (!state.entries.length) {
      refs.intentTable.innerHTML =
        "<p>의도 분석 통계를 표시하려면 로그를 불러와 주세요.</p>";
      return;
    }
    const { rows, total } = state.intentStats;
    if (!rows.length) {
      refs.intentTable.innerHTML =
        "<p>의도 분석 단계가 포함된 로그가 없습니다.</p>";
      return;
    }
    const bodyRows = rows
      .map(
        (row) => `
        <tr>
          <td>${escapeHTML(row.no)}</td>
          <td>${escapeHTML(row.intentName)}</td>
          <td>${row.count}</td>
          <td>${total ? Math.round((row.count / total) * 100) : 0}%</td>
        </tr>`
      )
      .join("");
    refs.intentTable.innerHTML = `
      <table>
        <thead>
          <tr>
            <th>의도 NO</th>
            <th>의도명</th>
            <th>발생 건수</th>
            <th>비중</th>
          </tr>
        </thead>
        <tbody>
          ${bodyRows}
        </tbody>
        <tfoot>
          <tr>
            <td colspan="4">의도 분석 단계가 감지된 총 ${total}건 기준</td>
          </tr>
        </tfoot>
      </table>
    `;
  }

  function buildRagResultCard(result, detail) {
    const wrapper = document.createElement("div");
    wrapper.className = "rag-result-card";

    const header = document.createElement("div");
    header.className = "rag-header";
    header.innerHTML = `
      <h4>📚 RAG 검색 결과</h4>
      <span class="rag-status ${result === "success" ? "success" : "failure"}">
        ${escapeHTML(result || "unknown")}
      </span>
    `;
    wrapper.appendChild(header);

    // ref_docs의 ID들을 Set으로 저장
    const refDocIds = new Set((detail.ref_docs || []).map((doc) => doc.id));

    // 참고 문서 표시
    if (detail.ref_docs && detail.ref_docs.length > 0) {
      const refSection = document.createElement("div");
      refSection.className = "rag-section";
      refSection.innerHTML = `<h5>📄 주요 참고문서 (${detail.ref_docs.length}건)</h5>`;

      detail.ref_docs.forEach((doc, idx) => {
        const docItem = document.createElement("details");
        docItem.className = "rag-doc-item";
        const docId = `ref-doc-${idx}`;
        docItem.innerHTML = `
          <summary>
            <span class="doc-number">#${idx + 1}</span>
            <span class="doc-id">${escapeHTML(doc.id || "미확인")}</span>
          </summary>
          <div class="doc-content">
            <div class="doc-controls">
              <button class="toggle-view-btn" data-target="${docId}">HTML 보기</button>
              <button class="copy-doc-btn">복사</button>
            </div>
            <div id="${docId}" class="doc-text" data-view-mode="text">
              <pre>${escapeHTML(doc.passage || "내용 없음")}</pre>
            </div>
          </div>
        `;

        // 토글 버튼 이벤트
        const toggleBtn = docItem.querySelector(".toggle-view-btn");
        const copyBtn = docItem.querySelector(".copy-doc-btn");
        const docTextDiv = docItem.querySelector(".doc-text");

        if (toggleBtn && docTextDiv) {
          toggleBtn.addEventListener("click", () => {
            const currentMode = docTextDiv.dataset.viewMode;
            if (currentMode === "text") {
              docTextDiv.innerHTML = doc.passage || "내용 없음";
              docTextDiv.dataset.viewMode = "html";
              toggleBtn.textContent = "텍스트 보기";
            } else {
              docTextDiv.innerHTML = `<pre>${escapeHTML(
                doc.passage || "내용 없음"
              )}</pre>`;
              docTextDiv.dataset.viewMode = "text";
              toggleBtn.textContent = "HTML 보기";
            }
          });
        }

        // 복사 버튼 이벤트
        if (copyBtn) {
          copyBtn.addEventListener("click", async () => {
            const originalText = copyBtn.textContent;
            try {
              await copyToClipboard(doc.passage || "");
              copyBtn.textContent = "복사됨!";
              setTimeout(() => {
                copyBtn.textContent = originalText;
              }, 2000);
            } catch (err) {
              copyBtn.textContent = "복사 실패";
              setTimeout(() => {
                copyBtn.textContent = originalText;
              }, 2000);
            }
          });
        }

        refSection.appendChild(docItem);
      });
      wrapper.appendChild(refSection);
    }

    // 전체 검색 결과 통계
    if (detail.total_docs && detail.total_docs.results) {
      const statsSection = document.createElement("div");
      statsSection.className = "rag-section";

      const totalQueries = detail.total_docs.results.length;
      let totalRetrieved = 0;
      detail.total_docs.results.forEach((result) => {
        totalRetrieved += (result.retrieved_documents || []).length;
      });

      statsSection.innerHTML = `
        <h5>📊 검색 통계</h5>
        <div class="rag-stats">
          <div class="stat-item">
            <span class="stat-label">검색 쿼리 수</span>
            <span class="stat-value">${totalQueries}건</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">총 검색 문서 수</span>
            <span class="stat-value">${totalRetrieved}건</span>
          </div>
        </div>
      `;
      wrapper.appendChild(statsSection);

      // 각 쿼리별 상세 결과
      const queriesSection = document.createElement("details");
      queriesSection.className = "rag-section rag-queries";
      queriesSection.innerHTML = `<summary><h5>🔍 쿼리별 상세 결과 (${totalQueries}건)</h5></summary>`;

      detail.total_docs.results.forEach((result, idx) => {
        const queryItem = document.createElement("details");
        queryItem.className = "rag-query-item";
        const docCount = (result.retrieved_documents || []).length;

        const queryResultsDiv = document.createElement("div");
        queryResultsDiv.className = "query-results";

        queryItem.innerHTML = `
          <summary>
            <span class="query-number">쿼리 #${idx + 1}</span>
            <span class="query-text">${escapeHTML(
              result.query || "쿼리 없음"
            )}</span>
            <span class="doc-count">${docCount}건</span>
          </summary>
        `;

        (result.retrieved_documents || []).forEach((doc, docIdx) => {
          const isSelected = refDocIds.has(doc.id);
          const queryDocDiv = document.createElement("div");
          queryDocDiv.className = `query-doc${
            isSelected ? " selected-doc" : ""
          }`;
          const queryDocId = `query-doc-${idx}-${docIdx}`;
          const docSectionsConfig = [
            {
              field: "text",
              label: "본문 (text)",
            },
            {
              field: "parent_text",
              label: "상위 본문 (parent_text)",
            },
          ];
          const docSectionsHtml = docSectionsConfig
            .map(({ field, label }) => {
              const sectionId = `${queryDocId}-${field}`;
              const sectionValue = doc.payload?.[field] || "";
              return `
                <div class="doc-section">
                  <div class="doc-section-header"><strong>${label}</strong></div>
                  <div class="doc-controls">
                    <button class="toggle-view-btn" data-target="${sectionId}" data-field="${field}">HTML 보기</button>
                    <button class="copy-doc-btn" data-field="${field}">복사</button>
                  </div>
                  <div id="${sectionId}" class="doc-text" data-view-mode="text" data-field="${field}">
                    <pre>${escapeHTML(sectionValue || "내용 없음")}</pre>
                  </div>
                </div>
              `;
            })
            .join("");

          queryDocDiv.innerHTML = `
            <div class="query-doc-header">
              <span class="query-doc-number">#${docIdx + 1}</span>
              <span class="query-doc-score">점수: ${
                doc.score?.toFixed(6) || "N/A"
              }</span>
              ${
                isSelected
                  ? '<span class="selected-badge">✓ 참고문서로 선택됨</span>'
                  : ""
              }
            </div>
            <div class="query-doc-info">
              <div><strong>파일:</strong> ${escapeHTML(
                doc.payload?.file || "미확인"
              )}</div>
              <div><strong>페이지:</strong> ${
                doc.payload?.page_num || "N/A"
              }</div>
              <div><strong>그룹:</strong> ${escapeHTML(
                doc.payload?.group || "미확인"
              )}</div>
            </div>
            <details class="query-doc-content">
              <summary>본문 보기</summary>
              ${docSectionsHtml}
            </details>
          `;

          // 토글 버튼 이벤트
          const toggleBtns = queryDocDiv.querySelectorAll(".toggle-view-btn");
          toggleBtns.forEach((toggleBtn) => {
            const target = toggleBtn.dataset.target;
            const field = toggleBtn.dataset.field;
            if (!target || !field) return;
            const docTextDiv = queryDocDiv.querySelector(`#${target}`);
            if (!docTextDiv) return;
            toggleBtn.addEventListener("click", () => {
              const currentMode = docTextDiv.dataset.viewMode;
              const text = doc.payload?.[field] || "";
              if (currentMode === "text") {
                docTextDiv.innerHTML = text || "내용 없음";
                docTextDiv.dataset.viewMode = "html";
                toggleBtn.textContent = "텍스트 보기";
              } else {
                docTextDiv.innerHTML = `<pre>${escapeHTML(
                  text || "내용 없음"
                )}</pre>`;
                docTextDiv.dataset.viewMode = "text";
                toggleBtn.textContent = "HTML 보기";
              }
            });
          });

          // 복사 버튼 이벤트
          const copyBtns = queryDocDiv.querySelectorAll(".copy-doc-btn");
          copyBtns.forEach((copyBtn) => {
            const field = copyBtn.dataset.field;
            if (!field) return;
            copyBtn.addEventListener("click", async () => {
              const originalText = copyBtn.textContent;
              try {
                await copyToClipboard(doc.payload?.[field] || "");
                copyBtn.textContent = "복사됨!";
                setTimeout(() => {
                  copyBtn.textContent = originalText;
                }, 2000);
              } catch (err) {
                copyBtn.textContent = "복사 실패";
                setTimeout(() => {
                  copyBtn.textContent = originalText;
                }, 2000);
              }
            });
          });

          queryResultsDiv.appendChild(queryDocDiv);
        });

        queryItem.appendChild(queryResultsDiv);
        queriesSection.appendChild(queryItem);
      });
      wrapper.appendChild(queriesSection);
    }

    return wrapper;
  }

  function buildEntryCard(entry) {
    const card = document.createElement("article");
    card.className = "entry-card";
    if (entry.missingSteps.length) {
      card.classList.add("is-missing");
    }

    const header = document.createElement("header");
    header.innerHTML = `
      <h3>${escapeHTML(entry.id)}</h3>
      <div class="entry-meta">
        <span>요청 시각: ${formatDate(entry.issued)}</span>
        <span>총 소요: ${formatSeconds(entry.totalDuration)}</span>
        <span>단계 수: ${entry.logs.length}</span>
        ${entry.botId ? `<span>봇 ID: ${escapeHTML(entry.botId)}</span>` : ""}
        ${
          entry.userId
            ? `<span>사용자 ID: ${escapeHTML(entry.userId)}</span>`
            : ""
        }
      </div>
      <span class="badge ${entry.missingSteps.length ? "missing" : "complete"}">
        ${
          entry.missingSteps.length
            ? `단계 누락 ${entry.missingSteps.length}건`
            : "전체 단계 완료"
        }
      </span>
    `;
    card.appendChild(header);

    const qa = document.createElement("div");
    qa.className = "qa-summary";
    const linkedAnswer = linkifyURLs(escapeHTML(entry.finalAnswer || "미기록"));
    qa.innerHTML = `
      <div class="qa-item">
        <span class="qa-label">질문</span>
        <p class="qa-content">${escapeHTML(entry.firstQuestion || "미기록")}</p>
      </div>
      <div class="qa-item">
        <span class="qa-label">최종 답변</span>
        <p class="qa-content">${linkedAnswer}</p>
      </div>
    `;
    card.appendChild(qa);

    // RAG 검색 결과 카드 추가
    const ragLog = entry.logs.find((log) => log.step === RAG_STEP);
    console.log("RAG Log:", ragLog);
    if (ragLog && ragLog.body?.detail) {
      const ragCard = buildRagResultCard(
        ragLog.body.result,
        ragLog.body.detail
      );
      card.appendChild(ragCard);
    }

    if (entry.missingSteps.length) {
      const missingList = document.createElement("ul");
      missingList.className = "missing-list";
      entry.missingSteps.forEach((step) => {
        const li = document.createElement("li");
        li.textContent = step;
        missingList.appendChild(li);
      });
      card.appendChild(missingList);
    }

    const stepsWrapper = document.createElement("div");
    stepsWrapper.className = "entry-steps";
    entry.logs.forEach((log) => {
      const details = document.createElement("details");
      details.className = "step";
      const statusClass =
        log.status === "success"
          ? "success"
          : log.status
          ? "failure"
          : "unknown";
      const statusLabel =
        log.status === "success"
          ? "success"
          : log.status
          ? log.status
          : "미기록";
      const bodyText = formatBody(log.body);
      const escapedBody = escapeHTML(bodyText);
      details.innerHTML = `
        <summary>
          ${escapeHTML(log.step)}
          <span class="step-meta">
            <span>${formatSeconds(log.duration)}</span>
            <span>${formatDate(log.issued)}</span>
          </span>
          <span class="status-flag ${statusClass}">${escapeHTML(
        statusLabel
      )}</span>
        </summary>
        <div class="step-content">
          <div class="step-actions">
            <button class="copy-button" type="button">복사</button>
          </div>
          <pre>${escapedBody}</pre>
        </div>
      `;
      const copyButton = details.querySelector(".copy-button");
      if (copyButton) {
        const originalLabel = copyButton.textContent;
        copyButton.addEventListener("click", async (event) => {
          event.preventDefault();
          event.stopPropagation();
          try {
            copyButton.disabled = true;
            await copyToClipboard(bodyText);
            copyButton.textContent = "복사 완료";
            setTimeout(() => {
              copyButton.textContent = originalLabel;
              copyButton.disabled = false;
            }, 2000);
          } catch (err) {
            console.warn("Copy failed", err);
            copyButton.textContent = "복사 실패";
            setTimeout(() => {
              copyButton.textContent = originalLabel;
              copyButton.disabled = false;
            }, 2000);
          }
        });
      }
      stepsWrapper.appendChild(details);
    });
    card.appendChild(stepsWrapper);
    return card;
  }

  function renderEntries() {
    if (!state.entries.length) {
      refs.entryList.innerHTML = "<p>로드된 로그가 없습니다.</p>";
      refs.entryCount.textContent = "";
      refs.filterStatus.textContent = "데이터를 불러오면 요약이 표시됩니다.";
      refs.filterStatus.className = "status-pill info";
      return;
    }
    const filtered = applyFilters(state.entries);
    refs.entryList.innerHTML = "";
    filtered.forEach((entry) => {
      const card = buildEntryCard(entry);
      refs.entryList.appendChild(card);
    });
    const missingCount = state.entries.filter(
      (entry) => entry.missingSteps.length > 0
    ).length;
    const unansweredCount = state.entries.filter((entry) => {
      if (typeof entry.finalAnswer === "string") {
        return entry.finalAnswer.trim().length === 0;
      }
      return !entry.finalAnswer;
    }).length;
    refs.entryCount.textContent = `${filtered.length}건 표시 (전체 ${state.entries.length}건)`;
    const statusText = `${state.entries.length}건 중 ${filtered.length}건 표시 · 누락 단계가 있는 요청 ${missingCount}건 · 최종 답변 미기록 ${unansweredCount}건`;
    refs.filterStatus.textContent = statusText;
    refs.filterStatus.className = "status-pill success";
    if (!filtered.length) {
      const empty = document.createElement("p");
      empty.textContent = "조건에 맞는 요청이 없습니다. 필터를 조정해 보세요.";
      refs.entryList.appendChild(empty);
      refs.filterStatus.className = "status-pill warning";
    }
  }

  function renderAll() {
    renderSummary();
    renderStepStats();
    renderIntentStats();
    renderEntries();
  }

  function updateFiltersVisibility(hasData) {
    if (hasData) {
      refs.filters.classList.add("active");
    } else {
      refs.filters.classList.remove("active");
    }
  }

  function ingestData(rawData, sourceLabel = "수동 입력") {
    const asArray = Array.isArray(rawData) ? rawData : [rawData];
    const cleaned = asArray.filter((item) => item && typeof item === "object");
    if (!cleaned.length) {
      throw new Error("로그 항목을 찾지 못했습니다.");
    }
    const entries = cleaned.map(normalizeEntry);
    const expectedSteps = deriveExpectedSteps(entries);
    entries.forEach((entry) => {
      entry.missingSteps = computeMissingSteps(entry, expectedSteps);
      entry.searchText = buildSearchText(entry);
      const questionLog = entry.logs.find((log) => log.step === QUESTION_STEP);
      let answerLog = entry.logs.find((log) => log.step == ANSWER_STEP_FROM_DB);

      const questionBody = questionLog?.body;
      const answerBody = answerLog?.body;
      const questionText =
        typeof questionBody?.text === "string"
          ? questionBody.text
          : typeof questionBody?.detail?.text === "string"
          ? questionBody.detail.text
          : "";
      const answerText =
        typeof answerBody?.detail === "string"
          ? answerBody.detail
          : typeof answerBody?.detail?.answer === "string"
          ? answerBody.detail.answer
          : typeof answerBody?.detail?.llm_result?.answer === "string"
          ? answerBody.detail.llm_result.answer
          : typeof answerBody?.answer === "string"
          ? answerBody.answer
          : "";
      entry.firstQuestion = questionText ? questionText.trim() : "";
      entry.finalAnswer = answerText ? answerText.trim() : "";
    });
    state.entries = entries;
    state.expectedSteps = expectedSteps;
    state.intentStats = computeIntentStats(entries);
    state.search = "";
    state.stepFilter = "";
    state.missingOnly = false;
    state.unansweredOnly = false;
    state.sourceLabel = sourceLabel;
    refs.searchInput.value = "";
    refs.stepFilter.value = "";
    refs.missingOnly.checked = false;
    if (refs.unansweredOnly) {
      refs.unansweredOnly.checked = false;
    }
    updateStepFilterOptions(expectedSteps);
    updateFiltersVisibility(true);
    renderAll();
  }

  function handleFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result;
        const parsed = JSON.parse(text);
        ingestData(parsed, file.name);
        setStatus(`${file.name} 파일을 불러왔습니다.`, "success");
        setExcelDownloadTarget("");
        setJsonDownloadTarget("");
      } catch (err) {
        console.error(err);
        setStatus(`JSON 파싱 실패: ${err.message}`, "error");
      }
    };
    reader.onerror = () => {
      setStatus("파일을 읽는 중 오류가 발생했습니다.", "error");
    };
    reader.readAsText(file, "utf-8");
  }

  async function getLogFromTaskId(taskId) {
    const base = getBasePath();
    const encodedTaskId = encodeURIComponent(taskId);
    const url = `${base}/api/collections/logs/get-task/${encodedTaskId}`;
    const excelUrl = `${base}/api/collections/logs/get-task/${encodedTaskId}/excel`;
    const jsonUrl = `${base}/api/collections/logs/get-task/${encodedTaskId}/json`;
    await getLogFromUrl(url, {
      excelUrl,
      jsonUrl,
      sourceLabel: `Task ID: ${taskId}`,
      successMessage: "Task ID로 로그를 불러왔습니다.",
    });
  }

  async function getLogFromUrl(url, options = {}) {
    const {
      excelUrl = "",
      jsonUrl = "",
      sourceLabel = "DB 검색",
      successMessage = "DB에서 로그를 불러왔습니다.",
    } = options;
    const button = refs.apiFetchButton;
    const originalLabel = button?.textContent;
    if (button) {
      button.disabled = true;
      button.textContent = "불러오는 중...";
    }
    setStatus("DB에서 로그를 가져오는 중...", "info");
    setExcelDownloadTarget("");
    setJsonDownloadTarget("");
    try {
      const response = await fetch(url, { cache: "no-store" });
      if (response.status === 204) {
        setStatus("검색 조건에 해당하는 로그가 없습니다.", "warning");
        return;
      }
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const responseText = await response.text();
      const trimmed = responseText.trim();
      if (!trimmed) {
        setStatus("검색 조건에 해당하는 로그가 없습니다.", "warning");
        return;
      }
      let parsed;
      try {
        parsed = JSON.parse(trimmed);
      } catch (jsonError) {
        throw new Error("유효한 JSON 응답이 아닙니다.");
      }
      const payload = Array.isArray(parsed?.data)
        ? parsed.data
        : Array.isArray(parsed?.logs)
        ? parsed.logs
        : Array.isArray(parsed?.items)
        ? parsed.items
        : parsed;
      const hasData =
        payload &&
        (!Array.isArray(payload) || (Array.isArray(payload) && payload.length));
      if (!hasData) {
        setStatus("검색 조건에 해당하는 로그가 없습니다.", "warning");
        setExcelDownloadTarget("");
        setJsonDownloadTarget("");
        return;
      }
      ingestData(payload, sourceLabel);
      setStatus(successMessage, "success");
      setExcelDownloadTarget(excelUrl);
      setJsonDownloadTarget(jsonUrl);
    } catch (err) {
      console.error(err);
      setStatus(`DB 요청 실패: ${err.message}`, "error");
    } finally {
      if (button) {
        button.disabled = false;
        button.textContent = originalLabel || "로그 DB 검색";
      }
    }
  }

  refs.apiForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const question = refs.questionInput.value.trim();
    const startDate = refs.startDateInput.value;
    const endDate = refs.endDateInput.value;

    if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
      setStatus("시작 날짜가 종료 날짜보다 늦습니다.", "error");
      return;
    }

    if (!question && !startDate && !endDate) {
      const proceed = window.confirm(
        "질문 검색어·시작 날짜·종료 날짜가 모두 비어 있습니다.\n전체 로그 DB를 조회하므로 시간이 오래 걸릴 수 있습니다.\n계속 진행하시겠습니까?"
      );
      if (!proceed) {
        setStatus("전체 로그 검색을 취소했습니다.", "info");
        return;
      }
    }

    const params = new URLSearchParams();
    params.append("q", question);
    const startParam = buildDateParam(startDate);
    const endParam = buildDateParam(endDate, true);
    if (startParam) params.append("s", startParam);
    if (endParam) params.append("e", endParam);

    const queryString = params.toString();
    const base = getBasePath();
    const url = queryString
      ? `${base}/api/collections/logs/search?${queryString}`
      : `${base}/api/collections/logs/search`;
    const excelUrl = queryString
      ? `${base}/api/collections/logs/search/excel?${queryString}`
      : `${base}/api/collections/logs/search/excel`;
    const jsonUrl = queryString
      ? `${base}/api/collections/logs/search/json?${queryString}`
      : `${base}/api/collections/logs/search/json`;
    await getLogFromUrl(url, {
      excelUrl,
      jsonUrl,
      sourceLabel: "DB 검색",
      successMessage: "검색 조건으로 로그를 불러왔습니다.",
    });
  });

  refs.todayFetchButton.addEventListener("click", async () => {
    const base = getBasePath();
    const url = `${base}/api/collections/logs/today`;
    await getLogFromUrl(url, {
      excelUrl: `${base}/api/collections/logs/today/excel`,
      jsonUrl: `${base}/api/collections/logs/today/json`,
      sourceLabel: "오늘 로그",
      successMessage: "오늘 생성된 로그를 불러왔습니다.",
    });
  });

  updateExcelButtonState();
  updateJsonButtonState();

  if (refs.excelDownloadButton) {
    refs.excelDownloadButton.addEventListener(
      "click",
      downloadExcelForLastQuery
    );
  }

  if (refs.jsonDownloadButton) {
    refs.jsonDownloadButton.addEventListener("click", downloadJsonForLastQuery);
  }

  refs.fileInput.addEventListener("change", (event) => {
    const [file] = event.target.files || [];
    handleFile(file);
    event.target.value = "";
  });

  refs.dropzone.addEventListener("dragenter", (event) => {
    event.preventDefault();
    refs.dropzone.classList.add("dragover");
  });
  refs.dropzone.addEventListener("dragover", (event) => {
    event.preventDefault();
    refs.dropzone.classList.add("dragover");
  });
  refs.dropzone.addEventListener("dragleave", () => {
    refs.dropzone.classList.remove("dragover");
  });
  refs.dropzone.addEventListener("drop", (event) => {
    event.preventDefault();
    refs.dropzone.classList.remove("dragover");
    const files = event.dataTransfer?.files;
    if (files && files.length) {
      handleFile(files[0]);
    }
  });

  refs.searchInput.addEventListener("input", (event) => {
    state.search = event.target.value;
    renderEntries();
  });

  refs.stepFilter.addEventListener("change", (event) => {
    state.stepFilter = event.target.value;
    renderEntries();
  });

  refs.missingOnly.addEventListener("change", (event) => {
    state.missingOnly = event.target.checked;
    renderEntries();
  });

  if (refs.unansweredOnly) {
    refs.unansweredOnly.addEventListener("change", (event) => {
      state.unansweredOnly = event.target.checked;
      renderEntries();
    });
  }

  window.addEventListener("DOMContentLoaded", () => {
    if (TASK_ID) {
      getLogFromTaskId(TASK_ID);
      return;
    }

    setStatus(
      "로그 DB를 검색하거나 JSON 파일을 선택/드래그 하여 로그를 불러올 수 있습니다.",
      "info"
    );
  });
})();
