(function () {
  const state = {
    entries: [],
    filtered: [],
    search: "",
    status: "",
    ext: "",
    contentOnly: false,
    lastJsonUrl: "",
  };

  const refs = {
    apiForm: document.getElementById("api-form"),
    startDateInput: document.getElementById("start-date-input"),
    endDateInput: document.getElementById("end-date-input"),
    apiFetchButton: document.getElementById("api-fetch-button"),
    todayFetchButton: document.getElementById("today-fetch-button"),
    jsonDownloadButton: document.getElementById("json-download-button"),
    fileInput: document.getElementById("file-input"),
    dropzone: document.getElementById("dropzone"),
    loaderStatus: document.getElementById("loader-status"),
    filters: document.getElementById("filters"),
    searchInput: document.getElementById("search-input"),
    statusFilter: document.getElementById("status-filter"),
    extFilter: document.getElementById("ext-filter"),
    contentOnly: document.getElementById("content-only"),
    filterStatus: document.getElementById("filter-status"),
    summary: document.getElementById("summary"),
    entryCount: document.getElementById("entry-count"),
    entryList: document.getElementById("entry-list"),
  };

  const KNOWN_FIELDS = ["was", "message", "_issued_time", "_duration"];
  const JSON_BUTTON_LABEL = "JSON 다운로드";
  const JSON_BUTTON_LOADING_LABEL = "JSON 준비 중...";
  const TASK_ID = document.body?.dataset?.taskId || null;

  function setStatus(message, type = "info") {
    if (!refs.loaderStatus) return;
    refs.loaderStatus.textContent = message;
    refs.loaderStatus.className = "status-pill " + type;
  }

  function buildDateParam(dateString, endOfDay = false) {
    if (!dateString) return null;
    const time = endOfDay ? "23:59:59.999" : "00:00:00.000";
    const date = new Date(`${dateString}T${time}`);

    if (Number.isNaN(date.getTime())) return null;

    const pad = (n, z = 2) => String(n).padStart(z, "0");
    const yyyy = date.getFullYear();
    const mm = pad(date.getMonth() + 1);
    const dd = pad(date.getDate());
    const hh = pad(date.getHours());
    const mi = pad(date.getMinutes());
    const ss = pad(date.getSeconds());
    const ms = pad(date.getMilliseconds(), 3);

    return `${yyyy}-${mm}-${dd}T${hh}:${mi}:${ss}.${ms}`;
  }

  function getBasePath() {
    const path = window.location.pathname;
    const idx = path.indexOf("log-viewer");
    if (idx === -1) return "/log-viewer";
    return path.slice(0, idx + "log-viewer".length);
  }

  function updateJsonButtonState() {
    if (!refs.jsonDownloadButton) return;
    const hasTarget = !!state.lastJsonUrl;
    refs.jsonDownloadButton.disabled = !hasTarget;
    refs.jsonDownloadButton.title = hasTarget
      ? "현재 조회 조건으로 JSON을 내려받습니다."
      : "먼저 API로 로그를 불러오세요.";
  }

  function setJsonDownloadTarget(url) {
    state.lastJsonUrl = typeof url === "string" ? url : "";
    updateJsonButtonState();
  }

  function escapeHTML(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function formatDate(value) {
    if (!value) return "—";
    const date = typeof value === "string" ? new Date(value) : value;
    if (Number.isNaN(date.getTime())) return "—";
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(
      2,
      "0"
    )}-${String(date.getDate()).padStart(2, "0")} ${String(
      date.getHours()
    ).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(
      date.getSeconds()
    ).padStart(2, "0")}`;
  }

  function formatDuration(seconds) {
    if (
      seconds === null ||
      seconds === undefined ||
      Number.isNaN(Number(seconds))
    ) {
      return "—";
    }
    const value = Number(seconds);
    if (value < 1) return `${Math.round(value * 1000)} ms`;
    if (value < 10) return `${value.toFixed(2)} s`;
    return `${value.toFixed(1)} s`;
  }

  function formatNumber(value) {
    if (value === null || value === undefined || Number.isNaN(Number(value)))
      return "—";
    return Number(value).toLocaleString();
  }

  function truncate(text, max = 600) {
    if (typeof text !== "string") return "";
    if (text.length <= max) return text;
    return text.slice(0, max) + "…";
  }

  function deriveStatus(logs) {
    const hasSuccess = logs.some(
      (log) =>
        (typeof log.message === "string" &&
          log.message.includes("정상처리되었습니다")) ||
        log.chat_session_id ||
        log.chat_number
    );
    const hasError = logs.some(
      (log) =>
        log.error ||
        (typeof log.message === "string" &&
          (log.message.includes("에러") || log.message.includes("오류")))
    );
    if (hasSuccess) return "success";
    if (hasError) return "failure";
    return "pending";
  }

  function normalizeLog(log) {
    const payload = {};
    Object.entries(log || {}).forEach(([key, value]) => {
      if (!KNOWN_FIELDS.includes(key)) {
        payload[key] = value;
      }
    });
    return {
      was: log?.was || "log",
      message: log?.message || "",
      issuedTime: log?._issued_time || null,
      duration: typeof log?._duration === "number" ? log._duration : null,
      payload,
    };
  }

  function normalizeEntry(raw) {
    const logs = Array.isArray(raw?.logs) ? raw.logs.map(normalizeLog) : [];
    const downloadLog = logs.find(
      (l) => l.payload && l.payload.download_file_info
    );
    const fileContentLog = logs.find(
      (l) => typeof l.payload?.file_content === "string"
    );
    const contentLength =
      fileContentLog?.payload?.file_length ??
      (fileContentLog?.payload?.file_content
        ? fileContentLog.payload.file_content.length
        : undefined);

    const status = deriveStatus(raw?.logs || []);
    const issued =
      raw?.issued_time ||
      raw?.issuedTime ||
      raw?.issued_at ||
      logs[0]?.issuedTime ||
      null;

    return {
      id: raw?._id || raw?.id || "",
      botId: raw?.bot_id || raw?.botId || "",
      userId: raw?.user_id || raw?.userId || "",
      issuedTime: issued,
      totalDuration:
        typeof raw?.total_duration === "number"
          ? raw.total_duration
          : typeof raw?.totalDuration === "number"
          ? raw.totalDuration
          : null,
      status,
      downloadInfo: downloadLog?.payload?.download_file_info || null,
      fileContent: fileContentLog?.payload?.file_content,
      fileLength: contentLength,
      chatSessionId:
        raw?.chat_session_id || fileContentLog?.payload?.chat_session_id,
      chatNumber: raw?.chat_number || fileContentLog?.payload?.chat_number,
      logs,
      raw,
    };
  }

  function updateFilters() {
    state.search = refs.searchInput?.value?.trim() || "";
    state.status = refs.statusFilter?.value || "";
    state.ext = refs.extFilter?.value || "";
    state.contentOnly = !!refs.contentOnly?.checked;
    applyFilters();
  }

  function applyFilters() {
    state.filtered = state.entries.filter((entry) => {
      if (state.status && entry.status !== state.status) return false;
      if (state.ext && entry.downloadInfo?.file_extension !== state.ext)
        return false;
      if (state.contentOnly && !entry.fileContent) return false;

      if (state.search) {
        const needle = state.search.toLowerCase();
        const haystack = [
          entry.id,
          entry.botId,
          entry.userId,
          entry.downloadInfo?.file_name,
          entry.downloadInfo?.file_id,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();

        const matchesMeta = haystack.includes(needle);
        const matchesLogs = entry.logs.some(
          (log) =>
            log.message?.toLowerCase().includes(needle) ||
            JSON.stringify(log.payload || {})
              .toLowerCase()
              .includes(needle)
        );

        if (!matchesMeta && !matchesLogs) return false;
      }
      return true;
    });

    render();
  }

  function buildExtensionOptions(entries) {
    if (!refs.extFilter) return;
    const exts = new Set();
    entries.forEach((entry) => {
      if (entry.downloadInfo?.file_extension) {
        exts.add(entry.downloadInfo.file_extension);
      }
    });
    const current = refs.extFilter.value;
    refs.extFilter.innerHTML =
      '<option value="">전체 확장자</option>' +
      Array.from(exts)
        .sort()
        .map(
          (ext) =>
            `<option value="${escapeHTML(ext)}"${
              current === ext ? " selected" : ""
            }>${escapeHTML(ext)}</option>`
        )
        .join("");
  }

  function renderSummary() {
    if (!refs.summary) return;
    if (!state.filtered.length) {
      refs.summary.innerHTML = "";
      return;
    }
    const total = state.filtered.length;
    const success = state.filtered.filter((e) => e.status === "success").length;
    const failure = state.filtered.filter((e) => e.status === "failure").length;
    const avgDuration =
      state.filtered.reduce((acc, e) => acc + (e.totalDuration || 0), 0) /
      total;
    const avgLength =
      state.filtered.reduce((acc, e) => acc + (e.fileLength || 0), 0) / total;

    refs.summary.innerHTML = `
      <div class="summary-grid">
        <div class="stat-card">
          <strong>${formatNumber(total)}</strong>
          <span>총 파일 작업</span>
        </div>
        <div class="stat-card">
          <strong>${formatNumber(success)}</strong>
          <span>성공</span>
        </div>
        <div class="stat-card">
          <strong>${formatNumber(failure)}</strong>
          <span>실패</span>
        </div>
        <div class="stat-card">
          <strong>${formatDuration(avgDuration)}</strong>
          <span>평균 처리 시간</span>
        </div>
        <div class="stat-card">
          <strong>${formatNumber(Math.round(avgLength))}</strong>
          <span>평균 파일 길이(문자)</span>
        </div>
      </div>
    `;
  }

  function renderFilterStatus() {
    if (!refs.filterStatus) return;
    const total = state.entries.length;
    const visible = state.filtered.length;
    refs.filterStatus.textContent = `${formatNumber(visible)} / ${formatNumber(
      total
    )}개 노출`;
    refs.filterStatus.className = "status-pill info";
  }

  function renderEntries() {
    if (!refs.entryList) return;
    refs.entryCount.textContent = state.filtered.length
      ? `${formatNumber(state.filtered.length)}건`
      : "0건";

    if (!state.filtered.length) {
      refs.entryList.innerHTML = `<div class="empty-state">불러온 로그가 없거나 필터 조건을 만족하는 항목이 없습니다.</div>`;
      return;
    }

    const nodes = state.filtered
      .map((entry) => {
        const statusClass =
          entry.status === "success"
            ? "pill success"
            : entry.status === "failure"
            ? "pill error"
            : "pill pending";
        const fileName =
          entry.downloadInfo?.file_name ||
          entry.downloadInfo?.file_id ||
          "알 수 없는 파일";
        const fileExt = entry.downloadInfo?.file_extension
          ? `.${entry.downloadInfo.file_extension}`
          : "";
        const duration = formatDuration(entry.totalDuration);
        const contentLabel =
          entry.fileLength || entry.fileContent
            ? `${formatNumber(entry.fileLength || entry.fileContent?.length)}자`
            : "본문 없음";

        const logSteps = entry.logs.map((log) => renderLogStep(log)).join("");

        return `
          <article class="entry-card">
            <header>
              <h3>
                <span class="${statusClass}">${entry.status}</span>
                <span class="file-chip">${escapeHTML(
                  fileName
                )} <small>${escapeHTML(fileExt)}</small></span>
              </h3>
              <div class="entry-meta">
                <span>Task ID: ${escapeHTML(entry.id)}</span>
                <span>Bot: ${escapeHTML(entry.botId || "—")}</span>
                <span>User: ${escapeHTML(entry.userId || "—")}</span>
                <span>기록 시각: ${escapeHTML(
                  formatDate(entry.issuedTime)
                )}</span>
                <span>총 소요: ${escapeHTML(duration)}</span>
                <span>파일 길이: ${escapeHTML(contentLabel)}</span>
              </div>
            </header>

            <div class="meta-grid">
              <div class="meta-item">
                <span class="meta-label">다운로드 ID</span>
                <span class="meta-value">${escapeHTML(
                  entry.downloadInfo?.file_id || "—"
                )}</span>
              </div>
              <div class="meta-item">
                <span class="meta-label">확장자</span>
                <span class="meta-value">${escapeHTML(
                  entry.downloadInfo?.file_extension || "—"
                )}</span>
              </div>
              <div class="meta-item">
                <span class="meta-label">발급 시간</span>
                <span class="meta-value">${escapeHTML(
                  formatDate(entry.downloadInfo?.issued_time)
                )}</span>
              </div>
              <div class="meta-item">
                <span class="meta-label">대화 기록</span>
                <span class="meta-value">${escapeHTML(
                  entry.chatSessionId || entry.chatNumber
                    ? `session ${entry.chatSessionId || "?"}, #${
                        entry.chatNumber || "?"
                      }`
                    : "—"
                )}</span>
              </div>
            </div>

            <div class="log-steps">
              ${logSteps}
            </div>
          </article>
        `;
      })
      .join("");

    refs.entryList.innerHTML = nodes;
  }

  function renderLogStep(log) {
    const payload = { ...(log.payload || {}) };
    const hasFileContent = typeof payload.file_content === "string";
    const fileLength =
      payload.file_length || (hasFileContent ? payload.file_content.length : 0);
    if (hasFileContent) {
      delete payload.file_content;
    }

    const payloadKeys = Object.keys(payload).filter(
      (key) => payload[key] !== undefined
    );

    const payloadHTML =
      payloadKeys.length || hasFileContent
        ? `
      <div class="log-step__payload">
        ${
          hasFileContent
            ? `<details open>
                <summary>파일 본문 미리보기 (${formatNumber(
                  fileLength
                )}자)</summary>
                <pre>${escapeHTML(
                  truncate(log.payload.file_content, 1200)
                )}</pre>
              </details>`
            : ""
        }
        ${
          payloadKeys.length
            ? `<details>
                <summary>추가 정보 보기 (${payloadKeys.length}개)</summary>
                <pre>${escapeHTML(JSON.stringify(payload, null, 2))}</pre>
              </details>`
            : ""
        }
      </div>`
        : "";

    return `
      <div class="log-step">
        <div class="log-step__head">
          <span class="badge">${escapeHTML(log.was || "log")}</span>
          <span class="log-step__title">${escapeHTML(
            log.message || "메시지 없음"
          )}</span>
        </div>
        <div class="log-step__meta">
          <span>${escapeHTML(formatDate(log.issuedTime))}</span>
          <span>소요 ${escapeHTML(formatDuration(log.duration))}</span>
        </div>
        ${payloadHTML}
      </div>
    `;
  }

  function render() {
    renderSummary();
    renderFilterStatus();
    renderEntries();
  }

  function handleDataArray(parsed) {
    state.entries = parsed.map(normalizeEntry);
    buildExtensionOptions(state.entries);
    refs.filters?.classList.add("active");
    applyFilters();
  }

  function handleFileContent(text) {
    try {
      const parsed = JSON.parse(text);
      if (!Array.isArray(parsed)) {
        setStatus("JSON 배열을 전달해 주세요.", "warning");
        return;
      }
      setJsonDownloadTarget("");
      setStatus(`총 ${parsed.length}건을 불러왔습니다.`, "success");
      handleDataArray(parsed);
    } catch (err) {
      console.error(err);
      setStatus("JSON 파싱에 실패했습니다.", "error");
    }
  }

  function handleFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => handleFileContent(e.target.result);
    reader.onerror = () =>
      setStatus("파일을 읽는 중 오류가 발생했습니다.", "error");
    reader.readAsText(file, "utf-8");
  }

  function setupFileInput() {
    refs.fileInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      handleFile(file);
      refs.fileInput.value = "";
    });
  }

  function setupDropzone() {
    if (!refs.dropzone) return;
    const prevent = (e) => {
      e.preventDefault();
      e.stopPropagation();
    };
    ["dragenter", "dragover", "dragleave", "drop"].forEach((event) => {
      refs.dropzone.addEventListener(event, prevent);
    });
    ["dragenter", "dragover"].forEach((event) => {
      refs.dropzone.addEventListener(event, () =>
        refs.dropzone.classList.add("dragover")
      );
    });
    ["dragleave", "drop"].forEach((event) => {
      refs.dropzone.addEventListener(event, () =>
        refs.dropzone.classList.remove("dragover")
      );
    });
    refs.dropzone.addEventListener("drop", (e) => {
      const file = e.dataTransfer?.files?.[0];
      handleFile(file);
    });
  }

  function setupFilters() {
    refs.searchInput?.addEventListener("input", () => updateFilters());
    refs.statusFilter?.addEventListener("change", () => updateFilters());
    refs.extFilter?.addEventListener("change", () => updateFilters());
    refs.contentOnly?.addEventListener("change", () => updateFilters());
  }

  async function downloadJsonForLastQuery() {
    if (!state.lastJsonUrl) {
      setStatus("먼저 API로 로그를 불러와 주세요.", "warning");
      return;
    }
    const button = refs.jsonDownloadButton;
    if (!button) return;
    const originalLabel = button.textContent;
    button.disabled = true;
    button.textContent = JSON_BUTTON_LOADING_LABEL;
    try {
      const response = await fetch(state.lastJsonUrl, { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const blob = await response.blob();
      const downloadUrl = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = downloadUrl;
      anchor.download = `file_logs_${Date.now()}.json`;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      URL.revokeObjectURL(downloadUrl);
      setStatus("JSON 파일을 다운로드했습니다.", "success");
    } catch (err) {
      console.error(err);
      setStatus(`JSON 다운로드 실패: ${err.message}`, "error");
    } finally {
      button.textContent = originalLabel || JSON_BUTTON_LABEL;
      button.disabled = !state.lastJsonUrl;
    }
  }

  async function fetchLogsFromTaskId(taskId) {
    if (!taskId) return;
    const basePath = getBasePath();
    const url = new URL(
      `${basePath}/api/collections/file-proc-logs/get-task/${encodeURIComponent(
        taskId
      )}`,
      window.location.origin
    );

    setStatus("로그를 불러오는 중입니다...", "info");
    setJsonDownloadTarget("");

    try {
      const response = await fetch(url.toString(), { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const data = await response.json();
      if (!Array.isArray(data)) {
        throw new Error("API 응답이 배열이 아닙니다.");
      }
      setStatus(`총 ${data.length}건을 불러왔습니다.`, "success");
      handleDataArray(data);

      const jsonUrl = `${basePath}/api/collections/file-proc-logs/get-task/${encodeURIComponent(
        taskId
      )}/json`;
      setJsonDownloadTarget(jsonUrl);
    } catch (err) {
      console.error(err);
      setStatus(`API 호출 실패: ${err.message}`, "error");
    }
  }

  async function fetchLogsFromApi({ startDate, endDate, today = false }) {
    const basePath = getBasePath();
    const url = new URL(
      `${basePath}/api/collections/file-proc-logs/${
        today ? "today" : "search"
      }`,
      window.location.origin
    );

    if (!today) {
      const start = buildDateParam(startDate, false);
      const end = buildDateParam(endDate, true);
      if (start) url.searchParams.set("s", start);
      if (end) url.searchParams.set("e", end);
    }

    setStatus("로그를 불러오는 중입니다...", "info");
    setJsonDownloadTarget("");

    try {
      const response = await fetch(url.toString(), { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const data = await response.json();
      if (!Array.isArray(data)) {
        throw new Error("API 응답이 배열이 아닙니다.");
      }
      setStatus(`총 ${data.length}건을 불러왔습니다.`, "success");
      handleDataArray(data);

      const jsonUrl = today
        ? `${basePath}/api/collections/file-proc-logs/today/json`
        : `${basePath}/api/collections/file-proc-logs/search/json${url.search}`;
      setJsonDownloadTarget(jsonUrl);
    } catch (err) {
      console.error(err);
      setStatus(`API 호출 실패: ${err.message}`, "error");
    }
  }

  function setupApiControls() {
    refs.apiForm?.addEventListener("submit", (e) => {
      e.preventDefault();
      const startDate = refs.startDateInput?.value || "";
      const endDate = refs.endDateInput?.value || "";

      if (!startDate && !endDate) {
        const proceed = window.confirm(
          "시작 날짜·종료 날짜가 모두 비어 있습니다.\n전체 로그 DB를 조회하므로 시간이 오래 걸릴 수 있습니다.\n계속 진행하시겠습니까?"
        );
        if (!proceed) {
          setStatus("전체 로그 검색을 취소했습니다.", "info");
          return;
        }
      }

      fetchLogsFromApi({ startDate, endDate, today: false });
    });
    refs.todayFetchButton?.addEventListener("click", (e) => {
      e.preventDefault();
      fetchLogsFromApi({ today: true });
    });
    refs.jsonDownloadButton?.addEventListener(
      "click",
      downloadJsonForLastQuery
    );
    updateJsonButtonState();
  }

  function init() {
    setupFileInput();
    setupDropzone();
    setupFilters();
    setupApiControls();
    setStatus("로그 파일을 불러와 주세요.", "info");

    if (TASK_ID) {
      fetchLogsFromTaskId(TASK_ID);
    }
  }

  init();
})();
