import logging
import os
from datetime import datetime
from typing import Annotated

from dotenv import load_dotenv
from fastapi import APIRouter, Body, Response
from pymongo import AsyncMongoClient

load_dotenv()

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/write-log",
)


@router.post("/collections/{collection}/tasks/{task_id}/bots/{bot_id}/users/{user_id}")
async def write_log(
    task_id: str,
    bot_id: str,
    user_id: str,
    collection: str,
    log: Annotated[dict, Body(...)],
):
    """로그 기록을 위한 API"""
    logger.info(
        f"로그 기록 수신: task_id={task_id}, bot_id={bot_id}, user_id={user_id}, log={log}"
    )

    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db[collection]

    document = await logs.find_one({"_id": task_id})

    if document:  # 이미 존재하는 document인 경우
        # 이전 log의 _issued_time을 가져와서 duration을 계산하여 업데이트

        log["_issued_time"] = datetime.now()

        previous_log = document["logs"][-1] if document["logs"] else None
        if previous_log:
            previous_date = previous_log.get("_issued_time")
            if previous_date:
                duration = (log["_issued_time"] - previous_date).total_seconds()
                log["_duration"] = duration

                # total_duration 업데이트
                await logs.update_one(
                    {"_id": task_id}, {"$inc": {"total_duration": duration}}
                )

        await logs.update_one({"_id": task_id}, {"$push": {"logs": log}})
    else:
        log["_issued_time"] = datetime.now()
        log["_duration"] = 0  # 첫 로그이므로 duration은 0으로 설정
        new_document = {
            "_id": task_id,
            "bot_id": bot_id,
            "user_id": user_id,
            "issued_time": datetime.now(),
            "total_duration": 0,
            "logs": [log],
        }
        await logs.insert_one(new_document)

    return Response(status_code=200)
