import json
import logging
import os
from datetime import datetime
from typing import Annotated, Optional

from dotenv import load_dotenv
from fastapi import APIRouter, Depends, Query, Request, Response
from fastapi.encoders import jsonable_encoder
from fastapi.templating import Jinja2Templates
from pymongo import AsyncMongoClient

from app.utils.excel_log_export import ExcelLogExporter

load_dotenv()

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/log-viewer",
)

FILE_TYPE = "file"

FILE_LOG_COLLECTION = "file-proc-logs"
LOG_COLLECTION = "logs"


def get_jinja2_templates():
    return Jinja2Templates(directory="templates")


def _build_file_name(prefix: str, extension: str) -> str:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_prefix = prefix.replace(" ", "_") if prefix else "log"
    return f"{safe_prefix}_{timestamp}.{extension}"


def _json_attachment(data, prefix: str = "log") -> Response:
    payload = jsonable_encoder(data)
    json_bytes = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    file_name = _build_file_name(prefix, "json")
    headers = {"Content-Disposition": f'attachment; filename="{file_name}"'}
    return Response(json_bytes, media_type="application/json", headers=headers)


@router.get("")
async def log_viewer(
    request: Request,
    templates: Annotated[Jinja2Templates, Depends(get_jinja2_templates)],
    type: str = Query(None, description="로그 뷰어 타입"),
    task: str = Query(None, description="로그 조회할 task id"),
):
    logger.info(f"로그 뷰어 접속: task={task}")
    if not task:
        task = ""

    if type == FILE_TYPE:
        return templates.TemplateResponse(
            "file-log-viewer.html", {"request": request, "task": task}
        )

    return templates.TemplateResponse(
        "log-viewer.html", {"request": request, "task": task}
    )


@router.get("/api/collections/{collection}/get-task/{task_id}")
async def get_task_logs(
    collection: str,
    task_id: str,
):
    """로그 조회을 위한 API - task id 기준"""
    logger.info(f"로그 조회(task) 요청: task_id={task_id}")

    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db.get_collection(collection)

    cursor = logs.find({"_id": task_id})
    result = await cursor.to_list(length=1)

    return result


@router.get("/api/collections/{collection}/get-task/{task_id}/excel")
async def get_task_logs_excel(
    collection: str,
    task_id: str,
):
    """로그 조회을 위한 API - task id 기준 (엑셀 다운로드용)"""

    if collection != LOG_COLLECTION:
        return Response(
            content=f"엑셀 다운로드는 '{LOG_COLLECTION}' 타입에서만 지원됩니다.",
            status_code=400,
        )

    result = await get_task_logs(collection, task_id)
    result = result[::-1]  # 최신 로그가 아래로 가도록 순서 변경

    excel_buffer = ExcelLogExporter(result).to_bytes_io()

    file_name = f"log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

    headers = {"Content-Disposition": f'attachment; filename="{file_name}"'}

    return Response(
        excel_buffer.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers,
    )


@router.get("/api/collections/{collection}/get-task/{task_id}/json")
async def get_task_logs_json(
    collection: str,
    task_id: str,
):
    """로그 조회 - task id 기준 (JSON 다운로드용)"""

    result = await get_task_logs(collection, task_id)
    result = result[::-1]
    return _json_attachment(result, prefix=f"task_{task_id}")


@router.get("/api/collections/{collection}/today")
async def query_log_today(
    collection: str,
):
    """로그 조회을 위한 API - 오늘 생성된 로그 기준"""
    today_start = datetime.combine(datetime.now().date(), datetime.min.time())
    logger.info(f"로그 조회(today) 요청: today_start={today_start}")

    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db.get_collection(collection)

    cursor = logs.find({"issued_time": {"$gte": today_start}}).sort("issued_time", -1)
    result = await cursor.to_list()

    return result


@router.get("/api/collections/{collection}/today/excel")
async def query_log_today_excel(
    collection: str,
):
    """로그 조회을 위한 API - 오늘 생성된 로그 기준 (엑셀 다운로드용)"""

    if collection != LOG_COLLECTION:
        return Response(
            content=f"엑셀 다운로드는 '{LOG_COLLECTION}' 타입에서만 지원됩니다.",
            status_code=400,
        )

    result = await query_log_today(collection)
    result = result[::-1]  # 최신 로그가 아래로 가도록 순서 변경

    excel_buffer = ExcelLogExporter(result).to_bytes_io()

    file_name = f"log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

    headers = {"Content-Disposition": f'attachment; filename="{file_name}"'}

    return Response(
        excel_buffer.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers,
    )


@router.get("/api/collections/{collection}/today/json")
async def query_log_today_json(
    collection: str,
):
    """오늘 생성된 로그 기준 (JSON 다운로드용)"""

    result = await query_log_today(collection)
    result = result[::-1]
    return _json_attachment(result, prefix="today")


@router.get("/api/collections/{collection}/search")
async def query_log_search(
    collection: str,
    q: str = Query(None, description="검색할 질문 내용"),
    s: Optional[datetime] = Query(None, description="검색 시작 시간"),
    e: Optional[datetime] = Query(None, description="검색 종료 시간"),
):
    """로그 조회을 위한 API - 질문 기준"""
    question = q
    start_time = s
    end_time = e

    logger.info(
        f"로그 조회(question-search) 요청: question={question} start_time={start_time} end_time={end_time}"
    )

    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db.get_collection(collection)

    query = {}
    if question and collection == LOG_COLLECTION:
        query["logs.BODY.text"] = {"$regex": question}

    if end_time is None:
        end_time = datetime.now()

    if start_time is None:
        start_time = datetime.min

    query["issued_time"] = {"$gte": start_time, "$lte": end_time}

    cursor = logs.find(query).sort("issued_time", -1)

    result = await cursor.to_list()

    return result


@router.get("/api/collections/{collection}/search/excel")
async def query_log_search_excel(
    collection: str,
    q: str = Query(None, description="검색할 질문 내용"),
    s: Optional[datetime] = Query(None, description="검색 시작 시간"),
    e: Optional[datetime] = Query(None, description="검색 종료 시간"),
):
    """로그 조회을 위한 API - 질문 기준 (엑셀 다운로드용)"""
    if collection != LOG_COLLECTION:
        return Response(
            content=f"엑셀 다운로드는 '{LOG_COLLECTION}' 타입에서만 지원됩니다.",
            status_code=400,
        )

    result = await query_log_search(collection, q, s, e)
    result = result[::-1]  # 최신 로그가 아래로 가도록 순서 변경

    excel_buffer = ExcelLogExporter(result).to_bytes_io()

    file_name = f"log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

    headers = {"Content-Disposition": f'attachment; filename="{file_name}"'}

    return Response(
        excel_buffer.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers,
    )


@router.get("/api/collections/{collection}/search/json")
async def query_log_search_json(
    collection: str,
    q: str = Query(None, description="검색할 질문 내용"),
    s: Optional[datetime] = Query(None, description="검색 시작 시간"),
    e: Optional[datetime] = Query(None, description="검색 종료 시간"),
):
    """질문 기준 로그 조회 (JSON 다운로드용)"""

    result = await query_log_search(collection, q, s, e)
    result = result[::-1]
    prefix = "search_log"

    return _json_attachment(result, prefix=prefix)
