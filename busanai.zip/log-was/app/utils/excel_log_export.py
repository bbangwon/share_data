from io import BytesIO
from typing import Any, Dict, Iterable, List, Optional

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, Side


class ExcelLogExporter:
    QUESTION_STEP = "01. Task WAS 메세지큐 수신"
    ANSWER_STEPS = (
        "08. DB 최종답변 저장",
        "07_02. 참고자료있는 경우 추가",
        "07_01. LLM WAS 최종답변 생성 API 요청",
    )
    RAG_STEP = "06_05. RAG 검색 API 요청"
    LLM_STEP = "07_01. LLM WAS 최종답변 생성 API 요청"
    HEADERS = [
        "질의문",
        "task_id",
        "SLM 답변",
        "doc_id",
        "score",
        "group",
        "file",
        "page_num",
    ]

    def __init__(self, logs: Any):
        self.logs = logs

    def log_to_excel(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Logs"
        sheet.append(self.HEADERS)

        entries = self.logs if isinstance(self.logs, list) else [self.logs]

        # 모든 엔트리에서 대상 행 개수를 가져옴 (먼저 전체 스캔)
        target_row_count = self._get_max_retrieved_documents_count()

        current_row = 2  # 헤더 다음부터 시작
        for entry in entries:
            if not isinstance(entry, dict):
                continue

            task_id = str(entry.get("_id", ""))
            logs = entry.get("logs", [])
            if not isinstance(logs, list):
                logs = []

            # target_row_count를 사용하여 이 엔트리의 행들을 구성
            rows, ref_doc_ids = self._build_entry_rows(entry, target_row_count)
            num_rows = len(rows)

            # 하이라이팅을 위해 LLM에서 사용된 RAG ID 추출
            rag_ids = self._extract_rag_ids(logs)

            # 테두리 스타일링을 위한 ref_doc 행의 인덱스 찾기
            ref_doc_row_indices = [
                i for i, row in enumerate(rows) if row[3] and row[3] in ref_doc_ids
            ]

            # 행 추가 및 서식 적용
            for i, row in enumerate(rows):
                # task_id 설정
                row[1] = task_id
                sheet.append(row)

                doc_id = row[3]

                # LLM에서 사용된 경우 doc_id 하이라이트
                if doc_id and doc_id in rag_ids:
                    for col_idx in range(4, 9):
                        sheet.cell(row=current_row + i, column=col_idx).font = Font(
                            color="FF0000"
                        )

                # ref_docs에 대한 테두리 적용
                if doc_id and doc_id in ref_doc_ids:
                    self._apply_ref_doc_border(
                        sheet, current_row, i, ref_doc_row_indices
                    )

            # 이 행들에 대해 1-3열(A-C) 병합
            if num_rows > 0:
                for col in range(1, 4):
                    sheet.merge_cells(
                        start_row=current_row,
                        start_column=col,
                        end_row=current_row + num_rows - 1,
                        end_column=col,
                    )

            current_row += num_rows

        self._apply_styling(sheet)
        return workbook

    def _apply_styling(self, sheet):
        """워크시트에 스타일 적용"""
        # 행 높이 및 셀 정렬
        for row in range(2, sheet.max_row + 1):
            sheet.row_dimensions[row].height = 90
            for col in range(1, len(self.HEADERS) + 1):
                cell = sheet.cell(row=row, column=col)
                cell.alignment = Alignment(wrap_text=True, vertical="top")

        # 열 너비
        column_widths = {
            "A": 30,
            "B": 10,
            "C": 50,
            "D": 10,
            "E": 10,
            "F": 10,
            "G": 30,
            "H": 10,
        }
        for col, width in column_widths.items():
            sheet.column_dimensions[col].width = width

    def _build_entry_rows(self, entry: Dict[str, Any], target_row_count: int = 1):
        """(rows, ref_doc_ids_set)을 반환"""
        logs = entry.get("logs", [])
        question = self._extract_question(logs)
        answer = self._extract_answer(logs)

        # reasoning_selector에서 updated_scores 추출
        rag_log = next((log for log in logs if log.get("STEP") == self.RAG_STEP), None)
        updated_scores_map = {}
        if rag_log:
            detail = rag_log.get("BODY", {}).get("detail", {})
            reasoning_selector = detail.get("reasoning_selector", {})
            updated_scores = reasoning_selector.get("updated_scores", [])
            if updated_scores:
                updated_scores_map = {
                    item["id"]: item["score"]
                    for item in updated_scores
                    if "id" in item and "score" in item
                }

        return self._build_rag_rows(
            logs, question, answer, target_row_count, updated_scores_map
        )

    def _build_rag_rows(
        self,
        logs: Iterable[Dict[str, Any]],
        question: str,
        answer: str,
        target_row_count: int = 1,
        updated_scores_map: Dict[str, float] = None,
    ):
        """retrieved_documents로부터 행을 구성. (rows, ref_doc_ids_set)을 반환"""
        rows = []
        ref_doc_ids = set()

        if updated_scores_map is None:
            updated_scores_map = {}

        rag_log = next((log for log in logs if log.get("STEP") == self.RAG_STEP), None)
        if not rag_log:
            # RAG 로그가 없으면 빈 행 생성
            for _ in range(target_row_count):
                rows.append(self._base_row(question, answer))
            return rows, ref_doc_ids

        detail = rag_log.get("BODY", {}).get("detail", {})
        if not detail:
            # detail이 없으면 빈 행 생성
            for _ in range(target_row_count):
                rows.append(self._base_row(question, answer))
            return rows, ref_doc_ids

        # 테두리 하이라이팅을 위한 ref_docs ID 가져오기
        ref_docs = detail.get("ref_docs", []) or []
        ref_doc_ids = {d.get("id") for d in ref_docs if d.get("id")}

        # total_docs.results[0]에서 retrieved_documents 가져오기
        total_docs = detail.get("total_docs", {})
        results = total_docs.get("results", []) or []

        retrieved_documents = []
        if results:
            retrieved_documents = results[0].get("retrieved_documents", []) or []

        # 행 생성: 먼저 실제 데이터로 채우고, 필요시 빈 행 추가
        for i in range(target_row_count):
            if i < len(retrieved_documents):
                doc = retrieved_documents[i]
                doc_id = doc.get("id", "")
                payload = doc.get("payload", {})
                original_score = doc.get("score", 0)

                # updated_scores_map에 업데이트된 점수가 있는지 확인
                if doc_id in updated_scores_map:
                    updated_score = updated_scores_map[doc_id]
                    score_display = f"{updated_score} ({original_score})"
                else:
                    score_display = original_score

                rows.append(
                    [
                        question,
                        "",  # task_id (나중에 채움)
                        answer,
                        doc_id,
                        score_display,
                        payload.get("group", ""),
                        payload.get("file", ""),
                        payload.get("page_num", ""),
                    ]
                )
            else:
                # 빈 행
                rows.append(self._base_row(question, answer))

        return rows, ref_doc_ids

    def _get_max_retrieved_documents_count(self) -> int:
        """모든 엔트리를 스캔하여 retrieved_documents의 최대 개수를 찾음.
        문서가 없어도 최소 1을 반환."""
        max_count = 0
        entries = self.logs if isinstance(self.logs, list) else [self.logs]

        for entry in entries:
            if not isinstance(entry, dict):
                continue

            logs = entry.get("logs", [])
            if not isinstance(logs, list):
                logs = []

            rag_log = next(
                (log for log in logs if log.get("STEP") == self.RAG_STEP), None
            )
            if not rag_log:
                continue

            detail = rag_log.get("BODY", {}).get("detail", {})
            if not detail:
                continue

            total_docs = detail.get("total_docs", {})
            results = total_docs.get("results", []) or []

            if results:
                retrieved_documents = results[0].get("retrieved_documents", []) or []
                doc_count = len(retrieved_documents)
                if doc_count > 0:
                    max_count = max(max_count, doc_count)
                    # 모든 0이 아닌 개수는 동일해야 하므로 조기 반환 가능
                    return max_count

        # 최소 1행 반환
        return max(max_count, 1)

    def _base_row(self, question: str, answer: str) -> List[Any]:
        return [
            question,
            "",
            answer,
            "",
            "",
            "",
            "",
            "",
        ]

    def _apply_ref_doc_border(
        self, sheet, current_row: int, row_idx: int, ref_doc_row_indices: List[int]
    ):
        """ref_doc 셀에 테두리 스타일 적용"""

        for col_idx in range(4, 9):
            cell = sheet.cell(row=current_row + row_idx, column=col_idx)
            left = Side(style="thick", color="87CEEB") if col_idx == 4 else None
            right = Side(style="thick", color="87CEEB") if col_idx == 8 else None
            top = Side(style="thick", color="87CEEB")
            bottom = Side(style="thick", color="87CEEB")
            cell.border = Border(left=left, right=right, top=top, bottom=bottom)

    def _extract_question(self, logs: Iterable[Dict[str, Any]]) -> str:
        for log in logs:
            if log.get("STEP") != self.QUESTION_STEP:
                continue
            return self._from_question_body(log.get("BODY"))
        return ""

    def _extract_answer(self, logs: Iterable[Dict[str, Any]]) -> str:
        for log in logs:
            if log.get("STEP") not in self.ANSWER_STEPS:
                continue
            answer = self._from_answer_body(log.get("BODY"))
            if answer:
                return answer
        return ""

    def _extract_rag_ids(self, logs: Iterable[Dict[str, Any]]) -> List[str]:
        for log in logs:
            if log.get("STEP") == self.LLM_STEP:
                detail = log.get("BODY", {}).get("detail", {})
                annotations = detail.get("annotations", [])
                rag_ids = []
                for annotation in annotations:
                    ids = annotation.get("rag_id", [])
                    if isinstance(ids, list):
                        rag_ids.extend(ids)
                    else:
                        rag_ids.append(ids)
                return rag_ids
        return []

    def _from_question_body(self, body: Optional[Any]) -> str:
        if isinstance(body, str):
            return body.strip()
        if isinstance(body, dict):
            text = body.get("text")
            if isinstance(text, str):
                return text.strip()
            detail = body.get("detail")
            if isinstance(detail, dict):
                inner_text = detail.get("text")
                if isinstance(inner_text, str):
                    return inner_text.strip()
        return ""

    def _from_answer_body(self, body: Optional[Any]) -> str:
        if isinstance(body, str):
            return body.strip()
        if not isinstance(body, dict):
            return ""
        detail = body.get("detail")
        if isinstance(detail, str):
            return detail.strip()
        if isinstance(detail, dict):
            answer = detail.get("answer")
            if isinstance(answer, str):
                return answer.strip()
            llm_result = detail.get("llm_result")
            if isinstance(llm_result, dict):
                llm_answer = llm_result.get("answer")
                if isinstance(llm_answer, str):
                    return llm_answer.strip()
        answer_value = body.get("answer")
        if isinstance(answer_value, str):
            return answer_value.strip()
        return ""

    def to_file(self, file_path):
        workbook = self.log_to_excel()
        workbook.save(file_path)

    def to_bytes_io(self):
        workbook = self.log_to_excel()
        byte_stream = BytesIO()
        workbook.save(byte_stream)
        byte_stream.seek(0)
        return byte_stream
