import logging
import logging.handlers
import os
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pymongo import ASCENDING, DESCENDING, AsyncMongoClient

from app import log_viewer, query_log, write_log

load_dotenv()
LOG_LEVEL = os.getenv("LOG_LEVEL", "ERROR").upper()
if LOG_LEVEL not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
    raise ValueError(f"Invalid LOG_LEVEL: {LOG_LEVEL}")

LOG_DIR = os.getenv("LOG_DIR", "./logs")
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", 7))

log_file_path = os.path.join(LOG_DIR, "log-was.log")
logging.basicConfig(
    level=LOG_LEVEL,
    format="[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s",
    handlers=[
        logging.StreamHandler(),  # 콘솔에 로그 출력
        logging.handlers.TimedRotatingFileHandler(
            log_file_path,
            when="midnight",  # 매일 자정에 로그 파일을 새로 만듭니다.
            interval=1,  # 1일마다 새 로그 파일 생성
            backupCount=LOG_BACKUP_COUNT,  # 최대 7개의 백업 로그 파일 유지
            encoding="utf-8",
            utc=False,  # 로컬 시간 사용
        ),
    ],
)

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 서버 시작 시 실행
    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db.logs

    await logs.create_index(
        [("user_id", ASCENDING), ("issued_time", ASCENDING)], name="user_time_idx"
    )
    await logs.create_index([("issued_time", DESCENDING)], name="issued_time_desc_idx")

    yield  # 여기서 앱이 실행됨

    # 서버 종료 시 실행 (필요시 자원 정리)
    await client.close()


app = FastAPI(lifespan=lifespan)


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    # 빈 응답
    return Response(status_code=404)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(write_log.router)
app.include_router(query_log.router)
app.include_router(log_viewer.router)


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


# 정적 파일을 /log-viewer 경로로 서빙 (html=True 옵션 추가)
app.mount(
    "/log-viewer/assets", StaticFiles(directory="./static", html=True), name="static"
)
