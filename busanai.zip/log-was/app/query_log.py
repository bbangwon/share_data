import logging
import os
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv
from fastapi import APIRouter, Query
from pymongo import AsyncMongoClient

load_dotenv()

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/query-log",
)


# query_log
@router.get("/user/{user_id}")
async def query_log_user(
    user_id: str,
    start_time: datetime = None,
    end_time: datetime = None,
    length: int = 100,
):
    """로그 조회을 위한 API - user id 기준, 기간(start_time, end_time) 옵션"""
    logger.info(
        f"로그 조회(user) 요청: user_id={user_id}, start_time={start_time}, end_time={end_time}, length={length}"
    )

    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db.logs

    if start_time:
        end_time = end_time or datetime.now()
        cursor = logs.find(
            {"user_id": user_id, "issued_time": {"$gte": start_time, "$lte": end_time}}
        ).sort("issued_time", -1)
    else:
        cursor = logs.find({"user_id": user_id}).sort("issued_time", -1)

    result = await cursor.to_list(length=length)
    return result


@router.get("/task/{task_id}")
async def query_log_task(task_id: str):
    """로그 조회을 위한 API - task id 기준"""
    logger.info(f"로그 조회(task) 요청: task_id={task_id}")

    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db.logs

    cursor = logs.find({"_id": task_id})
    result = await cursor.to_list(length=1)

    return result


@router.get("/last-tasks/{count}")
async def query_log_last_tasks(count: int):
    """로그 조회을 위한 API - 최근 생성된 task 기준"""
    logger.info(f"로그 조회(last-tasks) 요청: count={count}")

    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db.logs

    cursor = logs.find().sort("issued_time", -1).limit(count)
    result = await cursor.to_list(length=count)

    return result


@router.get("/get-admin-logs")
async def query_log_admin_logs(
    q: str = Query(None, description="검색할 질문 내용"),
    s: Optional[datetime] = Query(None, description="검색 시작 시간"),
    e: Optional[datetime] = Query(None, description="검색 종료 시간"),
):
    """로그 조회을 위한 API - 질문 기준"""
    question = q
    start_time = s
    end_time = e

    logger.info(
        f"admin 로그 조회 요청: question={question} start_time={start_time} end_time={end_time}"
    )

    client = AsyncMongoClient(os.getenv("LOG_DB_URL"))
    log_db = client.log_db
    logs = log_db["admin-logs"]

    query = {}
    if question:
        query["logs.AL-USER-MESSAGE"] = {"$regex": question}

    if end_time is None:
        end_time = datetime.now()

    if start_time:
        query["issued_time"] = {"$gte": start_time, "$lte": end_time}

    cursor = logs.find(query)
    result = await cursor.to_list()

    return result
