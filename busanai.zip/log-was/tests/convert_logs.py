import argparse
import json
import sys
from typing import Any, Dict


def convert_log_to_extended_json_single(log_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    단일 로그 문서의 issued_time, _issued_time 및 duration 관련 필드를
    MongoDB Extended JSON의 $date 및 $numberDouble 형식으로 변환합니다.
    """

    # 1. 최상위 issued_time 처리 (문자열 -> $date)
    if "issued_time" in log_data and isinstance(log_data["issued_time"], str):
        log_data["issued_time"] = {"$date": log_data["issued_time"]}

    # 2. total_duration 처리 (숫자/문자열 -> $numberDouble)
    if "total_duration" in log_data:
        # 이미 딕셔너리 형태($numberDouble)가 아니라면 변환
        if not isinstance(log_data["total_duration"], dict):
            try:
                # 숫자형으로 변환 가능한 경우에만 처리
                float_val = float(log_data["total_duration"])
                log_data["total_duration"] = {"$numberDouble": str(float_val)}
            except (ValueError, TypeError):
                # 변환할 수 없는 값은 무시하거나 로그를 남길 수 있습니다.
                pass

    # 3. logs 배열 내부의 필드 처리
    if "logs" in log_data and isinstance(log_data["logs"], list):
        for log_entry in log_data["logs"]:
            # _issued_time 처리 (문자열 -> $date)
            if "_issued_time" in log_entry and isinstance(
                log_entry["_issued_time"], str
            ):
                log_entry["_issued_time"] = {"$date": log_entry["_issued_time"]}

            # _duration 처리 (숫자/문자열 -> $numberDouble)
            if "_duration" in log_entry:
                if not isinstance(log_entry["_duration"], dict):
                    try:
                        float_val = float(log_entry["_duration"])
                        log_entry["_duration"] = {"$numberDouble": str(float_val)}
                    except (ValueError, TypeError):
                        pass

    return log_data


# -----------------------------------------------------------------


def main():
    """스크립트 실행을 위한 메인 함수"""
    parser = argparse.ArgumentParser(
        description="JSON 로그 파일을 MongoDB Extended JSON 형식으로 변환합니다."
    )

    # 필수 인자: 입력 파일 경로
    parser.add_argument(
        "input_filepath", help="변환할 원본 JSON 파일 경로 (예: input.json)"
    )

    # 필수 인자: 출력 파일 경로
    parser.add_argument(
        "output_filepath",
        help="변환된 Extended JSON을 저장할 파일 경로 (예: output.json)",
    )

    args = parser.parse_args()

    # 1. 입력 파일 읽기
    try:
        with open(args.input_filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

    except FileNotFoundError:
        print(
            f"❌ 오류: 입력 파일을 찾을 수 없습니다: {args.input_filepath}",
            file=sys.stderr,
        )
        sys.exit(1)
    except json.JSONDecodeError:
        print(
            f"❌ 오류: 입력 파일이 유효한 JSON 형식이 아닙니다: {args.input_filepath}",
            file=sys.stderr,
        )
        sys.exit(1)
    except Exception as e:
        print(f"❌ 오류: 파일을 읽는 중 예외가 발생했습니다: {e}", file=sys.stderr)
        sys.exit(1)

    # 2. 데이터 변환 처리
    if not isinstance(data, list):
        # 배열이 아닌 단일 객체인 경우 배열로 만들어 처리
        data = [data]

    processed_data = [
        convert_log_to_extended_json_single(log_document) for log_document in data
    ]

    # 3. 변환된 데이터를 출력 파일에 저장
    try:
        with open(args.output_filepath, "w", encoding="utf-8") as f:
            # mongoimport를 위해 압축된 형태로 저장 (줄바꿈 없이)
            json.dump(processed_data, f, ensure_ascii=False, indent=None)

    except Exception as e:
        print(
            f"❌ 오류: 출력 파일을 저장하는 중 예외가 발생했습니다: {e}",
            file=sys.stderr,
        )
        sys.exit(1)

    print(
        f"✅ 성공: 총 {len(processed_data)}개의 문서가 성공적으로 변환되어 '{args.output_filepath}'에 저장되었습니다."
    )
    print("📢 이 파일을 MongoDB로 import 할 때는 '--jsonArray' 옵션을 사용하세요.")


if __name__ == "__main__":
    main()
