#!/bin/bash

export LOG_DB_URL="mongodb://appuser:busan12%23%24@localhost:27017/log_db?authSource=log_db"

ENV=local uv run uvicorn app.main:app --reload --host=0.0.0.0 --port=8003