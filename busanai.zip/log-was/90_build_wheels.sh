#!/bin/bash

uv export --no-dev --no-hashes --no-annotate --no-header > requirements.txt

rm -rf ./wheels
mkdir ./wheels
cp requirements.txt ./wheels/

docker run --rm -v "$(pwd)/wheels:/app" whl-downloader

rm -rf ./wheels/requirements.txt
