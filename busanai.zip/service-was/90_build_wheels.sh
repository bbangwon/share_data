#!/bin/bash

uv export --no-dev --no-hashes --no-annotate --no-header \
    --no-emit-package db-manager \
    --no-emit-package naver-works-bot \
    --no-emit-package busan-bot-ui \
    > requirements.txt

rm -rf ./wheels
mkdir ./wheels
cp requirements.txt ./wheels/

docker run --rm -v "$(pwd)/wheels:/app" whl-downloader

rm -rf ./wheels/requirements.txt 

uv build --wheel --out-dir ./wheels ../packages/db-manager
uv build --wheel --out-dir ./wheels ../packages/naver-works-bot
uv build --wheel --out-dir ./wheels ../packages/busan-bot-ui