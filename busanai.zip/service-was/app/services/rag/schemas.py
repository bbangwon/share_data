from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class RetrieveType(str, Enum):
    semantic = "semantic"
    lexical = "lexical"
    hybrid = "hybrid"


class DenseType(str, Enum):
    bge = "bge"
    jina = "jina"


class SparseType(str, Enum):
    bm25 = "bm25"


class RerankTarget(str, Enum):
    text = "text"
    parent_text = "parent_text"


class BaseQueryType(str, Enum):
    origin = "origin"
    complete = "complete"


class FilterType(str, Enum):
    must = "must"
    must_not = "must_not"


class DenseEmbedding(BaseModel):
    type: DenseType | None = Field(
        default=None,
        description="Dense 임베딩 타입 (bge | jina)",
    )
    name: str | None = Field(
        default=None,
        description="Dense Vector 이름",
    )


class SparseEmbedding(BaseModel):
    type: SparseType | None = Field(
        default=None,
        description="Sparse 임베딩 타입 (bm25)",
    )
    name: str | None = Field(
        default=None,
        description="Sparse Vector 이름",
    )


class Reranking(BaseModel):
    is_active: bool | None = Field(
        default=None,
        description="리랭크 모델 사용 여부",
    )
    target: RerankTarget | None = Field(
        default=None,
        description="리랭크 기준 텍스트 (text | parent_text)",
    )
    include_summary: bool | None = Field(
        default=None,
        description="리랭크시 요약내용 참조 여부",
    )
    min_length: int | None = Field(
        default=None,
        description="텍스트 최소 길이(해당 길이보다 짧은 경우 최소 가중치 적용)",
    )
    noise_weight: int | float | None = Field(
        default=None,
        description="텍스트 최소 길이 미달일 경우 적용할 가중치(0~1 사이 설정)",
        ge=0,
        le=1,
    )


class Penalty(BaseModel):
    is_active: bool | None = Field(
        default=None,
        description="문장 길이에 따른 패널티 적용 여부",
    )
    criteria: int | None = Field(
        default=None,
        description="패널티를 적용할 문장의 기준 길이(50%가 적용되는 길이)",
    )
    insenstivity: int | None = Field(
        default=None,
        description="패널티 가중치 계산시 둔감도(값이 클수록 완만하게 증감)",
    )


class QueryFilter(BaseModel):
    type: FilterType | None = Field(
        default=None,
        description="필터링 타입 (must | must_not)",
    )
    key: str | None = Field(
        default=None,
        description="필터링할 페이로드(메타) 필드명",
    )
    values: list[str] | None = Field(
        default=None,
        description="필터링에 포함할 도메인값",
    )


class RequestQdrantRetrieve(BaseModel):
    queries: list[str] = Field(..., description="문서 검색에 사용할 문장")
    base_query: str | None = Field(
        default=None,
        description="재정렬(rerank)시 기준이 되는 문장 | None인 경우 queries 문장 각각의 내용으로 검색",
    )
    collection_name: str | None = Field(
        default=None,
        description="검색 대상 콜렉션명",
    )
    retrieve_type: RetrieveType | None = Field(
        default=None,
        description="검색 타입 (semantic | lexical | hybrid)",
    )
    dense_limit: int | None = Field(
        default=None,
        description="Hybrid Search 시 Semantic Search 로 찾을 문서의 수",
        ge=1,
        le=500,
    )
    sparse_limit: int | None = Field(
        default=None,
        description="Hybrid Search 시 Lexical Search 로 찾을 문서의 수",
        ge=1,
        le=500,
    )
    final_limit: int | None = Field(
        default=None,
        description="질의당 최종 검색 결과로 반환할 문서 단락(청크) 개수",
        ge=1,
        le=100,
    )
    dense_embedding: DenseEmbedding | None = Field(
        default=None,
        description="Dense Embedding 설정",
    )
    sparse_embedding: SparseEmbedding | None = Field(
        default=None,
        description="Sparse Embedding 설정",
    )
    reranking: Reranking | None = Field(
        default=None,
        description="Reranking 설정",
    )
    penalty: Penalty | None = Field(
        default=None,
        description="Penalty 설정",
    )
    filters: list[QueryFilter] | None = Field(
        default=None,
        description="검색 필터링 설정",
    )
    add_next_point: bool | None = Field(
        default=None,
        description="최종 검색 결과에서 다음 포인트(청크) 추가 여부",
    )
    added_chunk_max_size: int | None = Field(
        default=None,
        description="다음 포인트를 더하는 경우 parent_text 최대 크기 조건",
    )
    service_type: str | None = Field(
        default=None,
        description="서비스 타입 (internal | external | generate | general)",
    )


class Payload(BaseModel):
    model_config = ConfigDict(extra="allow")

    file: str = Field(..., description="파일명")
    page_num: int = Field(..., description="페이지 정보")
    group: str = Field(
        ..., description="파일출처(내부자료, 온나라, 부산시홈페이지, BDI...)"
    )
    parent_text: str = Field(
        ..., description="답변 생성에 활용될 텍스트(최대 2048토큰)"
    )
    text: str = Field(..., description="검색에 활용된 텍스트(최대 512토큰)")
    chunk_index: int | None = Field(
        default=None, description="청크의 순서(sequential number)"
    )
    parent_id: str | None = Field(default=None, description="부모 청크 식별값")
    parent_idx: int | None = Field(
        default=None, description="페이지 내 부모 청크 인덱스"
    )
    parent_table_statuses: list[int] | None = Field(
        default=None, description="페이지 내 부모 청크의 테이블 상태값"
    )
    child_idx: int | None = Field(
        default=None, description="부모 청크 내 자식 청크 인덱스"
    )
    child_table_statuses: list[int] | None = Field(
        default=None, description="부모 청크 자식 테이블의 상태값"
    )
    dept: str | None = Field(default=None, description="부서")
    service: list[str] | None = Field(default=None, description="서비스 카테고리")
    ner: bool | None = Field(default=False, description="비식별화 여부")
    summary: str | None = Field(default=None, description="파일 전체에 대한 요약")
    file_path: str | None = Field(default=None, description="내부망 파일 주소")
    boost_keywords: str | None = Field(default=None, description="검색 키워드(or 문구)")


class DocumentInfo(BaseModel):
    id: str = Field(..., description="검색된 문서(포인트, 청크) 식별값")
    score: float = Field(..., description="질의와 문서(포인트, 청크) 간의 유사도 점수")
    payload: Payload


class RetrieveResult(BaseModel):
    query: str
    retrieved_documents: list[DocumentInfo | None] | None = Field(default=None)


class RetrieveResponse(BaseModel):
    results: list[RetrieveResult | None] | None = Field(default=None)
    latency_details: list[dict] | None = Field(default=None)


class RefferenceInfo(BaseModel):
    id: str = Field(..., description="검색된 문서(포인트, 청크) 식별값")
    file: str = Field(..., description="파일명")
    page_num: int = Field(..., description="페이지 정보")
    group: str = Field(
        ..., description="파일 출처(내부자료, 온나라, 부산광역시 홈페이지, ...)"
    )
    parent_text: str = Field(
        ..., description="답변 생성에 활용될 텍스트(최대 2048토큰)"
    )
    file_path: str = Field(..., description="내부장 파일 주소")
    ner: bool = Field(..., description="비식별화 처리 여부")
