import json
import re
from functools import lru_cache
from typing import Any

import httpx

from app.core import settings
from app.core.logger import get_logger

from . import schemas

logger = get_logger("service-was")


@lru_cache
def get_dictionary(path: str, encoding: str = "utf-8") -> schemas.QueryFilter:
    with open(path, encoding=encoding) as f:
        dictionary = json.load(f)
    return dictionary


async def get_group_filter(queries: list[str], service_type: str) -> dict:
    """단어사전 기반으로 사용자 질의내 group 추출"""
    values = set()
    try:
        dict_path = settings.GROUP_DICT_PATH
        _dict: dict[str, list] = get_dictionary(dict_path)

        for query in queries:
            for key, variants in _dict.items():
                # 공백 제거 & 긴 표현 우선 매칭
                sorted_variants = sorted(variants, key=len, reverse=True)
                pattern = re.compile(
                    "|".join(map(re.escape, sorted_variants)), re.IGNORECASE
                )
                if pattern.search(query):  # 문장 안에 해당 표현이 존재한다면
                    values.add(key)
    except Exception as e:
        logger.error(f"get_group_filter\n{e}")

    filter_type = "must"
    if not (group_filter := list(values)):
        match service_type:
            case "internal":
                group_filter = settings.INTERNAL_GROUP_FILTER
            case "external":
                if settings.EXTERNAL_GROUP_FILTER:
                    group_filter = settings.EXTERNAL_GROUP_FILTER
                else:
                    filter_type = "must_not"
                    _temp_group_filter1 = (
                        settings.INTERNAL_GROUP_FILTER
                        if settings.INTERNAL_GROUP_FILTER
                        else []
                    )
                    _temp_group_filter2 = (
                        settings.GENERATE_GROUP_FILTER
                        if settings.GENERATE_GROUP_FILTER
                        else []
                    )
                    group_filter = [*_temp_group_filter1, *_temp_group_filter2]
            case "generate":
                group_filter = settings.GENERATE_GROUP_FILTER
            case _:
                group_filter = settings.DEFAULT_GROUP_FILTER
    return {
        "type": filter_type,
        "key": "group",
        "values": group_filter,
    }


async def get_service_filter(service_info: list) -> dict | None:
    """서비스 분류 API 요청 및 파싱 결과 기반으로 service 추출"""
    logger.info(f"{service_info}")
    values = set()
    try:
        dict_path = settings.SERVICE_DICT_PATH
        _dict: dict[str, str] = get_dictionary(dict_path)

        for service in service_info:
            service_no = f"{service.get('no'):02}"
            values.add(_dict.get(service_no))
    except Exception as e:
        logger.error(f"get_service_filter\n{e}")
    finally:
        return (
            {
                "type": "must",
                "key": "service",
                "values": list(values),
            }
            if values
            else None
        )


class RAG:
    BASE_URL = settings.RAG_WAS_BASE_URL

    def __init__(self, timeout: int | None = None):
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        self.timeout = timeout or settings.RAG_TIMEOUT

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.BASE_URL}{endpoint}"
        logger.info(f"Request: {method} {url} | params={params} | json={json}")
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=self.headers,
                    params=params,
                    json=json,
                )
                logger.info(f"Response: {response.status_code} {url}")
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(
                f"HTTP error for {method} {url}: {e.response.status_code} - {e.response.text}"
            )
            raise
        except Exception as e:
            logger.exception(f"Unexpected error during {method} {url}: {e}")
            raise

    async def health_check(self):
        logger.info("health_check called")
        response = await self._request(
            method="GET",
            endpoint="/",
        )
        return response

    async def retrieve_documents(
        self,
        queries: list[str],
        base_query: schemas.BaseQueryType | None = None,
        collection_name: str | None = None,
        retrieve_type: schemas.RetrieveType | None = None,
        dense_limit: int | None = None,
        sparse_limit: int | None = None,
        final_limit: int | None = None,
        dense_embedding: schemas.DenseEmbedding | None = None,
        sparse_embedding: schemas.SparseEmbedding | None = None,
        reranking: schemas.Reranking | None = None,
        penalty: schemas.Penalty | None = None,
        filters: list[schemas.QueryFilter] | None = None,
        add_next_point: bool | None = None,
        added_chunk_max_size: int | None = None,
        service_type: str | None = None,
    ):
        logger.info(f"retrieve_documents called | {queries=}")
        response = await self._request(
            method="POST",
            endpoint="/api/v1/qdrant/retrieve",
            json=schemas.RequestQdrantRetrieve(
                queries=queries,
                base_query=base_query,
                collection_name=collection_name,
                retrieve_type=retrieve_type,
                final_limit=final_limit,
                dense_embedding=dense_embedding,
                sparse_embedding=sparse_embedding,
                reranking=reranking,
                dense_limit=dense_limit,
                sparse_limit=sparse_limit,
                penalty=penalty,
                filters=filters,
                add_next_point=add_next_point,
                added_chunk_max_size=added_chunk_max_size,
                service_type=service_type,
            ).model_dump(exclude_none=True),
        )
        return schemas.RetrieveResponse.model_validate(response).model_dump()

    async def validate_documents(
        self, documents_list: list[list[schemas.DocumentInfo]], limit: int
    ) -> list[schemas.DocumentInfo]:
        logger.info("validate_documents called")

        validated_documents = []
        parent_texts = []
        for documents in documents_list:
            for doc in documents:
                # 검색 결과 후처리
                ##  유사도 임계값 설정
                if doc.get("score") < settings.RETRIEVE_THRESHOLD:
                    continue
                ## 중복 포인트 제거
                if (
                    _parent_texts := doc.get("payload").get("parent_text")
                ) in parent_texts:
                    continue
                parent_texts.append(_parent_texts)
                validated_documents.append(doc)

        # 점수("score") 기준으로 내림차순 정렬 & 참조 문서 개수 제한
        validated_documents = sorted(
            validated_documents, key=lambda x: x["score"], reverse=True
        )[:limit]
        return validated_documents

    async def get_ref_documents(
        self,
        query_document_dicts: list[schemas.RetrieveResult],
        ref_limit: int,
    ) -> dict[str, schemas.RefferenceInfo]:
        """검색결과를 llm api 요청에 적합한 문서 형태로 변환"""
        logger.info("get_ref_documents called")
        total_documents: list[list[schemas.DocumentInfo]] = [
            _docs
            for _dict in query_document_dicts
            if (_docs := _dict.get("retrieved_documents"))
        ]
        validated_documents: list[schemas.DocumentInfo] = await self.validate_documents(
            total_documents, ref_limit
        )

        return {
            doc.get("id"): schemas.RefferenceInfo(
                id=doc.get("id"),
                file=doc.get("payload").get("file"),
                page_num=doc.get("payload").get("page_num"),
                group=doc.get("payload").get("group"),
                parent_text=doc.get("payload").get("parent_text"),
                file_path=doc.get("payload").get("file_path"),
                ner=doc.get("payload").get("ner"),
            ).model_dump(exclude_none=True)
            for doc in validated_documents
        }
