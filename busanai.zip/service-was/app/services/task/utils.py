from typing import Any

import httpx

from app.core import settings
from app.core.logger import get_logger

from .schemas import RequestUdateTaskStatus, ResponseGetTask

logger = get_logger("service-was")


class Task:
    BASE_URL = settings.TASK_WAS_BASE_URL

    def __init__(self, timeout: int | None = None):
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        self.timeout = timeout or settings.TASK_WAS_TIMEOUT

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.BASE_URL}{endpoint}"
        logger.debug(f"Request: {method} {url} | params={params} | json={json}")
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=self.headers,
                    params=params,
                    json=json,
                )
                logger.debug(f"Response: {response.status_code} {url}")
                response.raise_for_status()
                # If response content is empty, return None (no task)
                if (
                    not response.content
                    or response.content.strip() == b""
                    or response.text.strip() == ""
                ):
                    return None
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(
                f"HTTP error for {method} {url}: {e.response.status_code} - {e.response.text}"
            )
            raise
        except Exception as e:
            logger.exception(f"Unexpected error during {method} {url}: {e}")
            raise

    async def get_task(self) -> dict | None:
        logger.debug("get_task called")
        response = await self._request(method="GET", endpoint="/api/v1/tasks/next")
        if response is None:
            return None
        return ResponseGetTask.model_validate(response, by_alias=True).model_dump()

    async def update_task(self, task_id: str, payload: RequestUdateTaskStatus) -> None:
        logger.info(f"update_task called | task_id={task_id} | payload={payload}")
        return await self._request(
            method="POST",
            endpoint=f"/api/v1/tasks/{task_id}/complete",
            json=payload,
        )
