from typing import Literal

from pydantic import AliasGenerator, BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel


class TaskHeaders(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    conten_type: str = Field(..., alias="content-type")
    signature: str = Field(..., alias="x-works-signature")


class Content(BaseModel):
    type: str
    text: str


class TaskBody(BaseModel):
    type: str
    content: Content


class Task(BaseModel):
    id: str = Field(..., description="작업 ID")
    # headers: TaskHeaders = Field(..., description="작업 Header 정보")
    # body: TaskBody = Field(..., description="작업 Body 정보")
    headers: dict = Field(..., description="작업 Header 정보")
    body: dict = Field(..., description="작업 Body 정보")


class ResponseGetTask(BaseModel):
    model_config = ConfigDict(alias_generator=AliasGenerator(validation_alias=to_camel))

    # chat_id: str = Field(..., description="채팅세션 ID")
    chat_id: int = Field(..., description="채팅세션 ID")
    task: Task = Field(..., description="작업 정보")


class RequestUdateTaskStatus(BaseModel):
    status: Literal["success", "failed"] = Field(
        ..., description="작업 성공여부", examples=["success", "failed"]
    )
    reason: str | None = Field(default=None, description="작업 실패 이유")
