import asyncio
from typing import Any

from pydantic import BaseModel, Field


class Buffer(BaseModel):
    data: list = Field(default=[])
    condition: Any = Field(default=asyncio.Condition())
    is_end: bool = Field(default=False)


class TokenInfo(BaseModel):
    chat_session_id: int
    chat_number: int
    stream_url: str
