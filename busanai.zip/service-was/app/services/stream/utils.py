import base64
import json

from .schemas import Buffer, TokenInfo


def encode_token(token_info: dict):
    json_str = TokenInfo(**token_info).model_dump_json()
    encoded_token = base64.urlsafe_b64encode(json_str.encode("utf-8")).decode("utf-8")
    return encoded_token


def decode_token(encoded_token: str):
    return json.loads(
        base64.urlsafe_b64decode(encoded_token.encode("utf-8")).decode("utf-8")
    )


class StreamDataProcessor:
    def __init__(self):
        self.buffer = Buffer()

    def get_data(self):
        return self.buffer.data

    def get_is_end(self):
        return self.buffer.is_end

    def set_is_end(self, _bool: bool | None = None):
        if _bool is None:
            _bool = not self.buffer.is_end

        self.buffer.is_end = _bool

    def append_data(self, _data):
        self.buffer.data.append(_data)

    async def notify(self):
        async with self.buffer.condition:
            self.buffer.condition.notify_all()

    async def stream(self):
        last_idx = 0
        while last_idx < len(self.buffer.data):
            yield f"{self.buffer.data[last_idx]}"
            last_idx += 1

        while True:
            async with self.buffer.condition:
                await self.buffer.condition.wait()
                while last_idx < len(self.buffer.data):
                    yield f"{self.buffer.data[last_idx]}"
                    last_idx += 1

                if self.buffer.is_end:
                    # print("streaming finished.")
                    break
            # print("waiting for new data...")
