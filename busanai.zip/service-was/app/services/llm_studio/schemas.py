from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


# Request ==========================
class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class Document(BaseModel):
    id: str
    passage: str


class BaseRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    user_query: str = Field(..., alias="contents")
    dialog_history: list[Message | None] = Field(default=[], description="대화이력")


class RequestWithRAG(BaseRequest):
    stream: bool
    is_rag: bool
    rag_psgs: list[Document] | None = Field(
        default=None, description="검색된 문서 정보"
    )


# Response =========================
class Annotation(BaseModel):
    rag_id: list[str]


class LLMResult(BaseModel):
    answer: str
    finish_reason: str | None = Field(default=None)
    annotations: list[Annotation] | None = Field(default=None)
    token_count: int | None
    processing_time: float | None


class BaseResponse(BaseModel):
    response_code: str
    response_message: str


class ResponseHealthCheck(BaseResponse):
    real_ip: str


class ResponseWithLLM(BaseResponse):
    llm_result: LLMResult


class Intent(BaseModel):
    no: int | str
    intent_name: str


class Service(BaseModel):
    no: str | int | None = Field(default=None)
    category: str | None = Field(default=None)


class ServiceInfo(BaseModel):
    service: list[Service] | None = Field(default=None)


class IntentInfo(BaseModel):
    intent: Intent | None = Field(default=None)


class QueryInfo(BaseModel):
    query_complete: str | None = Field(default=None)
    search_queries: list[str] | None = Field(default=None)
