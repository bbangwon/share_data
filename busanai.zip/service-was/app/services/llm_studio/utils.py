import re
from typing import Any, Type, TypeVar

import httpx

from app.core import settings
from app.core.logger import get_logger
from app.services.stream.utils import StreamDataProcessor
from app.state import AppState

from . import schemas

ReqT = TypeVar("ReqT", bound=schemas.BaseRequest)
ResT = TypeVar("ResT", bound=schemas.BaseResponse)

# Use shared logger from app.core.config
logger = get_logger("service-was")


class LLMStudio:
    BASE_URL = settings.LLM_STUDIO_BASE_URL

    def __init__(self, timeout: int | None = None):
        self.headers = {
            "Content-Type": "application/json",
        }
        self.timeout = timeout or settings.LLM_STUDIO_TIMEOUT
        self.base_endpoint = "/llm-studio/v1/api/task/generate/syncapi/busan_ai_llm"

    # API 요청 보일러플레이트
    async def _request(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.BASE_URL}{endpoint}"
        logger.info(f"Request: {method} {url} | params={params} | json={json}")
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=self.headers,
                    params=params,
                    json=json,
                )
                logger.info(f"Response: {response.status_code} {url}")
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(
                f"HTTP error for {method} {url}: {e.response.status_code} - {e.response.text}"
            )
            raise
        except Exception as e:
            logger.exception(f"Unexpected error during {method} {url}: {e}")
            raise

    # 스트림 API 요청 보일러플레이트
    async def _stream(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.BASE_URL}{endpoint}"
        logger.info(f"Request: {method} {url} | params={params} | json={json}")
        try:
            headers = self.headers | {"Accept": "text/event-stream"}
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                async with client.stream(
                    method=method,
                    url=url,
                    headers=headers,
                    params=params,
                    json=json,
                ) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        yield line + "\n\n"

        except httpx.RequestError as e:
            logger.error(f"Request error: {e}")
            yield f"data: Error occurred: {e}\n\n"
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            yield f"data: Unexpected error occurred: {e}\n\n"

    # 헬스체크
    async def health_check(self):
        logger.info("health_check called")
        response = await self._request(
            method="GET",
            endpoint="/llm-studio/v1/api/health",
        )
        return schemas.ResponseHealthCheck.model_validate(response).model_dump()

    # 의도분석
    async def get_intent(
        self, user_query: str, dialog_history: list[schemas.Message | None] = []
    ):
        logger.info(
            f"get_intent called | user_query={user_query} | dialog_history={dialog_history}"
        )
        response = await self._request(
            method="POST",
            endpoint=f"{self.base_endpoint}/intent_classify",
            json=schemas.BaseRequest(
                user_query=user_query, dialog_history=dialog_history
            ).model_dump(exclude_none=True),
        )
        return schemas.ResponseWithLLM.model_validate(response).model_dump()

    # 의도분석 응답 결과 파싱
    async def get_parsed_intent(self, answer: str):
        logger.info("get_parsed_intent called")
        pattern = r"\{\s*(\"|\')intent.*?\s*\}*\s*\}"
        match = re.search(pattern, answer, re.DOTALL)
        json_string = match.group(0)
        return schemas.IntentInfo.model_validate_json(json_string).model_dump()

    # 질의확장
    async def get_expanded_query(
        self, user_query: str, dialog_history: list[schemas.Message | None] = []
    ):
        logger.info(
            f"get_expanded_query called | user_query={user_query} | dialog_history={dialog_history}"
        )
        response = await self._request(
            method="POST",
            endpoint=f"{self.base_endpoint}/query_expand",
            json=schemas.BaseRequest(
                user_query=user_query, dialog_history=dialog_history
            ).model_dump(exclude_none=True),
        )
        return schemas.ResponseWithLLM.model_validate(response).model_dump()

    # 질의확장 응답 결과 파싱
    async def get_parsed_query(self, answer: str):
        logger.info("get_parsed_query called")
        pattern = r"\{\s*(\"|\')query_complete.*?\s*\]\s*\}"
        match = re.search(pattern, answer, re.DOTALL)
        json_string = match.group(0)
        return schemas.QueryInfo.model_validate_json(json_string).model_dump()

    # 서비스 분류
    async def get_service_category(
        self, user_query: str, dialog_history: list[schemas.Message | None] = []
    ):
        logger.info(
            f"get_service_category called | user_query={user_query} | dialog_history={dialog_history}"
        )
        response = await self._request(
            method="POST",
            endpoint=f"{self.base_endpoint}/service_category",
            json=schemas.BaseRequest(
                user_query=user_query, dialog_history=dialog_history
            ).model_dump(exclude_none=True),
        )
        return schemas.ResponseWithLLM.model_validate(response).model_dump()

    # 서비스분류 응답 결과 파싱
    async def get_parsed_service(self, answer: str):
        logger.info("get_parsed_service called")
        pattern = r"\{\s*(\"|\')service.*?\s*\]\s*\}"
        match = re.search(pattern, answer, re.DOTALL)
        json_string = match.group(0)
        return schemas.ServiceInfo.model_validate_json(json_string).model_dump()

    # Non-Stream 응답 생성 보일러플레이트
    async def _generate_answer(
        self,
        endpoint_suffix: str,
        user_query: str,
        stream: bool = False,
        is_rag: bool = False,
        rag_psgs: list[schemas.Document] | None = None,
        dialog_history: list[schemas.Message | None] = [],
        chat_session_id: str | None = None,  # // stream=False 인 경우 미사용
        request_model: Type[ReqT] = schemas.RequestWithRAG,
        response_model: Type[ResT] = schemas.ResponseWithLLM,
    ):
        logger.info(
            f"{endpoint_suffix} called | user_query={user_query} | stream={stream} | is_rag={is_rag} | rag_psgs={rag_psgs}"
        )

        endpoint = f"{self.base_endpoint}/{endpoint_suffix}"
        dump_config = {"exclude_none": True} | (
            {"by_alias": True} if endpoint_suffix == "content_summary" else {}
        )
        payload = request_model(
            user_query=user_query,
            is_rag=is_rag,
            rag_psgs=rag_psgs,
            stream=stream,
            dialog_history=dialog_history,
        ).model_dump(**dump_config)
        response = await self._request(method="POST", endpoint=endpoint, json=payload)
        return response_model.model_validate(response).model_dump()

    # Stream 응답 생성 보일러플레이트
    async def _stream_generate_answer(
        self,
        endpoint_suffix: str,
        user_query: str,
        stream: bool = True,
        is_rag: bool = False,
        rag_psgs: list[schemas.Document] | None = None,
        dialog_history: list[schemas.Message | None] = [],
        chat_session_id: str | None = None,
        request_model: Type[ReqT] = schemas.RequestWithRAG,
        response_model: Type[ResT] = schemas.ResponseWithLLM,
    ):
        logger.info(
            f"{endpoint_suffix} called | user_query={user_query} | stream={stream} | is_rag={is_rag} | rag_psgs={rag_psgs}"
        )

        endpoint = f"{self.base_endpoint}/{endpoint_suffix}"
        dump_config = {"exclude_none": True} | (
            {"by_alias": True} if endpoint_suffix == "content_summary" else {}
        )
        endpoint = f"{self.base_endpoint}/{endpoint_suffix}"
        payload = request_model(
            user_query=user_query,
            is_rag=is_rag,
            rag_psgs=rag_psgs,
            stream=stream,
            dialog_history=dialog_history,
        ).model_dump(**dump_config)

        if AppState.stream_buffers.get(chat_session_id) is None:
            AppState.stream_buffers[chat_session_id] = StreamDataProcessor()

        stream_buffer = AppState.stream_buffers[chat_session_id]

        async for line in self._stream(method="POST", endpoint=endpoint, json=payload):
            try:
                prefix_char = "data:"
                if line.startswith(prefix_char):
                    json_string = line.removeprefix(prefix_char)
                    res_data = response_model.model_validate_json(json_string)
                    finish_reason = res_data.llm_result.finish_reason

                    # 모든 스트림 데이터 버퍼에 저장
                    stream_buffer.append_data(line)

                    if finish_reason == "stop":
                        # // TODO: 'stop' 이 외의 종류상황 발생시 예외 처리
                        stream_buffer.set_is_end(True)

                    await stream_buffer.notify()

                    if stream_buffer.get_is_end():
                        AppState.stream_buffers.pop(
                            chat_session_id
                        )  # 스트림 데이터를 모두 받은 경우 삭제
                        yield res_data.model_dump()  # 최종 결과값 전달

            except Exception as e:
                print(e)

    # 스트림 여부에 따른 최종 답변 생성 보일러플레이트
    async def _final_generate_answer(self, endpoint_suffix: str, **kwargs):
        if kwargs.get("stream"):
            async for res in self._stream_generate_answer(
                endpoint_suffix=endpoint_suffix, **kwargs
            ):
                return res
        else:
            return await self._generate_answer(
                endpoint_suffix=endpoint_suffix,
                **kwargs,
            )

    # 101_일상대화, 501_민감정보, 900_미분류
    async def get_conversation(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="conversation",
            **kwargs,
        )

    # 201_질의응답
    async def get_qa_response(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="qa_response",
            **kwargs,
        )

    # 301_정책계획보고서
    async def get_draft_policy_plan(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_policy_plan",
            **kwargs,
        )

    # 302_보도자료
    async def get_draft_press(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_press",
            **kwargs,
        )

    # 303_인사말씀
    async def get_draft_speech(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_speech",
            **kwargs,
        )

    # 304_행사시나리오
    async def get_draft_event(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_event",
            **kwargs,
        )

    # 305_월간업무보고
    async def get_draft_monthly_report(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_monthly_report",
            **kwargs,
        )

    # 306_주간업무보고
    async def get_draft_weekly_report(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_weekly_report",
            **kwargs,
        )

    # 307_의회보고
    async def get_draft_congress(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_congress",
            **kwargs,
        )

    # 308_국과장보고자료
    async def get_draft_report(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_report",
            **kwargs,
        )

    # 309_시행문
    async def get_draft_letter(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_letter",
            **kwargs,
        )

    # 310_백서
    async def get_draft_annual_report(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_annual_report",
            **kwargs,
        )

    # 311_주간정책보고자료
    async def get_draft_weekly_policy(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="draft_weekly_policy",
            **kwargs,
        )

    # 콘텐츠 요약
    async def get_content_summary(self, **kwargs):
        return await self._final_generate_answer(
            endpoint_suffix="content_summary",
            **kwargs,
        )
