import asyncio
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.staticfiles import StaticFiles

from app import api, tests
from app.core import settings
from app.core.logger import get_logger
from app.worker import handle_task, poll_task

logger = get_logger(__file__)

MAX_TASK_CNT: int = settings.MAX_TASK_CNT


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        polling_task = asyncio.create_task(poll_task())
        handling_tasks = [
            asyncio.create_task(handle_task(f"{i + 1:02}")) for i in range(MAX_TASK_CNT)
        ]
        logger.info(f"✅ [PID {os.getpid()}] AI Service is started.")

        yield
    except Exception as e:
        logger.error(f"[Error - lifespan]: {e}", exc_info=True)
    finally:
        logger.info(f"🛑 [PID {os.getpid()}] AI Service shutting down... ")
        polling_task.cancel()
        for handling_task in handling_tasks:
            handling_task.cancel()
        await asyncio.gather(polling_task, *handling_tasks, return_exceptions=True)
        logger.info(":::::: All Services are stopped ::::::")


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None)
logger.info("FastAPI 앱 인스턴스 생성")

app.mount("/static", StaticFiles(directory="static"), name="static")
logger.info("정적파일(static) 마운트 완료")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
logger.info("CORS 미들웨어 추가 완료")


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    # 빈 응답
    return Response(status_code=404)


@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title=f"[TEST UI] {app.title}",
        # 로컬 정적 경로로 교체
        swagger_js_url="/static/swagger-ui/swagger-ui-bundle.js",
        swagger_css_url="/static/swagger-ui/swagger-ui.css",
        swagger_favicon_url="/static/swagger-ui/favicon-32x32.png",
    )


@app.get("/health-check")
async def health_check():
    logger.info("Health check endpoint called.")
    return {"SERVICE-WAS OK": True}


app.include_router(api.router, prefix="/api")
app.include_router(tests.router)
