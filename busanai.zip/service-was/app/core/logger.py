import logging
import os
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path

BASE_LOGGER_NAME = "service-was"

# --- one-time setup ---
LOG_DIR = Path(
    os.getenv("LOG_DIR", Path(__file__).parent.parent.parent / "logs")
).resolve()
LOG_DIR.mkdir(parents=True, exist_ok=True)

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", "7"))
FMT = "[%(asctime)s] %(levelname)s %(name)s: %(message)s"

base_logger = logging.getLogger(BASE_LOGGER_NAME)

if not base_logger.handlers:
    # 레벨
    base_logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))

    # 파일: 자정마다 회전. 현재 파일명은 'service-was.log',
    # 회전본은 'service-was.log.YYYY-MM-DD'
    file_handler = TimedRotatingFileHandler(
        filename=str(LOG_DIR / f"{BASE_LOGGER_NAME}.log"),
        when="midnight",
        interval=1,
        backupCount=LOG_BACKUP_COUNT,
        encoding="utf-8",
        utc=False,  # Asia/Seoul 환경이면 False 권장
        delay=True,  # 최초 로그 발생 시 파일 오픈
    )
    formatter = logging.Formatter(FMT)
    file_handler.setFormatter(formatter)
    base_logger.addHandler(file_handler)

    # 콘솔(stdout)도 동일 포맷으로 출력
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    base_logger.addHandler(stream_handler)

    # 루트로 전파 방지(중복 출력 방지)
    base_logger.propagate = False
# --- end one-time setup ---


def get_logger(name: str | None = None) -> logging.Logger:
    """
    - name이 없거나 BASE_LOGGER_NAME이면 베이스 로거 반환
    - 그 외에는 'service-was.<name>' 형태의 자식 로거 반환
      (이미 'service-was.'로 시작하면 중복 접두사 방지)
    """
    if not name or name == BASE_LOGGER_NAME:
        return base_logger
    if name.startswith(BASE_LOGGER_NAME + "."):
        return logging.getLogger(name)
    return logging.getLogger(f"{BASE_LOGGER_NAME}.{name}")
