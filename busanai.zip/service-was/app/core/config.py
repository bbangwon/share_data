import os
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

DEFAULT_ENV = "service"


class Settings(BaseSettings):
    ENV: str = DEFAULT_ENV

    MAX_TASK_CNT: int
    TASK_QUEUE_SIZE: int
    POLLING_INTERVER: float
    RAG_INTENT_CODES: list[int]

    SERVICE_WAS_IP: str
    SERVICE_WAS_PORT: str = os.getenv("SERVICE_WAS_PORT")
    LLM_STUDIO_BASE_URL: str
    LLM_STUDIO_TIMEOUT: int
    RAG_WAS_BASE_URL: str
    RAG_TIMEOUT: int
    TASK_WAS_BASE_URL: str
    TASK_WAS_TIMEOUT: int
    ADMIN_DATABASE_URL: str
    DATABASE_URL: str
    WEB_VIEW_URL: str

    ADD_ORIGINAL_MESSAGE: bool
    ADD_QUERY_COMPLETE: bool
    ADD_SEARCH_QUERIES: bool
    USE_BASE_QUERY: bool
    BASE_QUERY_TYPE: str

    RETRIEVE_THRESHOLD: float
    REF_LIMIT: int

    # BOT Manger File Path
    CONFIG_PATH: str
    STATIC_MESSAGES_PATH: str

    # RAG Retrival Filtering
    USE_GROUP_FILTER: bool
    GROUP_DICT_PATH: str
    DEFAULT_GROUP_FILTER: list[str]
    INTERNAL_GROUP_FILTER: list[str]
    EXTERNAL_GROUP_FILTER: list[str] | None = None
    GENERATE_GROUP_FILTER: list[str]
    USE_SERVICE_FILTER: bool
    SERVICE_DICT_PATH: str

    # Dialog History Settings
    USE_DIALOG_HISTORY: bool  # 대화이력 조회 여부
    DIALOG_HISTORY_COUNT: int  # 조회할 대화이력(질문-답변 쌍) 개수

    # [의도분석, 질의확장, 서비스분류, 최종답변] 순 대화이력 참조 여부(bool)
    DIALOG_USAGE_LIST: list[bool]
    # [의도분석, 질의확장, 서비스분류, 최종답변] 순 대화이력 참조 개수(int)
    DIALOG_USAGE_COUNT: list[int]

    model_config = SettingsConfigDict(
        env_file=f".env.{os.getenv('ENV', DEFAULT_ENV)}",
        env_file_encoding="utf-8",
        env_nested_delimiter=",",
        extra="allow",
    )


@lru_cache
def get_settings():
    return Settings()


settings = get_settings()
