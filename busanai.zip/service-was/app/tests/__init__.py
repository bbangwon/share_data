from fastapi import APIRouter

from . import integration, llm_studio, rag

router = APIRouter(prefix="/test/api")
router.include_router(rag.router, tags=["Test - VectorDB"])
router.include_router(llm_studio.router, tags=["Test - LLM Studio"])
router.include_router(integration.router, tags=["Test - Integration"])
