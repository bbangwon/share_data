from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from enum import Enum
from functools import lru_cache
from typing import Any, Iterator

from fastapi import APIRouter, Depends

from app.core.logger import get_logger
from app.services.llm_studio import BaseRequest, LLMStudio, RequestWithRAG
from app.services.rag import RAG

# Constants
DEFAULT_LLM_TIMEOUT = 30
DRAFT_GENERATION_THRESHOLD = 300
RAG_INTENT_CODES = frozenset([201, 301, 302])

router = APIRouter(prefix="/intergration")
logger = get_logger(__name__)


class ProcessingStatus(Enum):
    """처리 상태 열거형."""

    SUCCESS = "success"
    ERROR = "error"


class ProcessingStep(Enum):
    """한국어 이름을 포함한 처리 단계 열거형."""

    USER_QUERY_VALIDATION = (1, "사용자 질의 확인")
    INTENT_CLASSIFICATION = (2, "의도 분류 요청")
    INTENT_PARSING = (3, "의도 분류 답변 파싱")
    RAG_CHECK = (4, "RAG 검색 여부 확인")
    DOCUMENT_RETRIEVAL = ("4_1", "문서 검색")
    PARAMETER_PREPARATION = (5, "최종답변 생성 요청 파라미터 정의")
    RESPONSE_GENERATION = (6, "최종 답변 생성")

    def __init__(self, step_id: int | str, description: str):
        self.step_id = step_id
        self.description = description


# 사용자 정의 예외
class IntegrationError(Exception):
    """통합 서비스 오류를 위한 기본 예외."""

    def __init__(self, message: str, step: ProcessingStep):
        self.step = step
        super().__init__(message)


class UserQueryValidationError(IntegrationError):
    """사용자 쿼리 검증 실패 시 발생하는 예외."""

    pass


class IntentClassificationError(IntegrationError):
    """의도 분류 실패 시 발생하는 예외."""

    pass


class IntentParsingError(IntegrationError):
    """의도 파싱 실패 시 발생하는 예외."""

    pass


class DocumentRetrievalError(IntegrationError):
    """문서 검색 실패 시 발생하는 예외."""

    pass


class ResponseGenerationError(IntegrationError):
    """응답 생성 실패 시 발생하는 예외."""

    pass


@dataclass
class StepResult:
    """개별 처리 단계 결과."""

    status: ProcessingStatus | None = None
    response: dict[str, Any] | None = None
    latency: float | None = None


@dataclass
class ProcessingResult:
    """전체 처리 결과 구조."""

    status: ProcessingStatus | None = None
    message: str | None = None
    latency: str | None = None
    api_result: dict[str, StepResult] | None = None

    def __post_init__(self):
        if self.api_result is None:
            self.api_result = {
                "intent_classify": StepResult(),
                "rag_retrieve": StepResult(),
                "qa_response": StepResult(),
                "draft_press": StepResult(),
            }


@contextmanager
def measure_latency() -> Iterator[dict[str, float]]:
    """실행 지연시간 측정을 위한 컨텍스트 매니저."""
    start_time = time.perf_counter()
    result = {}
    try:
        yield result
    finally:
        result["latency"] = time.perf_counter() - start_time


class RequestValidator:
    """요청 검증을 위한 유틸리티 클래스."""

    @staticmethod
    def extract_user_query(req: BaseRequest) -> str:
        """요청에서 사용자 쿼리를 추출하고 검증."""
        if not req.user_query or not isinstance(req.user_query, str):
            raise UserQueryValidationError(
                "user_query는 필수이며 비어있지 않은 문자열이어야 합니다",
                ProcessingStep.USER_QUERY_VALIDATION,
            )

        # 기본 입력 검증
        user_query = req.user_query.strip()[:1000]  # 보안을 위한 길이 제한
        logger.info(f"user_query: {user_query}")
        return user_query


class ErrorHandler:
    """오류 처리를 위한 유틸리티 클래스."""

    @staticmethod
    def create_error_result(
        error: IntegrationError, result: ProcessingResult, additional_context: str = ""
    ) -> dict[str, Any]:
        """표준화된 오류 결과 생성."""
        error_message = f"step{error.step.step_id}. {error.step.description} 단계 에러"

        if additional_context:
            error_message += f"\n\n{additional_context}"
        error_message += f"\n{error}"

        result.status = ProcessingStatus.ERROR
        result.message = error_message

        logger.error(error_message, exc_info=True)
        return asdict(result)


class IntegrationService:
    """통합 요청 처리를 위한 서비스 클래스."""

    def __init__(self, llm_studio: LLMStudio, rag: RAG):
        self._llm_studio = llm_studio
        self._rag = rag

    async def _classify_intent(
        self, user_query: str, result: ProcessingResult
    ) -> tuple[dict[str, Any], int]:
        """사용자 의도를 분류하고 응답을 파싱."""
        intent_classify = result.api_result["intent_classify"]

        # Step 2: 의도 분류 요청
        try:
            with measure_latency() as timing:
                intent_response = await self._llm_studio.get_intent(
                    user_query=user_query
                )

            intent_classify.status = ProcessingStatus.SUCCESS
            intent_classify.response = intent_response
            intent_classify.latency = timing["latency"]

            logger.info(f"intent_response: {intent_classify}")
        except Exception as e:
            intent_classify.status = ProcessingStatus.ERROR
            raise IntentClassificationError(
                "의도 분류가 실패했습니다", ProcessingStep.INTENT_CLASSIFICATION
            ) from e

        # Step 3: 의도 분류 답변 파싱
        try:
            llm_result = intent_response.get("llm_result", {})
            answer = llm_result.get("answer", "")
            intent_info = self._llm_studio.get_answer(answer)

            logger.info(f"intent_info: {intent_info}")
            return intent_info, self._extract_intent_number(intent_info)
        except Exception as e:
            # 의도 파싱 실패 시 기본 질의응답으로 처리
            logger.warning(f"의도 파싱 실패, 기본 질의응답으로 처리: {e}")
            default_intent_info: dict[str, Any] = {
                "intent": [{"no": 101}],
                "search_query": [],
            }
            return default_intent_info, 101

    def _extract_intent_number(self, intent_info: dict[str, Any]) -> int:
        """월러스 연산자를 사용하여 의도 정보에서 의도 번호를 추출."""
        try:
            if not (intent := intent_info.get("intent")) or not isinstance(
                intent, list
            ):
                raise ValueError("잘못된 의도 구조입니다")

            if not intent or not (first_intent := intent[0]):
                raise ValueError("의도 목록이 비어있습니다")

            if not isinstance(intent_no := first_intent.get("no"), int):
                raise ValueError("의도 번호는 정수여야 합니다")

            logger.info(f"intent: {intent_no}")
            return intent_no
        except Exception as e:
            raise ValueError("의도 번호 추출에 실패했습니다") from e

    async def _retrieve_documents(
        self, user_query: str, intent_info: dict[str, Any], result: ProcessingResult
    ) -> Any | None:
        """필요한 경우 RAG를 사용하여 문서를 검색."""
        rag_retrieve = result.api_result["rag_retrieve"]

        try:
            search_query = [user_query]
            # if search_queries := intent_info.get("search_query", []):
            #     search_query.extend(search_queries)
            for query in [
                next(iter(q.values())) for q in intent_info.get("search_query", [])
            ]:
                if query not in search_query:
                    search_query.append(query)

            logger.info(f"search_query for RAG: {search_query}")

            with measure_latency() as timing:
                retrieve_response = await self._rag.retrieve_documents(
                    queries=search_query
                )

            rag_retrieve.status = ProcessingStatus.SUCCESS
            rag_retrieve.response = retrieve_response
            rag_retrieve.latency = timing["latency"]

            logger.info(f"retrieve_response: {retrieve_response}")

            rag_psgs = self._rag.get_rag_psgs(retrieve_response)
            logger.info(f"rag_psgs: {rag_psgs}")
            return rag_psgs
        except Exception as e:
            rag_retrieve.status = ProcessingStatus.ERROR
            raise DocumentRetrievalError(
                "문서 검색이 실패했습니다", ProcessingStep.DOCUMENT_RETRIEVAL
            ) from e

    async def _generate_final_response(
        self,
        user_query: str,
        intent_no: int,
        rag_psgs: Any | None,
        result: ProcessingResult,
    ) -> dict[str, Any]:
        """의도 유형에 따라 최종 응답을 생성."""
        # Step 5: 최종답변 생성 요청 파라미터 정의
        try:
            is_rag = rag_psgs is not None
            body = RequestWithRAG(
                user_query=user_query, is_rag=is_rag, rag_psgs=rag_psgs, stream=False
            ).model_dump(exclude_none=True)

            logger.info(f"RequestWithRAG body: {body}")
        except Exception as e:
            raise ResponseGenerationError(
                "요청 파라미터 준비에 실패했습니다",
                ProcessingStep.PARAMETER_PREPARATION,
            ) from e

        # Step 6: 최종 답변 생성 요청 ('문서검색' 또는 '초안생성')
        draft_press = result.api_result["draft_press"]
        qa_response = result.api_result["qa_response"]

        try:
            if intent_no > DRAFT_GENERATION_THRESHOLD:  # 초안생성
                logger.info("Branch: draft_press (초안생성)")

                with measure_latency() as timing:
                    response = await self._llm_studio.get_draft_press(**body)

                draft_press.status = ProcessingStatus.SUCCESS
                draft_press.response = response
                draft_press.latency = timing["latency"]

            else:  # 질의응답
                logger.info("Branch: qa_response (질의응답)")

                with measure_latency() as timing:
                    response = await self._llm_studio.get_qa_response(**body)

                qa_response.status = ProcessingStatus.SUCCESS
                qa_response.response = response
                qa_response.latency = timing["latency"]

            logger.info(f"Final response: {response}")
            return response
        except Exception as e:
            if intent_no > DRAFT_GENERATION_THRESHOLD:
                draft_press.status = ProcessingStatus.ERROR
                response_type = "초안생성"
            else:
                qa_response.status = ProcessingStatus.ERROR
                response_type = "질의응답"

            raise ResponseGenerationError(
                f"최종 응답 생성이 실패했습니다 ({response_type})",
                ProcessingStep.RESPONSE_GENERATION,
            ) from e

    async def process_request(self, req: BaseRequest) -> dict[str, Any]:
        """통합 요청을 위한 메인 처리 메서드."""
        result = ProcessingResult()
        validator = RequestValidator()

        total_start = time.perf_counter()

        try:
            logger.info("integration_answer endpoint called")

            # Step 1: 사용자 질의 확인
            try:
                user_query = validator.extract_user_query(req)
            except IntegrationError as e:
                result.status = ProcessingStatus.ERROR
                result.message = (
                    f"step{e.step.step_id}. {e.step.description} 단계 에러\n{e}"
                )
                result.latency = str(time.perf_counter() - total_start)
                logger.error(result.message, exc_info=True)
                return asdict(result)

            # Steps 2-3: 의도 분류 요청 및 파싱
            try:
                intent_info, intent_no = await self._classify_intent(user_query, result)
            except IntegrationError as e:
                result.status = ProcessingStatus.ERROR
                result.message = (
                    f"step{e.step.step_id}. {e.step.description} 단계 에러\n{e}"
                )
                result.latency = str(time.perf_counter() - total_start)
                logger.error(result.message, exc_info=True)
                return asdict(result)

            # Step 4 & 4_1: RAG 검색 여부 확인 및 문서 검색
            try:
                rag_psgs = None
                if intent_no in RAG_INTENT_CODES:
                    rag_psgs = await self._retrieve_documents(
                        user_query, intent_info, result
                    )
            except IntegrationError as e:
                result.status = ProcessingStatus.ERROR
                result.message = (
                    f"step{e.step.step_id}. {e.step.description} 단계 에러\n{e}"
                )
                result.latency = str(time.perf_counter() - total_start)
                logger.error(result.message, exc_info=True)
                return asdict(result)

            # Steps 5-6: 최종 답변 생성
            try:
                response = await self._generate_final_response(
                    user_query, intent_no, rag_psgs, result
                )
            except IntegrationError as e:
                result.status = ProcessingStatus.ERROR
                result.message = (
                    f"step{e.step.step_id}. {e.step.description} 단계 에러\n{e}"
                )
                result.latency = str(time.perf_counter() - total_start)
                logger.error(result.message, exc_info=True)
                return asdict(result)

            # 정상처리(LLM Studio 의 상태값이 C20000)
            if llm_result := response.get("llm_result"):
                result.message = llm_result.get("answer")
            else:
                result.message = response.get("response_code")

            result.status = ProcessingStatus.SUCCESS
            result.latency = str(time.perf_counter() - total_start)

            return asdict(result)

        except Exception as e:
            # 예상하지 못한 오류에 대한 폴백
            result.status = ProcessingStatus.ERROR
            result.message = f"예상하지 못한 오류가 발생했습니다: {e}"
            result.latency = str(time.perf_counter() - total_start)
            logger.error(result.message, exc_info=True)
            return asdict(result)


# 의존성 주입 함수들
@lru_cache(maxsize=1)
def get_llm_studio() -> LLMStudio:
    """LLMStudio 인스턴스를 가져옴 (싱글턴)."""
    return LLMStudio(timeout=DEFAULT_LLM_TIMEOUT)


@lru_cache(maxsize=1)
def get_rag() -> RAG:
    """RAG 인스턴스를 가져옴 (싱글턴)."""
    return RAG()


def get_integration_service(
    llm_studio: LLMStudio = Depends(get_llm_studio), rag: RAG = Depends(get_rag)
) -> IntegrationService:
    """의존성이 주입된 통합 서비스 인스턴스를 가져옴."""
    return IntegrationService(llm_studio=llm_studio, rag=rag)


@router.post("/get-answer")
async def integration_answer(
    req: BaseRequest, service: IntegrationService = Depends(get_integration_service)
) -> dict[str, Any]:
    """의도 분류 및 RAG를 통한 사용자 쿼리 처리를 위한 통합 엔드포인트.

    Args:
        req: user_query를 포함하는 BaseRequest
        service: IntegrationService 인스턴스 (주입됨)

    Returns:
        status, message, latency, api_result 세부사항을 포함하는 Dict
    """
    return await service.process_request(req)
