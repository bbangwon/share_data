from fastapi import APIRouter

from app.services.llm_studio import BaseRequest, LLMStudio, RequestWithRAG

router = APIRouter(prefix="/llm-studio")

llm_studio = LLMStudio(timeout=60)


@router.get("/health-check")
async def health_check():
    response = await llm_studio.health_check()
    return response


@router.post("/intent-classify", description="의도분석")
async def intent_classify(req_intent: BaseRequest):
    response = await llm_studio.get_intent(**req_intent.model_dump(exclude_none=True))
    return response


@router.post("/query-expand", description="질의확장")
async def expanded_query(req_expand: BaseRequest):
    response = await llm_studio.get_expanded_query(
        **req_expand.model_dump(exclude_none=True)
    )
    return response


@router.post(
    "/qa-response",
    description="101_일상대화 / 201_질의응답(RAG) / 501_민감정보 / 900_미분류",
)
async def qa_response(req: RequestWithRAG):
    response = await llm_studio.get_qa_response(**req.model_dump(exclude_none=True))
    return response


@router.post("/draft-policy-plan", description="301_정책계획보고서(RAG)")
async def draft_policy_plan(req: RequestWithRAG):
    response = await llm_studio.get_draft_policy_plan(
        **req.model_dump(exclude_none=True)
    )
    return response


@router.post("/draft-press", description="302_보도자료(RAG)")
async def draft_press(req: RequestWithRAG):
    response = await llm_studio.get_draft_press(**req.model_dump(exclude_none=True))
    return response


@router.post("/draft-speech", description="303_인사말씀")
async def draft_speech(req: RequestWithRAG):
    response = await llm_studio.get_draft_speech(**req.model_dump(exclude_none=True))
    return response


@router.post("/draft-event", description="304_행사시나리오")
async def draft_event(req: RequestWithRAG):
    response = await llm_studio.get_draft_event(**req.model_dump(exclude_none=True))
    return response


@router.post("/draft-monthly-report", description="305_월간업무보고")
async def draft_monthly_report(req: RequestWithRAG):
    response = await llm_studio.get_draft_monthly_report(
        **req.model_dump(exclude_none=True)
    )
    return response


@router.post("/draft-weekly-report", description="306_주간업무보고")
async def draft_weekly_report(req: RequestWithRAG):
    response = await llm_studio.get_draft_weekly_report(
        **req.model_dump(exclude_none=True)
    )
    return response


@router.post("/draft-congress", description="307_의회보고자료")
async def draft_congress(req: RequestWithRAG):
    response = await llm_studio.get_draft_congress(**req.model_dump(exclude_none=True))
    return response


@router.post("/draft-report", description="308_국과장보고자료")
async def draft_report(req: RequestWithRAG):
    response = await llm_studio.get_draft_report(**req.model_dump(exclude_none=True))
    return response


@router.post("/draft-letter", description="309_시행문")
async def draft_letter(req: RequestWithRAG):
    response = await llm_studio.get_draft_letter(**req.model_dump(exclude_none=True))
    return response


@router.post("/draft-annual-report", description="310_백서")
async def draft_annual_report(req: RequestWithRAG):
    response = await llm_studio.get_draft_annual_report(
        **req.model_dump(exclude_none=True)
    )
    return response


@router.post("/draft-weekly-policy", description="311_주간정책자료")
async def draft_weekly_policy(req: RequestWithRAG):
    response = await llm_studio.get_draft_weekly_policy(
        **req.model_dump(exclude_none=True)
    )
    return response


@router.post("/content-summary", description="콘텐츠 요약")
async def content_summary(req: RequestWithRAG):
    response = await llm_studio.get_content_summary(
        **req.model_dump(exclude_none=True, by_alias=True)
    )
    return response
