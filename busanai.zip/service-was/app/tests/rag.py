from fastapi import APIRouter
from fastapi.responses import JSONResponse

from app.services.rag import RAG, RequestQdrantRetrieve

router = APIRouter(prefix="/rag")

rag = RAG()


@router.get("/health-check")
async def health_check():
    response = await rag.health_check()
    return JSONResponse(response)


@router.post("/retrieve")
async def retrieve(req_retrieve: RequestQdrantRetrieve):
    response = await rag.retrieve_documents(
        **req_retrieve.model_dump(exclude_none=True)
    )
    return response
