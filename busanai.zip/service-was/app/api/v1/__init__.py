from fastapi import APIRouter

from . import event_stream

router = APIRouter()

router.include_router(event_stream.router, prefix="/stream", tags=["Text/Event-Stream"])
