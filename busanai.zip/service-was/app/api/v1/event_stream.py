from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from app.state import AppState

router = APIRouter()


@router.get("/generate")
async def stream_generate(chat_session_id: int):
    stream_buffer = AppState.stream_buffers.get(chat_session_id)
    if stream_buffer is None:
        err_message = "실시간 생성 답변을 찾을 수 없습니다."
        return StreamingResponse(content=err_message, status_code=404)
    return StreamingResponse(stream_buffer.stream(), media_type="text/event-stream")
