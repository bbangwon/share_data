import os

from admin_db_manager import AdminDBManager
from busan_bot_ui import BusanBotUIManager
from db_manager import DBManager

from app.core import settings
from app.core.logger import get_logger
from app.handlers.chat import ChatHandler
from app.services import RAG, LLMStudio, Task

logger = get_logger(__name__)


class TaskProcessor:
    def __init__(self):
        self.task_client = Task()

        # Initialize dependencies
        self.admin_db_manager = AdminDBManager(settings.ADMIN_DATABASE_URL)
        logger.info(
            f"Initializing AdminDBManager with URL: {settings.ADMIN_DATABASE_URL}"
        )

        self.db_manager = DBManager(settings.DATABASE_URL)
        logger.info(f"Initializing DBManager with URL: {settings.DATABASE_URL}")

        self.bot_manager = BusanBotUIManager(
            config_path=settings.CONFIG_PATH,
            static_messages_path=settings.STATIC_MESSAGES_PATH,
        )
        logger.info("Initialized BusanBotUIManager")

        self.llm_studio = LLMStudio()
        logger.info("Initialized LLMStudio")

        self.rag = RAG()
        logger.info("Initialized RAG")

        self.chat_handler = ChatHandler(
            admin_db_manager=self.admin_db_manager,
            db_manager=self.db_manager,
            bot_manager=self.bot_manager,
            llm_studio=self.llm_studio,
            rag=self.rag,
        )

    async def process(self, worker_id: str, task_info: dict):
        pid = os.getpid()
        task = task_info.get("task")
        task_id = task.get("id")

        logger.info(f"[PID {pid}] Received new task from queue: {task_id}")

        chat_session_id = task_info.get("chat_id")
        bot_id = task.get("headers").get("x-works-botid")
        # bot 정보 확인(내부, 외부, 문서)
        bot_meta_info = self.bot_manager.get_bot_meta_info(bot_id=bot_id)
        service_type = (
            bot_meta_info.service
        )  # >> Literal["general", "internal", "external", "generate"]

        body = task.get("body")
        user_id = body.get("source").get("user_id")
        content = body.get("content")
        content_type = content.get("type")
        message = content.get("text")
        attached_file: dict | None = body.get("attached_file")

        status = "success"

        await self.bot_manager.write_log(
            task_id=task_id,
            user_id=user_id,
            bot_id=bot_id,
            log={
                "WAS": "AI Service",
                "STEP": "01. Task WAS 메세지큐 수신",
                "BODY": {
                    "bot_type": service_type,
                    "type": content_type,
                    "text": message,
                },
            },
        )
        await self.bot_manager.write_admin_log(
            task_id=task_id,
            user_id=user_id,
            bot_id=bot_id,
            log={"AL-USER-MESSAGE": message},
        )

        try:
            await self.chat_handler.process_chat(
                task_id=task_id,
                chat_session_id=chat_session_id,
                user_id=user_id,
                bot_id=bot_id,
                service_type=service_type,
                message=message,
                attached_file=attached_file,
                pid=pid,
            )

        except Exception as e:
            status = "failed"
            logger.error(f"[Error - handle_task][{task_id=}]: {e}", exc_info=True)

            # "사용자 + 관리자" NAVER WORKS 오류 메시지 전송
            error_message = (
                "🚨 답변 생성중 오류가 발생했습니다. 관리자에게 문의해주세요."
            )
            await self.bot_manager.send_error_message(
                bot_id=bot_id,
                user_id=user_id,
                error_message=error_message,
                task_id=task_id,
            )
        finally:
            logger.info(f">>> [PID {pid}][{task_id=}] Worker # {worker_id} finished")
            await self.task_client.update_task(
                task_id=task_id, payload={"status": status}
            )
