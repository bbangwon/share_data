from typing import Literal

from admin_db_manager import AdminDBManager, ChatbotTypeEnum
from busan_bot_ui import BusanBotUIManager
from db_manager import DBManager

from app.core import settings
from app.core.logger import get_logger
from app.services import (
    RAG,
    LLMStudio,
    encode_token,
    get_group_filter,
    get_service_filter,
)

logger = get_logger(__name__)

RAG_INTENT_CODES = settings.RAG_INTENT_CODES


class ChatHandler:
    def __init__(
        self,
        admin_db_manager: AdminDBManager,
        db_manager: DBManager,
        bot_manager: BusanBotUIManager,
        llm_studio: LLMStudio,
        rag: RAG,
    ):
        self.admin_db_manager = admin_db_manager
        self.db_manager = db_manager
        self.bot_manager = bot_manager
        self.llm_studio = llm_studio
        self.rag = rag
        self.llm_studio_gen_answer_apis = {
            # 일상대화
            101: self.llm_studio.get_conversation,
            # 질의응답
            201: self.llm_studio.get_qa_response,
            # 정책계획 보고서 초안 작성
            301: self.llm_studio.get_draft_policy_plan,
            # 보도자료 초안 작성
            302: self.llm_studio.get_draft_press,
            # 인사말씀 초안 작성
            303: self.llm_studio.get_draft_speech,
            # 행사 시나리오 초안 작성
            304: self.llm_studio.get_draft_event,
            # 월간업무보고 초안 작성
            305: self.llm_studio.get_draft_monthly_report,
            # 주간업무보고 초안 작성
            306: self.llm_studio.get_draft_weekly_report,
            # 의회보고자료 초안 작성
            307: self.llm_studio.get_draft_congress,
            # 국/과장 보고자료 초안 작성
            308: self.llm_studio.get_draft_report,
            # 시행문 초안 작성
            309: self.llm_studio.get_draft_letter,
            # 백서 초안 작성
            310: self.llm_studio.get_draft_annual_report,
            # 주간정책자료 초안 작성
            311: self.llm_studio.get_draft_weekly_policy,
            # 민감정보
            501: self.llm_studio.get_conversation,
            # 미분류
            900: self.llm_studio.get_conversation,
        }

    def get_dialog_history(
        self,
        use_dialog: bool,
        total_cnt: int,
        api_with_dialog: bool,
        dialog_cnt: int,
        dialog_history: list = [],
    ) -> list:
        if (
            (use_dialog is False)
            or (api_with_dialog is False)
            or (total_cnt <= 0)
            or (dialog_cnt <= 0)
            or len(dialog_history) <= 0
        ):
            return []
        else:
            max_length = dialog_cnt if total_cnt >= dialog_cnt else total_cnt
            return dialog_history[-(max_length * 2) :]

    async def get_waiting_message_by_bot_id(self, bot_id: str) -> str | None:
        """
        지정한 bot_id에 대해 bot_meta를 가져오고 admin_db_manager를 사용하여
        해당 bot_service에 대한 최신 waiting_message를 반환합니다.
        """

        # bot id로 메타정보 가져옴(bot_service)
        bot_meta_info = self.bot_manager.get_bot_meta_info(bot_id=bot_id)
        if not bot_meta_info or not bot_meta_info.service:
            return None

        # bot_service에 따른 ChatbotTypeEnum 매핑
        mapping = {
            "generate": ChatbotTypeEnum.CREATE_DRAFT,
            "external": ChatbotTypeEnum.EXTERNAL_ANALYSIS,
            "internal": ChatbotTypeEnum.QNA,
        }
        chatbot_type = mapping.get(
            bot_meta_info.service
        )  # bot_service -> ChatbotTypeEnum
        if not chatbot_type:
            logger.error(f"유효하지 않은 bot_service입니다. : {bot_meta_info.service}")
            return None

        # 대기 메시지 가져옴
        waiting_message = (
            await self.admin_db_manager.get_latest_waiting_message_by_type(chatbot_type)
        )
        return waiting_message

    async def process_chat(
        self,
        task_id: str,
        chat_session_id: str,
        user_id: str,
        bot_id: str,
        service_type: Literal["general", "internal", "external", "generate"],
        message: str,
        attached_file: dict | None,
        pid: int,
    ) -> str:
        attached_message = None
        if attached_file is not None:
            attached_message = f"--- 파일정보 ---\n{attached_file}\n------\n{message}"

        is_rag = False
        rag_psgs = None
        static_message_obj = None
        final_message = ""
        annotated_file_paths = []

        # 1. DB 대화이력 조회
        dialog_history = []
        if settings.USE_DIALOG_HISTORY:
            try:
                logger.debug(
                    f"[PID {pid}][{task_id=}] Fetching chat history for session: {chat_session_id}"
                )
                dialog_pairs = await self.db_manager.get_chat_histories_by_session_id(
                    chat_session_id=chat_session_id,
                    count=settings.DIALOG_HISTORY_COUNT,
                )
                for d in dialog_pairs:
                    if d.user_message is not None and d.bot_message is not None:
                        dialog_history.append(
                            {"role": "user", "content": d.user_message}
                        )
                        dialog_history.append(
                            {"role": "assistant", "content": d.bot_message}
                        )
                log_body = {"result": "success", "detail": dialog_history}
            except Exception as e:
                err_message = "DB 대화이력 조회 ERR"
                log_body = {"result": "err", "detail": str(e)}
                logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
                raise e
            finally:
                await self.bot_manager.write_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "WAS": "AI Service",
                        "STEP": "02. DB 대화이력 조회",
                        "BODY": log_body,
                    },
                )

        # 2. DB 사용자 질의 저장
        try:
            logger.debug(f"[PID {pid}][{task_id=}] Saving user chat history")
            chat_number: int = await self.db_manager.add_user_chat_history(
                chat_session_id=chat_session_id,
                message=message,
            )
            log_body = {"result": "success", "detail": None}
        except Exception as e:
            err_message = "DB 사용자 질의 저장 ERR"
            log_body = {"result": "err", "detail": str(e)}
            logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
            raise e
        finally:
            await self.bot_manager.write_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "WAS": "AI Service",
                    "STEP": "03. DB 사용자 질의 저장",
                    "BODY": log_body,
                },
            )

        # 3. NAVERWORKS 답변생성중 메세지 발신
        web_view_uri = ""
        try:
            logger.debug(f"[PID {pid}][{task_id=}] Sending generate answer message")

            end_point = f"api/v1/stream/generate?chat_session_id={chat_session_id}"
            stream_url = (
                f"{settings.SERVICE_WAS_IP}:{settings.SERVICE_WAS_PORT}/{end_point}"
            )
            encode_info = {
                "chat_session_id": chat_session_id,
                "chat_number": chat_number,
                "stream_url": stream_url,
            }
            token = encode_token(encode_info)
            web_view_uri = (
                f"{settings.WEB_VIEW_URL}?service={service_type}&token={token}"
            )

            # Bot ID(bot type별)로 대기 메시지 가져오기
            waiting_message = await self.get_waiting_message_by_bot_id(bot_id=bot_id)

            await self.bot_manager.send_wait_message(
                bot_id=bot_id, user_id=user_id, uri=web_view_uri, text=waiting_message
            )

            log_body = {"result": "success", "detail": encode_info}
        except Exception as e:
            err_message = "NAVERWORKS 답변생성중 메세지 발신 ERR"
            log_body = {"result": "err", "detail": str(e)}
            logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
            raise e
        finally:
            await self.bot_manager.write_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "WAS": "AI Service",
                    "STEP": "04. NAVERWORKS 답변생성중 메세지 발신",
                    "BODY": log_body,
                },
            )

        # 4. 의도분석 API 요청
        try:
            logger.debug(
                f"[PID {pid}][{task_id=}] Requesting intent analysis for message"
            )
            intent_response = await self.llm_studio.get_intent(
                user_query=message,
                dialog_history=self.get_dialog_history(
                    use_dialog=settings.USE_DIALOG_HISTORY,
                    total_cnt=settings.DIALOG_HISTORY_COUNT,
                    api_with_dialog=settings.DIALOG_USAGE_LIST[0],
                    dialog_cnt=settings.DIALOG_USAGE_COUNT[0],
                    dialog_history=dialog_history,
                ),
            )
            log_body = {"result": "success", "detail": intent_response}
        except Exception as e:
            err_message = "LLM WAS 의도분석 API 요청 ERR"
            log_body = {"result": "err", "detail": str(e)}
            logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
            raise e
        finally:
            await self.bot_manager.write_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "WAS": "AI Service",
                    "STEP": "05_01. LLM WAS 의도분석 API 요청",
                    "BODY": log_body,
                },
            )

        # 5. 의도분석 API 요청 결과 파싱
        try:
            intent_info = await self.llm_studio.get_parsed_intent(
                intent_response.get("llm_result").get("answer")
            )
            intent = intent_info.get("intent")
            intent_no = int(intent.get("no"))
            intent_name = intent.get("intent_name")
            log_body = {"result": "success", "detail": intent}
            logger.info(f"[PID {pid}][{task_id=}] Intent analysis result: {intent}")
        except Exception as e:
            err_message = "의도분석 API 요청 결과 파싱 ERR"
            log_body = {"result": "err", "detail": str(e)}
            logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
            raise e
        finally:
            await self.bot_manager.write_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "WAS": "AI Service",
                    "STEP": "05_02. 의도분석 API 요청 결과 파싱",
                    "BODY": log_body,
                },
            )

        # 고정답변 여부 확인
        is_fixed_answer = False

        ## 특정 의도에 따른 고정답변 처리 여부 확인
        static_message_obj = await self.db_manager.get_static_message_from_intent(
            intent_id=intent_no, intent_name=intent_name
        )
        if static_message_obj is not None:
            is_fixed_answer = True
            final_message = static_message_obj.message

        ## 봇타입 별 질문의도에 따른 고정답변 처리 여부 확인
        if service_type == "internal" or service_type == "external":
            if intent_no // 100 == 3:
                is_fixed_answer = True
                final_message = "문서 초안 작성과 관련된 질문은 AI부기주무관(초안생성) 봇에게 물어봐주세요."  # // TODO: 메세지 동적주입으로 처리하기

        elif service_type == "generate":
            if (intent_no // 100 == 1) or (intent_no // 100 == 2):
                is_fixed_answer = True
                final_message = "저는 문서의 초안을 작성하는데 도움을 드릴 수 있습니다. 해당 질문은 다른 부기주무관에게 물어봐주세요."  # // TODO: 메세지 동적주입으로 처리하기

        # RAG 검색여부 확인 - 고정메세지가 있는 경우 문서(RAG) 검색 X
        if intent_no in RAG_INTENT_CODES and not is_fixed_answer:
            # RAG 검색 질문 리스트
            queries = [message] if settings.ADD_ORIGINAL_MESSAGE else []

            # 6. 검색 질문에 정제된 질의 또는 확장된 질의를 필요로 하는 경우
            if settings.ADD_QUERY_COMPLETE or settings.ADD_SEARCH_QUERIES:
                # 질의확장 API 요청
                try:
                    logger.debug(f"[PID {pid}][{task_id=}] Requesting query expand")
                    expand_response = await self.llm_studio.get_expanded_query(
                        user_query=message
                        if attached_file is None
                        else attached_message,
                        dialog_history=self.get_dialog_history(
                            use_dialog=settings.USE_DIALOG_HISTORY,
                            total_cnt=settings.DIALOG_HISTORY_COUNT,
                            api_with_dialog=settings.DIALOG_USAGE_LIST[1],
                            dialog_cnt=settings.DIALOG_USAGE_COUNT[1],
                            dialog_history=dialog_history,
                        ),
                    )
                    log_body = {"result": "success", "detail": expand_response}
                except Exception as e:
                    err_message = "질의확장 API 요청 ERR"
                    log_body = {"result": "err", "detail": str(e)}
                    logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
                    raise e
                finally:
                    await self.bot_manager.write_log(
                        task_id=task_id,
                        user_id=user_id,
                        bot_id=bot_id,
                        log={
                            "WAS": "AI Service",
                            "STEP": "06_01. LLM WAS 질의확장 API 요청",
                            "BODY": log_body,
                        },
                    )

                # 질의확장 API 요청 결과 파싱
                try:
                    query_info = await self.llm_studio.get_parsed_query(
                        expand_response.get("llm_result").get("answer")
                    )
                    # 정제된 질의
                    query_complete = query_info.get("query_complete")
                    _temp_queries = (
                        [query_complete]
                        if (query_complete and settings.ADD_QUERY_COMPLETE)
                        else []
                    )

                    # 검색 확장 질의
                    search_queries = query_info.get("search_queries")
                    if search_queries and settings.ADD_SEARCH_QUERIES:
                        _temp_queries.extend(search_queries)

                    for query in _temp_queries:
                        # 최소 두 글자 이상이고 중복되지 않는 경우만 검색 질문 리스트 추가
                        if (len(query) > 2) and (query not in queries):
                            queries.append(query)
                    log_body = {"result": "success", "detail": queries}
                    logger.info(
                        f"[PID {pid}][{task_id=}] Expanded query result: {queries}"
                    )
                except Exception as e:
                    err_message = "질의확장 API 요청 결과 파싱 ERR"
                    log_body = {"result": "err", "detail": str(e)}
                    logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
                    raise e
                finally:
                    await self.bot_manager.write_log(
                        task_id=task_id,
                        user_id=user_id,
                        bot_id=bot_id,
                        log={
                            "WAS": "AI Service",
                            "STEP": "06_02. 질의확장 API 요청 결과 파싱",
                            "BODY": log_body,
                        },
                    )

            try:
                if queries:
                    logger.debug(
                        f"[PID {pid}][{task_id=}] Performing RAG document retrieval"
                    )
                    # 검색 조건 추가
                    filters = []
                    if settings.USE_SERVICE_FILTER:
                        ## LLM Studio 서비스 분류 API 요청 > service 제약조건 확인
                        try:
                            service_response = (
                                await self.llm_studio.get_service_category(
                                    user_query=message,
                                    dialog_history=self.get_dialog_history(
                                        use_dialog=settings.USE_DIALOG_HISTORY,
                                        total_cnt=settings.DIALOG_HISTORY_COUNT,
                                        api_with_dialog=settings.DIALOG_USAGE_LIST[2],
                                        dialog_cnt=settings.DIALOG_USAGE_COUNT[2],
                                        dialog_history=dialog_history,
                                    ),
                                )
                            )
                            log_body = {
                                "result": "success",
                                "detail": service_response,
                            }
                        except Exception as e:
                            err_message = "서비스 분류 API 요청 ERR"
                            log_body = {"result": "err", "detail": str(e)}
                            logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
                            raise e
                        finally:
                            await self.bot_manager.write_log(
                                task_id=task_id,
                                user_id=user_id,
                                bot_id=bot_id,
                                log={
                                    "WAS": "AI Service",
                                    "STEP": "06_03. 서비스 분류 API 요청",
                                    "BODY": log_body,
                                },
                            )

                        try:
                            service_info = await self.llm_studio.get_parsed_service(
                                service_response.get("llm_result").get("answer")
                            )
                            log_body = {
                                "result": "success",
                                "detail": service_info,
                            }
                        except Exception as e:
                            err_message = "서비스 분류 API 요청 결과 파싱 ERR"
                            log_body = {"result": "err", "detail": str(e)}
                            logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
                            raise e
                        finally:
                            await self.bot_manager.write_log(
                                task_id=task_id,
                                user_id=user_id,
                                bot_id=bot_id,
                                log={
                                    "WAS": "AI Service",
                                    "STEP": "06_04. 서비스 분류 API 요청 결과 파싱",
                                    "BODY": log_body,
                                },
                            )
                        service_filter: list = await get_service_filter(
                            service_info.get("service", [])
                        )
                        if len(service_filter) > 0:
                            filters.append(service_filter)

                    if settings.USE_GROUP_FILTER:
                        ## "질의 원문 + 정제된 질의" > group 제약조건 확인
                        group_filter: list = await get_group_filter(
                            queries=[message, queries[0]], service_type=service_type
                        )
                        if len(group_filter) > 0:
                            filters.append(group_filter)

                    # RAG 검색 API 요청
                    retrieve_response = await self.rag.retrieve_documents(
                        queries=queries,
                        filters=filters if filters else None,
                        base_query=(
                            message
                            if settings.BASE_QUERY_TYPE == "origin"
                            else query_complete
                        )
                        if settings.USE_BASE_QUERY
                        else None,
                        service_type=service_type,
                    )
                    retrieve_results = retrieve_response.get("results")

                    # Retrieval 결과를 llm api에 맞춰 변형
                    ref_data = await self.rag.get_ref_documents(
                        retrieve_results, settings.REF_LIMIT
                    )
                    if ref_data:
                        is_rag = True
                        rag_psgs = [
                            {
                                "id": k,
                                "passage": (
                                    f"[파일명: {v.get('file')}]\n[페이지: {v.get('page_num')}]\n{v.get('parent_text')}"
                                ),
                            }
                            for k, v in ref_data.items()
                        ]
                    log_body = {
                        "result": "success",
                        "detail": {
                            "ref_docs": rag_psgs,
                            "total_docs": retrieve_response,
                        },
                    }

            except Exception as e:
                err_message = "RAG 검색 API 요청 ERR"
                log_body = {"result": "err", "detail": str(e)}
                logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
                raise e
            finally:
                await self.bot_manager.write_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "WAS": "AI Service",
                        "STEP": "06_05. RAG 검색 API 요청",
                        "BODY": log_body,
                    },
                )
                if is_rag and ref_data:
                    await self.bot_manager.write_admin_log(
                        task_id=task_id,
                        user_id=user_id,
                        bot_id=bot_id,
                        log={
                            "AL-VDB-CHUNKS": [
                                {"id": k, "parent_text": v.get("parent_text")}
                                for k, v in ref_data.items()
                            ]
                        },
                    )

        # 7. 최종답변 생성 - 고정메세지가 있는 경우 답변생성 API 요청 X
        if not is_fixed_answer:  # is_fixed_answer == False 인 경우
            # 최종답변 생성 API 요청
            try:
                logger.debug(f"[PID {pid}][{task_id=}] Generating final response")
                gen_ans_response = await self.llm_studio_gen_answer_apis[intent_no](
                    user_query=message if attached_file is None else attached_message,
                    is_rag=is_rag,
                    stream=True,
                    rag_psgs=rag_psgs,
                    chat_session_id=chat_session_id,
                    dialog_history=self.get_dialog_history(
                        use_dialog=settings.USE_DIALOG_HISTORY,
                        total_cnt=settings.DIALOG_HISTORY_COUNT,
                        api_with_dialog=settings.DIALOG_USAGE_LIST[3],
                        dialog_cnt=settings.DIALOG_USAGE_COUNT[3],
                        dialog_history=dialog_history,
                    ),
                )
                llm_result = gen_ans_response.get("llm_result")
                final_message: str = llm_result.get("answer")  # 생성된 답변
                logger.info(f"[PID {pid}][{task_id=}] LLM message generated")
                log_body = {"result": "success", "detail": llm_result}
            except Exception as e:
                err_message = "LLM WAS 최종답변 생성 API 요청 ERR"
                log_body = {"result": "err", "detail": str(e)}
                logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
                raise e
            finally:
                await self.bot_manager.write_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "WAS": "AI Service",
                        "STEP": "07_01. LLM WAS 최종답변 생성 API 요청",
                        "BODY": log_body,
                    },
                )

            # 참고자료있는 경우 추가
            try:
                annotations = llm_result.get("annotations")
                ref_prefix = "\n📌 참고링크"

                # RAG 검색 청크를 사용한 경우
                annotaion_info_list: list[dict | None] = []
                annotated_file_paths: list[str | None] = []
                if is_rag and rag_psgs and annotations:
                    for annotation in annotations:
                        rag_id: list[str] = annotation.get("rag_id")
                        for _id in rag_id:
                            _file_name_preposition = ""
                            # 비식별화 처리된 경우
                            if ref_data[_id].get("ner"):
                                _file_name_preposition += "[보안자료]"
                            # 외부서비스인 경우
                            if service_type == "external":
                                _file_name_preposition += (
                                    f"[{ref_data[_id].get('group')}]"
                                )
                            file = (
                                f"{_file_name_preposition}{ref_data[_id].get('file')}"
                            )
                            page_num = ref_data[_id].get("page_num")
                            ner_url = "(보안자료는 파일 다운로드를 제공하지 않습니다.)"  # 보안자료 파일 다운로드 미지원에 대한 안내 문구
                            url = (
                                ner_url
                                if ref_data[_id].get("ner")
                                else self.bot_manager.get_url_with_filepath_vdb_meta(
                                    file_path := ref_data[_id].get("file_path")
                                )
                            )

                            # 같은 파일의 경우 파일 제목 및 다운로드 버튼은 하나만 표시
                            for annotaion_info in annotaion_info_list:
                                if annotaion_info["file"] == file:
                                    annotaion_info["page_nums"].append(page_num)
                                    annotaion_info["page_nums"].sort()  # 오름차순
                                    break
                            else:
                                annotaion_info_list.append(
                                    {
                                        "file": file,
                                        "page_nums": [page_num],
                                        "url": url,
                                    }
                                )
                                if not ref_data[_id].get("ner"):
                                    annotated_file_paths.append(file_path)

                    ref_texts = f"\n{ref_prefix}\n" + "\n".join(
                        [
                            f"ㆍ{annotaion_info['file']} (p.{', '.join(map(str, annotaion_info['page_nums']))})\n{annotaion_info['url']}"
                            for annotaion_info in annotaion_info_list
                        ]
                    )
                    final_message += ref_texts

                    logger.debug(
                        f"[PID {pid}][{task_id=}] Add references end of message"
                    )
                log_body = {"result": "success", "detail": final_message}
            except Exception as e:
                err_message = "참고자료있는 경우 추가 ERR"
                log_body = {"result": "err", "detail": str(e)}
                logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
                raise e
            finally:
                await self.bot_manager.write_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "WAS": "AI Service",
                        "STEP": "07_02. 참고자료있는 경우 추가",
                        "BODY": log_body,
                    },
                )

        # 8. DB 최종답변 저장
        try:
            logger.debug(f"[PID {pid}][{task_id=}] Saving final message")
            await self.db_manager.add_bot_chat_history(
                chat_session_id=chat_session_id,
                chat_number=chat_number,
                message=final_message,
            )
            log_body = {"result": "success", "detail": final_message}
        except Exception as e:
            err_message = "DB 최종답변 저장 ERR"
            log_body = {"result": "err", "detail": str(e)}
            logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
            raise e
        finally:
            await self.bot_manager.write_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "WAS": "AI Service",
                    "STEP": "08. DB 최종답변 저장",
                    "BODY": log_body,
                },
            )

        # 9. NAVERWORKS 최종답변 메세지 발신
        try:
            await self.bot_manager.send_bot_answer_message(
                bot_id=bot_id,
                user_id=user_id,
                bot_message=final_message,
                uri=web_view_uri,
            )
            logger.debug(f"[PID {pid}][{task_id=}] Sending final message to user")

            ## 참조링크 다운로드 버튼 전송
            if static_message_obj is None:
                await self.bot_manager.send_file_download_button_ui_message_with_filepaths_vdb_meta(
                    bot_id=bot_id,
                    user_id=user_id,
                    file_paths=annotated_file_paths,
                )
                logger.debug(f"[PID {pid}][{task_id=}] Sending download button to user")
            log_body = {"result": "success", "detail": None}
        except Exception as e:
            err_message = "NAVERWORKS 최종답변 메세지 발신 ERR"
            log_body = {"result": "err", "detail": str(e)}
            logger.error(f"[PID {pid}][{task_id=}] {err_message}: {e}")
            raise e
        finally:
            await self.bot_manager.write_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "WAS": "AI Service",
                    "STEP": "09. NAVERWORKS 최종답변 메세지 발신",
                    "BODY": log_body,
                },
            )
            await self.bot_manager.write_admin_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={"AL-BOT-MESSAGE": final_message},
            )

        return final_message
