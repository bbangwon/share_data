import asyncio
import os

from app.core import settings
from app.core.logger import get_logger
from app.handlers.task_processor import TaskProcessor
from app.services import Task

logger = get_logger(__name__)

TASK_QUEUE_SIZE: int = settings.TASK_QUEUE_SIZE
POLLING_INTERVER = settings.POLLING_INTERVER

queue = asyncio.Queue(maxsize=TASK_QUEUE_SIZE)
task_client = Task()


async def poll_task(interval: float = POLLING_INTERVER):
    while True:
        try:
            fetched_task = await task_client.get_task()
            if fetched_task is not None:
                await queue.put(fetched_task)
                logger.info(
                    f"Input ID={fetched_task.get('task').get('id')} / size={queue.qsize()}"
                )

        except Exception as e:
            logger.error(f"[Error - poll_task]: {e}", exc_info=True)

        await asyncio.sleep(interval)


async def handle_task(worker_id: str):
    pid = os.getpid()
    logger.info(f"Worker #{worker_id} Start")

    processor = TaskProcessor()
    logger.info(f"[PID {pid}] Initialized TaskProcessor")

    while True:
        task_info = await queue.get()
        await processor.process(worker_id, task_info)
        queue.task_done()
