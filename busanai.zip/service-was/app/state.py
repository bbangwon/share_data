class AppState:
    stream_buffers = {}
