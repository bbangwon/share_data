# service-was
> AI 서비스 백엔드

#### Management
- 개발환경: `ENV=service.test` / `.env.service.test` 파일에 환경변수 관리
- 운영환경: `ENV=service` / `.env.service` 파일에 환경변수 관리
  
#### Running Command
- Uvicorn 실행
    ```sh
    ENV=service.test uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload

    ENV=service uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload
    ```
- Gunicorn + Uvicorn 실행
    ```sh
    # 워커 노드 수는 .env 파일에 `WORKER_COUNT` 환경변수로 세팅 권장
    ENV=service.test gunicorn -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:8080 --reload

    ENV=service gunicorn -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:8080 --reload
    ```
- `uv` 사용시 `ur run` 커맨드 사용 가능

#### API 확인
- Swagger UI >> [http://0.0.0.0:8000/docs](http://0.0.0.0:8000/docs)
- ReDoc >> [http://0.0.0.0:8000/redoc](http://0.0.0.0:8000/redoc)