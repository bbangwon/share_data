#!/bin/bash

: "${WORKERS:=$(($(nproc) - 6))}"
exec gunicorn -w "$WORKERS" -k uvicorn.workers.UvicornWorker app.main:app --bind 0.0.0.0:8080 --reload