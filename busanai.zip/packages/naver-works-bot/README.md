# 네이버웍스 봇 API 패키지

네이버웍스 봇 API를 쉽게 사용할 수 있는 Python 패키지입니다.

## 설치 (개발 환경)

```bash
uv add --editable ../packages/naver-works-bot
```

## 사용법

### 기본 설정

```python

from naver_works_bot import (
    BotMessageManager,
)

# 봇 매니저 생성
        self.bot_manager: BotMessageManager = BotMessageManager(
            auth_manager=AuthManager(
                config=AuthConfig(
                    client_id=self.config.service.service_client_id,
                    client_secret=self.config.service.service_client_secret,
                    private_key=private_key,
                    account=self.config.service.service_account,
                    base_url=self.config.service.auth_base_url,
                )
            ),
            naver_api_base_url=self.config.service.api_base_url,
            download_save_path=self.config.service.download_save_path,
            service_bot_meta_info=self.config.service.bots,
        )
```

### 메시지 전송

```python
from naver_works_bot import TextContent

# 텍스트 메시지 전송
result = await bot_manager.send_message(
    bot_id="bot_id",
    user_id="user_id",
    content=TextContent.from_text("안녕하세요!"),
)

```
