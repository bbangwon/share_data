import base64
import hashlib
import hmac
import logging
import os
import shutil
from typing import List

import httpx

from naver_works_bot.auth.auth_manager import AuthManager

from .schemas import BotInfo, BotMetaInfo, BotUpdateInfo, DownloadFileInfo
from .schemas.content import Content
from .schemas.send import _SendContent

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)

DEFAULT_DOWNLOAD_SAVE_PATH = "./downloaded_files"


class BotMessageManager:
    """네이버 웍스 봇 메시지 관리 클래스"""

    def __init__(
        self,
        auth_manager: AuthManager,
        naver_api_base_url: str,
        bot_meta_infos: List[BotMetaInfo],
        download_save_path: str = None,
    ):
        """
        BotMessageManager 초기화
        Args:
            naver_api_base_url (str): 네이버 API 기본 URL (필수)
            bot_meta_infos (List[BotMetaInfo]): 봇 메타 정보 (필수)
            auth_manager (AuthManager): 인증 관리자 인스턴스 (필수)
        Raises:
            ValueError: naver_api_base_url 또는 auth_manager가 None인 경우
            TypeError: bot_infos가 BotMetaInfo 타입의 리스트가 아닌 경우
        """
        if naver_api_base_url is None:
            raise ValueError("naver_api_base_url 매개변수는 필수입니다.")

        if not isinstance(bot_meta_infos, list) or not all(
            isinstance(b, BotMetaInfo) for b in bot_meta_infos
        ):
            raise TypeError("bot_meta_infos는 BotMetaInfo 객체의 리스트여야 합니다.")

        if auth_manager and not isinstance(auth_manager, AuthManager):
            raise TypeError("auth_manager는 AuthManager 타입이어야 합니다.")

        self.naver_api_base_url = naver_api_base_url
        self.bot_meta_infos = bot_meta_infos
        self.auth_manager = auth_manager

        self.download_save_path = download_save_path or DEFAULT_DOWNLOAD_SAVE_PATH

        logger.debug("BotMessageManager가 초기화되었습니다.")

    def _get_bot_message_url(self, bot_id: str, user_id: str) -> str:
        return self.naver_api_base_url + f"/v1.0/bots/{bot_id}/users/{user_id}/messages"

    def _get_bot_download_url(self, bot_id: str, file_id: str) -> str:
        return self.naver_api_base_url + f"/v1.0/bots/{bot_id}/attachments/{file_id}"

    async def _get_headers(self):
        """헤더를 반환합니다."""
        headers = {
            "Content-Type": "application/json; charset=UTF-8",
        }
        if self.auth_manager:
            access_token = await self.auth_manager.get_access_token()

            headers["Authorization"] = f"Bearer {access_token}"
            logger.debug("요청 헤더: %s", headers)
            return headers

    async def send_message(self, bot_id: str, user_id: str, content: Content) -> dict:
        """봇 메시지를 전송합니다."""
        logger.info(
            "봇 메시지를 전송합니다. bot_id: %s, user_id: %s",
            bot_id,
            user_id,
        )
        url = self._get_bot_message_url(bot_id, user_id)
        headers = await self._get_headers()

        send_content = _SendContent(content=content)
        logger.debug("전송 URL: %s", url)
        logger.debug(
            "전송 메시지: %s",
            send_content.model_dump_json(by_alias=True, exclude_none=True),
        )

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    json=send_content.model_dump(by_alias=True, exclude_none=True),
                    headers=headers,
                )
                response.raise_for_status()
                logger.info("메시지 전송에 성공했습니다.")
        except httpx.HTTPStatusError as e:
            if (
                isinstance(self.auth_manager, AuthManager)
                and e.response.status_code == 401
                and e.response.json().get("code") == "UNAUTHORIZED"
            ):
                logger.error(
                    "만료된 인증 토큰입니다. 인증 토큰을 재 발급받아 다시 시도합니다."
                )
                await self.auth_manager.issue_access_token()
                return await self.send_message(bot_id, user_id, content)
            else:
                logger.error(f"메시지 전송 중 오류 발생: {e} {e.response.text}")
                raise e
        except Exception as e:
            logger.error(f"메시지 전송 중 오류 발생: {e}")
            raise e

    async def send_any_message(
        self, bot_id: str, user_id: str, send_content: dict
    ) -> dict:
        """봇 메시지를 전송합니다."""
        logger.info(
            "봇 메시지를 전송합니다. bot_id: %s, user_id: %s",
            bot_id,
            user_id,
        )
        url = self._get_bot_message_url(
            bot_id=bot_id,
            user_id=user_id,
        )
        headers = await self._get_headers()

        logger.debug("전송 URL: %s", url)
        logger.debug("전송 메시지: %s", send_content)

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    json=send_content,
                    headers=headers,
                )
                response.raise_for_status()
                logger.info("메시지 전송에 성공했습니다.")
        except httpx.HTTPStatusError as e:
            if (
                isinstance(self.auth_manager, AuthManager)
                and e.response.status_code == 401
                and e.response.json().get("code") == "UNAUTHORIZED"
            ):
                logger.error(
                    "만료된 인증 토큰입니다. 인증 토큰을 재 발급받아 다시 시도합니다."
                )
                await self.auth_manager.issue_access_token()
                return await self.send_any_message(bot_id, user_id, send_content)
            else:
                logger.error(f"메시지 전송 중 오류 발생: {e} {e.response.text}")
                raise e
        except Exception as e:
            logger.error(f"메시지 전송 중 오류 발생: {e}")
            raise e

    def get_signature(self, bot_id: str, body: bytes) -> str:
        """요청 본문에 대한 HMAC-SHA256 서명을 생성합니다."""
        logger.debug("서명 생성을 시작합니다.")

        # HMAC-SHA256 서명 생성
        bot_info = self.get_bot_meta_info(bot_id)
        if not bot_info:
            return None

        bot_secret = bot_info.secret

        secret_bytes = bot_secret.encode("utf-8")
        signature = base64.b64encode(
            hmac.new(secret_bytes, body, hashlib.sha256).digest()
        ).decode("utf-8")

        logger.debug("생성된 서명: %s", signature)
        return signature

    def verify_signature(self, bot_id: str, signature: str, body: bytes) -> bool:
        """요청의 서명을 검증합니다."""
        logger.debug("서명 검증을 시작합니다.")

        # HMAC-SHA256 서명 생성
        expected_signature = self.get_signature(bot_id, body)

        logger.debug("전송된 서명: %s", signature)
        logger.debug("생성된 서명: %s", expected_signature)

        # 서명 비교
        if signature != expected_signature:
            logger.error("서명 검증에 실패했습니다.")
            return False

        logger.info("서명 검증에 성공했습니다.")
        return True

    async def get_download_url(
        self, bot_id: str, file_id: str
    ) -> DownloadFileInfo | None:
        """파일 다운로드 URL을 조회합니다."""
        logger.info(
            "파일 다운로드 URL 조회 요청. bot_id: %s, file_id: %s",
            bot_id,
            file_id,
        )
        url = self._get_bot_download_url(
            bot_id=bot_id,
            file_id=file_id,
        )
        headers = await self._get_headers()

        logger.debug("전송 URL: %s", url)

        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers)
            logger.debug("응답 헤더 내용: %s", response.headers)
            if response.status_code == 302:
                logger.info("파일 다운로드 URL 조회에 성공했습니다.")
                download_url = response.headers.get("location")
                return DownloadFileInfo.from_download_url(download_url)
            elif (
                isinstance(self.auth_manager, AuthManager)
                and response.status_code == 401
                and response.json().get("code") == "UNAUTHORIZED"
            ):
                logger.error(
                    "만료된 인증 토큰입니다. 인증 토큰을 재 발급받아 다시 시도합니다."
                )
                await self.auth_manager.issue_access_token()
                return await self.get_download_url(bot_id, file_id)
            else:
                return None

    async def download_and_save_file(
        self, download_file_info: DownloadFileInfo, overwrite: bool = False
    ) -> str:
        """파일을 다운로드하고 저장합니다."""
        logger.info(
            "파일 다운로드 요청. file_download_url: %s",
            download_file_info.download_url,
        )
        if not download_file_info.download_url:
            raise ValueError("download_file_info 필수입니다.")

        save_file_path = f"{self.download_save_path}/{download_file_info.file_id}/{download_file_info.file_name}"
        if not overwrite and os.path.exists(save_file_path):
            logger.info(f"파일이 이미 존재합니다: {save_file_path}")
            return save_file_path

        headers = await self._get_headers()

        try:
            async with httpx.AsyncClient() as client:
                async with client.stream(
                    "GET", download_file_info.download_url, headers=headers
                ) as response:
                    response.raise_for_status()

                    save_file_path = f"{self.download_save_path}/{download_file_info.file_id}/{download_file_info.file_name}"
                    os.makedirs(os.path.dirname(save_file_path), exist_ok=True)

                    with open(save_file_path, "wb") as f:
                        async for chunk in response.aiter_bytes():
                            f.write(chunk)

                    return save_file_path
        except httpx.HTTPStatusError as e:
            if (
                isinstance(self.auth_manager, AuthManager)
                and e.response.status_code == 401
                and e.response.json().get("code") == "UNAUTHORIZED"
            ):
                logger.error(
                    "만료된 인증 토큰입니다. 인증 토큰을 재 발급받아 다시 시도합니다."
                )
                await self.auth_manager.issue_access_token()
                return await self.download_and_save_file(download_file_info, overwrite)
            else:
                logger.error(f"파일 다운로드 중 오류 발생: {e} {e.response.text}")
                raise e
        except Exception as e:
            logger.error(f"파일 다운로드 중 오류 발생: {e}")
            raise e

    def clean_up_downloaded_file(self, download_file_info: DownloadFileInfo):
        """다운로드된 파일을 삭제합니다."""
        try:
            remove_dir = f"{self.download_save_path}/{download_file_info.file_id}"
            if os.path.isdir(remove_dir):
                shutil.rmtree(remove_dir)
                logger.info(f"파일이 성공적으로 삭제되었습니다: {remove_dir}")
            else:
                logger.warning(f"삭제할 파일이 존재하지 않습니다: {remove_dir}")
        except Exception as e:
            logger.error(f"파일 삭제 중 오류 발생: {e}")

    def get_all_bot_ids(self) -> List[str]:
        """모든 봇 ID를 반환합니다."""
        return [str(bot_meta.id) for bot_meta in self.bot_meta_infos]

    def get_bot_meta_info(self, bot_id: str) -> BotMetaInfo | None:
        """특정 봇 메타 정보를 반환합니다."""
        for bot_meta in self.bot_meta_infos:
            if str(bot_meta.id) == bot_id:
                return bot_meta.model_copy()
        return None

    async def get_bot_info(self, bot_id: str) -> BotInfo:
        """봇 정보를 반환합니다."""
        logger.info("봇 정보 조회 요청. bot_id: %s", bot_id)
        url = self.naver_api_base_url + f"/v1.0/bots/{bot_id}"
        headers = await self._get_headers()

        logger.debug("전송 URL: %s", url)

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    url,
                    headers=headers,
                )
                response.raise_for_status()
                response_data = response.json()
                logger.debug("응답 내용: %s", response_data)
                logger.info("봇 조회에 성공했습니다.")
                return BotInfo.model_validate(response_data, by_alias=True)
        except httpx.HTTPStatusError as e:
            if (
                isinstance(self.auth_manager, AuthManager)
                and e.response.status_code == 401
                and e.response.json().get("code") == "UNAUTHORIZED"
            ):
                logger.error(
                    "만료된 인증 토큰입니다. 인증 토큰을 재 발급받아 다시 시도합니다."
                )
                await self.auth_manager.issue_access_token()
                return await self.get_bot_info(bot_id)
            else:
                logger.error(f"봇 조회중 에러 발생 : {e} {e.response.text}")
                return None

        except Exception as e:
            logger.error(f"봇 조회중 에러 발생 : {e}")
            return None

    async def update_bot(self, bot_id: str, bot_update_info: BotUpdateInfo) -> bool:
        """봇을 수정합니다."""
        logger.info(
            "봇 수정 요청. bot_id: %s",
            bot_id,
        )
        url = self.naver_api_base_url + f"/v1.0/bots/{bot_id}"
        headers = await self._get_headers()

        logger.debug("전송 URL: %s", url)
        logger.debug(
            "전송 메시지: %s", bot_update_info.model_dump_json(indent=2, by_alias=True)
        )
        try:
            async with httpx.AsyncClient() as client:
                response = await client.put(
                    url,
                    json=bot_update_info.model_dump(by_alias=True),
                    headers=headers,
                )
                response.raise_for_status()
                response_data = response.json()
                logger.debug("응답 내용: %s", response_data)
                logger.info("봇 수정에 성공했습니다.")
                return True
        except httpx.HTTPStatusError as e:
            if (
                isinstance(self.auth_manager, AuthManager)
                and e.response.status_code == 401
                and e.response.json().get("code") == "UNAUTHORIZED"
            ):
                logger.error(
                    "만료된 인증 토큰입니다. 인증 토큰을 재 발급받아 다시 시도합니다."
                )
                await self.auth_manager.issue_access_token()
                return await self.update_bot(bot_id, bot_update_info)
            else:
                logger.error(f"봇 수정중 에러 발생 : {e} {e.response.text}")
                return False
        except Exception as e:
            logger.error(f"봇 수정중 에러 발생 : {e}")
            return False

    async def regist_bot_member(
        self, bot_id: str, domain_id: str, user_id: str
    ) -> bool:
        """
        봇 멤버를 등록합니다.
        userId는 사용자를 식별하는 ID, 사용자ID, 로그인ID
        """

        logger.info(
            "봇 멤버 등록 요청. bot_id: %s, domain_id: %s, user_id: %s",
            bot_id,
            domain_id,
            user_id,
        )
        url = (
            self.naver_api_base_url + f"/v1.0/bots/{bot_id}/domains/{domain_id}/members"
        )
        headers = await self._get_headers()

        payload = {"userId": user_id}

        logger.debug("전송 URL: %s", url)
        logger.debug("전송 메시지: %s", payload)

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    json=payload,
                    headers=headers,
                )
                response.raise_for_status()
                logger.info("봇 멤버 등록에 성공했습니다.")
                return True
        except httpx.HTTPStatusError as e:
            if (
                isinstance(self.auth_manager, AuthManager)
                and e.response.status_code == 401
                and e.response.json().get("code") == "UNAUTHORIZED"
            ):
                logger.error(
                    "만료된 인증 토큰입니다. 인증 토큰을 재 발급받아 다시 시도합니다."
                )
                await self.auth_manager.issue_access_token()
                return await self.regist_bot_member(bot_id, domain_id, user_id)
            else:
                logger.error(f"봇 멤버 등록중 에러 발생 : {e} {e.response.text}")
                return False
        except Exception as e:
            logger.error(f"봇 멤버 등록중 에러 발생 : {e}")
            return False

    async def clear_bot_members(self, bot_id: str, domain_id: str) -> bool:
        """
        봇 멤버를 전체 삭제합니다.
        """

        logger.info(
            "봇 멤버 전체 삭제 요청. bot_id: %s, domain_id: %s",
            bot_id,
            domain_id,
        )
        # 일단 해당 도메인의 유저들을 모두 가져옵니다.

        url = (
            self.naver_api_base_url + f"/v1.0/bots/{bot_id}/domains/{domain_id}/members"
        )
        headers = await self._get_headers()

        logger.debug("전송 URL: %s", url)

        try:
            while True:
                async with httpx.AsyncClient() as client:
                    response = await client.get(url, headers=headers)

                    response.raise_for_status()
                    response_data = response.json()

                    members = response_data.get("members")
                    if not members:
                        break

                    logger.info(f"현재 {len(members)}명의 멤버를 가져왔습니다.")

                    for member in members:
                        logger.info(f"멤버 삭제: {member}")
                        response = await client.delete(
                            url + f"/{member}", headers=headers
                        )
                        response.raise_for_status()

        except httpx.HTTPStatusError as e:
            if (
                isinstance(self.auth_manager, AuthManager)
                and e.response.status_code == 401
                and e.response.json().get("code") == "UNAUTHORIZED"
            ):
                logger.error(
                    "만료된 인증 토큰입니다. 인증 토큰을 재 발급받아 다시 시도합니다."
                )
                await self.auth_manager.issue_access_token()
                return await self.clear_bot_members(bot_id, domain_id)
            else:
                logger.error(f"봇 멤버 전체 삭제중 에러 발생 : {e} {e.response.text}")
                return False
        except Exception as e:
            logger.error(f"봇 멤버 전체 삭제중 에러 발생 : {e}")
            return False
