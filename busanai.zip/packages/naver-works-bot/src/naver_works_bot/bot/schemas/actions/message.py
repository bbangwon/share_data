import logging
from typing import Literal, Optional

from pydantic import Field

from .base import ActionBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class MessageAction(ActionBase):  # button_template에서 사용
    type: Literal["message"] = Field("message", description="Message로 고정")
    label: Optional[str] = Field(
        None,
        description="항목에 표시되는 레이블. 기본 최대 글자수: 20자, 이미지 캐러셀 최대 글자수: 12자. 고정메뉴 최대 글자수: 1000자",
    )
    text: str = Field(
        None,
        description="항목을 누를 때 전송되는 텍스트. 캐러셀. 이미지 캐러셀. 리치 메뉴. Quick Reply에서 필수값. 최대 글자수 300자",
    )
    postback: Optional[str] = Field(
        None,
        description="message.postback 속성으로 반환되는 문자열. 최대 글자수: 1000자",
    )
