import logging
from typing import Literal, Optional

from pydantic import Field

from .base import ActionBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


# carousel, image carousel, quick reply, rich menu에서 사용
class PostbackAction(ActionBase):
    type: Literal["postback"] = Field("postback", description="Postback로 고정")
    label: Optional[str] = Field(
        None,
        description="항목에 표시되는 레이블. 기본 최대 글자수: 20자, 이미지 캐러셀 최대 글자수: 12자",
    )
    data: str = Field(
        ..., description="postback.data 속성의 callback을 통해 반환되는 문자열"
    )
    display_text: Optional[str] = Field(
        None,
        description="사용자가 보낸 메시지로 채팅에 표시되는 텍스트. 입력하지 않으면 텍스트가 표시되지 않음. 최대 글자수: 300자",
    )
