import logging
from typing import Literal, Optional

from pydantic import Field

from .base import ActionBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class UriAction(ActionBase):  # 필요시 추가
    type: Literal["uri"] = Field("uri", description="uri로 고정")
    label: Optional[str] = Field(
        None,
        description="항목에 표시되는 레이블. 기본 최대 글자수: 20자, 이미지 캐러셀 최대 글자수: 12자, 고정 메뉴 최대 글자수: 1000자",
    )
    uri: str = Field(
        ...,
        description="항목을 누를 때 이동하는 URL. HTTP, HTTPS 스키마를 지원한다. 최대 글자수: 1000자",
    )
