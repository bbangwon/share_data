from pydantic import Field

from ..base import SchemaBase


class ActionBase(SchemaBase):
    type: str = Field(..., description="액션 타입")
    """기본 액션 타입 필드, 하위 클래스에서 고정값으로 설정됨"""
