import logging
from typing import Optional

from pydantic import Field

from .action import Action
from .base import SchemaBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class QuickReplyItem(SchemaBase):
    image_url: Optional[str] = Field(
        None,
        description="""버튼 앞에 표시될 아이콘 URL(PNG 형식, HTTPS만 허용). imageUrl, imageResourceId 중 하나만 지정해야 하며, 필수는 아니다. 
        camera, camera roll, location일 때는 설정하지 않으면 기본 아이콘이 표시된다.
        최대 크기: 1MB
        최대 글자수: 1000자""",
    )
    action: Action = Field(
        ...,
        description="버튼을 눌렀을 때 동작",
    )


class QuickReply(SchemaBase):
    items: list[QuickReplyItem] = Field(
        ..., description="빠른 답장 버튼 객체. 최대 13개"
    )

    @classmethod
    def from_items(cls, items: list[QuickReplyItem]):
        logger.debug("QuickReply.from_items 호출됨. items: %s", items)
        return cls(items=items)
