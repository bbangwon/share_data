from typing import Annotated, Union

from pydantic import Field

from .actions.message import MessageAction
from .actions.postback import PostbackAction
from .actions.uri import UriAction

# Action이 늘어날때마다 여기에 추가
Action = Annotated[
    Union[PostbackAction, MessageAction, UriAction], Field(discriminator="type")
]
