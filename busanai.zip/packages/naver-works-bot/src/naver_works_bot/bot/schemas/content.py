from typing import Annotated, Union

from pydantic import Field

from .contents.button_template import ButtonTemplateContent
from .contents.carousel import CarouselContent
from .contents.file import FileContent
from .contents.flexibles import FlexibleContent
from .contents.image import ImageContent
from .contents.text import TextContent

# from .contents.flexibles import FlexibleContent

# TODO: 컨텐츠가 늘어날때마다 여기에 추가
Content = Annotated[
    Union[
        TextContent,
        ImageContent,
        FileContent,
        ButtonTemplateContent,
        CarouselContent,
        FlexibleContent,
    ],
    Field(discriminator="type"),
]
