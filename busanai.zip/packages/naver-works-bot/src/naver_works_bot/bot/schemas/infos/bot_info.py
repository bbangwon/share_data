from pydantic import BaseModel, ConfigDict, Field


def to_camel(string: str) -> str:
    parts = string.split("_")
    return parts[0] + "".join(word.capitalize() for word in parts[1:])


# 봇 업데이트 요청용 스키마
class BotUpdateInfo(BaseModel):
    bot_name: str = Field(..., description="봇 이름", examples=["AI부기주무관"])
    photo_url: str = Field(
        ...,
        description="봇 프로필 사진 URL",
        examples=[
            "https://dev.worksmobile.com/gateway/image/view?path=/k/wauth/r/kr1.300223877/bot_profile/1753323168933/478749_111248.png"
        ],
    )
    description: str = Field(..., description="봇 설명", examples=["부산시 AI 봇"])
    administrators: list[str] = (
        Field(
            ...,
            description="봇 관리자 사용자 ID 리스트",
            examples=[
                "95fe2166-112c-4597-1115-032ccd8f293c",
                "5da2dc99-ae80-4375-1c71-03eeb5034d0a",
            ],
        ),
    )
    enable_callback: bool = Field(True, description="콜백 사용 여부", examples=[True])
    callback_events: list[str] = Field(
        ["text", "file"],
        description="봇에게 보낼수 있는 정보 타입",
        examples=["text", "file"],
    )
    callback_url: str = Field(
        ...,
        description="콜백 URL",
        examples=["https://busanai.busan.go.kr/message-callback"],
    )

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


# 봇 정보 조회용 스키마
class BotInfo(BotUpdateInfo):
    bot_id: int = Field(..., description="봇 ID", examples=[10784315])
    subadministrators: list[str] | None = Field(
        None,
        description="봇 부담당자 계정",
    )
    allow_domains: list[int] | None = Field(
        None, description="봇을 사용 가능한 도메인 목록"
    )
    enable_group_join: bool = Field(False, description="1:N 메시지방 참여 가능 여부")
    default_richmenu_id: str | None = Field(
        None, description="모든 사용자에게 적용되는 기본 리치 메뉴 ID"
    )
    created_time: str | None = Field(None, description="봇 생성 시간")
    modified_time: str | None = Field(None, description="봇 수정 시간")


# 봇 메타 정보 스키마
class BotMetaInfo(BaseModel):
    id: int = Field(..., description="봇 ID", examples=[10784315])
    secret: str = Field(
        ..., description="봇 시크릿", examples=["ut4wLpNm7qXeE2ew9MopHipfFpVs/7"]
    )
    role: str = Field(
        ...,
        description="봇 역할(service : 상용, dev: 개발, test : 테스트, error : 에러 봇)",
        examples=["service", "dev", "test", "error"],
    )
    service: str = Field(
        "general",
        description="봇 서비스 유형 (general: 일반봇 ,internal : 내부문서, external: 외부문서, generate: 문서생성)",
        examples=["general", "internal", "external", "generate"],
    )
