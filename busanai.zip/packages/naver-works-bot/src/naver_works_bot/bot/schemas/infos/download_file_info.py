import unicodedata
from urllib.parse import unquote

from pydantic import BaseModel


class DownloadFileInfo(BaseModel):
    file_id: str
    file_name: str
    file_extension: str
    download_url: str

    @classmethod
    def from_download_url(cls, download_url: str):
        # ex: https://apis-storage.worksmobile.com/k/emsg/r/kr1/1759658985102178125.1759745385.2.10242846.300223877.353087074.2333/sibo-1.pdf/download.api
        file_id = download_url.split("/")[-3]
        file_name = download_url.split("/")[-2]
        # 파일이름에 URL 인코딩이 포함될 수 있으므로 디코딩 처리
        file_name = unquote(file_name)
        # NFC 정규화 처리(MacOS에서 업로드된 파일명이 NFD로 저장되는 문제 대응)
        file_name = unicodedata.normalize("NFC", file_name)
        if "." in file_name:
            file_extension = file_name.split(".")[-1].lower()
        return cls(
            file_id=file_id,
            file_name=file_name,
            file_extension=file_extension,
            download_url=download_url,
        )
