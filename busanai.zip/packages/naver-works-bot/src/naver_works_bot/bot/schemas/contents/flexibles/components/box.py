from typing import TYPE_CHECKING, List, Literal

from pydantic import Field

from ....action import Action

# 순환 참조 문제를 피하기 위해
if TYPE_CHECKING:
    from ..component import Component

from .base import ComponentBase


class BoxComponent(ComponentBase):
    type: Literal["box"] = Field(
        "box",
        description="box로 고정",
    )
    layout: Literal["horizontal", "vertical", "baseline"] = Field(
        ...,
        description="""
        박스에서 컴포넌트를 배치하는 방향.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#component-placement-direction
        """,
    )
    contents: List["Component"] = Field(
        ...,
        description="""
        박스의 컴포넌트. 다음과 같은 타입의 컴포넌트를 추가할 수 있다.
        - layout 속성값이 horizontal, vertical인 경우: box, button, image, text, separator, filler
        - layout 속성값이 baseline인 경우: icon, text, filler
        하위에 추가된 컴포넌트는 배열에 지정된 순서에 따라 표시된다.
        """,
    )
    background_color: str = Field(
        None,
        description="""
        블록의 배경색. RGB 색상 외에 알파 채널(투명도)도 설정할 수 있다. Hex 색상 코드로 지정한다.(예: #RRGGBBAA).
        기본값은 #00000000 이다.""",
    )
    border_color: str = Field(
        None,
        description="""
        박스 테두리 색상. Hex 색상 코드로 지정한다.
        """,
    )
    border_width: str = Field(
        None,
        description="""
        박스 테두리의 두께. 픽셀값을 직접 입력하거나, none, light, normal, medium, semi-bold, bold 중 하나의 값을 지정할 수 있다.
        none으로 지정하면 테두리가 표시되지 않으며, 그 외의 값들은 열거된 순으로 테두리 두께가 두꺼워진다.
        """,
    )
    corner_radius: str = Field(
        None,
        description="""
        테두리 모서리를 둥글게 설정. 픽셀값을 직접 입력하거나, none, xs, sm, md, lg, xl, xxl 중 하나의 값을 지정할 수 있다.
        none으로 지정하면 모서리가 둥글게 설정되지 않으며, 그 외의 값들은 열거된 순으로 모서리를 더 둥글게 만든다.
        기본값은 none 이다.
        """,
    )
    width: str = Field(
        None,
        description="""
        박스의 너비. 
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#box-width
        """,
    )
    height: str = Field(
        None,
        description="""
        박스의 높이.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#box-height
        """,
    )
    flex: int = Field(
        None,
        description="""
        상위 컴포넌트 내 컴포넌트들의 너비 또는 높이의 비율.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#component-height-width
        """,
    )
    spacing: str = Field(
        None,
        description="""
        박스 내 컴포넌트들 사이의 최소 간격. 기본값은 none이다.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#spacing
        """,
    )
    margin: str = Field(
        None,
        description="""
        상위 컴포넌트 내 특정 컴포넌트와 이전 컴포넌트와의 최소 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#margin
        """,
    )
    padding_all: str = Field(
        None,
        description="""
        박스 테두리와 해당 박스에 추가된 컴포넌트 사이의 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#padding
        """,
    )
    padding_top: str = Field(
        None,
        description="""
        박스 위쪽 테두리와 해당 박스에 추가된 컴포넌트 위쪽 테두리 사이의 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#padding
        """,
    )
    padding_bottom: str = Field(
        None,
        description="""
        박스 아래쪽 테두리와 해당 박스에 추가된 컴포넌트 아래쪽 테두리 사이의 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#padding
        """,
    )
    padding_start: str = Field(
        None,
        description="""
        박스 왼쪽 테두리와 해당 박스에 추가된 컴포넌트 왼쪽 테두리 사이의 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#padding
        """,
    )
    padding_end: str = Field(
        None,
        description="""
        박스 오른쪽 테두리와 해당 박스에 추가된 컴포넌트 오른쪽 테두리 사이의 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#padding
        """,
    )
    position: Literal["relative", "absolute"] = Field(
        None,
        description="""
        박스를 배치하는 위치. 다음 값 중 하나를 지정한다.
        • relative: 이전 박스가 기준이 된다.
        • absolute: 부모 컴포넌트의 왼쪽 상단이 기준이 된다.
        기본값은 relative 이다. 
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_top: str = Field(
        None,
        description="""
        상단 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_bottom: str = Field(
        None,
        description="""
        하단 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_start: str = Field(
        None,
        description="""
        왼쪽 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_end: str = Field(
        None,
        description="""
        오른쪽 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    action: Action = Field(
        None,
        description="""박스를 탭하면 실행되는 액션.""",
    )
