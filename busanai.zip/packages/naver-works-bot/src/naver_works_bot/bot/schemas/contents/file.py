import logging
from typing import Literal, Optional

from pydantic import Field

from .base import ContentBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class FileContent(ContentBase):
    type: Literal["file"] = Field("file", description="file로 고정")
    original_content_url: Optional[str] = Field(
        None,
        description="원본 파일이 위치한 URL. 차단파일형식: 'bat', 'cmd', 'com', 'cpl', 'exe', 'scr', 'js', 'vbs', 'wsf', 'hta'. 최대 글자수: 1000자. file_id와 original_content_url 중 하나만 사용해야 함.",
    )
    file_id: Optional[str] = Field(
        None,
        description="콘텐츠 업로드시 획득한 파일 ID. file_id와 original_content_url 중 하나만 사용해야 함.",
    )

    @classmethod
    def from_url(cls, original_content_url: str):
        logger.debug(
            "FileContent.from_url 호출됨. original_content_url: %s",
            original_content_url,
        )
        return cls(original_content_url=original_content_url)

    @classmethod
    def from_file_id(cls, file_id: str):
        logger.debug("FileContent.from_file_id 호출됨. file_id: %s", file_id)
        return cls(file_id=file_id)
