import logging
from typing import Literal, Optional

from pydantic import Field

from .base import ContentBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class ImageContent(ContentBase):
    type: Literal["image"] = Field("image", description="image로 고정")
    preview_image_url: Optional[str] = Field(
        None,
        description="미리보기 이미지가 위치한 URL(PNG형식, HTTPS만 허용). 최대 글자수: 1000자. file_id 속성이 없을 때만 사용",
    )
    original_content_url: Optional[str] = Field(
        None,
        description="원본 이미지가 위치한 URL(PNG형식, HTTPS만 허용). 최대 글자수: 1000자. file_id 속성이 없을 때만 사용",
    )
    file_id: Optional[str] = Field(
        None,
        description="콘텐츠 업로드시 획득한 파일 ID. file_id와 preview_image_url/original_content_url 중 하나만 사용해야 함.",
    )

    @classmethod
    def from_url(cls, preview_image_url: str, original_content_url: str):
        logger.debug(
            "ImageContent.from_url 호출됨. preview_image_url: %s, original_content_url: %s",
            preview_image_url,
            original_content_url,
        )
        return cls(
            preview_image_url=preview_image_url,
            original_content_url=original_content_url,
        )

    @classmethod
    def from_file_id(cls, file_id: str):
        logger.debug("ImageContent.from_file_id 호출됨. file_id: %s", file_id)
        return cls(file_id=file_id)
