import logging
from typing import Literal, Optional

from pydantic import Field

from ..action import Action
from ..base import SchemaBase
from .base import ContentBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class CarouselContentColumn(SchemaBase):
    original_content_url: Optional[str] = Field(
        None,
        description="이미지 URL(PNG형식, HTTPS만 허용). 최대 크기: 1MB. 최대 글자수: 1000자. original_content_url/file_id 둘 중 하나만 사용해야 하나 필수는 아님",
        max_length=1000,
    )
    file_id: Optional[str] = Field(
        None,
        description="이미지 파일 ID. 최대 크기: 1MB. original_content_url/file_id 둘 중 하나만 사용해야 하나 필수는 아님",
        max_length=1000,
    )
    title: Optional[str] = Field(
        None, description="제목. 최대 글자수: 40자", max_length=40
    )
    text: str = Field(
        ...,
        description="메시지 내용. 이미지와 제목이 없을 경우 최대길이 4줄, 120자. 이미지와 제목이 있을 경우 최대길이 2줄, 60자",
        max_length=120,
    )
    default_action: Optional[Action] = Field(
        None,
        description="기본 액션. 사용자가 image, title, text영역을 클릭했을 때 실행되는 액션",
    )
    actions: list[Action] = Field(
        ...,
        description="액션이 정의된 버튼들. 최대 3개",
        examples=[
            {
                "type": "message",
                "label": "FAQ",
                "postback": "Carousel_FAQ",
            }
        ],
        max_length=3,
    )


class CarouselContent(ContentBase):
    type: Literal["carousel"] = Field("carousel", description="carousel로 고정")
    image_aspect_ratio: str = Field(
        None,
        description="이미지의 비율, 모든 열에 적용된다. rectangle: 1.51:1(기본값), square: 1:1",
        examples=["rectangle", "square"],
    )
    image_size: str = Field(
        None,
        description="이미지의 사이즈. 모든 열에 적용된다. cover: 이미지가 전체 영역을 채운다(기본값). 영역에 맞지 않는 이미지 부분은 표시되지 않느다. contain: 전체 영역에 이미지를 체운다. 세로로 긴 이미지는 좌우로 공백이 채워진다. 가로로 긴 이미지는 상하로 공백이 채워진다.",
        examples=["cover", "contain"],
    )
    columns: list[CarouselContentColumn] = Field(
        ...,
        description="캐러셀에 사용할 컬럼들. 최대 10개",
        examples=[
            {
                "original_content_url": "https://example.com/image.jpg",
                "title": "제목",
                "text": "내용",
                "actions": [
                    {"type": "message", "label": "버튼", "postback": "Carousel_Button"}
                ],
            }
        ],
        max_length=10,  # 최대 10개 컬럼
    )
