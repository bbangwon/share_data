from typing import Annotated, Union

from pydantic import Field

from .components import (
    BoxComponent,
    ButtonComponent,
    ImageComponent,
    SeparatorComponent,
    SpanComponent,
    TextComponent,
)

Component = Annotated[
    Union[
        BoxComponent,
        ButtonComponent,
        ImageComponent,
        SeparatorComponent,
        TextComponent,
        SpanComponent,
    ],
    Field(discriminator="type"),
]
