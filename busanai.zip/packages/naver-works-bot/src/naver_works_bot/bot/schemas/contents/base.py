from typing import Optional

from pydantic import Field

from ..base import SchemaBase
from ..quick_reply import QuickReply


class ContentBase(SchemaBase):
    type: str = Field(..., description="콘텐츠 타입")
    """기본 콘텐츠 타입 필드, 하위 클래스에서 고정값으로 설정됨"""

    quick_reply: Optional[QuickReply] = Field(
        None,
        description="빠른 답장 버튼 객체. 최대 13개",
    )
