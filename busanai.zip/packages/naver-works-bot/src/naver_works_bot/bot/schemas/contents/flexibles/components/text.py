from typing import Literal

from pydantic import Field

from ....action import Action
from .base import ComponentBase
from .span import SpanComponent


class TextComponent(ComponentBase):
    type: Literal["text"] = Field("text", description="text 로 고정")
    text: str = Field(
        ...,
        description="""
        표시되는 문자열.
        text 또는 contents 속성 중 하나를 반드시 지정해야 한다.
        contents 속성을 지정하면 text 속성은 무시된다.
        """,
    )
    contents: list[SpanComponent] = Field(
        None,
        description="""
        Span 컴포넌트 문자열 영역.
        text 또는 contents 속성 중 하나를 반드시 지정해야 한다.
        contents 속성을 지정하면 text 속성은 무시된다.
        """,
    )
    flex: int = Field(
        None,
        description="""
        상위 컴포넌트 내 해당 컴포넌트의 너비 또는 높이의 비율.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#component-height-width
        """,
    )
    margin: str = Field(
        None,
        description="""
        상위 컴포넌트 내 특정 컴포넌트와 이전 컴포넌트와의 최소 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#margin
        """,
    )
    position: Literal["relative", "absolute"] = Field(
        None,
        description="""
        박스를 배치하는 위치. 다음 값 중 하나를 지정한다.
        • relative: 이전 박스가 기준이 된다.
        • absolute: 부모 컴포넌트의 왼쪽 상단이 기준이 된다.
        기본값은 relative 이다. 
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_top: str = Field(
        None,
        description="""
        상단 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_bottom: str = Field(
        None,
        description="""
        하단 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_start: str = Field(
        None,
        description="""
        왼쪽 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_end: str = Field(
        None,
        description="""
        오른쪽 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    size: str = Field(
        None,
        description="""
        이미지의 최대 너비.
        xxs, xs, sm, md, lg, xl, xxl, 3xl, 4xl, 5xl, full 중 하나의 값을 지정한다.
        열거된 순으로 이미지 너비가 증가한다.
        기본값은 md 이다.
        """,
    )
    align: str = Field(
        None,
        description="""
        수평 정렬 방식.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#horizontal-align
        """,
    )
    gravity: str = Field(
        None,
        description="""
        수직 정렬 방식.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#vertical-align
        """,
    )
    wrap: bool = Field(
        None,
        description="""
        true 로 설정하면 문자열을 줄 바꿈 처리한다. 기본값은 false 이다.
        true 로 설정하면, 개행 문자(\n)를 입력해 줄 바꿈을 할 수 있다.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-element
        """,
    )
    max_lines: int = Field(
        None,
        description="""
        문자열의 최대 행 개수. 최대 행 개수를 지정하려면 반드시 wrap 파라미터를 true 로 설정해야 한다.
        지정한 행에 표시할 수 없는 문자열은 말줄임(...) 처리된다
        값을 0 으로 지정하면 모든 문자열이 표시된다.
        기본값은 0 이다.
        """,
    )
    weight: Literal["regular", "bold"] = Field(
        None,
        description="""
        문자열 두께. regular 또는 bold 중 하나의 값을 지정한다.
        bold 로 지정하면 문자열이 굵게 처리된다.
        기본값은 regular 이다.
        """,
    )
    color: str = Field(
        None,
        description="""문자열 색상. Hex 코드로 지정한다.""",
    )
    action: Action = Field(
        None,
        description="""
        텍스트를 탭하면 실행되는 액션.        
        """,
    )
    style: Literal["normal", "italic"] = Field(
        None,
        description="""
        문자열 스타일. 다음 중 하나의 값을 지정한다:
        • normal: 스타일 없음
        • italic: 기울임꼴
        기본값은 normal 이다.
        """,
    )
    decoration: Literal["none", "underline", "line-through"] = Field(
        None,
        description="""
        문자열 꾸미기. 다음 중 하나의 값을 지정한다:
        • none: 꾸미기 없음
        • underline: 밑줄
        • line-through: 취소선
        기본값은 none 이다.
        """,
    )
