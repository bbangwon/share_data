import logging
from typing import Literal

from pydantic import Field

from ..action import Action
from .base import ContentBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class ButtonTemplateContent(ContentBase):
    type: Literal["button_template"] = Field(
        "button_template", description="button_template로 고정"
    )
    content_text: str = Field(..., description="본문 내용")
    actions: list[Action] = Field(
        ...,
        description="버튼 템플릿에 사용할 버튼. 최대 10개",
        examples=[
            {
                "type": "message",
                "label": "FAQ",
                "postback": "ButtonTemplate_FAQ",
            }
        ],
    )
