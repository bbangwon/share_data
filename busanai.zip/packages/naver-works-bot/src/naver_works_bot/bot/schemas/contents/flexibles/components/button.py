from typing import Literal

from pydantic import Field

from ....action import Action
from .base import ComponentBase


class ButtonComponent(ComponentBase):
    type: Literal["button"] = Field(
        "button",
        description="button으로 고정",
    )
    action: Action = Field(
        ...,
        description="버튼을 탭했을 때 실행되는 액션",
    )
    flex: int = Field(
        None,
        description="""
        상위 컴포넌트 내 해당 컴포넌트의 너비 또는 높이의 비율.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#component-height-width
        """,
    )
    margin: str = Field(
        None,
        description="""
        상위 컴포넌트 내 특정 컴포넌트와 이전 컴포넌트와의 최소 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#margin
        """,
    )
    position: Literal["relative", "absolute"] = Field(
        None,
        description="""
        박스를 배치하는 위치. 다음 값 중 하나를 지정한다.
        • relative: 이전 박스가 기준이 된다.
        • absolute: 부모 컴포넌트의 왼쪽 상단이 기준이 된다.
        기본값은 relative 이다. 
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_top: str = Field(
        None,
        description="""
        상단 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_bottom: str = Field(
        None,
        description="""
        하단 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_start: str = Field(
        None,
        description="""
        왼쪽 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_end: str = Field(
        None,
        description="""
        오른쪽 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    height: Literal["sm", "md"] = Field(
        None,
        description="""
        버튼의 높이. 
        sm 또는 md 중 하나의 값을 지정한다. 기본값은 md 이다.
        """,
    )
    style: Literal["primary", "secondary", "link"] = Field(
        None,
        description="""
        버튼의 스타일. 다음의 값 중 하나를 지정한다.
        • primary: 진한 색상의 버튼 스타일
        • secondary: 연한 색상의 버튼 스타일
        • link: HTML 링크 스타일
        기본값은 link 이다.
        """,
    )
    color: str = Field(
        None,
        description="""
        style 속성이 _link_일 때 버튼의 글자색.
        style 속성이 primary 또는 _secondary_일 때 버튼의 배경색.
        Hex 색상 코드로 지정한다.
        """,
    )
    gravity: str = Field(
        None,
        description="""
        수직 정렬 방식.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#vertical-gravity
        """,
    )
