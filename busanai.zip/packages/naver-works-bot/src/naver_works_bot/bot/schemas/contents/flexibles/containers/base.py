from pydantic import Field

from ...base import SchemaBase


class ContainerBase(SchemaBase):
    type: str = Field(
        ...,
        description="컨테이너 타입",
    )
