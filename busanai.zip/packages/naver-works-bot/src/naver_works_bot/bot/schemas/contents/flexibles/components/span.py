from typing import Literal

from pydantic import Field

from .base import ComponentBase


class SpanComponent(ComponentBase):
    type: Literal["span"] = Field("span", description="span 으로 고정")
    text: str = Field(
        ...,
        description="""
        표시되는 문자열.
        상위 텍스트 컴포넌트의 wrap 속성이 true 이면, 개행 문자(\n)를 사용해 줄 바꿈 처리할 영역을 지정할 수 있다.
        """,
    )
    color: str = Field(None, description="""문자열 색상. Hex 코드로 지정한다.""")
    size: str = Field(
        None,
        description="""
        문자열 크기. xxs, xs, sm, md, lg, xl, xxl, 3xl, 4xl, 5xl 중 하나의 값을 지정한다.
        열거된 순으로 문자열의 크기가 커진다.
        기본값은 md 이다.
        """,
    )
    weight: str = Field(
        None,
        description="""
        문자열 두께. regular 또는 bold 중 하나의 값을 지정한다.
        bold 로 지정하면 문자열이 굵게 처리된다.
        기본값은 regular 이다.
        """,
    )
    style: Literal["normal", "italic"] = Field(
        None,
        description="""
        문자열 스타일. 다음 중 하나의 값을 지정한다:
        • normal: 스타일 없음
        • italic: 기울임꼴
        기본값은 normal 이다.
        """,
    )
    decoration: Literal["none", "underline", "line-through"] = Field(
        None,
        description="""
        문자열 꾸미기. 다음 중 하나의 값을 지정한다:
        • none: 꾸미기 없음
        • underline: 밑줄
        • line-through: 취소선
        기본값은 none 이다.
        """,
    )
