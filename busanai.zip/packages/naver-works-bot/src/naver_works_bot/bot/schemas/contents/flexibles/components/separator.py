from typing import Literal

from pydantic import Field

from .base import ComponentBase


class SeparatorComponent(ComponentBase):
    type: Literal["separator"] = Field(
        "separator",
        description="separator으로 고정",
    )
    margin: str = Field(
        None,
        description="""
        상위 컴포넌트 내 특정 컴포넌트와 이전 컴포넌트와의 최소 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#margin
        """,
    )
    color: str = Field(
        None,
        description="""
        구분선의 색상. Hex 색상 코드로 지정한다.
        """,
    )
