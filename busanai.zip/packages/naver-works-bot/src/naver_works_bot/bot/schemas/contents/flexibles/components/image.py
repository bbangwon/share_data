from typing import Literal

from pydantic import Field

from ....action import Action
from .base import ComponentBase


class ImageComponent(ComponentBase):
    type: Literal["image"] = Field("image", description="image 로 고정")
    url: str = Field(
        ...,
        description="""이미지 URL (PNG 형식 권장, HTTPS만 허용).
        최대 크기: 1MB
        최대 글자수: 1,000자""",
    )
    flex: int = Field(
        None,
        description="""
        상위 컴포넌트 내 해당 컴포넌트의 너비 또는 높이의 비율.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#component-height-width
        """,
    )
    margin: str = Field(
        None,
        description="""
        상위 컴포넌트 내 특정 컴포넌트와 이전 컴포넌트와의 최소 간격.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#margin
        """,
    )
    position: Literal["relative", "absolute"] = Field(
        None,
        description="""
        박스를 배치하는 위치. 다음 값 중 하나를 지정한다.
        • relative: 이전 박스가 기준이 된다.
        • absolute: 부모 컴포넌트의 왼쪽 상단이 기준이 된다.
        기본값은 relative 이다. 
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_top: str = Field(
        None,
        description="""
        상단 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_bottom: str = Field(
        None,
        description="""
        하단 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_start: str = Field(
        None,
        description="""
        왼쪽 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    offset_end: str = Field(
        None,
        description="""
        오른쪽 오프셋.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#offset
        """,
    )
    align: str = Field(
        None,
        description="""
        수평 정렬 방식.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#horizontal-align
        """,
    )
    gravity: str = Field(
        None,
        description="""
        수직 정렬 방식.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-note#vertical-align
        """,
    )
    size: Literal[
        "xxs", "xs", "sm", "md", "lg", "xl", "xxl", "3xl", "4xl", "5xl", "full"
    ] = Field(
        None,
        description="""
        이미지의 최대 너비.
        xxs, xs, sm, md, lg, xl, xxl, 3xl, 4xl, 5xl, full 중 하나의 값을 지정한다.
        열거된 순으로 이미지 너비가 증가한다.
        기본값은 md 이다.
        """,
    )
    aspect_ratio: str = Field(
        None,
        description="""
        이미지의 비율. {width}:{height} 형식으로 지정한다.
        1~10000 사이의 값으로 _{width}_와 _{height}_값을 지정해야 한다.
        단, _{height}_값은 _{width}_값의 3배를 초과할 수 없다.
        기본값은 1:1 이다.
        """,
    )
    aspect_mode: Literal["cover", "fit"] = Field(
        None,
        description="""
        이미지의 비율과 aspectRatio 속성에 지정한 비율이 일치하지 않을 때 이미지가 표시되는 방식.
        https://developers.worksmobile.com/kr/docs/bot-send-flex-image#rendering-area
        """,
    )
    action: Action = Field(
        None,
        description="""
        이미지를 탭하면 실행되는 액션.        
        """,
    )
