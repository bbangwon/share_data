from typing import Annotated, Union

from pydantic import Field

from .containers.bubble import BubbleContainer
from .containers.carousel import CarouselContainer

# TODO: 컨텐츠가 늘어날때마다 여기에 추가
Container = Annotated[
    Union[BubbleContainer, CarouselContainer],
    Field(discriminator="type"),
]
