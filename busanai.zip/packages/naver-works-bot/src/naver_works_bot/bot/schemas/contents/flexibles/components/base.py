from pydantic import Field

from ...base import SchemaBase


class ComponentBase(SchemaBase):
    type: str = Field(
        ...,
        description="컴포넌트 타입",
    )
