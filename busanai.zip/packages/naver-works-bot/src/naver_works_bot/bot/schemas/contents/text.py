import logging
from typing import Literal, Optional

from pydantic import Field

from .base import ContentBase

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class TextContent(ContentBase):
    type: Literal["text"] = Field("text", description="text로 고정")
    text: str = Field(..., description="문자 메시지 내용. 최대 글자수: 2000자")
    postback: Optional[str] = Field(
        None, description="사용자 postback 정보(그리팅 혹은 템플릿 사용)"
    )

    @classmethod
    def from_text(cls, text: str):
        logger.debug("TextContent.from_text 호출됨. text: %s", text)
        return cls(text=text)
