from typing import Literal

from pydantic import Field

from ..base import ContentBase
from .container import Container


class FlexibleContent(ContentBase):
    type: Literal["flex"] = Field("flex", description="flex로 고정")
    alt_text: str = Field(
        ...,
        description="메시지 목록과 푸시에 표시되는 대체 텍스트. 대체 텍스트는 다국어로 전송할 수 있다. 최대 글자수: 400자",
    )
    contents: Container = Field(
        ...,
        description="Flexible Template 컨테이너.",
    )
