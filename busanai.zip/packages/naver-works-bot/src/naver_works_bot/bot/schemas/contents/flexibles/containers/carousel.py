from typing import Literal

from pydantic import Field

from .base import ContainerBase
from .bubble import BubbleContainer


class CarouselContainer(ContainerBase):
    type: Literal["carousel"] = Field(
        "carousel",
        description="carousel로 고정",
    )
    contents: list[BubbleContainer] = Field(
        ...,
        description="Carousel 컨테이너에 포함되는 Bubble 최대 10개",
        max_length=10,
    )
