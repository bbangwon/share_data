from typing import Literal

from pydantic import Field

from ....action import Action
from ...base import SchemaBase
from ..components.box import BoxComponent
from ..components.image import ImageComponent
from .base import ContainerBase


class BlockStyle(SchemaBase):
    background_color: str = Field(
        None, description="블록의 배경색. Hex 색상 코드로 지정한다."
    )
    separator: bool = Field(
        None,
        description="true로 설정하면 블록 위에 구분선이 표시된다. 기본값은 false이다.",
    )
    separator_color: str = Field(
        None, description="구분선의 색상. Hex 색상 코드로 지정한다."
    )


class BubbleStyle(SchemaBase):
    header: BlockStyle = Field(None, description="헤더 블록 스타일")
    hero: BlockStyle = Field(None, description="히어로 블록 스타일")
    body: BlockStyle = Field(None, description="바디 블록 스타일")
    footer: BlockStyle = Field(None, description="푸터 블록 스타일")


class BubbleContainer(ContainerBase):
    type: Literal["bubble"] = Field(
        "bubble",
        description="bubble로 고정",
    )
    size: Literal["nano", "micro", "kilo", "mega", "giga"] = Field(
        None,
        description="버블의 크기. nano, micro, kilo, mega, giga 중 하나의 값으로 지정한다. 기본값은 mega이다.",
    )
    direction: Literal["ltr", "rtl"] = Field(
        None,
        description="""문자열의 방향이며, 수평 박스에서는 하위 컴포넌트들이 배치되는 방향이다. 다음 값 중 하나를 지정한다. 
                                             - ltr: 문자열과 컴포넌트를 왼쪽에서 오른쪽으로 표기 및 배치
                                             - rtl: 문자열과 컴포넌트를 오른쪽에서 왼쪽으로 표기 및 배치
                                             기본값은 ltr이다.""",
    )
    header: BoxComponent = Field(None, description="헤더 블록. Box로 지정한다.")
    hero: BoxComponent | ImageComponent = Field(
        None, description="히어로 블록. Box또는 Image로 지정한다."
    )
    body: BoxComponent = Field(None, description="바디 블록. Box로 지정한다.")
    footer: BoxComponent = Field(None, description="푸터 블록. Box로 지정한다.")
    styles: BubbleStyle = Field(None, description="버블의 스타일을 지정하는 객체.")
    action: Action = Field(None, description="버블을 탭하면 실행되는 액션")
