import logging

from pydantic import Field

from .base import SchemaBase
from .content import Content

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class _SendContent(SchemaBase):
    content: Content = Field(
        ...,
        description="보낼 메시지 입니다.",
        examples=[
            {"type": "text", "text": "안녕하세요!"},
            {
                "type": "image",
                "previewImageUrl": "https://example.com/image.jpg",
                "originalImageUrl": "https://example.com/original_image.jpg",
            },
        ],
    )
