import logging
from typing import Literal, Optional

from pydantic import Field

from .base import SchemaBase
from .content import Content

# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)


class ReceiveSourceContext(SchemaBase):
    user_id: str = Field(
        ..., description="대화한 사용자의 대표 계정", examples=["user123"]
    )
    channel_id: Optional[str] = Field(
        None,
        description="대화한 사용자가 속한 메시지방 ID. 1:1 메시지방의 ID는 전송되지 않는다.",
        examples=["channel456"],
    )
    domain_id: int = Field(
        ..., description="대화한 사용자가 속한 도메인 ID", examples=[789]
    )


class ReceiveMessage(SchemaBase):
    type: Literal["message", "postback"] = Field(
        "message", description="message로 고정"
    )
    source: ReceiveSourceContext = Field(
        ..., description="callback 메시지를 전달한 주체"
    )
    issued_time: str = Field(
        ...,
        description="이벤트 발생 시각(형식: YYYY-MM-DDThh:mm:ss.SSSZ)",
        examples=["2025-07-03T10:30:45.123Z"],
    )
    content: Optional[Content] = Field(
        None,
        description="사용자가 보낸 메시지 내용",
        examples=[
            {"type": "text", "text": "안녕하세요!"},
            {
                "type": "image",
                "previewImageUrl": "https://example.com/image.jpg",
                "originalImageUrl": "https://example.com/original_image.jpg",
            },
        ],
    )
    data: Optional[str] = Field(
        None,
        description="사용자가 보낸 postback 정보.",
        examples=["postback_data"],
    )
