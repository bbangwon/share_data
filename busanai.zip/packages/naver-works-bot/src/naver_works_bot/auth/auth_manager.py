import json
import logging
import os
import time
from typing import Literal

import httpx
import jwt

from naver_works_bot.auth.auth_schema import (
    AuthAccessToken,
    AuthConfig,
    AuthRefreshToken,
    AuthRequest,
    AuthRevokeToken,
    JwtClaim,
    JwtHeader,
)

logger = logging.getLogger(__name__)


class AuthManager:
    def __init__(
        self,
        config: AuthConfig,
    ):
        """
        AuthManager 초기화

        Args:
            config (AuthConfig): 인증 설정 객체 (필수)

        Raises:
            ValueError: config가 None인 경우
            TypeError: config가 AuthConfig 타입이 아닌 경우
        """

        if config is None:
            raise ValueError("config 매개변수는 필수입니다.")

        if not isinstance(config, AuthConfig):
            raise TypeError("config는 AuthConfig 타입이어야 합니다.")

        self._config = config

        self.naver_access_token_url = self._config.base_url + "/oauth2/v2.0/token"
        self.naver_revoke_token_url = self._config.base_url + "/oauth2/v2.0/revoke"

        self.access_token: AuthAccessToken | None = None

        logger.debug("네이버 API 기본 URL: %s", self._config.base_url)
        logger.debug("네이버 계정: %s", self._config.account)
        logger.debug("네이버 클라이언트 ID: %s", self._config.client_id)
        logger.debug("네이버 클라이언트 시크릿: %s", self._config.client_secret)
        logger.debug("네이버 개인 키: %s", self._config.private_key)
        logger.debug("네이버 스코프: %s", self._config.scope)

        logger.debug("네이버 엑세스 토큰 URL: %s", self.naver_access_token_url)
        logger.debug("네이버 리보크 토큰 URL: %s", self.naver_revoke_token_url)
        logger.debug(
            "네이버 엑세스 토큰 스코프: %s",
            ", ".join(self._config.scope) if self._config.scope else "없음",
        )
        logger.debug("AuthManager가 초기화되었습니다.")

    def _create_jwt(self) -> str:
        """JWT를 생성합니다."""
        logger.info("JWT를 생성합니다.")
        now = int(time.time())
        claims = JwtClaim(
            iat=now,
            exp=now + 3600,
            iss=self._config.client_id,
            sub=self._config.account,
        ).model_dump()  # 1시간 유효
        headers = JwtHeader().model_dump()

        token = jwt.encode(
            headers=headers,
            payload=claims,
            key=self._config.private_key,
            algorithm="RS256",
        )
        logger.debug(
            "JWT 생성 완료. claims: %s, headers: %s, token: %s", claims, headers, token
        )
        return token

    async def issue_access_token(self) -> AuthAccessToken:
        """엑세스 토큰을 발급합니다."""
        logger.info("엑세스 토큰을 발급합니다.")
        jwt_token = self._create_jwt()
        auth_request = AuthRequest(
            assertion=jwt_token,
            client_id=self._config.client_id,
            client_secret=self._config.client_secret,
            scope=" ".join(self._config.scope) if self._config.scope else "",
        )

        logger.debug("엑세스 토큰 요청: %s", auth_request.model_dump())

        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.naver_access_token_url,
                data=auth_request.model_dump(),
                headers={
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                },
            )
            response.raise_for_status()
            response_data = response.json()
            logger.debug("Access token 요청 응답: %s", response_data)

            self.access_token = AuthAccessToken(**response_data)
            self.write_access_token(self.access_token)
            logger.info("엑세스 토큰 발급 성공.")
            return self.access_token

    async def _refresh_access_token(self, refresh_token: str) -> AuthAccessToken:
        """엑세스 토큰을 갱신합니다."""
        logger.info("엑세스 토큰을 갱신합니다.")
        auth_refresh = AuthRefreshToken(
            refresh_token=refresh_token,
            client_id=self._config.client_id,
            client_secret=self._config.client_secret,
        )

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.naver_access_token_url,
                    data=auth_refresh.model_dump(),
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
                response.raise_for_status()
                response_data = response.json()
                logger.debug("Refresh token 요청 응답: %s", response_data)

                self.access_token = AuthAccessToken(**response_data)
                if self._config.reuse_access_token:
                    # 엑세스 토큰을 파일에 저장합니다.
                    logger.info("엑세스 토큰을 파일에 저장합니다.")
                    self.write_access_token(self.access_token)

                logger.info("엑세스 토큰 갱신 성공.")

        except httpx.HTTPStatusError:
            logger.error("엑세스 토큰 갱신에 실패하여 다시 발급합니다.")
            self.access_token = await self.issue_access_token()
        except Exception as e:
            logger.error("엑세스 토큰 갱신 중 오류가 발생했습니다: %s", e)
            raise e

        return self.access_token

    def write_access_token(self, access_token: AuthAccessToken):
        """엑세스 토큰을 파일에 저장합니다."""
        logger.info("엑세스 토큰을 파일에 저장합니다.")
        with open(self._config.reuse_access_token_path, "w") as f:
            write_access_token = access_token.model_dump(exclude_none=True)
            f.write(json.dumps(write_access_token))

    def read_access_token(self) -> AuthAccessToken | None:
        """엑세스 토큰을 파일에서 읽어옵니다."""
        logger.info("엑세스 토큰을 파일에서 읽어옵니다.")
        if os.path.exists(self._config.reuse_access_token_path):
            with open(self._config.reuse_access_token_path, "r") as f:
                token_data = f.read()
                access_token_json = json.loads(token_data)

                return AuthAccessToken(**access_token_json)
        return None

    async def get_access_token(self) -> str:
        """엑세스 토큰을 가져옵니다. 만약 토큰이 없으면 새로 발급합니다."""
        logger.info("엑세스 토큰을 가져옵니다. 만약 토큰이 없으면 새로 발급합니다.")

        if self.access_token is None:
            # 파일에서 엑세스 토큰을 읽어옵니다.
            if self._config.reuse_access_token:
                self.access_token = self.read_access_token()

        if self.access_token is None:
            # 파일에 엑세스 토큰이 없으면 새로 발급합니다.
            self.access_token = await self.issue_access_token()
        else:
            # 파일에서 읽어온 엑세스 토큰이 유효한 경우
            logger.info("파일에서 엑세스 토큰을 읽어왔습니다.")

        if not self.access_token.is_valid():  # 내부적으로 만료 여부 확인
            # 엑세스 토큰이 만료되었으면 갱신합니다.
            logger.info("엑세스 토큰이 만료되었습니다. 갱신합니다.")

            self.access_token = await self._refresh_access_token(
                self.access_token.refresh_token
            )

        return self.access_token.access_token

    async def revoke_access_token(
        self, token: str, token_type: Literal["access_token", "refresh_token"]
    ):
        """엑세스 토큰/리프레시 토큰을 취소합니다."""
        logger.info("엑세스/리프레시 토큰을 취소합니다. token_type: %s", token_type)
        auth_revoke = AuthRevokeToken(
            token=token,
            token_type_hint=token_type,
            client_id=self._config.client_id,
            client_secret=self._config.client_secret,
        )

        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.naver_revoke_token_url,
                data=auth_revoke.model_dump(),
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            response.raise_for_status()

        self.access_token = None  # Clear the access token after revocation
        if token_type == "access_token":
            logger.info("엑세스 토큰 취소 성공.")
        elif token_type == "refresh_token":
            logger.info("리프레시 토큰 취소 성공.")
        return True
