import time
from typing import Literal

from pydantic import BaseModel, Field

REUSE_ACCESS_TOKEN_PATH = "access_token_cached.json"


class AuthConfig(BaseModel):
    """네이버 웍스 OAuth 인증 설정 모델"""

    client_id: str = Field(..., description="네이버 웍스 클라이언트 ID")
    client_secret: str = Field(..., description="네이버 웍스 클라이언트 시크릿")
    private_key: str = Field(..., description="네이버 웍스 개인 키")
    account: str = Field(..., description="네이버 웍스 계정")
    base_url: str = Field(..., description="네이버 웍스 API 기본 URL")
    scope: list[str] = Field(
        default=["bot", "bot.message", "bot.read"], description="OAuth Scope"
    )
    reuse_access_token: bool = Field(
        default=True, description="액세스 토큰 재사용 여부"
    )
    reuse_access_token_path: str = Field(
        default=REUSE_ACCESS_TOKEN_PATH,
        description="액세스 토큰 재사용 시 저장할 파일 경로",
    )


class AuthAccessToken(BaseModel):
    """네이버 웍스 OAuth 액세스 토큰 모델"""

    access_token: str = Field(..., description="액세스 토큰")
    refresh_token: str = Field(..., description="리프레시 토큰")
    token_type: str = Field(..., description="토큰 유형")
    expires_in: int = Field(..., description="토큰 만료 시간(초)")
    scope: str = Field(..., description="토큰 Scope")
    created_at: int = Field(default=int(time.time()), description="토큰 생성 시간")

    def is_valid(self) -> bool:
        """액세스 토큰이 유효한지 확인합니다. 만료 30분 전까지 유효로 간주합니다."""
        current_time = int(time.time())
        return current_time < (self.created_at + self.expires_in) - 1800


class AuthRequest(BaseModel):
    """JWT Bearer 방식의 OAuth 인증 요청 모델"""

    assertion: str = Field(..., description="JWT Assertion")
    grant_type: str = Field(
        default="urn:ietf:params:oauth:grant-type:jwt-bearer", description="Grant Type"
    )
    client_id: str = Field(..., description="네이버 웍스 클라이언트 ID")
    client_secret: str = Field(..., description="네이버 웍스 클라이언트 시크릿")
    scope: str = Field(..., description="OAuth Scope")


class AuthRefreshToken(BaseModel):
    """리프레시 토큰을 사용한 토큰 갱신 요청 모델"""

    refresh_token: str = Field(..., description="리프레시 토큰")
    grant_type: str = Field(default="refresh_token", description="Grant Type")
    client_id: str = Field(..., description="네이버 웍스 클라이언트 ID")
    client_secret: str = Field(..., description="네이버 웍스 클라이언트 시크릿")


class AuthRevokeToken(BaseModel):
    """토큰 취소 요청 모델"""

    client_id: str = Field(..., description="네이버 웍스 클라이언트 ID")
    client_secret: str = Field(..., description="네이버 웍스 클라이언트 시크릿")
    token: str = Field(..., description="취소할 토큰")
    token_type_hint: Literal["access_token", "refresh_token"] = Field(
        default="access_token", description="토큰 유형 힌트"
    )


class JwtHeader(BaseModel):
    """JWT 헤더 모델"""

    alg: str = Field(default="RS256", description="알고리즘")
    typ: str = Field(default="JWT", description="유형")


class JwtClaim(BaseModel):
    """JWT 클레임 모델"""

    iss: str = Field(..., description="발급자")
    sub: str = Field(..., description="주제")
    iat: int = Field(..., description="발급 시간")
    exp: int = Field(..., description="만료 시간")


__all__ = [
    "AuthConfig",
    "AuthAccessToken",
    "AuthRequest",
    "AuthRefreshToken",
    "AuthRevokeToken",
]
