# Request Queue

Redis를 기반으로 한 비동기 요청 큐 워커 시스템입니다.

## 개요

Request Queue는 Redis를 사용하여 HTTP 요청을 큐에 저장하고 비동기적으로 처리하는 Python 패키지입니다.
대량의 요청을 비동기적으로 처리하거나 워커 풀을 사용한 동시 처리가 필요한 시나리오에서 유용합니다.

## 기능

- Redis를 사용한 FIFO(First In, First Out) 큐 구현
- 비동기 워커 풀을 통한 동시 요청 처리
- 세마포어를 사용한 동시성 제어
- 요청 헤더와 본문을 포함한 구조화된 요청 데이터 저장
- 큐에 요청 추가(enqueue) 및 자동 처리 기능
- 큐 크기 조회 기능
- Redis 연결 오류 시 자동 재연결
- Pydantic을 사용한 데이터 검증

## 설치(개발 환경)

```bash
uv add --editable ../packages/request-queue
```

## 사용법

### 기본 사용법

```python
import asyncio
import logging
from request_queue import AsyncRedisQueueWorker, RequestQueueItem

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 작업 처리 함수 정의
async def process_task(item: RequestQueueItem):
    """큐에서 가져온 작업을 처리하는 함수"""
    logger.info(f"작업 시작: {item.id}")

    # 실제 작업 처리 로직 (예: API 호출, 데이터 처리 등)
    print(f"헤더: {item.headers}")
    print(f"본문: {item.body}")

    logger.info(f"작업 완료: {item.id}")

async def main():
    # 워커 인스턴스 생성
    worker = AsyncRedisQueueWorker(
        redis_url="redis://localhost:6379",
        task_processor=process_task,
        max_workers=5  # 최대 5개 동시 작업
    )

    # 워커 시작 (백그라운드에서 실행)
    worker_task = asyncio.create_task(worker.start(queue_name="my_request_queue"))

    # 요청 아이템 생성 및 큐에 추가
    for i in range(3):
        item = RequestQueueItem(
            headers={"Content-Type": "application/json", "Authorization": "Bearer token"},
            body={"user_id": 123 + i, "action": "update_profile"}
        )
        await worker.enqueue(queue_name="my_request_queue", item=item)
        logger.info(f"큐에 작업 추가: {item.id}")

    # 큐 크기 확인
    count = await worker.get_queue_count("my_request_queue")
    print(f"큐에 있는 요청 수: {count}")

    # 일정 시간 후 워커 중지
    await asyncio.sleep(10)
    await worker.stop()
    await worker_task

if __name__ == "__main__":
    asyncio.run(main())
```

### 생산자와 소비자 분리

대규모 시스템에서는 작업을 생성하는 부분과 처리하는 부분을 분리할 수 있습니다.

#### 생산자 (작업 생성)

```python
import asyncio
from request_queue import AsyncRedisQueueWorker, RequestQueueItem

async def produce_tasks():
    # 생산자는 task_processor가 필요 없음
    producer = AsyncRedisQueueWorker(
        redis_url="redis://localhost:6379"
    )

    # 작업 100개 생성
    for i in range(100):
        item = RequestQueueItem(
            headers={"Content-Type": "application/json"},
            body={"task_id": i, "data": f"task_data_{i}"}
        )
        await producer.enqueue(queue_name="task_queue", item=item)
        print(f"작업 추가: {item.id}")

if __name__ == "__main__":
    asyncio.run(produce_tasks())
```

#### 소비자 (작업 처리)

```python
import asyncio
import signal
from request_queue import AsyncRedisQueueWorker, RequestQueueItem

async def process_heavy_task(item: RequestQueueItem):
    """무거운 작업 처리"""
    print(f"처리 시작: {item.id}")
    # 실제 처리 로직
    await asyncio.sleep(2)  # 2초간 처리 시뮬레이션
    print(f"처리 완료: {item.id}")

async def run_consumer():
    worker = AsyncRedisQueueWorker(
        redis_url="redis://localhost:6379",
        task_processor=process_heavy_task,
        max_workers=10  # 동시에 10개 작업 처리
    )

    # 그레이스풀 셧다운을 위한 시그널 핸들러
    def signal_handler():
        print("종료 신호를 받았습니다. 워커를 중지합니다...")
        asyncio.create_task(worker.stop())

    # SIGINT (Ctrl+C) 시그널 등록
    loop = asyncio.get_event_loop()
    if hasattr(signal, 'SIGINT'):
        loop.add_signal_handler(signal.SIGINT, signal_handler)

    try:
        await worker.start(queue_name="task_queue")
    except KeyboardInterrupt:
        print("워커가 중지되었습니다.")

if __name__ == "__main__":
    asyncio.run(run_consumer())
```

### 요청 아이템 구조

`RequestQueueItem`은 자동으로 고유 ID를 생성하며, 헤더와 본문 정보를 포함합니다:

```python
from request_queue import RequestQueueItem

# 기본 사용법
item = RequestQueueItem(
    headers={"Content-Type": "application/json"},  # 요청 헤더 (dict)
    body={"key": "value"}                         # 요청 본문 (dict)
)

# ID는 자동으로 UUID4로 생성됩니다
print(f"생성된 ID: {item.id}")

# 커스텀 ID 지정도 가능합니다
item_with_custom_id = RequestQueueItem(
    id="custom-task-001",
    headers={"Authorization": "Bearer token"},
    body={"action": "process_data", "data": [1, 2, 3]}
)
```

### 워커 설정 옵션

```python
worker = AsyncRedisQueueWorker(
    task_processor=process_task,      # 작업 처리 함수 (필수)
    redis_url="redis://localhost:6379",  # Redis 연결 URL (필수)
    max_workers=10                   # 최대 동시 작업 수 (기본값: 10)
)
```

### 주요 메서드

- `start(queue_name)`: 워커 시작 (지정된 큐에서 작업을 처리)
- `stop()`: 워커 중지 (진행 중인 작업 완료 후 종료)
- `enqueue(queue_name, item)`: 큐에 작업 추가
- `get_queue_count(queue_name)`: 큐에 있는 작업 수 조회

## 실행 환경 설정

### Redis 서버 시작

Docker를 사용하여 Redis 서버를 시작할 수 있습니다:

```bash
# Redis 서버 시작
docker run -d -p 6379:6379 --name redis redis:alpine

# Redis CLI로 연결 확인
docker exec -it redis redis-cli ping
```

### 예제 실행

1. **소비자 워커 실행**:

   ```bash
   python consumer.py
   ```

2. **생산자 실행** (다른 터미널에서):
   ```bash
   python producer.py
   ```

## 요구사항

- Python 3.11 이상
- Redis 서버
- pydantic >= 2.11.7
- redis >= 5.0.0

## 주요 특징

- **비동기 처리**: asyncio 기반의 완전 비동기 워커 시스템
- **동시성 제어**: 세마포어를 사용한 최대 워커 수 제한
- **오류 복구**: Redis 연결 오류 시 자동 재연결
- **그레이스풀 셧다운**: 진행 중인 작업 완료 후 안전한 종료
- **구조화된 데이터**: Pydantic을 사용한 타입 안전성과 데이터 검증
- **확장 가능**: 여러 큐와 워커 인스턴스를 동시에 실행 가능
