import asyncio
import logging

from request_queue.redis_queue.async_redis_queue_worker import AsyncRedisQueueWorker
from request_queue.schemes.request_queue_item import RequestQueueItem

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("request_queue.log", mode="a", encoding="utf-8"),
    ],
)

logger = logging.getLogger(__name__)
# 로거 레벨 설정


# 작업 처리 함수 정의
async def process_task(item: RequestQueueItem):
    """큐에서 가져온 작업을 처리하는 함수"""
    logger.info(f"작업 시작: {item.id}")

    # 실제 작업 처리 로직 (예: API 호출, 데이터 처리 등)
    await asyncio.sleep(2)  # 2초간 작업 시뮬레이션

    logger.info(f"작업 완료: {item.id}")


async def main():
    # 워커 인스턴스 생성 (제네릭 타입 지정)
    worker = AsyncRedisQueueWorker[RequestQueueItem](
        redis_url="redis://localhost:6379",
        task_class=RequestQueueItem,
        task_processor=process_task,
    )

    # 테스트용 작업 몇 개 큐에 추가
    for i in range(10):
        item = RequestQueueItem(
            headers={"Content-Type": "application/json"},
            body={"message": f"작업 내용 {i}"},
        )
        await worker.enqueue(queue_name="my_request_queue", item=item)

    # 워커 시작 (백그라운드에서 실행)
    worker.start(queue_name="my_request_queue", max_workers=5)

    # 10초 후 워커 중지
    await asyncio.sleep(10)

    # 워커 태스크 완료 대기
    await worker.stop()


if __name__ == "__main__":
    asyncio.run(main())
