from uuid import uuid4

from pydantic import BaseModel, Field


class RequestQueueItem(BaseModel):
    """요청 큐 아이템 모델"""

    id: str = Field(default_factory=lambda: uuid4().hex, description="요청 아이디")
    headers: dict = Field(..., description="요청 헤더 정보")
    body: dict = Field(..., description="요청 본문 정보")

    def get_bot_id(self) -> str:
        """요청의 봇 ID를 반환합니다."""
        return self.headers.get("x-works-botid", "")

    def get_signature(self) -> str:
        """요청의 서명을 반환합니다."""
        return self.headers.get("x-works-signature", "")

    def get_user_id(self) -> str:
        """요청에서 사용자 ID를 추출합니다."""
        return self.body.get("source", {}).get("user_id", "")

    def get_postback(self) -> str | None:
        """요청이 포스트백인지 확인하고, 포스트백 데이터를 반환합니다."""
        content = self.body.get("content", {})
        return content.get("postback", None) or self.body.get("data", None)

    def get_file_id(self) -> str | None:
        """요청의 파일 ID를 반환합니다."""
        content = self.body.get("content", {})
        if content.get("type", "") == "file":
            return content.get("file_id", "")
        return None

    def get_user_message(self) -> str | None:
        """요청의 사용자 메시지를 반환합니다."""
        content = self.body.get("content", {})
        if content.get("type", "") == "text":
            return content.get("text", "")
        return None

    def set_user_message(self, message: str):
        """사용자 메시지를 설정합니다."""
        content = self.body.get("content", {})
        if content.get("type", "") == "text":
            content["text"] = message
            self.body["content"] = content

    def add_attached_file(self, file_info: dict):
        """파일 콘텐츠 정보를 요청에 추가합니다."""

        content = self.body.get("attached_file", {})
        content.update(file_info)
        self.body["attached_file"] = content

    def get_attached_file(self) -> dict | None:
        content = self.body.get("attached_file", None)
        return content
