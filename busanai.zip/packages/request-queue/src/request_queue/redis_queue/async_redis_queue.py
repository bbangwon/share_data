import asyncio
import json
import logging
import os
from typing import Callable, Generic, Type, TypeVar

import redis.asyncio as redis
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)

logger = logging.getLogger(__name__)

PUBLISH_ENQUEUE_FORMAT = "queue:{queue_name}"


class AsyncRedisQueue(Generic[T]):
    def __init__(
        self,
        redis_url: str,
        item_class: Type[T] | None = None,
        publish_enqueue: bool = False,
    ):
        self.redis_url = redis_url
        self.item_class = item_class
        self.redis_client = None
        self.publish_enqueue = publish_enqueue
        self.subscribed_channels = set()

    async def connect(self):
        """Redis 연결"""
        if self.redis_client:
            logger.debug("이미 Redis에 연결되어 있습니다.")
            return
        logger.debug(f"Redis에 연결 중: {self.redis_url}")
        try:
            self.redis_client = redis.from_url(self.redis_url, decode_responses=True)
            await self.redis_client.ping()
            logger.debug("Redis에 연결되었습니다.")
        except redis.ConnectionError as e:
            logger.error(f"Redis 연결 오류: {e}")
            self.redis_client = None
            raise e

    async def disconnect(self):
        """Redis 연결 종료"""
        if self.redis_client:
            await self.redis_client.close()
            logger.debug("Redis 연결이 종료되었습니다.")
            self.redis_client = None
        else:
            logger.debug("Redis 연결이 이미 종료되었습니다.")

    async def enqueue_dict(self, queue_name: str, item: dict):
        """큐에 추가"""
        if not self.redis_client:
            await self.connect()

        item_json = json.dumps(item, ensure_ascii=False)

        logger.info(f"'{queue_name}' 큐에 추가합니다.")
        logger.debug(f"큐에 추가된 데이터: {item_json}")

        await self.redis_client.rpush(queue_name, item_json)

        # Pub/Sub을 사용하여 구독자에게 알림
        if self.publish_enqueue:
            logger.info(f"'{queue_name}' 큐에 메시지를 발행합니다.")
            await self.publish_message(
                PUBLISH_ENQUEUE_FORMAT.format(queue_name=queue_name), item
            )

    async def dequeue_dict(self, queue_name: str) -> dict | None:
        """큐에서 데이터를 가져옵니다."""
        if not self.redis_client:
            await self.connect()

        logger.info(f"'{queue_name}' 큐에서 가져옵니다.")
        item_json = await self.redis_client.lpop(queue_name)
        if not item_json:
            logger.info(f"'{queue_name}' 큐에 데이터가 없습니다.")
            return None

        logger.debug(f"큐에서 가져온 데이터: {item_json}")
        return json.loads(item_json)

    async def get_queue_count(self, queue_name: str) -> int:
        """큐에 있는 데이터의 개수를 반환"""
        if not self.redis_client:
            await self.connect()

        logger.info(f"'{queue_name}' 큐에 있는 데이터 개수를 가져옵니다.")
        count = await self.redis_client.llen(queue_name)
        logger.info(f"'{queue_name}' 큐에 있는 데이터 개수: {count}")
        return count

    async def enqueue(self, queue_name: str, item: T) -> None:
        """Pydantic 모델을 큐에 추가"""
        if not self.redis_client:
            await self.connect()

        if not self.item_class:
            raise ValueError("item_class가 설정되지 않았습니다.")

        item_dict = item.model_dump()
        await self.enqueue_dict(queue_name, item_dict)

    async def dequeue(self, queue_name: str) -> T | None:
        """큐에서 Pydantic 모델을 가져옵니다."""
        if not self.redis_client:
            await self.connect()

        if not self.item_class:
            raise ValueError("item_class가 설정되지 않았습니다.")

        item_dict = await self.dequeue_dict(queue_name)
        if not item_dict:
            return None

        return self.item_class.model_validate(item_dict)

    async def publish_message(self, channel: str, message: dict):
        """Redis Pub/Sub을 사용하여 메시지를 발행합니다."""
        if not self.redis_client:
            await self.connect()

        message_json = json.dumps(message, ensure_ascii=False)

        logger.info(f"'{channel}' 채널에 메시지를 발행합니다: {message_json}")
        await self.redis_client.publish(channel=channel, message=message_json)

    async def subscribe(
        self,
        channel: str,
        callback: Callable[[dict], None],
        call_callback_on_start=True,
    ):
        """Redis Pub/Sub을 사용하여 큐를 구독합니다."""
        if not self.redis_client:
            await self.connect()

        try:
            async with self.redis_client.pubsub() as pubsub:
                await pubsub.subscribe(channel)
                self.subscribed_channels.add(channel)

                if call_callback_on_start:
                    callback()  # 구독 시작 시 콜백 호출

                while self.subscribed_channels.__contains__(channel):
                    message = await pubsub.get_message()
                    if message and message["type"] == "message":
                        item = json.loads(message["data"])
                        callback(item)
        except redis.ConnectionError as e:
            logger.error(f"Redis 연결 오류.. 구독 복구를 시도합니다.: {e}")
            await self.disconnect()
            asyncio.create_task(
                self._recover_subscribe(channel, callback)
            )  # 연결 복구 시도

    async def unsubscribe(self, channel: str):
        """Redis Pub/Sub 구독을 취소합니다."""
        if not self.redis_client:
            await self.connect()

        async with self.redis_client.pubsub() as pubsub:
            await pubsub.unsubscribe(channel)
            self.subscribed_channels.discard(channel)
            logger.info(f"'{channel}' 큐의 구독을 취소했습니다.")

    async def _recover_subscribe(self, channel: str, callback: Callable[[dict], None]):
        """구독 복구 시도"""
        while self.subscribed_channels.__contains__(channel):
            try:
                logger.debug(f"'{channel}' 채널 구독을 복구 시도 중...")
                if not self.redis_client:
                    await self.connect()

                # 재구독
                asyncio.create_task(self.subscribe(channel, callback))

                logger.info(f"'{channel}' 채널 구독을 복구했습니다.")
                return
            except redis.ConnectionError:
                await asyncio.sleep(5)  # 5초 후에 재시도


# Helper 함수: 환경 변수를 사용하여 요청 큐 워커를 가져오는 함수
def get_redis_queue_using_env(
    item_class: Type[T], publish_enqueue: bool = False, redis_url: str = None
) -> AsyncRedisQueue[T]:
    if redis_url is None:
        env_name_redis_url = "REQUEST_REDIS_URL"
        redis_url = os.getenv(env_name_redis_url)
        if not redis_url:
            raise ValueError(
                f"{env_name_redis_url} 환경 변수가 설정되어 있지 않습니다."
            )

    # 요청 큐 설정
    redis_queue = AsyncRedisQueue[T](
        redis_url=redis_url, item_class=item_class, publish_enqueue=publish_enqueue
    )
    return redis_queue
