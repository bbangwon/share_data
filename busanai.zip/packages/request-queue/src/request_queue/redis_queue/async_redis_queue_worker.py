import asyncio
import logging
import os
from typing import Awaitable, Callable, Type

import redis.asyncio as redis

from request_queue.redis_queue.async_redis_queue import (
    PUBLISH_ENQUEUE_FORMAT,
    AsyncRedisQueue,
    T,
)

logger = logging.getLogger(__name__)


class AsyncRedisQueueWorker(AsyncRedisQueue[T]):
    def __init__(
        self,
        redis_url: str,
        item_class: Type[T],
        item_processor: Callable[[T], Awaitable[None]] | None = None,
    ):
        super().__init__(redis_url, item_class, publish_enqueue=True)
        self.item_processor = item_processor
        self.running = False
        self.working = False
        self.tasks = set()
        self.semaphore = None  # 초기화 추가
        self._event = asyncio.Event()

    async def handle_task(self, item: T):
        """큐에서 가져온 요청을 처리하는 함수"""

        async def process():
            """실제 작업 처리"""
            try:
                logger.info(f"처리 중인 요청: {item}")
                if self.item_processor is not None:
                    await self.item_processor(item)
                else:
                    logger.info(
                        f"item_processor가 None이므로 요청을 처리하지 않습니다: {item}"
                    )
            except Exception as e:
                logger.error(f"요청 처리 중 오류 발생: {e}")

        if self.semaphore:
            async with self.semaphore:
                await process()
        else:
            await process()

    async def worker_loop(self):
        """비동기 워커 루프 Processing 인 경우에 루프를 계속 수행"""
        try:
            self.working = True
            while True:
                try:
                    if not self.running:
                        break

                    item = await self.dequeue(self.queue_name)
                    if item:
                        logger.info(f"큐에서 요청을 가져왔습니다: {item}")
                        task = asyncio.create_task(self.handle_task(item))
                        self.tasks.add(task)
                        task.add_done_callback(self.tasks.discard)
                    else:
                        break
                except redis.ConnectionError as e:
                    logger.error(f"Redis 연결 오류: {e}")
                    await self.disconnect()
                    await self.connect()
                except asyncio.CancelledError:
                    logger.info("워커가 취소되었습니다.")
                    break
                except Exception as e:
                    logger.error(f"큐에서 요청을 가져오는 중 오류 발생: {e}")
                    break
        finally:
            self.working = False

    def start(self, queue_name: str, max_workers: int = 10):
        """워커 시작"""
        asyncio.create_task(self._start(queue_name, max_workers))

    async def _start(self, queue_name: str, max_workers: int):
        """워커 시작"""
        try:
            await self.connect()

            self._event.clear()
            self.max_workers = max_workers
            self.semaphore = asyncio.Semaphore(max_workers)
            self.queue_name = queue_name
            self.running = True

            logger.info(
                f"비동기 큐 작업이 시작되었습니다. {max_workers}개로 시작합니다."
            )

            asyncio.create_task(
                self.subscribe(
                    PUBLISH_ENQUEUE_FORMAT.format(queue_name=queue_name),
                    self._subscribe_handler,
                )
            )
        except Exception as e:
            logger.error(f"비동기 큐 작업 시작 중 오류 발생: {e}")
            raise e

    async def stop(self):
        """워커 중지"""
        logger.info("비동기 큐 작업이 중지되었습니다.")

        self.running = False

        await self.unsubscribe(
            PUBLISH_ENQUEUE_FORMAT.format(queue_name=self.queue_name)
        )
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)
        await self.disconnect()

        if not self._event.is_set():
            self._event.set()

    def _subscribe_handler(self, _=None) -> None:
        """큐에 대한 구독 핸들러를 설정합니다."""

        logger.info("구독 핸들러가 호출되었습니다")

        # 작업 진행 중이면 계속 이어서 큐 처리를 할것이므로..
        if not self.working:
            asyncio.create_task(self.worker_loop())
        else:
            logger.info("워커가 이미 실행 중이므로 구독 핸들러를 무시합니다.")

    async def wait_until_stopped(self):
        """워커가 중지될 때까지 대기"""
        if not self._event.is_set():
            await self._event.wait()


# Helper 함수: 환경 변수를 사용하여 요청 큐 워커를 가져오는 함수
def get_redis_queue_worker_using_env(
    env_name_redis_url: str,
    item_class: Type[T],
    item_processor: Awaitable[None] | None = None,
) -> AsyncRedisQueueWorker[T]:
    redis_url = os.getenv(env_name_redis_url)
    if not redis_url:
        raise ValueError(f"{env_name_redis_url} 환경 변수가 설정되어 있지 않습니다.")

    # 요청 큐 설정
    redis_queue = AsyncRedisQueueWorker[item_class](
        redis_url=redis_url,
        item_class=item_class,
        item_processor=item_processor,  # 작업 처리 함수는 별도로 지정하지 않음
    )
    return redis_queue
