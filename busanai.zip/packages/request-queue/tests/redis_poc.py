import json
import time

import redis

redis_client = redis.from_url("redis://localhost:6379/0", decode_responses=True)


def enqueue_task(user_id, task):
    """
    특정 사용자의 작업을 큐에 추가합니다.
    """
    task_data = {
        "task_id": task.get("task_id"),
        "task": task.get("task"),
    }
    redis_client.rpush(
        f"ready_tasks:{user_id}", json.dumps(task_data, ensure_ascii=False)
    )
    # 사용자가 작업을 준비할 수 있도록 ready_users 목록에 추가합니다.
    redis_client.sadd("ready_users", user_id)


def process_tasks(user_id):
    """
    사용자의 작업을 처리합니다.
    """
    task_json = redis_client.lpop(f"ready_tasks:{user_id}")
    if not task_json:
        # 사용자의 작업이 없으면 None을 반환합니다.
        return None

    # 사용자가 ready_users 목록에 있다면, 해당 사용자를 processing_users 목록으로 이동합니다.
    # 이는 사용자가 작업을 처리 중임을 나타냅니다.
    # 만약 사용자가 ready_users 목록에 없다면, 이미 작업을 처리 중인 상태이므로
    # 이 부분은 무시됩니다.
    if redis_client.sismember("ready_users", user_id):
        redis_client.srem("ready_users", user_id)
        redis_client.sadd("processing_users", user_id)

    task_data = json.loads(task_json)
    task_id = task_data.get("task_id")

    # 작업을 처리 중인 상태로 변경합니다.
    # 이는 사용자가 작업을 처리 중임을 나타냅니다.
    # 작업 ID를 키로 사용하여 Redis 해시에 저장합니다.
    redis_client.hset(f"processing_task:{user_id}", task_id, task_json)

    return task_data


def complete_task(user_id, task_id):
    """
    특정 사용자의 작업을 완료하고, 해당 작업을 처리 중인 상태에서 제거합니다.
    """

    # 사용자가 작업을 완료하면, processing_task 해시에서 해당 작업을 제거합니다.
    # 작업이 완료되면 해당 사용자를 processing_users 목록에서 제거합니다.
    redis_client.hdel(f"processing_task:{user_id}", task_id)
    if redis_client.hlen(f"processing_task:{user_id}") == 0:
        redis_client.srem("processing_users", user_id)
    else:
        # 작업이 남아있다면 처리 중인 사용자 목록에서 제거하지 않습니다.
        pass

    # 작업이 완료된 후, 사용자의 ready_tasks 목록에 작업이 남아있다면
    # 해당 사용자를 ready_users 목록에 추가합니다.
    # 이는 사용자가 여전히 작업을 수행할 준비가 되어 있음을 나타냅니다
    if redis_client.llen(f"ready_tasks:{user_id}") > 0:
        redis_client.sadd("ready_users", user_id)


def test_case_1():
    """
    테스트 케이스 1: 작업을 큐에 추가하고 처리하는 시나리오
    """
    user_id = "user123"
    task = {"task_id": "task1", "task": "뭔가 중요한 일"}

    enqueue_task(user_id, task)
    print(f"작업을 큐에 추가했습니다 {user_id}: {task}")

    time.sleep(10)  # Simulate some processing time
    processed_task = process_tasks(user_id)
    if processed_task:
        print(f"작업을 처리 중입니다 {user_id}: {processed_task}")
    else:
        print(f"사용자 {user_id}의 작업이 없습니다.")

    time.sleep(10)  # Simulate some processing time
    complete_task(user_id, task["task_id"])
    print(f"작업을 완료했습니다 {user_id}: {task['task_id']}")


def test_case_2():
    """
    테스트 케이스 2: 여러 작업이 큐에 추가되고 처리되는 시나리오
    """
    user_id = "user456"
    tasks = [
        {"task_id": "task2", "task": "첫 번째 작업"},
        {"task_id": "task3", "task": "두 번째 작업"},
    ]

    for task in tasks:
        enqueue_task(user_id, task)
        print(f"작업을 큐에 추가했습니다 {user_id}: {task}")

    time.sleep(10)  # Simulate some processing time

    # 1개만 진행
    task = process_tasks(user_id)
    if task:
        print(f"작업을 처리 중입니다 {user_id}: {task}")
    else:
        print(f"사용자 {user_id}의 작업이 없습니다.")

    time.sleep(10)  # Simulate some processing time

    complete_task(user_id, task["task_id"])
    print(f"작업을 완료했습니다 {user_id}: {task['task_id']}")

    time.sleep(10)  # Simulate some processing time
    # 남은 작업 처리
    task = process_tasks(user_id)
    if task:
        print(f"남은 작업을 처리 중입니다 {user_id}: {task}")
    else:
        print(f"사용자 {user_id}의 작업이 없습니다.")

    time.sleep(10)  # Simulate some processing time
    complete_task(user_id, task["task_id"])
    print(f"남은 작업을 완료했습니다 {user_id}: {task['task_id']}")


def test_case_3():
    """
    테스트 케이스 3: 여러 사용자가 작업을 큐에 추가하고 처리하는 시나리오
    """

    user_ids = ["user789", "user1011"]
    tasks = [
        {"task_id": "task4", "task": "사용자 789의 작업"},
        {"task_id": "task5", "task": "사용자 1011의 작업"},
    ]

    for user_id, task in zip(user_ids, tasks):
        enqueue_task(user_id, task)
        print(f"작업을 큐에 추가했습니다 {user_id}: {task}")

    time.sleep(10)  # Simulate some processing time

    for user_id in user_ids:
        task = process_tasks(user_id)
        if task:
            print(f"작업을 처리 중입니다 {user_id}: {task}")
            time.sleep(10)
            complete_task(user_id, task["task_id"])
            print(f"작업을 완료했습니다 {user_id}: {task['task_id']}")
        else:
            print(f"사용자 {user_id}의 작업이 없습니다.")


if __name__ == "__main__":
    test_case_1()
    # test_case_2()
    # test_case_3()
