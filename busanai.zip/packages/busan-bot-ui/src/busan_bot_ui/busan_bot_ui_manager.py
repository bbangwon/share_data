import logging
import os
import re
from typing import Any, List
from urllib.parse import urlparse

import httpx
from naver_works_bot import (
    AuthConfig,
    AuthManager,
    BotMessageManager,
    BotMetaInfo,
    ButtonTemplateContent,
    DownloadFileInfo,
    MessageAction,
    QuickReply,
    QuickReplyItem,
    TextContent,
    UriAction,
)
from naver_works_bot.bot.schemas import BotInfo, BotUpdateInfo
from naver_works_bot.bot.schemas.content import Content
from naver_works_bot.bot.schemas.contents.base import ContentBase

from .schemas import Button, ButtonCarousel, ButtonContainer, UriActionData
from .schemas.config import BusanBotUIConfig, StaticMessageInfo
from .static_messages import StaticMessageType

logger = logging.getLogger(__name__)

LOG_DB_COLLECTION = "logs"
ADMIN_LOG_DB_COLLECTION = "admin-logs"
ERROR_LOG_DB_COLLECTION = "error-logs"
FILE_PROC_LOG_DB_COLLECTION = "file-proc-logs"


class BusanBotUIManager:
    def __init__(
        self,
        config_path: str = None,
        static_messages_path: str = None,
    ):
        if not config_path:
            config_path = os.getenv("NAVER_BOT_CONFIG_PATH")
        if not config_path:
            raise ValueError("NAVER_BOT_CONFIG_PATH 환경 변수가 설정되지 않았습니다.")

        if not static_messages_path:
            static_messages_path = os.getenv("NAVER_BOT_STATIC_MESSAGES_PATH")
        if not static_messages_path:
            raise ValueError(
                "NAVER_BOT_STATIC_MESSAGES_PATH 환경 변수가 설정되지 않았습니다."
            )

        self.config: BusanBotUIConfig = BusanBotUIConfig.load_config(config_path)
        self.static_messages: StaticMessageInfo = StaticMessageInfo.load_config(
            static_messages_path
        )

        private_key = None
        if self.config.service.service_key_path:
            if not os.path.exists(self.config.service.service_key_path):
                raise FileNotFoundError(
                    f"서비스 키 파일이 존재하지 않습니다: {self.config.service.service_key_path}"
                )
            if not os.path.isfile(self.config.service.service_key_path):
                raise ValueError(
                    f"지정된 서비스 키 경로가 파일이 아닙니다: {self.config.service.service_key_path}"
                )
            with open(self.config.service.service_key_path, "r") as f:
                private_key = f.read()

        auth_manager = None
        if self.config.service.auth_base_url is not None:
            auth_manager = AuthManager(
                config=AuthConfig(
                    client_id=self.config.service.service_client_id,
                    client_secret=self.config.service.service_client_secret,
                    private_key=private_key,
                    account=self.config.service.service_account,
                    base_url=self.config.service.auth_base_url,
                )
            )

        self.bot_manager: BotMessageManager = BotMessageManager(
            auth_manager=auth_manager,
            naver_api_base_url=self.config.service.api_base_url,
            download_save_path=self.config.service.download_save_path,
            bot_meta_infos=self.config.service.bots,
        )

        btn_label = self.get_typed_text(
            type=StaticMessageType.TXT_BUTTON_LABEL_REVIEW_START_SERVICE.value
        )

        self.review_start_service = QuickReply.from_items(
            items=[
                QuickReplyItem(
                    action=MessageAction(
                        label=btn_label,
                        text=btn_label,
                        postback="start_service",
                    )
                )
            ]
        )

    async def send_content_message(
        self,
        bot_id: str,
        user_id: str,
        content: ContentBase,
        review_start_service: bool = True,
    ):
        """콘텐츠 메시지를 사용자에게 전송합니다."""

        if review_start_service:
            content.quick_reply = self.review_start_service

        await self.bot_manager.send_message(
            bot_id=bot_id, user_id=user_id, content=content
        )

    async def send_text_message(
        self, bot_id: str, user_id: str, text: str, review_start_service: bool = True
    ):
        """텍스트 메시지를 사용자에게 전송합니다."""
        await self.send_content_message(
            bot_id=bot_id,
            user_id=user_id,
            content=TextContent.from_text(text=text),
            review_start_service=review_start_service,
        )

    async def send_typed_text_message(
        self,
        bot_id: str,
        user_id: str,
        type: str,
        params: dict = None,
        review_start_service: bool = True,
    ):
        """타입에 맞는 텍스트 메시지를 사용자에게 전송합니다."""
        text = self.get_typed_text(type=type, params=params)
        await self.send_text_message(
            bot_id=bot_id,
            user_id=user_id,
            text=text,
            review_start_service=review_start_service,
        )

    async def _send_error_message_to_admins(
        self,
        user_id: str,
        task_id: str,
        error_message: str,
        viewer_name: str = "log-viewer",
    ):
        """에러 메시지를 관리자에게 전송합니다."""
        # 에러 Role을 가진 봇이 관리자에게 이 에러 메시지를 전달함
        # 일단 오류 전달 봇이 있는지 확인
        logger.info("에러메시지를 관리자에게 전송합니다.: %s", error_message)

        final_error_message = (
            f"[{user_id}]님이 봇과의 대화 중 오류가 발생했습니다.\n\n{error_message}"
        )

        if task_id:
            if self.config.log_was.viewer_url:
                final_error_message += (
                    f"\n\n로그 확인 : {self.config.log_was.viewer_url}?task={task_id}"
                )
                if viewer_name == "file-log-viewer":
                    final_error_message += "&type=file"
            else:
                final_error_message += f"\n\n(작업ID: {task_id})"

        bot_metas = [
            self.get_bot_meta_info(bot_id=bot_id)
            for bot_id in self.bot_manager.get_all_bot_ids()
        ]

        # 에러 전달 봇 찾기
        error_bot = next((bot for bot in bot_metas if bot.role == "error"), None)

        try:
            if error_bot:
                logger.debug(
                    f"에러 메시지 전달용 봇({error_bot.id})이 있습니다. 관리자에게 에러 메시지를 전달합니다."
                )
                # 봇의 관리자들 정보 가져오기
                bot_administrators = []
                error_bot_info = await self.bot_manager.get_bot_info(
                    bot_id=error_bot.id
                )
                bot_administrators.extend(error_bot_info.administrators)
                if error_bot_info.subadministrators:
                    bot_administrators.extend(error_bot_info.subadministrators)
                bot_administrators = list(set(bot_administrators))  # 중복 제거

                if bot_administrators:
                    logger.debug(
                        f"에러 메시지 전달용 봇({error_bot.id})의 관리자: {bot_administrators}"
                    )

                    # 전송
                    for admin_id in bot_administrators:
                        await self.send_content_message(
                            bot_id=error_bot.id,
                            user_id=admin_id,
                            content=TextContent.from_text(text=final_error_message),
                            review_start_service=False,
                        )
        except Exception as e:
            logger.error(f"관리자에게 에러 메시지 전송 중 오류 발생: {e}.")

    async def send_error_message(
        self,
        bot_id: str,
        user_id: str,
        error_message: str,
        task_id: str = None,
        send_with_admin=True,
        only_send_to_admin=False,
        viewer_name: str = "log-viewer",
    ):
        """에러 메시지를 사용자에게 전송합니다."""
        # 에러 Role을 가진 봇이 관리자에게 이 에러 메시지를 전달함
        # 일단 오류 전달 봇이 있는지 확인
        logger.info("에러메시지를 사용자/관리자에게 전송합니다.: %s", error_message)

        if send_with_admin:
            await self._send_error_message_to_admins(
                user_id=user_id,
                task_id=task_id,
                error_message=error_message,
                viewer_name=viewer_name,
            )
            if only_send_to_admin:  # 관리자에게만 전송하게 한다면..
                return

        await self.send_content_message(
            bot_id=bot_id,
            user_id=user_id,
            content=TextContent.from_text(text=error_message),
        )

    def get_typed_text(self, type: str, params: dict = None) -> str:
        return self.static_messages.get_message(type=type, params=params)

    async def send_typed_error_message(
        self,
        bot_id: str,
        user_id: str,
        type: str,
        params: dict = None,
        task_id: str = None,
        send_with_admin=True,
        only_send_to_admin=False,
        viewer_name: str = "log-viewer",
    ):
        text = self.get_typed_text(type, params)
        await self.send_error_message(
            bot_id=bot_id,
            user_id=user_id,
            error_message=text,
            task_id=task_id,
            send_with_admin=send_with_admin,
            only_send_to_admin=only_send_to_admin,
            viewer_name=viewer_name,
        )

    def _get_button_data_content(self, text: str, label: str, uri: str):
        """버튼 데이터 콘텐츠 생성"""
        return Button.from_data(
            Button.Data(
                button_data=ButtonContainer.Data(
                    text=text,  # 버튼 컨테이너 텍스트
                    color=self.config.flex_style.main_color,  # 버튼 배경색
                    text_color=self.config.flex_style.button_text_color,  # 버튼 텍스트 색상
                    action_data=UriActionData(  # 버튼 클릭 시 동작
                        uri=uri,
                        label=label,
                    ),
                )
            )
        )

    async def send_wait_message(
        self, bot_id: str, user_id: str, uri: str, text: str = None
    ):
        """대기 메시지를 사용자에게 전송합니다."""
        if text is None:  # 기본 대기 메시지 사용
            text = self.get_typed_text(
                type=StaticMessageType.TXT_WAIT_MESSAGE.value,  # 기본 메시지
            )

        btn_label = self.get_typed_text(
            type=StaticMessageType.TXT_BUTTON_LABEL_WAIT_MESSAGE.value
        )

        content = self._get_button_data_content(text=text, label=btn_label, uri=uri)
        await self.send_content_message(
            bot_id=bot_id,
            user_id=user_id,
            content=content,
            review_start_service=False,
        )

    def get_bot_answer_message_content(
        self, bot_message: str, uri: str
    ) -> ButtonTemplateContent | TextContent:
        """봇 답변 메시지 콘텐츠 생성"""

        split_length = self.config.service.bot_message_split_length

        if len(bot_message) > split_length:
            cut_index = split_length
            # URL 패턴: http:// 또는 https:// 로 시작하고 공백이 아닌 문자가 반복됨
            url_pattern = re.compile(r"https?://[^\s]+")

            # 잘리는 위치가 URL 중간에 있는지 확인
            for match in url_pattern.finditer(bot_message):
                if match.start() < split_length < match.end():
                    cut_index = match.end()
                    break

            bot_message = bot_message[:cut_index] + " ..."

            btn_label = self.get_typed_text(
                type=StaticMessageType.TXT_BUTTON_LABEL_VIEW_MORE.value
            )

            return ButtonTemplateContent(
                content_text=bot_message,
                actions=[
                    UriAction(
                        label=btn_label,
                        uri=uri,
                    )
                ],
            )
        else:
            return TextContent.from_text(text=bot_message)

    async def send_bot_answer_message(
        self, bot_id: str, user_id: str, bot_message: str, uri: str
    ):
        """봇 답변을 사용자에게 전송합니다."""

        content = self.get_bot_answer_message_content(bot_message, uri)
        await self.send_content_message(
            bot_id=bot_id,
            user_id=user_id,
            content=content,
        )

    def get_file_download_button_ui_message_content(self, url_chunk: list[str]):
        """일단 파일 다운로드 UI 메시지 콘텐츠 생성"""

        btn_label = self.get_typed_text(
            type=StaticMessageType.TXT_BUTTON_LABEL_DOWNLOAD.value
        )

        # [(url, file_name), ...]
        url_infos = [(url, os.path.basename(urlparse(url).path)) for url in url_chunk]

        return ButtonCarousel.from_data(
            data=ButtonCarousel.Data(
                button_datas=[
                    ButtonContainer.Data(
                        text=file_name,
                        text_color=self.config.flex_style.button_text_color,
                        color=self.config.flex_style.main_color,
                        action_data=UriActionData(
                            uri=url,
                            label=btn_label,
                        ),
                    )
                    for url, file_name in url_infos
                ]
            )
        )

    def get_contents_files_download_button_ui_message(
        self, urls: list[str]
    ) -> List[ContentBase]:
        results = []

        url_chunks = [urls[i : i + 10] for i in range(0, len(urls), 10)]  # 10개씩 분할

        for url_chunk in url_chunks:
            results.append(self.get_file_download_button_ui_message_content(url_chunk))

        return results

    async def send_files_download_button_ui_message(
        self, bot_id: str, user_id: str, urls: list[str]
    ):
        """
        일단 파일 다운로드 UI 메시지 전송
        다운로드 버튼을 버튼 캐러셀 형태로 전송
        """
        contents = self.get_contents_files_download_button_ui_message(urls)
        for content in contents:
            await self.send_content_message(
                bot_id=bot_id, user_id=user_id, content=content
            )

    def get_url_with_filepath_vdb_meta(self, file_path: str) -> str:
        """
        VDB 메타 -> 파일 다운로드 URL 생성
        file_path: 실제 파일 경로 ex) /data/uploads/20251117/sample.pdf
        file_download.base_url과 결합 remove_prefix_path를 제거한 후 결합
        20251117/sample.pdf
        """
        _temp_uri = file_path.replace(self.config.file_download.remove_prefix_path, "")
        uri = f"{self.config.file_download.base_url}{_temp_uri}"
        return uri

    async def send_file_download_button_ui_message_with_filepaths_vdb_meta(
        self, bot_id: str, user_id: str, file_paths: list[str]
    ):
        """
        VDB 메타 -> 파일 다운로드 UI 메시지 전송(추후에 UI Color 등 개선 필요해 보임)
        file_paths: 실제 파일 경로 ex) /data/uploads/20251117/sample.pdf의 리스트
        file_download.base_url과 결합 remove_prefix_path를 제거한 후 결합
        20251117/sample.pdf
        """

        await self.send_files_download_button_ui_message(
            bot_id=bot_id,
            user_id=user_id,
            urls=[
                self.get_url_with_filepath_vdb_meta(file_path)
                for file_path in file_paths
            ],
        )

    async def get_download_url(
        self, bot_id: str, file_id: str
    ) -> DownloadFileInfo | None:
        return await self.bot_manager.get_download_url(bot_id=bot_id, file_id=file_id)

    async def download_and_save_file(
        self, download_file_info: DownloadFileInfo, overwrite: bool = False
    ) -> str:
        return await self.bot_manager.download_and_save_file(
            download_file_info, overwrite=overwrite
        )

    def clean_up_downloaded_file(self, download_file_info: DownloadFileInfo):
        return self.bot_manager.clean_up_downloaded_file(download_file_info)

    def verify_signature(self, bot_id: str, signature: str, body: bytes) -> bool:
        if self.config.service.use_verify_signature is False:
            logger.debug("서명 검증이 비활성화되어 있습니다. 항상 True를 반환합니다.")
            return True

        return self.bot_manager.verify_signature(
            bot_id=bot_id, signature=signature, body=body
        )

    async def send_message(self, bot_id: str, user_id: str, content: Content) -> dict:
        return await self.bot_manager.send_message(
            bot_id=bot_id, user_id=user_id, content=content
        )

    async def update_bot(self, bot_id: str, bot_update_info: BotUpdateInfo) -> bool:
        return await self.bot_manager.update_bot(
            bot_id=bot_id, bot_update_info=bot_update_info
        )

    def get_bot_meta_info(self, bot_id: str) -> BotMetaInfo | None:
        return self.bot_manager.get_bot_meta_info(bot_id=bot_id)

    async def get_bot_info(self, bot_id: str) -> BotInfo:
        return await self.bot_manager.get_bot_info(bot_id=bot_id)

    def get_all_bot_ids(self) -> List[str]:
        return self.bot_manager.get_all_bot_ids()

    async def regist_bot_member(
        self, bot_id: str, domain_id: str, user_id: str
    ) -> bool:
        return await self.bot_manager.regist_bot_member(
            bot_id=bot_id, domain_id=domain_id, user_id=user_id
        )

    async def clear_bot_members(self, bot_id: str, domain_id: str) -> bool:
        return await self.bot_manager.clear_bot_members(
            bot_id=bot_id, domain_id=domain_id
        )

    async def write_log(
        self,
        task_id: str,
        user_id: str,
        bot_id: str,
        log: Any,
        collection: str = LOG_DB_COLLECTION,
    ):
        if not self.config.log_was.write_url:
            return

        log_url = f"{self.config.log_was.write_url}/collections/{collection}/tasks/{task_id}/bots/{bot_id}/users/{user_id}"

        if not isinstance(log, dict):
            try:
                log = {"log": str(log)}
            except Exception:
                try:
                    log = {"log": repr(log)}
                except Exception:
                    log = {"log": f"[str, repr 변환 실패] {type(log)}"}

        try:
            async with httpx.AsyncClient() as client:  # 기본 타임아웃은 5초
                result = await client.post(
                    log_url,
                    json=log,
                )
                result.raise_for_status()
        except httpx.TimeoutException as e:
            logger.warning(f"[write_log] 로그 서버 연결 타임아웃: {log_url} {e}")
        except httpx.HTTPStatusError as e:
            logger.error(
                f"[write_log] 로그 서버 요청 실패: {log_url}, 상태 코드: {e.response.status_code}, 내용: {e.response.text}"
            )
        except Exception as e:
            logger.error(
                f"[write_log] 로그 서버 요청 실패: {log_url}, 오류: {type(e)}, {e}"
            )

    async def write_admin_log(self, task_id: str, user_id: str, bot_id: str, log: Any):
        await self.write_log(
            task_id=task_id,
            user_id=user_id,
            bot_id=bot_id,
            log=log,
            collection=ADMIN_LOG_DB_COLLECTION,
        )

    async def write_error_log(self, task_id: str, user_id: str, bot_id: str, log: Any):
        await self.write_log(
            task_id=task_id,
            user_id=user_id,
            bot_id=bot_id,
            log=log,
            collection=ERROR_LOG_DB_COLLECTION,
        )

    async def write_file_proc_log(
        self, task_id: str, user_id: str, bot_id: str, log: Any
    ):
        await self.write_log(
            task_id=task_id,
            user_id=user_id,
            bot_id=bot_id,
            log=log,
            collection=FILE_PROC_LOG_DB_COLLECTION,
        )
