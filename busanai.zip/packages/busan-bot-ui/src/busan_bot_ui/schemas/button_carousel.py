from naver_works_bot import (
    FlexibleCarouselContainer,
    FlexibleContent,
)
from pydantic import BaseModel

from .containers import ButtonContainer


class ButtonCarousel(FlexibleContent):
    # 데이터 클래스
    class Data(BaseModel):
        alt_text: str = "새로운 메시지가 도착했습니다."
        button_datas: list[ButtonContainer.Data]

    alt_text: str = "새로운 메시지가 도착했습니다."
    contents: FlexibleCarouselContainer

    @classmethod
    def from_data(cls, data: Data) -> "ButtonCarousel":
        return cls(
            alt_text=data.alt_text,
            contents=FlexibleCarouselContainer(
                contents=[
                    ButtonContainer.from_data(button_data)
                    for button_data in data.button_datas
                ]
            ),
        )
