from typing import List

import yaml
from naver_works_bot import BotMetaInfo
from pydantic import BaseModel, Field


class FlexStyleConfig(BaseModel):
    main_color: str = Field("#E6007E", alias="mainColor")
    button_text_color: str = Field("#FFFFFF", alias="buttonTextColor")


class NaverWorksBotConfig(BaseModel):
    api_base_url: str = Field(None, alias="apiBaseUrl")
    auth_base_url: str | None = Field(None, alias="authBaseUrl")
    use_verify_signature: bool = Field(True, alias="useVerifySignature")
    download_save_path: str = Field(None, alias="downloadSavePath")
    service_account: str = Field(None, alias="serviceAccount")
    service_client_id: str = Field(None, alias="serviceClientId")
    service_client_secret: str = Field(None, alias="serviceClientSecret")
    service_key_path: str = Field(None, alias="serviceKeyPath")
    bot_message_split_length: int = Field(1800, alias="botMessageSplitLength")

    bots: List[BotMetaInfo] = Field([], alias="bots")


class LogWasConfig(BaseModel):
    write_url: str = Field(
        None, alias="writeUrl"
    )  # 로그 작성용 URL (예: http://log-was.example.com/write-log)
    viewer_url: str = Field(
        None, alias="viewerUrl"
    )  # 로그 뷰어 URL (예: http://log-was.example.com/log-viewer)


class FileDownloadConfig(BaseModel):
    base_url: str = Field(..., alias="baseUrl")  # 파일 다운로드 기본 URL
    remove_prefix_path: str = Field(
        ..., alias="removePrefixPath"
    )  # 파일 경로에서 제거할 접두사 경로


class BusanBotUIConfig(BaseModel):
    service: NaverWorksBotConfig = Field(..., alias="service")
    file_download: FileDownloadConfig = Field(..., alias="fileDownload")
    log_was: LogWasConfig = Field(..., alias="logWas")
    flex_style: FlexStyleConfig = Field(..., alias="flexStyle")

    @classmethod
    def load_config(cls, yaml_path: str):
        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            config = cls(**data)
            return config


if __name__ == "__main__":
    config = BusanBotUIConfig.load_config("./config/config.yaml")
    print(config)
