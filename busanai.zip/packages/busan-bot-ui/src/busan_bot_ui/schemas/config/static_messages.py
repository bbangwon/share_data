from typing import Dict, List

import yaml
from pydantic import BaseModel, Field


class StaticMessage(BaseModel):
    message: str = Field(..., alias="message")
    description: str | None = Field(None, alias="description")
    parameters: List[str] | None = Field(None, alias="parameters")

    def get_message(self, params: dict[str, str] | None = None) -> str:
        """정적 메시지를 반환합니다."""
        return self.message.format(**(params or {})) if params else self.message


class StaticMessageInfo(BaseModel):
    parameters: Dict[str, str] = Field(..., alias="parameters")  # 공통 파라미터
    messages: Dict[str, StaticMessage] = Field(..., alias="messages")

    def get_message(self, type: str, params: dict[str, str] | None = None):
        """정적 메시지를 가져옵니다."""

        if type not in self.messages:
            raise ValueError(f"정적 메시지 가져오기 오류. 알 수 없는 타입: {type}")

        params = {**(self.parameters or {}), **(params or {})}

        for p in self.messages[type].parameters or []:
            if p not in params:
                raise ValueError(f"필수 파라미터 '{p}'가 제공되지 않았습니다.")

        return self.messages[type].get_message(params)

    def load_config(yaml_path: str):
        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            return StaticMessageInfo(**data)


if __name__ == "__main__":
    config = StaticMessageInfo.load_config("./config/static-messages.yaml")
    print(config)
