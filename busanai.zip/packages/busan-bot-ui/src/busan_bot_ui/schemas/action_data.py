from typing import Annotated, Union

from pydantic import Field

from .action_datas import (
    MessageActionData,
    PostbackActionData,
    UriActionData,
)

# Action이 늘어날때마다 여기에 추가
ActionData = Annotated[
    Union[PostbackActionData, UriActionData, MessageActionData],
    Field(discriminator="type"),
]
