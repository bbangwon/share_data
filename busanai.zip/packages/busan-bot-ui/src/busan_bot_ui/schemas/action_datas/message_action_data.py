from typing import Literal

from naver_works_bot import MessageAction

from .base import ActionDataBase


class MessageActionData(ActionDataBase):
    type: Literal["message"] = "message"
    label: str
    text: str
    postback: str | None = None

    def to_action(self) -> MessageAction:
        """MessageAction 객체로 변환합니다."""
        return MessageAction(
            label=self.label,
            text=self.text,
            postback=self.postback,
        )
