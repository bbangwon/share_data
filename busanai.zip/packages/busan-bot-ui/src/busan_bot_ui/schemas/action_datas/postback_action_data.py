from typing import Literal

from naver_works_bot import PostbackAction

from .base import ActionDataBase


class PostbackActionData(ActionDataBase):
    type: Literal["postback"] = "postback"
    label: str
    data: str
    display_text: str | None = None

    def to_action(self) -> PostbackAction:
        """PostbackAction 객체로 변환합니다."""
        return PostbackAction(
            label=self.label,
            data=self.data,
            display_text=self.display_text,
        )
