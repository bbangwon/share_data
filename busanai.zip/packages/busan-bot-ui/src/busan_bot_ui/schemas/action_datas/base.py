from abc import ABC, abstractmethod

from pydantic import BaseModel


class ActionDataBase(BaseModel, ABC):
    type: str

    @abstractmethod
    def to_action(self):
        """Convert to a specific action type."""
        pass
