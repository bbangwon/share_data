from typing import Literal

from naver_works_bot import UriAction

from .base import ActionDataBase


class UriActionData(ActionDataBase):
    type: Literal["uri"] = "uri"
    label: str
    uri: str

    def to_action(self) -> UriAction:
        """UriAction 객체로 변환합니다."""
        return UriAction(
            label=self.label,
            uri=self.uri,
        )
