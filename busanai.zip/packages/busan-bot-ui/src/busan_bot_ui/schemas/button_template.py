from naver_works_bot import (
    FlexibleBoxComponent,
    FlexibleBubbleContainer,
    FlexibleButtonComponent,
    FlexibleContent,
    FlexibleSeparatorComponent,
)
from pydantic import BaseModel

from .action_data import ActionData


class ButtonTemplate(FlexibleContent):
    class Data(BaseModel):
        alt_text: str = "새로운 메시지가 도착했습니다."
        color: str
        action_datas: list[ActionData]

    alt_text: str = "새로운 메시지가 도착했습니다."
    contents: FlexibleBubbleContainer

    @classmethod
    def from_data(cls, data: Data) -> "ButtonTemplate":
        c = cls(
            alt_text=data.alt_text,
            contents=FlexibleBubbleContainer(
                size="kilo",
                body=FlexibleBoxComponent(
                    layout="vertical",
                    contents=[
                        item
                        for btn in data.action_datas
                        for item in [
                            FlexibleSeparatorComponent(),
                            FlexibleButtonComponent(
                                action=btn.to_action(),
                                height="sm",
                                color=data.color,
                            ),
                        ]
                    ],
                ),
            ),
        )

        # 마지막 구분선 추가
        c.contents.body.contents.append(FlexibleSeparatorComponent())

        return c
