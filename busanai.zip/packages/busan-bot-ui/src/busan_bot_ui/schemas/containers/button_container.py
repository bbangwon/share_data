from naver_works_bot import (
    FlexibleBoxComponent,
    FlexibleBubbleContainer,
    FlexibleButtonComponent,
    FlexibleTextComponent,
)
from pydantic import BaseModel

from ..action_data import ActionData


class ButtonContainer(FlexibleBubbleContainer):
    class Data(BaseModel):
        color: str
        text_color: str = "#FFFFFF"
        text: str
        action_data: ActionData

    size: str = "kilo"
    body: FlexibleBoxComponent
    footer: FlexibleBoxComponent

    @classmethod
    def from_data(cls, data: Data) -> "ButtonContainer":
        return cls(
            body=FlexibleBoxComponent(
                layout="vertical",
                contents=[
                    FlexibleTextComponent(
                        text=data.text, wrap=True, size="sm", color="#000000"
                    ),
                ],
            ),
            footer=FlexibleBoxComponent(
                layout="vertical",
                contents=[
                    FlexibleBoxComponent(
                        layout="horizontal",
                        contents=[
                            FlexibleButtonComponent(
                                action=data.action_data.to_action(),
                                color=data.text_color,
                                height="sm",
                            )
                        ],
                        background_color=data.color,
                        corner_radius="10px",
                    ),
                ],
            ),
        )
