from naver_works_bot import (
    FlexibleContent,
)
from pydantic import BaseModel

from .containers import ButtonContainer


class Button(FlexibleContent):
    class Data(BaseModel):
        alt_text: str = "새로운 메시지가 도착했습니다."
        button_data: ButtonContainer.Data

    alt_text: str = "새로운 메시지가 도착했습니다."
    contents: ButtonContainer

    @classmethod
    def from_data(cls, data: Data) -> "Button":
        return cls(
            alt_text=data.alt_text,
            contents=ButtonContainer.from_data(data=data.button_data),
        )
