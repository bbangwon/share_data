from naver_works_bot import (
    FlexibleBoxComponent,
    FlexibleBubbleContainer,
    FlexibleButtonComponent,
    FlexibleCarouselContainer,
    FlexibleContent,
    FlexibleImageComponent,
    FlexibleSeparatorComponent,
    FlexibleTextComponent,
)
from pydantic import BaseModel

from .action_data import ActionData


class MainCarousel(FlexibleContent):
    # 데이터 클래스
    class Data(BaseModel):
        class Column(BaseModel):
            color: str
            image_url: str
            text: str
            action_datas: list[ActionData]

        alt_text: str = "새로운 메시지가 도착했습니다."
        columns: list[Column]

    alt_text: str = "새로운 메시지가 도착했습니다."
    contents: FlexibleCarouselContainer

    @classmethod
    def from_data(cls, data: Data) -> "MainCarousel":
        contents = [
            FlexibleBubbleContainer(
                size="kilo",
                hero=FlexibleImageComponent(
                    url=column.image_url,
                    aspect_mode="cover",
                    size="full",
                    aspect_ratio="16:9",
                ),
                body=FlexibleBoxComponent(
                    layout="vertical",
                    contents=[
                        FlexibleTextComponent(
                            text=column.text, size="sm", wrap=True, color="#000000"
                        ),
                    ],
                ),
                footer=FlexibleBoxComponent(
                    layout="vertical",
                    contents=[
                        item
                        for btn in column.action_datas
                        for item in [
                            FlexibleSeparatorComponent(),
                            FlexibleButtonComponent(
                                action=btn.to_action(),
                                height="sm",
                                color=column.color,
                            ),
                        ]
                    ],
                ),
            )
            for column in data.columns
        ]

        # 마지막 구분선 추가
        for content in contents:
            content.footer.contents.append(FlexibleSeparatorComponent())

        return cls(
            alt_text=data.alt_text,
            contents=FlexibleCarouselContainer(contents=contents),
        )
