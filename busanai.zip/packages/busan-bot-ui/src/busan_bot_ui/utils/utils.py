from typing import Literal

import httpx

PROD_SERVICE_URL = "https://busanai.busan.go.kr"


def _get_ngrok_url():
    """ngrok URL을 가져옵니다."""

    try:
        response = httpx.get("http://localhost:4040/api/tunnels")
        if response.status_code == 200:
            tunnels = response.json().get("tunnels", [])
            if tunnels:
                return tunnels[0]["public_url"]
    except Exception as e:
        print("ngrok URL을 가져오는 중 오류가 발생했습니다:", e)
    return None


def get_service_url(env: Literal["prod", "local"]) -> str:
    """서비스 URL을 반환합니다. local 환경에서는 ngrok URL을, prod 환경에서는 실제 서비스 URL을 반환합니다."""
    if env == "local":
        ngrok_url = _get_ngrok_url()
        if ngrok_url:
            return ngrok_url
        else:
            raise ValueError("ngrok URL을 가져올 수 없습니다.")
    else:
        return PROD_SERVICE_URL
