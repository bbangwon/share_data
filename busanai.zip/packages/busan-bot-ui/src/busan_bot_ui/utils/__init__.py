from .utils import get_service_url

__all__ = ["get_service_url"]
