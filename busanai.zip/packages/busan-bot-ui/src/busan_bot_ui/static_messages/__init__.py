from .static_message_type import StaticMessageType

__all__ = [
    "StaticMessageType",
]
