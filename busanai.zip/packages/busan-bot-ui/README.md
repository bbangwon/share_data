# Busan Bot UI

네이버웍스 봇 서비스를 위한 UI 라이브러리(부산)

## 개요

`busan-bot-ui`는 네이버웍스 봇에서 사용할 수 있는 다양한 UI 컴포넌트를 제공하는 Python 라이브러리입니다. Flex Message 템플릿 기반의 버튼, 캐러셀, 컨테이너 등을 쉽게 생성하고 관리할 수 있습니다.

## 설치

```bash
pip install busan-bot-ui
```

또는 개발 환경에서:

```bash
uv add busan-bot-ui
```

## 주요 기능

### UI 컴포넌트

- **Button**: 기본 버튼 컴포넌트
- **ButtonTemplate**: 버튼 템플릿
- **ButtonCarousel**: 버튼 캐러셀
- **MainCarousel**: 메인 캐러셀
- **ButtonContainer**: 버튼 컨테이너

### 액션 데이터

- **PostbackActionData**: 포스트백 액션
- **UriActionData**: URI 액션
- **MessageActionData**: 메시지 액션

## 사용법

### 기본 사용 예제

```python
import asyncio
import logging

from busan_bot_ui import BusanBotUIManager, get_busan_bot_ui_manager_using_env

from busan_bot_ui import MainCarousel, PostbackActionData

logging.basicConfig(level="DEBUG")
logger = logging.getLogger(__name__)

if __name__ == "__main__":

    async def main():
        # 봇 매니저 생성
        bot_manager = BusanBotUIManager()

        logger.info("봇 메시지 매니저가 초기화되었습니다.")

        result = await bot_manager.send_message(
            bot_id="bot_id",
            user_id="user_id",
            content=MainCarousel.from_data(
                MainCarousel.Data(
                    columns=[
                        MainCarousel.Data.Column(
                            color="#FF5733",
                            image_url="https://example.com/image1.jpg",
                            text="첫번째 캐러셀 컬럼",
                            action_datas=[
                                PostbackActionData(
                                    label="첫번째 액션",
                                    data="action_data_1",
                                    display_text="첫번째 액션 클릭 했어요!",
                                )
                            ],
                        ),
                        MainCarousel.Data.Column(
                            color="#33FF57",
                            image_url="https://example.com/image2.jpg",
                            text="두번째 캐러셀 컬럼",
                            action_datas=[
                                PostbackActionData(
                                    label="두번째 액션",
                                    data="action_data_2",
                                    display_text="두번째 액션 클릭 했어요!",
                                )
                            ],
                        ),
                    ]
                )
            ),
        )
        logger.info("메시지 전송 완료. 결과: %s", result)

    asyncio.run(main())

```

## API 레퍼런스

### ActionData

액션 데이터는 Union 타입으로 다음 중 하나를 사용할 수 있습니다:

- `PostbackActionData`: 포스트백 액션
- `UriActionData`: URI 액션
- `MessageActionData`: AI 질문 액션

discriminator 필드인 `type`을 통해 자동으로 적절한 타입이 선택됩니다.

### 컴포넌트

#### Button

기본 버튼 컴포넌트입니다.

#### ButtonTemplate

여러 버튼을 포함하는 템플릿입니다.

#### ButtonCarousel

여러 열(column)을 가진 캐러셀 형태의 UI입니다.

#### MainCarousel

메인 화면에서 사용하는 캐러셀 컴포넌트입니다.

## 개발

### 요구사항

- Python >= 3.11
- naver-works-bot

### 개발 환경 설정

```bash
# 저장소 클론
git clone <repository-url>
cd busan-ai/packages/busan-bot-ui

# 의존성 설치
uv sync

# 예제 실행
python examples/basic_usage.py
```

## 템플릿

`naver-works-flex-template/` 디렉토리에는 네이버웍스 Flex Message 템플릿 JSON 파일들이 포함되어 있습니다:

- `button.json`: 기본 버튼 템플릿
- `button_template.json`: 버튼 템플릿
- `button_carousel.json`: 버튼 캐러셀 템플릿
- `main_carousel.json`: 메인 캐러셀 템플릿

## 라이선스

이 프로젝트는 부산시 AI 프로젝트의 일부입니다.

## 기여

버그 리포트나 기능 요청은 이슈를 통해 제출해 주세요.
