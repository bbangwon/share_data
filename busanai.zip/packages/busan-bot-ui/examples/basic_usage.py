import asyncio
import logging

from busan_bot_ui import (
    BusanBotUIManager,
    Button,
    ButtonContainer,
    MainCarousel,
    PostbackActionData,
    UriActionData,
)

logging.basicConfig(level="DEBUG")
logger = logging.getLogger(__name__)


async def send_content_message():
    bot_manager = BusanBotUIManager()

    logger.info("봇 메시지 매니저가 초기화되었습니다.")

    result = await bot_manager.send_content_message(
        bot_id="bot_id",
        user_id="user_id",
        content=MainCarousel.from_data(
            MainCarousel.Data(
                columns=[
                    MainCarousel.Data.Column(
                        color="#FF5733",
                        image_url="https://example.com/image1.jpg",
                        text="첫번째 캐러셀 컬럼",
                        action_datas=[
                            PostbackActionData(
                                label="첫번째 액션",
                                data="action_data_1",
                                display_text="첫번째 액션 클릭 했어요!",
                            )
                        ],
                    ),
                    MainCarousel.Data.Column(
                        color="#33FF57",
                        image_url="https://example.com/image2.jpg",
                        text="두번째 캐러셀 컬럼",
                        action_datas=[
                            PostbackActionData(
                                label="두번째 액션",
                                data="action_data_2",
                                display_text="두번째 액션 클릭 했어요!",
                            )
                        ],
                    ),
                ]
            )
        ),
    )
    logger.info("메시지 전송 완료. 결과: %s", result)

    result = await bot_manager.send_content_message(
        bot_id="bot_id",
        user_id="user_id",
        content=Button.from_data(
            ButtonContainer.Data(
                text="파일 다운로드",  # 버튼 컨테이너 텍스트
                color="#FF5733",  # 버튼 배경색
                text_color="#FFFFFF",  # 버튼 텍스트 색상
                action_data=UriActionData(  # 버튼 클릭 시 동작
                    uri="https://example.com/download/sample.pdf",
                    label="파일이름.pdf 다운로드",
                ),
            )
        ),
    )
    logger.info("메시지 전송 완료. 결과: %s", result)


if __name__ == "__main__":
    asyncio.run(send_content_message())
