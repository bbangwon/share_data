#!/bin/bash

alembic upgrade head --sql > ./scripts/init_table.sql