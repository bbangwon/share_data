## SQLAlchemy AsyncIO 설치

```bash
uv add sqlalchemy --extra asyncio
```

## Asyncpg 설치

```bash
uv add asyncpg
```

## DB URL 설정

```
postgresql+asyncpg://postgres:postgres@localhost:5432/postgres
```

## 설치 (개발 환경)

```bash
uv add --editable ../packages/db-manager
```

# Postgres Docker Run

- 5432 포트로 Postgres를 실행합니다.

```bash
docker run -d --name postgres \
-e POSTGRES_PASSWORD=postgres \
-e POSTGRES_USER=postgres \
-e POSTGRES_DB=postgres \
-e TZ=Asia/Seoul \
-v pgdata:/var/lib/postgresql/data \
-p 5432:5432 \
-d postgres
```

# psql 명령어

- Postgres에 접속하기 위한 psql 명령어입니다.

```bash
psql -U postgres -h localhost -p 5432 -d postgres
```

```bash
\l # 데이터베이스 목록 조회
\c <database_name> # 데이터베이스 접속
\dt # 테이블 목록 조회
\di # 인덱스 목록 조회
\dv # 뷰 목록 조회
\df # 함수 목록 조회
\du # 사용자 목록 조회
\dn # 스키마 목록 조회
\dt <table_name> # 테이블 구조 조회
\d <table_name> # 테이블 구조 조회
\q # psql 종료
```

# alembic

- init

```bash
alembic init -t async alembic
```

- 데이터베이스 마이그레이션을 위한 Alembic을 사용합니다.
- Alembic은 SQLAlchemy의 데이터베이스 마이그레이션 도구입니다.

- alembic migration 생성

```bash
alembic revision --autogenerate -m "migration message"
```

- alembic migration 적용

```bash
alembic upgrade head
```

- alembic migration 되돌리기

```bash
alembic downgrade -1
```
