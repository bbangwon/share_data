"""
DB Manager 사용 예제
"""

import asyncio

from sqlalchemy import select

from db_manager import ChatSession, DBManager
from db_manager.models.static_feedback import StaticFeedback


async def add_chat_history():
    db_url = "postgresql+asyncpg://postgres:postgres@localhost:5432/postgres"
    db_manager = DBManager(db_url)

    await db_manager.create_chat_session(
        chat_session=ChatSession(
            user_id="user123",
            bot_id="busan_bot",
        )
    )

    last_chat_session_id = await db_manager.get_last_chat_session_id(
        user_id="user123",
        bot_id="busan_bot",
    )

    chat_number = await db_manager.add_user_chat_history(
        chat_session_id=last_chat_session_id,  # 채팅 세션 ID
        message="추가로 하나 물어보겠습니다.",
    )

    await db_manager.add_bot_chat_history(
        chat_session_id=last_chat_session_id,
        chat_number=chat_number,
        message="답변하겠습니다.",
    )


async def get_chat_histories():
    db_url = "postgresql+asyncpg://postgres:postgres@localhost:5432/postgres"
    db_manager = DBManager(db_url)

    chat_histories_by_user_and_bot = (
        await db_manager.get_last_chat_histories_by_user_and_bot_id(
            user_id="user123",
            bot_id="busan_bot",
        )
    )

    print(
        f"ChatHistories(UserID/BotID) found: count={len(chat_histories_by_user_and_bot)}"
    )
    for chat_history in chat_histories_by_user_and_bot:
        print(f"ChatHistory found: {chat_history}")

    last_chat_session_id = await db_manager.get_last_chat_session_id(
        user_id="user123",
        bot_id="busan_bot",
    )

    chat_histories = await db_manager.get_chat_histories_by_session_id(
        chat_session_id=last_chat_session_id, count=2
    )

    # chat_histories = await db_manager.get_last_chat_histories_by_user_and_bot_id(
    #     user_id="user123", bot_id="busan_bot", count=2
    # )

    print(
        f"ChatHistories(ChatSessionID): session_id={last_chat_session_id}, count={len(chat_histories)}"
    )

    for chat_history in chat_histories:
        print(f"ChatHistory found: {chat_history}")


async def main():
    db_url = "postgresql+asyncpg://postgres:postgres@localhost:5432/postgres"
    db_manager = DBManager(db_url)

    async with db_manager.get_session() as session:
        stmt = select(StaticFeedback).where(StaticFeedback.from_postback == "start")
        result = await session.execute(stmt)
        start_feedback = result.scalars().first()

        if start_feedback:
            print(f"StaticFeedback found: {start_feedback}")
        else:
            print("No StaticFeedback found for 'start' postback.")

        await session.commit()


if __name__ == "__main__":
    asyncio.run(get_chat_histories())
