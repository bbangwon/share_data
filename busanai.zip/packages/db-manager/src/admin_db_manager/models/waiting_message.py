# SQLAlchemy 모델 정의
import enum

from sqlalchemy import BigInteger, Column, DateTime, Enum, String
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class ChatbotTypeEnum(str, enum.Enum):
    CREATE_DRAFT = "CREATE_DRAFT"
    EXTERNAL_ANALYSIS = "EXTERNAL_ANALYSIS"
    QNA = "QNA"


class WaitingMessage(Base):
    __tablename__ = "waiting_message"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    created_date = Column(DateTime(6), nullable=True)
    deleted_date = Column(DateTime(6), nullable=True)
    modified_date = Column(DateTime(6), nullable=True)
    chatbot_type = Column(Enum(ChatbotTypeEnum), nullable=False)
    message = Column(String(255), nullable=False)
