import logging
import os

from sqlalchemy import case, select
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from admin_db_manager.models import ChatbotTypeEnum, WaitingMessage

logger = logging.getLogger(__name__)


class AdminDBManager:
    def __init__(self, database_url):
        self.database_url = database_url
        self.new_connection()

    def new_connection(self):
        """새 데이터베이스 연결을 생성합니다."""
        self._engine = create_async_engine(
            self.database_url,
            pool_size=10,  # 동시에 유지할 수 있는 커넥션 수
            max_overflow=0,  # 풀 크기 초과 시 생성할 수 있는 추가 커넥션 수
            echo=True,
            pool_pre_ping=True,
        )
        self._session_factory = async_sessionmaker(
            bind=self._engine, class_=AsyncSession, expire_on_commit=False
        )

    def get_session(self):
        """새 데이터베이스 세션을 반환합니다."""
        return self._session_factory()

    async def get_latest_waiting_message_by_type(
        self, chatbot_type: ChatbotTypeEnum
    ) -> str:
        """
        지정한 ChatbotTypeEnum에 대해 deleted_date가 null인 최신 waiting_message의 message를 반환합니다.
        최신 기준: modified_date, created_date 내림차순
        """

        try:
            async with self.get_session() as session:
                stmt = (
                    select(WaitingMessage.message)
                    .where(
                        WaitingMessage.chatbot_type == chatbot_type,
                        WaitingMessage.deleted_date.is_(None),
                    )
                    .order_by(
                        case(
                            (WaitingMessage.modified_date.is_(None), 1), else_=0
                        ),  # nulls last(mariadb는 nulls last 지원 안함)
                        WaitingMessage.modified_date.desc(),
                        case(
                            (WaitingMessage.created_date.is_(None), 1), else_=0
                        ),  # nulls last(mariadb는 nulls last 지원 안함)
                        WaitingMessage.created_date.desc(),
                    )
                    .limit(1)
                )
                result = await session.execute(stmt)
                row = result.scalar_one_or_none()
                return row
        except Exception as e:
            logger.error(f"get_latest_waiting_message_by_type 실행 중 오류 발생: {e}")
            return None

    async def close(self):
        """데이터베이스 연결을 종료합니다."""
        if self._engine:
            await self._engine.dispose()
            logger.info("데이터베이스 연결이 종료되었습니다.")
        else:
            logger.info("데이터베이스 연결이 이미 종료되었습니다.")


# Helper 함수: AdminDBManager 인스턴스를 환경 변수에서 가져옵니다.
def get_admin_db_manager_using_env(admin_database_url: str = None) -> AdminDBManager:
    """환경 변수에서 데이터베이스 URL을 가져와 DBManager 인스턴스를 반환합니다. database_url을 직접 지정할 수 있습니다."""

    if not admin_database_url:
        env_name_database_url = "ADMIN_DATABASE_URL"

        admin_database_url = os.getenv(env_name_database_url)
        if not admin_database_url:
            raise ValueError(
                f"{env_name_database_url} 환경 변수가 설정되어 있지 않습니다."
            )

    logger.debug(
        f"AdminDBManager 인스턴스를 생성합니다. 데이터베이스 URL: {admin_database_url}"
    )
    return AdminDBManager(admin_database_url)
