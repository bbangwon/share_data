from typing import List

from sqlalchemy import (
    TEXT,
    DateTime,
    ForeignKey,
    SmallInteger,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db_manager.models.base import Base


class StaticFeedback(Base):
    __tablename__ = "TB_STATIC_FEEDBACK"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    parent_id: Mapped[int] = mapped_column(
        ForeignKey("TB_STATIC_FEEDBACK.id"), nullable=True
    )
    bot_service: Mapped[str] = mapped_column(String(50), index=True, nullable=True)
    message_type: Mapped[str] = mapped_column(String(20))
    sort_number: Mapped[int] = mapped_column(SmallInteger)
    content: Mapped[str] = mapped_column(TEXT, nullable=True, default=None)
    from_postback: Mapped[str] = mapped_column(
        String(20), index=True, nullable=True, default=None
    )
    to_postback: Mapped[str] = mapped_column(
        String(20), index=True, nullable=True, default=None
    )
    created_at: Mapped[DateTime] = mapped_column(DateTime, default=func.now())

    children: Mapped[List["StaticFeedback"]] = relationship(
        back_populates="parent",
        cascade="all, delete-orphan",
        order_by="StaticFeedback.sort_number, StaticFeedback.id",
    )

    parent: Mapped["StaticFeedback"] = relationship(
        back_populates="children",
        remote_side=[id],
        uselist=False,
    )

    def __repr__(self):
        return (
            f"<StaticFeedback(id={self.id}, from_postback={self.from_postback}, "
            f"message_type={self.message_type}, sort_number={self.sort_number}, "
            f"content={self.content}, created_at={self.created_at})>"
        )
