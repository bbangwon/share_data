from sqlalchemy import (
    TEXT,
    DateTime,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from db_manager.models.base import Base


class Setting(Base):
    __tablename__ = "TB_SETTING"

    key: Mapped[str] = mapped_column(String(50), primary_key=True)
    value: Mapped[str] = mapped_column(TEXT, nullable=True, default=None)
    created_at: Mapped[DateTime] = mapped_column(DateTime, default=func.now())

    def __repr__(self):
        return f"<Setting(key={self.key}, value={self.value}, created_at={self.created_at})>"
