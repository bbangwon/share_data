from typing import List

from sqlalchemy import (
    TEXT,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db_manager.models.base import Base


class ChatSession(Base):
    __tablename__ = "TB_CHAT_SESSION"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(String(50))
    bot_id: Mapped[str] = mapped_column(String(50))
    created_at: Mapped[DateTime] = mapped_column(DateTime, default=func.now())

    chat_history: Mapped[List["ChatHistory"]] = relationship(
        back_populates="chat_session",
        cascade="all, delete-orphan",
    )

    chat_summaries: Mapped[List["ChatSummary"]] = relationship(
        back_populates="chat_session",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        Index("IDX_USER_BOT", "user_id", "bot_id", "created_at", unique=True),
    )

    def __repr__(self):
        return (
            f"<ChatSession(id={self.id}, user_id={self.user_id}, "
            f"bot_id={self.bot_id}, created_at={self.created_at})>"
        )


class ChatHistory(Base):
    __tablename__ = "TB_CHAT_HISTORY"

    chat_session_id: Mapped[int] = mapped_column(
        ForeignKey("TB_CHAT_SESSION.id"), primary_key=True
    )
    chat_number: Mapped[int] = mapped_column(Integer, primary_key=True)
    is_file_content: Mapped[bool] = mapped_column(Boolean, default=False)
    user_message: Mapped[str] = mapped_column(TEXT)
    user_message_summary: Mapped[str] = mapped_column(TEXT, nullable=True, default=None)
    bot_message: Mapped[str] = mapped_column(TEXT, nullable=True, default=None)
    bot_message_summary: Mapped[str] = mapped_column(TEXT, nullable=True, default=None)

    created_at: Mapped[DateTime] = mapped_column(DateTime, default=func.now())
    updated_at: Mapped[DateTime] = mapped_column(
        DateTime, default=func.now(), onupdate=func.now()
    )

    chat_session: Mapped["ChatSession"] = relationship(back_populates="chat_history")

    def __repr__(self):
        return (
            f"<ChatHistory(chat_session_id={self.chat_session_id}, "
            f"chat_number={self.chat_number}, is_file_content={self.is_file_content}, "
            f"user_message={self.user_message}, user_message_summary={self.user_message_summary}, "
            f"bot_message={self.bot_message}, bot_message_summary={self.bot_message_summary}, "
            f"created_at={self.created_at}, updated_at={self.updated_at})>"
        )


class ChatSummary(Base):
    __tablename__ = "TB_CHAT_SUMMARY"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    chat_session_id: Mapped[int] = mapped_column(ForeignKey("TB_CHAT_SESSION.id"))
    start_number: Mapped[int] = mapped_column(Integer)
    end_number: Mapped[int] = mapped_column(Integer)
    message: Mapped[str] = mapped_column(TEXT)
    created_at: Mapped[DateTime] = mapped_column(DateTime, default=func.now())

    chat_session: Mapped["ChatSession"] = relationship(back_populates="chat_summaries")

    __table_args__ = (
        Index(
            "IDX_CHAT_SUMMARY",
            "chat_session_id",
            "start_number",
            "end_number",
            unique=True,
        ),
    )

    def __repr__(self):
        return (
            f"<ChatSummary(id={self.id}, chat_session_id={self.chat_session_id}, "
            f"start_number={self.start_number}, end_number={self.end_number}, "
            f"message={self.message}, created_at={self.created_at})>"
        )
