from sqlalchemy import (
    TEXT,
    DateTime,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from db_manager.models.base import Base


class StaticMessageFromIntent(Base):
    __tablename__ = "TB_STATIC_MESSAGE_FROM_INTENT"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    intent_id: Mapped[int] = mapped_column(index=True)
    intent_name: Mapped[str] = mapped_column(String(50), index=True)
    message: Mapped[str] = mapped_column(TEXT, nullable=True, default=None)
    created_at: Mapped[DateTime] = mapped_column(DateTime, default=func.now())

    def __repr__(self):
        return (
            f"<StaticMessageFromIntent(id={self.id}, intent_id={self.intent_id}, "
            f"intent_name={self.intent_name}, message={self.message}, "
            f"created_at={self.created_at})>"
        )
