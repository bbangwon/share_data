import logging
import os

from sqlalchemy import or_, select, update
from sqlalchemy.exc import NoResultFound
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import joinedload

from db_manager.models import (
    ChatHistory,
    ChatSession,
    Setting,
    StaticFeedback,
    StaticMessageFromIntent,
)

logger = logging.getLogger(__name__)


class DBManager:
    def __init__(self, database_url):
        self.database_url = database_url
        self.new_connection()

    def new_connection(self):
        """새 데이터베이스 연결을 생성합니다."""
        self._engine = create_async_engine(
            self.database_url,
            pool_size=2,  # 동시에 유지할 수 있는 커넥션 수(pgbouncer와 이중 풀링 방지)
            max_overflow=0,  # pgbouncer와 이중 풀링 방지
            echo=True,  # 데이터 베이스에서 실행되는 쿼리를 로그로 출력
            pool_pre_ping=True,  # DB 연결이 유효한지 확인하는 옵션(연결 상태를 점검하고 문제가 있을 경우 새로운 연결을 시도함)
        )
        self._session_factory = async_sessionmaker(
            bind=self._engine, class_=AsyncSession, expire_on_commit=False
        )

    def get_session(self):
        """새 데이터베이스 세션을 반환합니다."""
        return self._session_factory()

    async def create_chat_session(self, chat_session: ChatSession) -> int:
        """새 채팅 세션을 데이터베이스에 생성합니다."""
        async with self.get_session() as session:
            try:
                session.add(chat_session)
                await session.commit()
                logger.info(f"채팅 세션 생성: {chat_session}")
                return chat_session.id
            except Exception as e:
                await session.rollback()
                logger.error(f"채팅 세션 생성 오류: {e}")
                raise e

    async def add_bot_chat_history(
        self,
        chat_session_id: int,
        chat_number: int,
        message: str,
        message_summary: str | None = None,
    ):
        async with self.get_session() as session:
            try:
                await session.execute(
                    update(ChatHistory)
                    .where(
                        ChatHistory.chat_session_id == chat_session_id,
                        ChatHistory.chat_number == chat_number,
                    )
                    .values(
                        bot_message=message,
                        bot_message_summary=message_summary,
                    )
                )
                await session.commit()
                logger.info(
                    f"봇 채팅 기록 업데이트: session_id={chat_session_id}, chat_number={chat_number}, message='{message}', message_summary='{message_summary}'"
                )
            except Exception as e:
                await session.rollback()
                logger.error(f"봇 채팅 기록 업데이트 오류: {e}")
                raise e

    async def add_user_chat_history(
        self,
        chat_session_id: int,
        message: str,
        message_summary: str | None = None,
        is_file_content: bool = False,
    ) -> int:
        """채팅 기록을 데이터베이스에 추가합니다. 챗 넘버를 반환합니다."""
        async with self.get_session() as session:
            try:
                last_chat_number = await session.scalar(
                    select(ChatHistory.chat_number)
                    .where(ChatHistory.chat_session_id == chat_session_id)
                    .order_by(ChatHistory.chat_number.desc())
                    .limit(1)
                )
                new_chat_number = (last_chat_number or 0) + 1
                session.add(
                    ChatHistory(
                        chat_session_id=chat_session_id,
                        chat_number=new_chat_number,
                        is_file_content=is_file_content,
                        user_message=message,
                        user_message_summary=message_summary,
                    )
                )
                await session.commit()
                logger.info(
                    f"유저 채팅 기록 추가: session_id={chat_session_id}, is_file_content={is_file_content}, message='{message}', message_summary='{message_summary}', new_chat_number={new_chat_number}"
                )
                return new_chat_number
            except Exception as e:
                await session.rollback()
                logger.error(f"유저 채팅 기록 추가 오류: {e}")
                raise e

    async def get_chat_histories_by_session_id(
        self,
        chat_session_id: int,
        allow_empty_bot_message: bool = False,
        count: int = 10,
    ) -> list[ChatHistory]:
        """채팅 세션 ID에 해당하는 채팅 기록을 반환합니다."""
        async with self.get_session() as session:
            select_stmt = select(ChatHistory).where(
                ChatHistory.chat_session_id == chat_session_id
            )

            if not allow_empty_bot_message:
                select_stmt = select_stmt.where(ChatHistory.bot_message.isnot(None))

            select_stmt = select_stmt.order_by(ChatHistory.chat_number.desc()).limit(
                count
            )
            result = await session.execute(select_stmt)
            chat_histories = result.scalars().all()

            # 뽑아온 채팅 이력 오름차순으로 재정렬
            chat_histories = sorted(chat_histories, key=lambda x: x.chat_number)

            return chat_histories

    async def get_last_chat_histories_by_user_and_bot_id(
        self,
        user_id: str,
        bot_id: str,
        allow_empty_bot_message: bool = False,
        count: int = 10,
    ) -> list[ChatHistory]:
        """사용자와 봇 ID에 해당하는 최근 질문을 반환합니다. => 내 최근 질문 보기 기능용"""
        async with self.get_session() as session:
            select_stmt = (
                select(ChatHistory)
                .join(ChatSession, ChatHistory.chat_session_id == ChatSession.id)
                .where(
                    ChatSession.user_id == user_id,
                    ChatSession.bot_id == bot_id,
                )
            )

            if not allow_empty_bot_message:
                select_stmt = select_stmt.where(
                    ChatHistory.bot_message.isnot(None),
                )

            select_stmt = select_stmt.order_by(ChatHistory.created_at.desc()).limit(
                count
            )

            result = await session.execute(select_stmt)
            chat_histories = result.scalars().all()

            # 뽑아온 채팅 이력 오름차순으로 재정렬
            chat_histories = sorted(chat_histories, key=lambda x: x.created_at)

            return chat_histories

    async def delete_chat_history(self, chat_history: ChatHistory):
        """채팅 기록을 삭제합니다."""
        async with self.get_session() as session:
            try:
                await session.delete(chat_history)
                # select_stmt = delete(ChatHistory).where(
                #     ChatHistory.chat_session_id == chat_history.chat_session_id,
                #     ChatHistory.chat_number == chat_history.chat_number,
                # )

                # await session.execute(select_stmt)
                await session.commit()
                logger.info(
                    f"채팅 기록 삭제: session_id={chat_history.chat_session_id}, chat_number={chat_history.chat_number}"
                )
            except Exception as e:
                await session.rollback()
                logger.error(f"채팅 기록 삭제 오류: {e}")
                raise e

    async def get_chat_history_by_session_and_chat_number(
        self, chat_session_id: int, chat_number: int
    ) -> ChatHistory | None:
        """채팅 세션 ID와 챗 넘버에 해당하는 채팅 기록을 반환합니다."""
        async with self.get_session() as session:
            select_stmt = select(ChatHistory).where(
                ChatHistory.chat_session_id == chat_session_id,
                ChatHistory.chat_number == chat_number,
            )
            result = await session.execute(select_stmt)
            chat_history = result.scalar_one_or_none()

            if chat_history is None:
                logger.info(
                    f"채팅 세션 ID '{chat_session_id}'와 챗 넘버 '{chat_number}'에 해당하는 채팅 기록이 없습니다."
                )
                return None

            logger.info(
                f"채팅 세션 ID '{chat_session_id}'와 챗 넘버 '{chat_number}'에 해당하는 채팅 기록을 조회했습니다."
            )
            return chat_history

    async def get_last_chat_session_id(self, user_id: str, bot_id: str) -> int | None:
        """사용자와 봇 ID에 해당하는 마지막 채팅 세션 ID를 반환합니다."""
        async with self.get_session() as session:
            try:
                select_stmt = (
                    select(ChatSession.id)
                    .where(
                        ChatSession.user_id == user_id,
                        ChatSession.bot_id == bot_id,
                    )
                    .order_by(ChatSession.created_at.desc())
                    .limit(1)
                )
                result = await session.execute(select_stmt)
                chat_session_id = result.scalar_one()
            except NoResultFound:
                logger.warning(
                    f"사용자 ID '{user_id}'와 봇 ID '{bot_id}'에 해당하는 채팅 세션이 없어 새로 생성합니다."
                )
                new_session_id = await self.create_chat_session(
                    ChatSession(user_id=user_id, bot_id=bot_id)
                )
                return new_session_id
            except Exception as e:
                logger.error(
                    f"사용자 ID '{user_id}'와 봇 ID '{bot_id}'에 해당하는 마지막 채팅 세션 ID 조회 오류: {e}"
                )
                raise e

            return chat_session_id

    async def get_feedback_items_by_postback(
        self, bot_service: str, postback: str
    ) -> list[StaticFeedback] | None:
        """포스트백에 해당하는 피드백 아이템을 반환합니다."""

        async with self.get_session() as session:
            select_stmt = (
                select(StaticFeedback)
                .where(StaticFeedback.from_postback == postback)
                .where(StaticFeedback.bot_service == bot_service)
                .order_by(StaticFeedback.sort_number)
                .options(
                    joinedload(StaticFeedback.children).joinedload(
                        StaticFeedback.children
                    )  # 필요시 더 중첩해야 할 수 있음. 일단 3단계까지만 필요하므로
                )
            )
            result = await session.execute(select_stmt)
            feedback_items = result.unique().scalars().all()

            if not feedback_items:
                logger.info(
                    f"포스트백 '{postback}'에 해당하는 피드백 아이템이 없습니다."
                )
                return None

            logger.info(
                f"포스트백 '{postback}'에 해당하는 피드백 아이템을 조회했습니다."
            )
            return feedback_items

    async def get_setting_value(self, key: str) -> str | None:
        """설정 키에 해당하는 값을 반환합니다."""
        async with self.get_session() as session:
            select_stmt = select(Setting.value).where(Setting.key == key)
            result = await session.execute(select_stmt)
            value = result.scalar_one_or_none()

            if value is None:
                logger.info(f"설정 키 '{key}'에 해당하는 값이 없습니다.")
                return None

            logger.info(f"설정 키 '{key}'의 값을 조회했습니다: {value}")
            return value

    async def get_static_message_from_intent(
        self, intent_id: int, intent_name: str
    ) -> StaticMessageFromIntent | None:
        """의도 ID에 해당하는 정적 메시지를 반환합니다."""
        async with self.get_session() as session:
            select_stmt = select(StaticMessageFromIntent).where(
                or_(
                    StaticMessageFromIntent.intent_id == intent_id,
                    StaticMessageFromIntent.intent_name == intent_name,
                )
            )
            result = await session.execute(select_stmt)
            message = result.scalar_one_or_none()

            if message is None:
                logger.info(
                    f"의도 ID '{intent_id}'와 의도 이름 '{intent_name}'에 해당하는 정적 메시지가 없습니다."
                )
                return None

            logger.info(
                f"의도 ID '{intent_id}'와 의도 이름 '{intent_name}'에 해당하는 정적 메시지를 조회했습니다."
            )
            return message

    async def close(self):
        """데이터베이스 연결을 종료합니다."""
        if self._engine:
            await self._engine.dispose()
            logger.info("데이터베이스 연결이 종료되었습니다.")
        else:
            logger.info("데이터베이스 연결이 이미 종료되었습니다.")


# Helper 함수: DBManager 인스턴스를 환경 변수에서 가져옵니다.
def get_db_manager_using_env(database_url: str = None) -> DBManager:
    """환경 변수에서 데이터베이스 URL을 가져와 DBManager 인스턴스를 반환합니다. database_url을 직접 지정할 수 있습니다."""

    if not database_url:
        env_name_database_url = "DATABASE_URL"

        database_url = os.getenv(env_name_database_url)
        if not database_url:
            raise ValueError(
                f"{env_name_database_url} 환경 변수가 설정되어 있지 않습니다."
            )

    logger.debug(f"DBManager 인스턴스를 생성합니다. 데이터베이스 URL: {database_url}")
    return DBManager(database_url)
