"""
데이터베이스에 초기 데이터를 삽입하는 스크립트
"""

import asyncio
import json
import os
from datetime import datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from db_manager import DBManager
from db_manager.models.chat import ChatHistory, ChatSession
from db_manager.models.setting import Setting
from db_manager.models.static_feedback import StaticFeedback


async def create_setting_data(session: AsyncSession) -> None:
    """Setting 초기 데이터 생성"""
    settings = [
        Setting(key="app_name", value="AI부기주무관"),
        Setting(key="version", value="0.0.1"),
    ]
    session.add_all(settings)
    await session.flush()  # ID 생성을 위해 flush


async def create_static_feedback_data(session: AsyncSession) -> None:
    """StaticFeedback 초기 데이터 생성"""

    # 시작 인사말 피드백
    start_feedback_1 = StaticFeedback(
        from_postback="start_service",
        message_type="text",
        sort_number=1,
        content="안녕하세요. AI맞춤 행정업무를 지원하는 AI 부기주무관 입니다. 업무에 궁금한 점을 바로 질문하시거나 아래에서 해당하는 질문을 클릭해주세요.",
    )

    start_feedback_2 = StaticFeedback(
        from_postback="start_service",
        message_type="main_carousel",
        content=json.dumps(
            {
                "alt_text": "AI 부기주무관이 지원 업무/자주묻는 질문",
            },
            ensure_ascii=False,
        ),
        sort_number=2,
    )

    carousel_item_1 = StaticFeedback(
        message_type="carousel_column",
        sort_number=1,
        content=json.dumps(
            {
                "image_url": "https://busanai.busan.go.kr/views/images/c1.png",
                "text": "AI 부기주무관이 지원하는 업무를 확인해보세요.",
            },
            ensure_ascii=False,
        ),
    )

    carousel_item_1_button_1 = StaticFeedback(
        message_type="message",
        sort_number=1,
        content=json.dumps(
            {
                "label": "업무 영역",
                "text": "AI 부기주무관 지원 업무 영역",
            },
            ensure_ascii=False,
        ),
        to_postback="task_area",
    )

    carousel_item_1_button_2 = StaticFeedback(
        message_type="uri",
        sort_number=2,
        content=json.dumps(
            {
                "label": "지원 업무 상세 보기",
                "uri": "https://busanai.busan.go.kr/views/guide-view",
            },
            ensure_ascii=False,
        ),
    )

    carousel_item_2 = StaticFeedback(
        message_type="carousel_column",
        sort_number=2,
        content=json.dumps(
            {
                "image_url": "https://busanai.busan.go.kr/views/images/c2.png",
                "text": "AI 부기주무관에 자주묻는 질문을 확인해보세요.",
            },
            ensure_ascii=False,
        ),
    )

    carousel_item_2_button_1 = StaticFeedback(
        message_type="message",
        sort_number=1,
        content=json.dumps(
            {"label": "FAQ", "text": "FAQ"},
            ensure_ascii=False,
        ),
        to_postback="faq",
    )

    carousel_item_2_button_2 = StaticFeedback(
        message_type="message",
        sort_number=2,
        content=json.dumps(
            {"label": "나의 최근 질문", "text": "나의 최근 질문"},
            ensure_ascii=False,
        ),
        to_postback="recent_questions",
    )

    # 관계 설정
    start_feedback_2.children.append(carousel_item_1)
    start_feedback_2.children.append(carousel_item_2)
    carousel_item_1.children.append(carousel_item_1_button_1)
    carousel_item_1.children.append(carousel_item_1_button_2)
    carousel_item_2.children.append(carousel_item_2_button_1)
    carousel_item_2.children.append(carousel_item_2_button_2)

    session.add(start_feedback_1)
    session.add(start_feedback_2)
    await session.flush()  # ID 생성을 위해 flush

    text_area_text_feedback = StaticFeedback(
        from_postback="task_area",
        message_type="text",
        sort_number=1,
        content="업무영역을 선택하셨군요! AI 부기주무관이 지원하는 업무 구분은 아래와 같습니다. 해당하는 업무를 클릭하면 상세한 설명을 보실 수 있습니다.",
    )

    # 업무 영역 피드백
    text_area_feedback = StaticFeedback(
        from_postback="task_area",
        message_type="button_template",
        content=json.dumps(
            {
                "alt_text": "AI 부기주무관 지원 업무",
            },
            ensure_ascii=False,
        ),
        sort_number=2,
    )

    # Level 1
    text_area_feedback_items: list[StaticFeedback] = [
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "시민서비스", "text": "시민서비스"},
                ensure_ascii=False,
            ),
            to_postback="citizen_service",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "예산회계", "text": "예산회계"},
                ensure_ascii=False,
            ),
            to_postback="budget_accounting",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "문서봇", "text": "문서봇"},
                ensure_ascii=False,
            ),
            to_postback="document_bot",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "법무∙특사경", "text": "법무∙특사경"},
                ensure_ascii=False,
            ),
            to_postback="law",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "인사∙복지∙교육", "text": "인사∙복지∙교육"},
                ensure_ascii=False,
            ),
            to_postback="employee_welfare",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "IT & 빅데이터", "text": "IT & 빅데이터"},
                ensure_ascii=False,
            ),
            to_postback="it_bigdata",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "홍보", "text": "홍보"},
                ensure_ascii=False,
            ),
            to_postback="promotion",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "기록물", "text": "기록물"},
                ensure_ascii=False,
            ),
            to_postback="record",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "대외협력", "text": "대외협력"},
                ensure_ascii=False,
            ),
            to_postback="external_cooper",
        ),
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {"label": "안전∙환경", "text": "안전∙환경"},
                ensure_ascii=False,
            ),
            to_postback="safety_environment",
        ),
    ]

    text_area_feedback.children.extend(text_area_feedback_items)
    session.add(text_area_text_feedback)
    session.add(text_area_feedback)

    await session.commit()  # 즉시 반영

    # 최근 질문 피드백(템플릿)
    recent_questions_text_feedback = StaticFeedback(
        from_postback="recent_questions",
        message_type="text",
        sort_number=1,
        content="최근 부기주무관에 문의한 질문 내역을 확인할 수 있습니다.",
    )
    recent_questions_button_carousel = StaticFeedback(
        from_postback="recent_questions",
        message_type="button_carousel",
        content=json.dumps(
            {
                "alt_text": "나의 최근 질문",
            },
            ensure_ascii=False,
        ),
        sort_number=2,
    )
    recent_questions_button = StaticFeedback(
        message_type="button",
        sort_number=1,
        content=json.dumps(
            {
                "text": "나의 최근 질문",  # 업데이트 필요
            },
            ensure_ascii=False,
        ),
    )
    recent_questions_button.children.append(
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {
                    "text": "나의 최근 질문",  # 업데이트 필요
                    "label": "답변보기",
                },
                ensure_ascii=False,
            ),
        )
    )

    recent_questions_button_carousel.children.append(recent_questions_button)
    session.add(recent_questions_text_feedback)
    session.add(recent_questions_button_carousel)
    await session.commit()  # 즉시 반영

    # 시민서비스 피드백
    citizen_service_text_feedback = StaticFeedback(
        from_postback="citizen_service",
        message_type="text",
        sort_number=1,
        content="시민서비스를 선택하셨군요! 시민서비스는 부산시정, 당직민원, 청사안내 업무를 지원합니다.\n\n"
        "부산시정 업무에서는 시정, 시장, 정책, 시민, 부산, 경영관리계획, 기본계획, 중장기, 업무계획, 의전 등의 업무를 지원합니다.\n\n"
        "당직민원 업무에서는 민원, 전화 문의, 질문과 답변 업무를 지원합니다.\n\n"
        "청사안내 업무에서는 청사, 층별, 부서안내, 건물, 주차, 방문자, 안내 업무를 지원합니다.\n\n"
        "시민서비스에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 부산시의 주요 정책은 무엇인가요?",
    )

    session.add(citizen_service_text_feedback)

    # 예산회계 피드백
    budget_accounting_text_feedback = StaticFeedback(
        from_postback="budget_accounting",
        message_type="text",
        sort_number=1,
        content="예산회계를 선택하셨군요! 예산회계는 예산회계 및 지원사업 업무를 지원합니다.\n\n"
        "예산회계 업무에서는 예산, 회계, 지출, 계약, 부정수급, 재정, 결산, 입찰, 구매, 국비, 시비매칭 등의 업무를 지원합니다.\n\n"
        "지원사업 업무에서는 지원사업, 공모사업, 보조사업, 지원금, 공모, 신청, 선정, 지원 등의 업무를 지원합니다.\n\n"
        "예산회계에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 예산 편성 절차는 어떻게 되나요?",
    )

    session.add(budget_accounting_text_feedback)

    # 문서봇 피드백
    document_bot_text_feedback = StaticFeedback(
        from_postback="document_bot",
        message_type="text",
        sort_number=1,
        content="문서봇을 선택하셨군요! 문서봇 업무에서는 문서작성 등의 업무를 지원합니다.\n\n"
        "문서작성 업무에서는 인사말씀, 보도자료, 계획서, 보고자료등 초안생성 업무를 지원합니다.\n\n"
        "문서작성에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 보도자료 작성 방법은 무엇인가요?",
    )

    session.add(document_bot_text_feedback)

    # 법무/특사경 피드백
    law_text_feedback = StaticFeedback(
        from_postback="law",
        message_type="text",
        sort_number=1,
        content="법무∙특사경을 선택하셨군요! 법무∙특사경 업무에서는 법령, 사법경찰 등의 업무를 지원합니다.\n\n"
        "법령 업무에서는 법령, 법률, 조례, 규칙, 시행령, 시행규칙, 규정, 법무, 입법 등의 업무를 지원합니다.\n\n"
        "사법경찰 업무에서는 사법경찰, 특사경, 단속, 수사 등의 업무를 지원합니다.\n\n"
        "법무∙특사경에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 법령 개정 절차는 어떻게 되나요?",
    )

    session.add(law_text_feedback)

    # 인사/복지/교육 피드백
    employee_welfare_text_feedback = StaticFeedback(
        from_postback="employee_welfare",
        message_type="text",
        sort_number=1,
        content="인사∙복지∙교육을 선택하셨군요! 인사∙복지∙교육 업무에서는 직원복지, 교육 등의 업무를 지원합니다.\n\n"
        "직원복지 업무에서는 복지, 연가, 건강검진, 출장비, 식당, 휴가, 인사, 채용 등의 업무를 지원합니다.\n\n"
        "교육 업무에서는 교육, 훈련, 연수, 인력개발, 직무교육, 시민교육, 강의, 학습, 역량, 개발원 등의 업무를 지원합니다.\n\n"
        "인사∙복지∙교육에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 직원 복지 혜택은 어떤 것이 있나요?",
    )

    session.add(employee_welfare_text_feedback)

    # IT/빅데이터 피드백
    it_bigdata_text_feedback = StaticFeedback(
        from_postback="it_bigdata",
        message_type="text",
        sort_number=1,
        content="IT & 빅데이터를 선택하셨군요! IT & 빅데이터 업무에서는 IT, 정보보안, 빅데이터 등의 업무를 지원합니다.\n\n"
        "IT 업무에서는 시스템, DRM, PC, 권한, 장애, 전산, 정보통신, 보안, IP, 행정전화 등의 업무를 지원합니다.\n\n"
        "정보보안 업무에서는 보안, 해킹, 방화벽, 개인정보 등의 업무를 지원합니다.\n\n"
        "빅데이터 업무에서는 빅데이터, 데이터, 통계, 데이터 분석 등의 업무를 지원합니다.\n\n"
        "IT & 빅데이터에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 전산 장애 발생 시 어떻게 하나요?",
    )

    session.add(it_bigdata_text_feedback)

    # 홍보 피드백
    promotion_text_feedback = StaticFeedback(
        from_postback="promotion",
        message_type="text",
        sort_number=1,
        content="홍보를 선택하셨군요! 홍보 업무에서는 홍보, 홈페이지, 보도, 콘텐츠, 부기 등의 업무를 지원합니다.\n\n"
        "홍보에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 홍보 자료는 어떻게 제작하나요?",
    )

    session.add(promotion_text_feedback)

    # 기록물 피드백
    record_text_feedback = StaticFeedback(
        from_postback="record",
        message_type="text",
        sort_number=1,
        content="기록물을 선택하셨군요! 기록물 업무에서는 기록물, 보존, 문서관리, 국가기록원, 기록 등의 업무를 지원합니다.\n\n"
        "기록물에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 기록물 관리 방침은 어떻게 되나요?",
    )

    session.add(record_text_feedback)

    # 대외협력 피드백
    external_cooper_text_feedback = StaticFeedback(
        from_postback="external_cooper",
        message_type="text",
        sort_number=1,
        content="대외협력을 선택하셨군요! 대외협력 업무에서는 민간단체, 공공기관, 부울경, 위원회, 업무협약 등의 업무를 지원합니다.\n\n"
        "민간단체 업무에서는 민간단체, 비영리, 보조금 등의 업무를 지원합니다.\n\n"
        "공공기관 업무에서는 공공기관, 공기업, 출자, 출연, 지방공기업 업무를 지원합니다.\n\n"
        "부울경 업무에서는 부울경, 경남, 울산, 광역, 초광역, 경제동맹, 협력 업무를 지원합니다.\n\n"
        "위원회 업무에서는 위원회, 심의회, 협의회 등의 업무를 지원합니다.\n\n"
        "업무협약 업무에서는 MOU, 협약, 업무협약 등의 업무를 지원합니다.\n\n"
        "대외협력에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 민간단체 보조금 신청은 어떻게 해야 하나요?",
    )

    session.add(external_cooper_text_feedback)

    # 안전/환경 피드백
    safety_environment_text_feedback = StaticFeedback(
        from_postback="safety_environment",
        message_type="text",
        sort_number=1,
        content="안전∙환경을 선택하셨군요! 안전∙환경 업무에서는 환경지키미, 안전지키미 등의 업무를 지원합니다.\n\n"
        "환경지키미 업무에서는 환경, 환경민원, 환경부담금, 대기, 수질, 소음, 폐기물, 하천, 하수도등의 업무를 지원합니다.\n\n"
        "안전지키미 업무에서는 안전, 재난, 응급, 소방, 방재, 비상, 중대재해, 원자력, 사고, 침수, 싱크홀 등의 업무를 지원합니다.\n\n"
        "안전∙환경에 관련하여 궁금하신 점을 메시지창에 입력하여 질문해 주세요.\n\n"
        "예시 질문: 폐기물 관리 절차는 어떻게 되나요?",
    )

    session.add(safety_environment_text_feedback)

    await session.commit()  # 즉시 반영

    # FAQ - Button Carousel 피드백
    faq_text_feedback = StaticFeedback(
        from_postback="faq",
        message_type="text",
        sort_number=1,
        content="부기주무관에 궁금한 자주 묻는 질문을 확인하고, 답변을 확인해 보세요.",
    )

    faq_button_carousel = StaticFeedback(
        from_postback="faq",
        message_type="button_carousel",
        content=json.dumps(
            {
                "alt_text": "FAQ",
            },
            ensure_ascii=False,
        ),
        sort_number=2,
    )

    faq_buttons = [
        StaticFeedback(
            message_type="button",
            sort_number=1,
            content=json.dumps(
                {
                    "text": "부기주무관 사용 방법이 궁금해요",
                },
                ensure_ascii=False,
            ),
        ),
        StaticFeedback(
            message_type="button",
            sort_number=2,
            content=json.dumps(
                {
                    "text": "2025년 축제 편성 총괄 담당자는 누구인가요?",
                },
                ensure_ascii=False,
            ),
        ),
    ]

    faq_button_carousel.children.extend(faq_buttons)

    faq_buttons[0].children.append(
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {
                    "text": "부기주무관 사용 방법이 궁금해요",
                    "label": "답변보기",
                },
                ensure_ascii=False,
            ),
        )
    )

    faq_buttons[1].children.append(
        StaticFeedback(
            message_type="message",
            sort_number=1,
            content=json.dumps(
                {
                    "text": "2025년 축제 편성 총괄 담당자는 누구인가요?",
                    "label": "답변보기",
                },
                ensure_ascii=False,
            ),
        )
    )

    session.add(faq_text_feedback)
    session.add(faq_button_carousel)
    await session.commit()  # 즉시 반영


async def create_sample_chat_data(session: AsyncSession) -> None:
    """샘플 채팅 데이터 생성"""

    # 샘플 채팅 세션
    chat_session = ChatSession(user_id="user123", bot_id="busan_bot")
    session.add(chat_session)
    await session.flush()  # ID 생성을 위해 flush

    # 채팅 히스토리
    base_time = datetime.now()
    chat_histories = [
        ChatHistory(
            chat_session_id=chat_session.id,
            chat_number=1,
            user_message="스트리밍 테스트를 위해 bot_message 필드를 비워둡니다.",
            created_at=base_time + timedelta(seconds=0),
        ),
        ChatHistory(
            chat_session_id=chat_session.id,
            chat_number=2,
            user_message="관광지 정보를 알고 싶어요",
            bot_message="부산의 대표 관광지를 소개해드릴게요!",
            created_at=base_time + timedelta(seconds=1),
        ),
        ChatHistory(
            chat_session_id=chat_session.id,
            chat_number=3,
            user_message="해운대에 대해 알려주세요",
            bot_message="해운대는 부산의 대표 해변으로, 아름다운 백사장과 다양한 먹거리, 즐길 거리가 가득한 곳입니다.",
            created_at=base_time + timedelta(seconds=2),
        ),
        ChatHistory(
            chat_session_id=chat_session.id,
            chat_number=4,
            user_message="고마워요",
            bot_message="천만에요! 더 궁금한 점 있으면 언제든지 물어보세요.",
            created_at=base_time + timedelta(seconds=3),
        ),
    ]

    for history in chat_histories:
        session.add(history)


async def seed_all_data(db_url: str) -> None:
    """모든 초기 데이터 생성"""

    db_manager = DBManager(db_url)
    async with db_manager.get_session() as session:
        try:
            await create_setting_data(session)
            print("Setting 데이터 생성 완료")

            await create_static_feedback_data(session)
            print("StaticFeedback 데이터 생성 완료")

            # await create_sample_chat_data(session)
            # print("Chat 샘플 데이터 생성 완료")

            await session.commit()
            print("모든 초기 데이터 생성이 완료되었습니다!")

        except Exception as e:
            await session.rollback()
            print(f"오류 발생: {e}")
            raise
        finally:
            await db_manager.close()


async def main():
    """메인 실행 함수"""
    db_url = os.getenv(
        "DATABASE_URL", "postgresql+asyncpg://appuser:busan12#$@localhost:6432/appdb"
    )

    print(f"데이터베이스 URL: {db_url}")
    await seed_all_data(db_url)


if __name__ == "__main__":
    asyncio.run(main())
