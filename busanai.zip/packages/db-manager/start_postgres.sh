#!/bin/bash

docker run -d --name postgres \
-e POSTGRES_PASSWORD=postgres \
-e POSTGRES_USER=postgres \
-e POSTGRES_DB=postgres \
-e TZ=Asia/Seoul \
-v pgdata:/var/lib/postgresql/data \
-v ./scripts:/home/scripts \
-p 5432:5432 \
-d postgres

