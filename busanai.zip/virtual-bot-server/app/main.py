import asyncio
import logging
import logging.handlers
import os
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import Annotated

import httpx
from dotenv import load_dotenv
from fastapi import Body, FastAPI, File, HTTPException, Request, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.schemas.message import Message

load_dotenv()
LOG_LEVEL = os.getenv("LOG_LEVEL", "ERROR").upper()
if LOG_LEVEL not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
    raise ValueError(f"Invalid LOG_LEVEL: {LOG_LEVEL}")

LOG_DIR = os.getenv("LOG_DIR", "./logs")
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", 7))

ENV = os.getenv("ENV", "prod")
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./uploads")

DOMAIN_ID = 300223877

log_file_path = os.path.join(LOG_DIR, "virtual-bot-server.log")
logging.basicConfig(
    level=LOG_LEVEL,
    format="[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s",
    handlers=[
        logging.StreamHandler(),  # 콘솔에 로그 출력
        logging.handlers.TimedRotatingFileHandler(
            log_file_path,
            when="midnight",  # 매일 자정에 로그 파일을 새로 만듭니다.
            interval=1,  # 1일마다 새 로그 파일 생성
            backupCount=LOG_BACKUP_COUNT,  # 최대 7개의 백업 로그 파일 유지
            encoding="utf-8",
            utc=False,  # 로컬 시간 사용
        ),
    ],
)

logger = logging.getLogger(__name__)

messages = {}
last_message_time = None  # 추가
upload_base_path = Path(UPLOAD_DIR)
if not upload_base_path.exists():
    upload_base_path.mkdir(parents=True, exist_ok=True)

app = FastAPI()


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    # 빈 응답
    return Response(status_code=404)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


@app.post("/v1.0/bots/{bot_id}/users/{user_id}/messages")
async def virtual_bot_server(
    bot_id: str,
    user_id: str,
    body: Annotated[dict, Body(...)],
):
    """메시지를 받으면 표시만 해줌"""
    global last_message_time
    last_message_time = datetime.now()  # 추가

    logger.info(
        f"가상 네이버 봇 메시지 수신: bot_id={bot_id}, user_id={user_id}, json={body}"
    )

    return Response(status_code=200)


@app.post("/simulate-message")
async def simulate_message(
    message: Annotated[Message, Body(...)],
):
    """메시지 콜백"""
    logger.info(f"메시지 콜백 수신: message={message}")

    callback_server_url = os.getenv("CALLBACK_SERVER_URL")

    async with httpx.AsyncClient() as client:
        try:
            now = datetime.now()
            issued_time = now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

            headers = {
                "content-type": "application/json",
                "x-works-signature": "virtual-signature",
                "x-works-botid": message.bot_id,
            }

            request: dict = {
                "type": "message",
                "source": {"domain_id": DOMAIN_ID, "user_id": message.user_id},
                "issued_time": issued_time,
                "content": {
                    "type": "text",
                    "text": message.text,
                },
            }
            if message.postback:
                request["content"]["postback"] = message.postback

            response = await client.post(
                url=callback_server_url,
                headers=headers,
                json=request,
            )

            response.raise_for_status()

            task_id = response.headers["X-Task-Id"]
            logger.info(
                f"메시지 콜백 응답 수신: status={response.status_code}, task-id={task_id}"
            )

        except Exception as e:
            logger.error("요청 중 오류 발생: %s", e)
            return Response(status_code=500, content="Internal Server Error")

    return JSONResponse(status_code=200, content={"task-id": task_id})


async def _save_upload_file(upload_file: UploadFile, destination: Path) -> int:
    """UploadFile 객체를 지정한 경로에 저장하고 파일 크기를 반환합니다."""

    def _write_file() -> int:
        destination.parent.mkdir(parents=True, exist_ok=True)
        upload_file.file.seek(0)
        with destination.open("wb") as buffer:
            shutil.copyfileobj(upload_file.file, buffer)
        return destination.stat().st_size

    return await asyncio.to_thread(_write_file)


@app.post("/upload-file")
async def upload_file(file: UploadFile = File(...)):
    """파일 업로드 후 저장 위치 정보를 반환합니다."""

    if not file.filename:
        raise HTTPException(status_code=400, detail="파일 이름이 비어 있습니다.")

    original_name = Path(file.filename).name
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    extension = Path(original_name).suffix
    stored_name = f"{timestamp}_{uuid.uuid4().hex}{extension}"
    destination = upload_base_path / stored_name

    try:
        file_size = await _save_upload_file(file, destination)
    except Exception as exc:  # pragma: no cover - 로그를 위해 예외를 기록
        logger.exception("파일 저장 실패: original=%s", original_name)
        raise HTTPException(
            status_code=500, detail="파일 업로드에 실패했습니다."
        ) from exc
    finally:
        await file.close()

    logger.info(
        "파일 업로드 성공: original=%s stored=%s size=%d",
        original_name,
        stored_name,
        file_size,
    )

    return {
        "original_filename": original_name,
        "stored_filename": stored_name,
        "size": file_size,
    }


@app.get("/last-message-time")  # 추가
async def get_last_message_time():
    """마지막 봇 메시지 시간 조회"""
    global last_message_time
    if last_message_time:
        return {"last_message_time": last_message_time.isoformat()}
    return {"last_message_time": None}
