from pydantic import BaseModel, Field


class Message(BaseModel):
    bot_id: str = Field(..., description="봇 ID", examples=["10242846"])
    user_id: str = Field(
        ..., description="사용자 ID", examples=["95fe2166-112c-4597-1115-032ccd8f293c"]
    )
    text: str = Field(
        ...,
        description="전송할 텍스트 메시지",
        examples=["안녕하세요, 챗봇입니다!"],
    )
    postback: str | None = Field(
        None, description="포스트백 작업을 위한 추가 정보", examples=["start"]
    )
