#!/bin/bash

docker-compose build --no-cache

# Remove unused images
docker rmi -f $(docker images -f "dangling=true" -q)

# Create dist
rm -rf ./dist
mkdir -p ./dist

# copy env files
cp .env ./dist/.env
cp docker-compose.yml ./dist/docker-compose.yml

docker save -o ./dist/virtual-bot-server.tar virtual-bot-server
