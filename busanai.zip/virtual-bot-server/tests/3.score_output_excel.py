import argparse
import os
import re
import sys

import openpyxl
from openpyxl.styles import Alignment, PatternFill


def normalize_val(val):
    """값을 문자열로 변환하고, 정수형 실수는 정수 문자로 변환 (예: 1.0 -> '1')"""
    if val is None:
        return ""
    if isinstance(val, float) and val.is_integer():
        return str(int(val))
    return str(val).strip()


def parse_pages(page_str):
    """
    페이지 문자열을 파싱하여 개별 페이지 번호의 리스트(문자열)를 반환
    예: "1, 3~5" -> {'1', '3', '4', '5'}
    """
    pages = set()
    s = str(page_str).strip()
    if not s or s.lower() == "nan" or s == "none":
        return pages

    # 단일 개행(\n)로 페이지가 이어지는 케이스(예: "2,3,5\n 594, 595") 대응
    # *중요*: 여러 문서/페이지 쌍 구분(2개 이상 개행)은 상위 로직에서 처리하고,
    # 여기서는 "하나의 페이지 블록" 안에서 숫자 토큰을 안정적으로 분리하는 역할만 한다.
    s = s.replace("\r\n", "\n").replace("\r", "\n")

    # 쉼표/개행으로 1차 분리 후, 토큰 내부 공백은 추가 분리
    parts = re.split(r"[,\n]+", s)
    for part in parts:
        part = part.strip()
        if not part:
            continue

        # 공백으로도 페이지가 분리된 경우(예: "5 594") 대응
        subparts = [p for p in re.split(r"\s+", part) if p]
        for token in subparts:
            token = token.strip()
            if not token:
                continue
            if "~" in token:
                # 범위 처리 (예: 1~3)
                try:
                    start_s, end_s = re.split(r"\s*~\s*", token, maxsplit=1)
                    start = int(start_s)
                    end = int(end_s)
                    for i in range(start, end + 1):
                        pages.add(str(i))
                except ValueError:
                    pages.add(token)
            else:
                pages.add(token)
    return pages


_MULTI_NEWLINE_SPLIT_RE = re.compile(r"(?:\n[ \t]*){2,}")


def split_by_multi_newlines(val):
    """2개 이상 개행(중간 공백 라인 포함) 기준으로 블록을 분리한다."""
    if val is None:
        return []
    s = str(val)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = s.strip()
    if not s or s.lower() == "nan" or s == "none":
        return []

    blocks = [b.strip() for b in _MULTI_NEWLINE_SPLIT_RE.split(s)]
    return [b for b in blocks if b]


def detect_merge_rows(ws):
    """
    엑셀 워크시트에서 머지된 행의 개수를 자동으로 감지한다.
    2행 이후의 첫 번째 머지된 셀 범위에서 행의 개수를 추출한다.
    """
    if not ws.merged_cells or len(ws.merged_cells.ranges) == 0:
        return 5  # 기본값

    for merged_range in ws.merged_cells.ranges:
        # merged_range는 'A2:A6' 같은 형식의 문자열
        # 또는 CellRange 객체
        try:
            if hasattr(merged_range, "min_row"):
                min_row = merged_range.min_row
                max_row = merged_range.max_row
            else:
                # 문자열 형식 파싱
                range_str = str(merged_range)
                parts = range_str.split(":")
                if len(parts) == 2:
                    # A2에서 행 번호 추출
                    min_row = int(re.search(r"\d+", parts[0]).group())
                    # A6에서 행 번호 추출
                    max_row = int(re.search(r"\d+", parts[1]).group())
                else:
                    continue

            # 2행부터 시작하는 데이터 영역에서 첫 머지된 범위 찾기
            if min_row >= 2:
                merge_count = max_row - min_row + 1
                return merge_count
        except Exception:
            continue

    return 5  # 기본값


def pair_docs_and_pages(doc_val, page_val):
    """문서/페이지 값이 2개 이상 개행으로 분리된 경우, 같은 인덱스끼리 (doc, page_block)로 짝지어 반환."""
    doc_blocks = split_by_multi_newlines(doc_val)
    page_blocks = split_by_multi_newlines(page_val)

    if not doc_blocks and not page_blocks:
        return []

    # 둘 중 하나만 여러 블록인 경우도 현실적으로 발생할 수 있어 최대한 합리적으로 매칭한다.
    # - 문서가 1개, 페이지가 N개: 같은 문서에 대해 페이지 블록을 N개로 해석
    # - 페이지가 1개, 문서가 N개: 각 문서에 같은 페이지 블록을 적용(데이터 정합성 문제지만 방어)
    if not doc_blocks:
        doc_blocks = [""]
    if not page_blocks:
        page_blocks = [""]

    if len(doc_blocks) == len(page_blocks):
        pairs = list(zip(doc_blocks, page_blocks))
    elif len(doc_blocks) == 1 and len(page_blocks) > 1:
        pairs = [(doc_blocks[0], pb) for pb in page_blocks]
    elif len(page_blocks) == 1 and len(doc_blocks) > 1:
        pairs = [(db, page_blocks[0]) for db in doc_blocks]
    else:
        # 일반 케이스: 가능한 인덱스 범위 내에서만 매칭
        pairs = list(zip(doc_blocks, page_blocks))

    normalized_pairs = []
    for doc, pg in pairs:
        doc_norm = normalize_val(doc)
        pg_norm = normalize_val(pg)
        if doc_norm or pg_norm:
            normalized_pairs.append((doc_norm, pg_norm))
    return normalized_pairs


def check_red(cell):
    # 글자색이 있고 RGB값이 빨간색(FFFF0000 등)인지 확인
    if cell.font and cell.font.color and hasattr(cell.font.color, "rgb"):
        color = str(cell.font.color.rgb)
        # Alpha channel 포함(FFFF0000) 또는 미포함(FF0000/00FF0000) 케이스 대응
        if "FF0000" in color and color != "00000000":
            if color == "FFFF0000" or color == "00FF0000":
                return True
    return False


def is_llm_delivered_chunk(cell):
    """외곽선(두꺼운 선)으로 표시된 LLM 전달 청크 여부를 확인한다."""
    border = cell.border
    if not border:
        return False

    sides = [border.left, border.right, border.top, border.bottom]
    for side in sides:
        if side and side.style == "thick":
            return True
    return False


def process_excel_log(
    input_file, output_file, condition_mode="AND", merge_rows=None, top_n: int = 5
):
    print(f"[{input_file}] 파일을 읽는 중... (조건 모드: {condition_mode})")

    # 1. 엑셀 파일 불러오기
    try:
        wb = openpyxl.load_workbook(input_file)
        ws = wb.active
    except FileNotFoundError:
        print(f"오류: 입력 파일 '{input_file}'을(를) 찾을 수 없습니다.")
        sys.exit(1)
    except Exception as e:
        print(f"오류 발생: {e}")
        sys.exit(1)

    # 머지 행 개수 자동 감지 (파라미터가 없으면 엑셀에서 감지)
    if merge_rows is None:
        merge_rows = detect_merge_rows(ws)
    print(f"   - 감지된 머지 행 개수: {merge_rows}")

    # 3. 신규 결과 열 삽입 (5번째 위치에 4개 열)
    ws.insert_cols(5, 4)

    # 헤더 설정
    ws["E1"] = f"검색TOP{merge_rows}포함"
    ws["F1"] = f"검색TOP{top_n}포함"
    ws["G1"] = "LLM전달 청크내 포함"
    ws["H1"] = "SLM정답청크선택"

    widths = [5, 30, 20, 10, 10, 14, 10, 12, 10, 50, 10, 10, 10, 30, 10]
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = width

    print("데이터 분석 및 처리 중...")

    # 배경색 스타일 정의
    light_green_fill = PatternFill(
        start_color="CCFFCC", end_color="CCFFCC", fill_type="solid"
    )

    # 머지된 행 개수만큼 처리
    max_row = ws.max_row
    for row_start in range(2, max_row + 1, merge_rows):
        row_end = min(row_start + merge_rows - 1, max_row)

        # 병합 처리
        ws.merge_cells(
            start_row=row_start, start_column=7, end_row=row_end, end_column=7
        )
        ws.merge_cells(
            start_row=row_start, start_column=8, end_row=row_end, end_column=8
        )
        ws.merge_cells(
            start_row=row_start, start_column=9, end_row=row_end, end_column=9
        )
        ws.merge_cells(
            start_row=row_start, start_column=10, end_row=row_end, end_column=10
        )

        cell_c = ws.cell(row=row_start, column=3)  # 답변참조문서
        cell_d = ws.cell(row=row_start, column=4)  # 참조페이지
        cell_e = ws.cell(row=row_start, column=5)  # 검색TOPN 포함 여부
        cell_f = ws.cell(row=row_start, column=6)  # 검색TOPN포함
        cell_g = ws.cell(row=row_start, column=7)  # LLM전달 청크내 포함
        cell_h = ws.cell(row=row_start, column=8)  # SLM정답청크선택

        cell_e.alignment = Alignment(vertical="top")
        cell_f.alignment = Alignment(vertical="top")
        cell_g.alignment = Alignment(vertical="top")
        cell_h.alignment = Alignment(vertical="top")

        doc_page_pairs = pair_docs_and_pages(cell_c.value, cell_d.value)

        # top_n개씩 참조 데이터베이스 구축
        ref_db = dict()
        ref_db_color = dict()
        ref_db_llm_delivered = dict()
        ref_db_top5 = dict()
        top5_end = min(row_start + top_n - 1, row_end)

        for r_item in range(row_start, row_end + 1):
            cell_l = ws.cell(row=r_item, column=14)
            cell_m = ws.cell(row=r_item, column=15)

            file_val = normalize_val(cell_l.value)
            page_val = normalize_val(cell_m.value)

            if file_val and page_val:
                ref_db[(file_val, page_val)] = r_item
                if check_red(cell_l) and check_red(cell_m):
                    ref_db_color[(file_val, page_val)] = r_item
                if is_llm_delivered_chunk(cell_l) or is_llm_delivered_chunk(cell_m):
                    ref_db_llm_delivered[(file_val, page_val)] = r_item
                if r_item <= top5_end:
                    ref_db_top5[(file_val, page_val)] = r_item

        # 검증 로직
        # - 문서/페이지가 2개 이상 개행으로 구분되면, 같은 인덱스끼리 (문서, 페이지블록)으로 매칭
        # - 각 페이지블록은 parse_pages로 다중 페이지(쉼표/개행/범위)를 처리
        required_keys = set()
        for doc, page_block in doc_page_pairs:
            if not doc or not page_block:
                continue
            for page in parse_pages(page_block):
                if page:
                    required_keys.add((doc, page))

        if required_keys:
            found_count = 0
            referenced_count = 0
            llm_delivered_count = 0
            top5_count = 0
            total_items = len(required_keys)

            for key in required_keys:
                # 1. DB에 존재하는지 확인
                if key in ref_db:
                    found_count += 1
                    # 매칭된 행 색칠하기
                    r_item = ref_db[key]
                    for col in range(11, 16):
                        ws.cell(row=r_item, column=col).fill = light_green_fill

                # 2. 빨간색(SLM참조)인지 확인
                if key in ref_db_color:
                    referenced_count += 1

                # 3. 외곽선(LLM전달 청크)인지 확인
                if key in ref_db_llm_delivered:
                    llm_delivered_count += 1

                # 4. TOP5 안에 포함되는지 확인
                if key in ref_db_top5:
                    top5_count += 1

            # 조건 모드에 따른 결과 판정
            if condition_mode == "OR":
                # 하나라도 존재하면 True
                exist_bool = found_count > 0
                ref_bool = referenced_count > 0
                llm_bool = llm_delivered_count > 0
                top5_bool = top5_count > 0
            else:
                # AND: 모든 (문서,페이지) 아이템이 존재/참조되어야 True
                exist_bool = found_count == total_items
                ref_bool = referenced_count == total_items
                llm_bool = llm_delivered_count == total_items
                top5_bool = top5_count == total_items

            cell_e.value = "포함" if exist_bool else "미포함"
            cell_f.value = "포함" if top5_bool else "미포함"
            cell_g.value = "포함" if llm_bool else "미포함"
            cell_h.value = "선택" if ref_bool else "미선택"

        else:
            # 참조 문서나 페이지 정보가 없는 경우
            cell_e.value = "미포함"
            cell_f.value = "미포함"
            cell_g.value = "미포함"
            cell_h.value = "미선택"

    # 워크시트 추가
    try:
        statistics = wb.create_sheet(title="Statistics")
        wb._sheets.insert(0, wb._sheets.pop())

        statistics["A1"] = "총 질문 수"
        statistics["B1"] = "=COUNTA(Logs!A:A) - 1"
        statistics["A2"] = f"검색TOP{merge_rows}포함"
        statistics["B2"] = '=COUNTIF(Logs!E:E, "포함")'
        statistics["C2"] = "=B2/B1"
        statistics["A3"] = f"검색TOP{top_n}포함"
        statistics["B3"] = '=COUNTIF(Logs!F:F, "포함")'
        statistics["C3"] = "=B3/B1"
        statistics["A4"] = "LLM전달 청크내 포함"
        statistics["B4"] = '=COUNTIF(Logs!G:G, "포함")'
        statistics["C4"] = "=B4/B1"
        statistics["A5"] = "SLM정답청크선택"
        statistics["B5"] = '=COUNTIF(Logs!H:H, "선택")'
        statistics["C5"] = "=B5/B1"

        # C2~C5를 %로 표시
        statistics["C2"].number_format = "0.00%"
        statistics["C3"].number_format = "0.00%"
        statistics["C4"].number_format = "0.00%"
        statistics["C5"].number_format = "0.00%"

        statistics.column_dimensions["A"].width = 20
    except Exception as e:
        print(f"워크시트 추가 중 오류 발생: {e}")

    # 5. 저장
    try:
        wb.save(output_file)
        print(f"완료! 결과가 '{output_file}'(으)로 저장되었습니다.")
    except Exception as e:
        print(f"저장 중 오류 발생: {e}")


# --- 메인 실행 블록 ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="엑셀 로그 파일을 처리하고 검증 결과를 출력합니다.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예제:
  python 3.score_output_excel.py -i input.xlsx
  python 3.score_output_excel.py -i input.xlsx -o output.xlsx
  python 3.score_output_excel.py -i input.xlsx -m AND
  python 3.score_output_excel.py -i input.xlsx -m AND -r 3
  python 3.score_output_excel.py -i input.xlsx -t 3
        """,
    )

    parser.add_argument(
        "-i", "--input", required=True, dest="input_file", help="입력 엑셀 파일 경로"
    )
    parser.add_argument(
        "-o",
        "--output",
        dest="output_file",
        default=None,
        help="출력 엑셀 파일 경로 (기본값: 입력파일_correct.xlsx)",
    )
    parser.add_argument(
        "-m",
        "--mode",
        dest="condition_mode",
        choices=["AND", "OR"],
        default="OR",
        help="조건 모드: AND는 모든 항목이 일치해야 함, OR는 하나라도 일치하면 됨 (기본값: OR)",
    )
    parser.add_argument(
        "-r",
        "--rows",
        dest="merge_rows",
        type=int,
        default=None,
        help="머지할 행 개수 (미지정 시 엑셀 파일에서 자동 감지)",
    )
    parser.add_argument(
        "-t",
        "--top",
        dest="top_n",
        type=int,
        default=5,
        help="검색TOP N 포함 여부 판정 기준 개수 (기본값: 5)",
    )

    args = parser.parse_args()

    input_path = args.input_file

    # 출력 파일명 자동 생성
    if args.output_file:
        output_path = args.output_file
    else:
        filename, ext = os.path.splitext(input_path)
        output_path = f"{filename}_correct{ext}"

    process_excel_log(
        input_path, output_path, args.condition_mode, args.merge_rows, args.top_n
    )
