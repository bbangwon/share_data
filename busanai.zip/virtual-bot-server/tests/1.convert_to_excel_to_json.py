import argparse
import json
import os

import openpyxl


def format_as_int_string(value):
    try:
        f_val = float(value)

        if f_val.is_integer():
            return str(int(f_val))
        else:
            return str(f_val)
    except (ValueError, TypeError):
        return str(value)


def convert_excel_to_json(input_filename, output_filename, max_rows=None):
    try:
        # 1. 엑셀 파일 로드 (data_only=True는 수식이 아닌 값을 가져옴)
        wb = openpyxl.load_workbook(input_filename, data_only=True)
        ws = wb["제출내역"]  # 제출내역 워크시트 선택

        # 2. '질의문' 헤더 찾기
        # 몇 번째 행, 몇 번째 열에 '질의문'이 있는지 찾습니다.
        header_row_index = -1
        number_index = -1
        question_col_index = -1
        check_point_index = -1
        ref_doc_index = -1
        ref_doc_page_index = -1

        for r_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
            # 행(row) 안에 '질의문'이라는 텍스트가 있는지 확인
            if "질의문" in row:
                header_row_index = r_idx
                number_index = row.index("순번")
                question_col_index = row.index("질의문")
                check_point_index = row.index("체크사항")
                ref_doc_index = row.index("답변 참조 문서명")
                ref_doc_page_index = row.index("참조 페이지")
                break

        if header_row_index == -1:
            print("오류: 엑셀 파일에서 '질의문' 헤더를 찾을 수 없습니다.")
            return

        # 3. 데이터 변환
        formatted_data = []
        processed_count = 0

        # 헤더 다음 행부터 데이터를 읽어옵니다.
        for row in ws.iter_rows(min_row=header_row_index + 1, values_only=True):
            # max_rows가 지정되었고 이미 충분히 처리했으면 종료
            if max_rows is not None and processed_count >= max_rows:
                break

            if row[check_point_index] != "참조문서확정":
                continue

            number_text = row[number_index]
            question_text = row[question_col_index]
            ref_doc_text = row[ref_doc_index]
            ref_doc_page_text = format_as_int_string(row[ref_doc_page_index])

            # 내용이 없으면 건너뜀
            if question_text is None or str(question_text).strip() == "":
                continue

            # 질문 객체
            question_obj = {
                "number": int(number_text),
                "text": str(question_text),
                "ref_doc": str(ref_doc_text),
                "ref_page": str(ref_doc_page_text),
            }

            formatted_data.append(question_obj)
            processed_count += 1

        # 4. JSON 파일 저장
        with open(output_filename, "w", encoding="utf-8") as f:
            json.dump(formatted_data, f, ensure_ascii=False, indent=2)

        print(f"변환 완료! '{output_filename}' 파일이 생성되었습니다.")
        print(f"총 {len(formatted_data)}개의 질문이 처리되었습니다.")

    except FileNotFoundError:
        print(f"오류: 입력 파일 '{input_filename}'을(를) 찾을 수 없습니다.")
    except Exception as e:
        print(f"오류 발생: {e}")


if __name__ == "__main__":
    # argparse 설정
    parser = argparse.ArgumentParser(
        description="엑셀 파일을 JSON 형식으로 변환합니다.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  python %(prog)s -i input.xlsx
  python %(prog)s -i input.xlsx -o output.json
  python %(prog)s -i input.xlsx -o output.json -r 3
        """,
    )

    parser.add_argument(
        "-i",
        "--input",
        required=True,
        help="변환할 엑셀 파일 경로 (필수)",
        metavar="FILE",
    )

    parser.add_argument(
        "-o",
        "--output",
        help="출력할 JSON 파일 경로 (기본값: 입력 파일명.json)",
        metavar="FILE",
    )

    parser.add_argument(
        "-r",
        "--rows",
        type=int,
        help="변환할 최대 행 개수 (기본값: 전체)",
        metavar="N",
    )

    args = parser.parse_args()

    # 입력 파일
    input_file = args.input

    # 출력 파일 (지정되지 않았으면 입력 파일명에서 확장자를 .json으로 변경)
    if args.output:
        output_file = args.output
    else:
        base_name = os.path.splitext(input_file)[0]
        output_file = base_name + ".json"

    # 변환 실행
    convert_excel_to_json(input_file, output_file, max_rows=args.rows)
