import argparse
import os
import re
import sys

import openpyxl
from openpyxl.styles import Alignment

THRESHOLD_SHEET_NAME = "LLM Threshold Analysis"
DEFAULT_THRESHOLD_MIN = 0.0
DEFAULT_THRESHOLD_MAX = 1.0
DEFAULT_THRESHOLD_STEP = 0.05
MULTI_NEWLINE_SPLIT_RE = re.compile(r"(?:\n[ \t]*){2,}")
SCORE_NUMBER_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")


def normalize_val(val):
    if val is None:
        return ""
    if isinstance(val, float) and val.is_integer():
        return str(int(val))
    return str(val).strip()


def parse_pages(page_str):
    pages = set()
    s = str(page_str).strip()
    if not s or s.lower() == "nan" or s == "none":
        return pages

    s = s.replace("\r\n", "\n").replace("\r", "\n")
    parts = re.split(r"[,\n]+", s)
    for part in parts:
        part = part.strip()
        if not part:
            continue

        for token in [p for p in re.split(r"\s+", part) if p]:
            if "~" in token:
                try:
                    start_s, end_s = re.split(r"\s*~\s*", token, maxsplit=1)
                    start = int(start_s)
                    end = int(end_s)
                    for page in range(start, end + 1):
                        pages.add(str(page))
                except ValueError:
                    pages.add(token)
            else:
                pages.add(token)
    return pages


def split_by_multi_newlines(val):
    if val is None:
        return []

    s = str(val).replace("\r\n", "\n").replace("\r", "\n").strip()
    if not s or s.lower() == "nan" or s == "none":
        return []

    blocks = [block.strip() for block in MULTI_NEWLINE_SPLIT_RE.split(s)]
    return [block for block in blocks if block]


def pair_docs_and_pages(doc_val, page_val):
    doc_blocks = split_by_multi_newlines(doc_val)
    page_blocks = split_by_multi_newlines(page_val)

    if not doc_blocks and not page_blocks:
        return []

    if not doc_blocks:
        doc_blocks = [""]
    if not page_blocks:
        page_blocks = [""]

    if len(doc_blocks) == len(page_blocks):
        pairs = zip(doc_blocks, page_blocks)
    elif len(doc_blocks) == 1:
        pairs = ((doc_blocks[0], page_block) for page_block in page_blocks)
    elif len(page_blocks) == 1:
        pairs = ((doc_block, page_blocks[0]) for doc_block in doc_blocks)
    else:
        pairs = zip(doc_blocks, page_blocks)

    normalized_pairs = []
    for doc, page in pairs:
        doc_norm = normalize_val(doc)
        page_norm = normalize_val(page)
        if doc_norm or page_norm:
            normalized_pairs.append((doc_norm, page_norm))
    return normalized_pairs


def build_required_keys(doc_val, page_val):
    required_keys = set()
    for doc, page_block in pair_docs_and_pages(doc_val, page_val):
        if not doc or not page_block:
            continue
        for page in parse_pages(page_block):
            if page:
                required_keys.add((doc, page))
    return required_keys


def parse_score_value(val):
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)

    match = SCORE_NUMBER_RE.search(str(val))
    if not match:
        return None

    try:
        return float(match.group())
    except ValueError:
        return None


def detect_merge_rows(ws):
    if not ws.merged_cells or not ws.merged_cells.ranges:
        return 5

    for merged_range in ws.merged_cells.ranges:
        try:
            if merged_range.min_row >= 2:
                return merged_range.max_row - merged_range.min_row + 1
        except Exception:
            continue
    return 5


def find_header_column(ws, candidates):
    normalized_candidates = {candidate.strip().lower() for candidate in candidates}
    for column_index in range(1, ws.max_column + 1):
        header_value = normalize_val(ws.cell(row=1, column=column_index).value).lower()
        if header_value in normalized_candidates:
            return column_index
    return None


def find_logs_sheet(workbook):
    if "Logs" in workbook.sheetnames:
        return workbook["Logs"]
    return workbook.active


def check_llm_delivered(cell):
    border = cell.border
    if not border:
        return False
    for side in (border.left, border.right, border.top, border.bottom):
        if side and side.style == "thick":
            return True
    return False


def build_threshold_values(threshold_min, threshold_max, threshold_step):
    if threshold_step <= 0:
        raise ValueError("threshold-step must be greater than 0")
    if threshold_min > threshold_max:
        raise ValueError("threshold-min cannot be greater than threshold-max")

    values = []
    current = threshold_min
    epsilon = threshold_step / 10
    while current <= threshold_max + epsilon:
        values.append(round(current, 10))
        current += threshold_step
    return values


def find_result_column(ws, header_prefix):
    for column_index in range(1, ws.max_column + 1):
        header_value = normalize_val(ws.cell(row=1, column=column_index).value)
        if header_value.startswith(header_prefix):
            return column_index
    return None


def build_group_ranges(ws, merge_rows):
    max_row = ws.max_row
    return [
        (row_start, min(row_start + merge_rows - 1, max_row))
        for row_start in range(2, max_row + 1, merge_rows)
    ]


def evaluate_llm_inclusion(required_keys, chunk_keys, condition_mode):
    if not required_keys:
        return False

    matched_count = sum(1 for key in required_keys if key in chunk_keys)
    if condition_mode == "AND":
        return matched_count == len(required_keys)
    return matched_count > 0


def collect_group_metadata(ws, group_ranges, score_col, file_col, page_col):
    metadata = []
    for row_start, row_end in group_ranges:
        required_keys = build_required_keys(
            ws.cell(row=row_start, column=3).value,
            ws.cell(row=row_start, column=4).value,
        )

        candidate_rows = []
        for row_index in range(row_start, row_end + 1):
            score_value = parse_score_value(
                ws.cell(row=row_index, column=score_col).value
            )
            file_value = normalize_val(ws.cell(row=row_index, column=file_col).value)
            page_value = normalize_val(ws.cell(row=row_index, column=page_col).value)
            llm_delivered = check_llm_delivered(
                ws.cell(row=row_index, column=file_col)
            ) or check_llm_delivered(ws.cell(row=row_index, column=page_col))
            candidate_rows.append(
                {
                    "score": score_value,
                    "key": (file_value, page_value)
                    if file_value and page_value
                    else None,
                    "llm_delivered": llm_delivered,
                }
            )

        metadata.append(
            {
                "row_start": row_start,
                "required_keys": required_keys,
                "candidate_rows": candidate_rows,
            }
        )
    return metadata


def analyze_thresholds(group_metadata, thresholds, condition_mode):
    total_questions = len(group_metadata)
    questions_with_answer_key = sum(
        1 for item in group_metadata if item["required_keys"]
    )
    analysis_rows = []

    for threshold in thresholds:
        eligible_questions = 0
        llm_included_count = 0

        for group in group_metadata:
            required_keys = group["required_keys"]
            if not required_keys:
                continue

            chunk_keys = set()
            has_eligible_row = False
            for candidate in group["candidate_rows"]:
                score_value = candidate["score"]
                key = candidate["key"]
                if score_value is None or score_value <= threshold or key is None:
                    continue
                has_eligible_row = True
                if candidate["llm_delivered"]:
                    chunk_keys.add(key)

            if not has_eligible_row:
                continue

            eligible_questions += 1
            if evaluate_llm_inclusion(required_keys, chunk_keys, condition_mode):
                llm_included_count += 1

        total_ratio = llm_included_count / total_questions if total_questions else 0
        eligible_ratio = (
            llm_included_count / eligible_questions if eligible_questions else 0
        )
        analysis_rows.append(
            [
                threshold,
                total_questions,
                questions_with_answer_key,
                eligible_questions,
                llm_included_count,
                total_ratio,
                eligible_ratio,
            ]
        )

    return analysis_rows


def write_threshold_sheet(workbook, rows):
    if THRESHOLD_SHEET_NAME in workbook.sheetnames:
        workbook.remove(workbook[THRESHOLD_SHEET_NAME])

    sheet = workbook.create_sheet(title=THRESHOLD_SHEET_NAME)
    headers = [
        "score 임계값",
        "전체 질문 수",
        "정답키 보유 질문 수",
        "채점 대상 질문 수",
        "LLM전달 청크내 포함 개수",
        "전체 대비 비율",
        "채점 대상 대비 비율",
    ]
    sheet.append(headers)

    for row in rows:
        sheet.append(row)

    for row_index in range(2, sheet.max_row + 1):
        sheet.cell(row=row_index, column=1).number_format = "0.00"
        sheet.cell(row=row_index, column=6).number_format = "0.00%"
        sheet.cell(row=row_index, column=7).number_format = "0.00%"

    widths = [14, 14, 18, 18, 24, 14, 16]
    for column_index, width in enumerate(widths, start=1):
        sheet.column_dimensions[
            openpyxl.utils.get_column_letter(column_index)
        ].width = width
    return sheet


def apply_single_threshold_result(ws, group_metadata, threshold, condition_mode):
    header = f"LLM전달 청크내 포함(score>{threshold:.2f})"
    target_col = None
    for column_index in range(1, ws.max_column + 1):
        if normalize_val(ws.cell(row=1, column=column_index).value) == header:
            target_col = column_index
            break

    if target_col is None:
        target_col = ws.max_column + 1
        ws.cell(row=1, column=target_col).value = header

    ws.column_dimensions[openpyxl.utils.get_column_letter(target_col)].width = 24

    for group in group_metadata:
        row_start = group["row_start"]
        required_keys = group["required_keys"]
        chunk_keys = set()
        has_eligible_row = False

        for candidate in group["candidate_rows"]:
            score_value = candidate["score"]
            key = candidate["key"]
            if score_value is None or score_value <= threshold or key is None:
                continue
            has_eligible_row = True
            if candidate["llm_delivered"]:
                chunk_keys.add(key)

        cell = ws.cell(row=row_start, column=target_col)
        cell.alignment = Alignment(vertical="top")
        if not required_keys or not has_eligible_row:
            cell.value = "미포함"
        else:
            cell.value = (
                "포함"
                if evaluate_llm_inclusion(required_keys, chunk_keys, condition_mode)
                else "미포함"
            )

    return target_col


def process_workbook(
    input_file,
    output_file,
    condition_mode,
    merge_rows,
    threshold_min,
    threshold_max,
    threshold_step,
    apply_threshold,
):
    try:
        workbook = openpyxl.load_workbook(input_file)
    except FileNotFoundError:
        print(f"오류: 입력 파일 '{input_file}'을(를) 찾을 수 없습니다.")
        sys.exit(1)
    except Exception as exc:
        print(f"오류: 엑셀 파일을 읽는 중 문제가 발생했습니다: {exc}")
        sys.exit(1)

    ws = find_logs_sheet(workbook)
    if merge_rows is None:
        merge_rows = detect_merge_rows(ws)

    score_col = find_header_column(ws, ["score"])
    file_col = find_header_column(ws, ["file"])
    page_col = find_header_column(ws, ["page_num", "page"])

    if score_col is None or file_col is None or page_col is None:
        print("오류: score/file/page_num 헤더를 찾지 못했습니다.")
        sys.exit(1)

    group_ranges = build_group_ranges(ws, merge_rows)
    group_metadata = collect_group_metadata(
        ws, group_ranges, score_col, file_col, page_col
    )
    thresholds = build_threshold_values(threshold_min, threshold_max, threshold_step)
    analysis_rows = analyze_thresholds(group_metadata, thresholds, condition_mode)
    write_threshold_sheet(workbook, analysis_rows)

    if apply_threshold is not None:
        apply_single_threshold_result(
            ws, group_metadata, apply_threshold, condition_mode
        )

    workbook.save(output_file)
    print(f"완료: '{output_file}' 파일로 저장했습니다.")
    print(
        f"임계값 분석 범위: {threshold_min:.2f} ~ {threshold_max:.2f}, step={threshold_step:.2f}, merge_rows={merge_rows}"
    )
    if apply_threshold is not None:
        print(
            f"Logs 시트에 단일 임계값 결과 열도 추가했습니다. threshold={apply_threshold:.2f}"
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="3.score_output_excel.py 결과 엑셀을 입력으로 받아 score 임계값별 LLM 전달 청크 포함 개수를 계산합니다."
    )
    parser.add_argument(
        "-i", "--input", required=True, dest="input_file", help="입력 엑셀 파일 경로"
    )
    parser.add_argument(
        "-o",
        "--output",
        dest="output_file",
        default=None,
        help="출력 엑셀 파일 경로 (기본값: 입력파일_threshold.xlsx)",
    )
    parser.add_argument(
        "-m",
        "--mode",
        dest="condition_mode",
        choices=["AND", "OR"],
        default="OR",
        help="정답 판정 모드 (기본값: OR)",
    )
    parser.add_argument(
        "-r",
        "--rows",
        dest="merge_rows",
        type=int,
        default=None,
        help="질문당 머지 행 개수 (미지정 시 자동 감지)",
    )
    parser.add_argument(
        "--threshold-min",
        dest="threshold_min",
        type=float,
        default=DEFAULT_THRESHOLD_MIN,
        help="임계값 시작값 (기본값: 0.0)",
    )
    parser.add_argument(
        "--threshold-max",
        dest="threshold_max",
        type=float,
        default=DEFAULT_THRESHOLD_MAX,
        help="임계값 종료값 (기본값: 1.0)",
    )
    parser.add_argument(
        "--threshold-step",
        dest="threshold_step",
        type=float,
        default=DEFAULT_THRESHOLD_STEP,
        help="임계값 증가 간격 (기본값: 0.05)",
    )
    parser.add_argument(
        "--apply-threshold",
        dest="apply_threshold",
        type=float,
        default=None,
        help="지정 시 Logs 시트에 해당 임계값 기준 결과 열을 추가합니다.",
    )

    args = parser.parse_args()

    input_path = args.input_file
    if args.output_file:
        output_path = args.output_file
    else:
        filename, ext = os.path.splitext(input_path)
        output_path = f"{filename}_threshold{ext}"

    process_workbook(
        input_file=input_path,
        output_file=output_path,
        condition_mode=args.condition_mode,
        merge_rows=args.merge_rows,
        threshold_min=args.threshold_min,
        threshold_max=args.threshold_max,
        threshold_step=args.threshold_step,
        apply_threshold=args.apply_threshold,
    )
