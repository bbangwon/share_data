import logging

from busan_bot_ui.static_messages import StaticMessageType
from dotenv import load_dotenv
from request_queue import (
    AsyncRedisQueueWorker,
    RequestQueueItem,
    get_redis_queue_worker_using_env,
)

from app.core.task_manager import get_task_manager_using_env

QUEUE_NAME_REQUEST = "request_queue"

load_dotenv()
logger = logging.getLogger(__name__)


class EnqueueTaskWorker:
    def __init__(self, max_workers: int = 1):
        self.task_manager = get_task_manager_using_env()
        self.max_workers = max_workers

    def _verify_request_item(self, item: RequestQueueItem) -> bool:
        """요청의 유효성을 검증합니다."""
        logger.debug("요청 검증을 시작합니다.")
        if not item.get_user_id():
            logger.error("사용자 ID가 없습니다.")
            return False

        if not item.get_bot_id():
            logger.error("봇 ID가 없습니다.")
            return False

        logger.info("요청 검증에 성공했습니다.")
        return True

    async def _check_available_task(self, item: RequestQueueItem) -> bool:
        user_id = item.get_user_id()
        bot_id = item.get_bot_id()

        status = await self.task_manager.get_task_status(user_id=user_id, bot_id=bot_id)
        if status == "processing" or status == "ready":
            await self.task_manager.bot_manager.send_typed_error_message(
                bot_id=bot_id,
                user_id=user_id,
                type=StaticMessageType.ERR_ALREADY_PROCESSING.value,
                send_with_admin=False,
                only_send_to_admin=False,
            )

            logger.info("이미 처리 중인 작업이 있습니다.")
            return False
        return True

    async def _enqueue_task_processor(self, item: RequestQueueItem):
        """
        요청 큐에서 작업을 처리하는 함수
        """
        try:
            # 요청 아이템을 검증합니다.
            if not self._verify_request_item(item):
                logger.error(f"요청 검증 실패: {item}")
                return

            if not await self._check_available_task(item):
                logger.info("처리 가능한 작업이 아닙니다. 건너뜁니다.")
                return

            # 작업 처리 로직
            task_type = await self.task_manager.enqueue_task(item)

            logger.info(
                f"작업이 큐에 추가되었습니다. 작업 유형: {task_type}, 아이템: {item}"
            )

            # 최대치에 도달한 경우 대기해야 한다는 메세지를 보냄
            if task_type == "task":
                available_process = await self.task_manager.available_process_tasks()
                if not available_process:
                    user_id = item.get_user_id()
                    bot_id = item.get_bot_id()

                    await self.task_manager.bot_manager.send_typed_text_message(
                        bot_id=bot_id,
                        user_id=user_id,
                        type=StaticMessageType.TXT_RECEIVED_MESSAGE.value,
                        review_start_service=False,
                    )

        except Exception as e:
            logger.error(f"작업 처리 중 오류 발생 {item}: {e}")
            raise e

    async def start(self):
        request_queue: AsyncRedisQueueWorker = get_redis_queue_worker_using_env(
            env_name_redis_url="REQUEST_REDIS_URL",
            item_class=RequestQueueItem,
            item_processor=self._enqueue_task_processor,
        )

        # 워커 시작 (백그라운드에서 실행)
        request_queue.start(
            queue_name=QUEUE_NAME_REQUEST,
            max_workers=self.max_workers,
        )

        await request_queue.wait_until_stopped()
