import copy
import json
import logging
from enum import Enum

from busan_bot_ui import (
    ActionData,
    Button,
    ButtonCarousel,
    ButtonContainer,
    ButtonTemplate,
    MainCarousel,
    MessageActionData,
    PostbackActionData,
    UriActionData,
)
from db_manager import ChatHistory, StaticFeedback
from dotenv import load_dotenv
from naver_works_bot import (
    TextContent,
)
from naver_works_bot.bot.schemas.contents.base import ContentBase
from pydantic import BaseModel, Field

load_dotenv()
logger = logging.getLogger(__name__)

NO_RECENT_QUESTIONS = "최근 부기주무관에 문의한 질문 내역이 없습니다."


class MessageType(Enum):
    """메시지 타입 Enum"""

    TEXT = "text"
    """일반 텍스트 메시지 타입. 텍스트 콘텐츠를 출력합니다."""
    MAIN_CAROUSEL = "main_carousel"
    """메인 캐러셀 메시지 타입. 메인 캐러셀 콘텐츠를 출력합니다."""
    CAROUSEL_COLUMN = "carousel_column"
    """캐러셀 컬럼 메시지 타입."""
    BUTTON_CAROUSEL = "button_carousel"
    """버튼 캐러셀 메시지 타입. 버튼 캐러셀 콘텐츠를 출력합니다."""
    BUTTON = "button"
    """버튼 메시지 타입. 버튼 콘텐츠를 출력합니다."""
    BUTTON_TEMPLATE = "button_template"
    """버튼 템플릿 메시지 타입. 버튼 템플릿 콘텐츠를 출력합니다."""
    POSTBACK = "postback"
    """포스트백 메시지 타입. 포스트백 액션 데이터를 포함합니다."""
    URI = "uri"
    """URI 메시지 타입. UriActionData를 포함합니다."""
    MESSAGE = "message"
    """메시지 액션 데이터 타입. MessageActionData를 포함합니다."""


class FeedbackItemProcessor:
    class Config(BaseModel):
        """피드백 아이템 처리 설정 클래스"""

        main_color: str = Field(..., description="UI 색상 설정")
        button_text_color: str = Field(
            "#FFFFFF",
            description="버튼 텍스트 색상 설정",
        )

    def __init__(self, config: Config):
        """피드백 아이템 프로세서 초기화"""
        self.config = config

    def _get_action_data_from_feedback(
        self, feedback: StaticFeedback
    ) -> ActionData | None:
        """피드백에서 액션 데이터 추출"""
        content = json.loads(feedback.content)
        if feedback.message_type == MessageType.POSTBACK.value:
            if "data" in content:  # data가 없는 경우도 있어서 조건문 추가
                return PostbackActionData(**content)
            else:
                return PostbackActionData(
                    **content,
                    data=feedback.to_postback,
                )
        elif feedback.message_type == MessageType.MESSAGE.value:
            if "postback" in content:  # postback이 없는 경우도 있어서 조건문 추가
                return MessageActionData(**content)
            else:
                return MessageActionData(
                    **content,
                    postback=feedback.to_postback if feedback.to_postback else None,
                )
        elif feedback.message_type == MessageType.URI.value:
            return UriActionData(
                **content,
            )
        return None

    def _get_action_datas_from_feedback(
        self, feedback: StaticFeedback
    ) -> list[ActionData]:
        """피드백에서 액션 데이터 추출"""
        return [
            action_data
            for feedback_child in feedback.children
            if (action_data := self._get_action_data_from_feedback(feedback_child))
        ]

    def _process_text_feedback(self, config: Config, feedback: StaticFeedback):
        """텍스트 피드백 처리"""
        logger.info(f"텍스트 피드백 처리: {feedback}")

        return TextContent.from_text(feedback.content)

    def _process_main_carousel_feedback(self, config: Config, feedback: StaticFeedback):
        """메인 캐러셀 피드백 처리"""

        logger.info(f"메인 캐러셀 피드백 처리: {feedback}")
        if not feedback.children:
            logger.warning(f"메인 캐러셀에 자식 아이템이 없습니다: {feedback}")
            return None

        columns = []
        for column in feedback.children:
            if column.message_type != MessageType.CAROUSEL_COLUMN.value:
                logger.warning(
                    f"메인 캐러셀 컬럼이 아닌 피드백 아이템이 있습니다: {column}"
                )
                continue

            columns.append(
                MainCarousel.Data.Column(
                    **json.loads(column.content),
                    color=config.main_color,
                    action_datas=self._get_action_datas_from_feedback(column),
                )
            )

        return MainCarousel.from_data(
            data=MainCarousel.Data(
                **json.loads(feedback.content),
                columns=columns,
            )
        )

    def _process_button_template_feedback(
        self, config: Config, feedback: StaticFeedback
    ):
        """버튼 템플릿 피드백 처리"""
        logger.info(f"버튼 템플릿 피드백 처리: {feedback}")
        if not feedback.children:
            logger.warning(f"버튼 템플릿에 버튼 아이템이 없습니다: {feedback}")
            return None

        return ButtonTemplate.from_data(
            data=ButtonTemplate.Data(
                **json.loads(feedback.content),
                action_datas=self._get_action_datas_from_feedback(feedback),
                color=config.main_color,
            )
        )

    def _create_button_container_data(
        self, config: Config, feedback: StaticFeedback
    ) -> ButtonContainer.Data | None:
        """버튼 컨테이너 데이터 추출"""
        logger.info(f"버튼 컨테이너 데이터 추출: {feedback}")

        if not feedback.children:
            logger.warning(f"버튼 컨테이너에 자식 아이템이 없습니다: {feedback}")
            return None

        return ButtonContainer.Data(
            **json.loads(feedback.content),
            text_color=config.button_text_color,
            color=config.main_color,
            action_data=self._get_action_data_from_feedback(feedback.children[0]),
        )

    def _button_carousel_feedback(self, config: Config, feedback: StaticFeedback):
        """버튼 캐러셀 피드백 처리"""
        logger.info(f"버튼 캐러셀 피드백 처리: {feedback}")
        if not feedback.children:
            logger.warning(f"버튼 캐러셀에 버튼 아이템이 없습니다: {feedback}")
            return None

        button_datas = []
        for button in feedback.children:
            if button.message_type != MessageType.BUTTON.value:
                logger.warning(
                    f"버튼 캐러셀 버튼이 아닌 피드백 아이템이 있습니다: {button}"
                )
                continue

            button_datas.append(
                self._create_button_container_data(
                    config=config,
                    feedback=button,
                )
            )

        return ButtonCarousel.from_data(
            data=ButtonCarousel.Data(
                **json.loads(feedback.content),
                button_datas=button_datas,
            )
        )

    def _button_feedback(self, config: Config, feedback: StaticFeedback):
        """버튼 피드백 처리"""
        logger.info(f"버튼 피드백 처리: {feedback}")

        button_data = (
            self._create_button_container_data(
                config=config,
                feedback=feedback,
            ),
        )

        # 버튼 생성
        return Button.from_data(
            data=Button.Data(
                **json.loads(feedback.content),
                button_data=button_data,
            )
        )

    def process(self, feedback_items: list[StaticFeedback]) -> list[ContentBase] | None:
        """피드백 아이템을 처리하여 콘텐츠 목록을 생성"""

        if not feedback_items:
            logger.warning("피드백 아이템이 비어 있습니다.")
            return None

        send_contexts = []
        for feedback_item in feedback_items:
            logger.info(f"피드백 아이템 처리: {feedback_item}")

            send_context = None

            if feedback_item.message_type == MessageType.TEXT.value:
                send_context = self._process_text_feedback(self.config, feedback_item)

            elif feedback_item.message_type == MessageType.MAIN_CAROUSEL.value:
                send_context = self._process_main_carousel_feedback(
                    self.config, feedback_item
                )

            elif feedback_item.message_type == MessageType.BUTTON_CAROUSEL.value:
                send_context = self._button_carousel_feedback(
                    self.config, feedback_item
                )

            elif feedback_item.message_type == MessageType.BUTTON_TEMPLATE.value:
                send_context = self._process_button_template_feedback(
                    self.config, feedback_item
                )

            elif feedback_item.message_type == MessageType.BUTTON.value:
                send_context = self._button_feedback(
                    config=self.config,
                    feedback=feedback_item,
                )

            if send_context:
                send_contexts.append(send_context)

        return send_contexts

    def process_recent_question_list(
        self, feedback_items: list[StaticFeedback], chat_histories: list[ChatHistory]
    ) -> list[ContentBase] | None:
        """최근 질문을 처리하여 최근 질문 목록을 생성"""

        def update_button_message(
            chat_info: dict[str, str], button_template: StaticFeedback
        ) -> ButtonContainer:
            """질문에 대한 버튼 템플릿 생성 (질문은 300자까지만 들어감)"""

            user_message = chat_info["user_message"]
            # DB에서 바로 가져오도록 postback 생성
            postback = f"recent_questions:{chat_info['chat_session_id']}:{chat_info['chat_number']}"

            button = copy.deepcopy(button_template)
            button.content = json.dumps({"text": user_message})

            button_action = button.children[0]
            json_data = json.loads(button_action.content)
            json_data["text"] = user_message
            json_data["postback"] = postback
            button.children[0].content = json.dumps(json_data)
            return button

        history_infos = [
            {
                "chat_session_id": chat_history.chat_session_id,
                "chat_number": chat_history.chat_number,
                "user_message": (
                    chat_history.user_message_summary
                    if chat_history.user_message_summary
                    else chat_history.user_message
                ),
            }
            for chat_history in chat_histories
        ]

        # 질문이 300자를 초과하는 것들은 제외하기
        history_infos = [
            info for info in history_infos if len(info["user_message"]) <= 300
        ]

        # 파일 정보가 추가된 질문들도 제외하기
        history_infos = [
            info
            for info in history_infos
            if info["user_message"][:13] != "--- 파일 정보 ---"
        ]

        if not history_infos:
            logger.warning(NO_RECENT_QUESTIONS)
            feedback_items = [
                StaticFeedback(
                    message_type=MessageType.TEXT.value,
                    content=NO_RECENT_QUESTIONS,
                    sort_number=1,
                )
            ]
        else:
            # find button carousel template
            button_carousel_template = next(
                (
                    item
                    for item in feedback_items
                    if item.message_type == MessageType.BUTTON_CAROUSEL.value
                ),
                None,
            )

            if not button_carousel_template:
                logger.error("버튼 캐러셀이 없습니다.")
                return None

            if not button_carousel_template.children:
                logger.error("버튼 캐러셀에 버튼이 없습니다.")
                return None

            button_template = button_carousel_template.children[0]

            new_button_carousel = copy.deepcopy(button_carousel_template)
            new_button_carousel.children.clear()
            new_button_carousel.children.extend(
                update_button_message(history_info, button_template)
                for history_info in history_infos[:10]
            )  # 최대 10개 까지만 질문 추가

            feedback_items.remove(
                button_carousel_template
            )  # 기존 버튼 캐러셀 템플릿 제거 (사실상 업데이트..)
            feedback_items.append(new_button_carousel)

        return self.process(
            feedback_items=feedback_items,
        )
