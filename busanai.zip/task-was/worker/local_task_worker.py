import asyncio
import logging
import os

import httpx
from admin_db_manager import ChatbotTypeEnum, get_admin_db_manager_using_env
from busan_bot_ui import BusanBotUIManager
from busan_bot_ui.static_messages import StaticMessageType
from busan_bot_ui.utils import get_service_url
from db_manager import get_db_manager_using_env
from dotenv import load_dotenv

from app.core import get_task_manager_using_env
from app.schemas.tasks import CompleteTask, Task

load_dotenv()
logger = logging.getLogger(__name__)

SIMULATE_TASK_PROCESSING_TIME_SEC = 5


class LocalTaskWorker:
    def __init__(self, max_workers: int = 1):
        self.task_was_base_url = os.getenv("TASK_WAS_BASE_URL")
        if not self.task_was_base_url:
            raise ValueError("TASK_WAS_BASE_URL 환경 변수가 설정되지 않았습니다.")

        self.task_manager = get_task_manager_using_env()

        self.max_workers = max_workers
        self.semaphore = asyncio.Semaphore(max_workers)

        self.running = False
        self._event = asyncio.Event()

        self.bot_manager = BusanBotUIManager()
        self.db_manager = get_db_manager_using_env()
        self.admin_db_manager = get_admin_db_manager_using_env()

    async def _get_next_task(self) -> Task | None:
        """다음 작업을 가져오는 함수입니다.
        이 함수는 Task WAS에서 다음 작업을 가져옵니다."""

        logger.info("다음 작업을 요청합니다.")
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{self.task_was_base_url}/api/v1/tasks/next")
            response.raise_for_status()

            if response.status_code == httpx.codes.OK:
                return Task(**response.json())
            elif response.status_code == httpx.codes.NO_CONTENT:
                logger.info("작업이 없습니다.")
                return None

    async def _complete_task(self, task_id: str, complete_task: CompleteTask):
        """작업을 완료하는 함수입니다.
        이 함수는 Task WAS에 작업 완료 요청을 보냅니다."""
        logger.info(f"작업 완료 요청: {task_id}, 완료정보 {complete_task}")

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.task_was_base_url}/api/v1/tasks/{task_id}/complete",
                json=complete_task.model_dump(),
            )
            response.raise_for_status()

            if response.status_code == httpx.codes.OK:
                logger.info(f"파일 작업 완료: {task_id}")
            else:
                logger.error(
                    f"파일 작업 완료 실패: {task_id}, 상태 코드: {response.status_code}"
                )

    async def get_waiting_message_by_bot_id(self, bot_id: str) -> str | None:
        """
        지정한 bot_id에 대해 bot_meta를 가져오고 admin_db_manager를 사용하여
        해당 bot_service에 대한 최신 waiting_message를 반환합니다.
        """

        bot_meta_info = self.bot_manager.get_bot_meta_info(bot_id=bot_id)
        if not bot_meta_info or not bot_meta_info.service:
            return None

        # bot_service에 따른 ChatbotTypeEnum 매핑
        mapping = {
            "generate": ChatbotTypeEnum.CREATE_DRAFT,
            "external": ChatbotTypeEnum.EXTERNAL_ANALYSIS,
            "internal": ChatbotTypeEnum.QNA,
        }
        chatbot_type = mapping.get(bot_meta_info.service)
        if not chatbot_type:
            logger.error(f"유효하지 않은 bot_service입니다. : {bot_meta_info.service}")
            return None

        waiting_message = (
            await self.admin_db_manager.get_latest_waiting_message_by_type(chatbot_type)
        )

        return waiting_message

    async def _process_task(self, task: Task):
        """
        작업을 처리하는 함수입니다.
        이 함수는 실제 작업 처리 로직을 구현해야 합니다.
        """
        logger.info(f"작업 처리: {task.task.id}")

        # 작업 처리 로직 구현
        try:
            task_id = task.task.id
            user_id = task.task.get_user_id()
            bot_id = task.task.get_bot_id()
            message = task.task.get_user_message()
            attached_file = task.task.get_attached_file()

            chat_session_id = task.chat_id

            bot_meta_info = self.bot_manager.get_bot_meta_info(bot_id=bot_id)

            chat_number = await self.db_manager.add_user_chat_history(
                chat_session_id=chat_session_id,
                message=message,
            )

            await self.bot_manager.write_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={"STEP": "01. Task WAS 메세지큐 수신", "BODY": {"text": message}},
            )

            # Detail-View-WAS의 스트림 테스트
            wait_url = "https://example.com/wait"
            async with httpx.AsyncClient() as client:
                json = await client.get(
                    f"http://0.0.0.0:8002/views/test_api/v1/get-token-url?chat_session_id={chat_session_id}&chat_number={chat_number}"
                )
                json_data = json.json()
                token = json_data["token"]

                if bot_meta_info and bot_meta_info.role == "dev":
                    wait_url = (
                        get_service_url(env="local")
                        + f"/dev/views/detail?service={bot_meta_info.service}&token={token}"
                    )
                else:
                    wait_url = (
                        get_service_url(env="local")
                        + f"/views/detail?service={bot_meta_info.service}&token={token}"
                    )

            waiting_message = await self.get_waiting_message_by_bot_id(bot_id=bot_id)
            await self.bot_manager.send_wait_message(
                bot_id=bot_id, user_id=user_id, uri=wait_url, text=waiting_message
            )

            await asyncio.sleep(
                SIMULATE_TASK_PROCESSING_TIME_SEC
            )  # 작업 처리 시뮬레이션

            if attached_file:  # { name, size, content }
                message += f"\n첨부된 파일 정보 : {attached_file}"

            if bot_meta_info and bot_meta_info.service:
                message += f"\n(서비스: {bot_meta_info.service})"

            await self.bot_manager.send_bot_answer_message(
                bot_id=bot_id,
                user_id=user_id,
                bot_message=message,
                uri=wait_url,
            )

            # DB 저장
            await self.db_manager.add_bot_chat_history(
                chat_session_id=chat_session_id,
                chat_number=chat_number,
                message=message,
            )

            await self.bot_manager.write_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "STEP": "08. DB 최종답변 저장",
                    "BODY": {"detail": message},
                },
            )

            # 에러 메시지 테스트
            # await bot_manager.send_error_message(
            #     bot_id=bot_id,
            #     user_id=user_id,
            #     error_message="에러 메시지를 테스트합니다.",
            #     task_id=task_id,
            # )

            return CompleteTask(
                status="success",
                reason="작업이 성공적으로 처리되었습니다.",
            )

        except Exception as e:
            error_message = f"작업 처리 중 오류 발생: {e}"
            logger.error(error_message)
            await self.bot_manager.send_typed_error_message(
                bot_id=bot_id,
                user_id=user_id,
                type=StaticMessageType.ERR_NETWORK_ERROR.value,
                task_id=task_id,
            )

            return CompleteTask(status="failure", reason=error_message)

    async def _task_handler(self):
        """
        작업을 처리하는 핸들러입니다.
        이 함수는 작업을 가져와서 처리합니다.
        """
        async with self.semaphore:
            if not self.running:
                return

            while True:
                task = await self._get_next_task()
                if task:
                    # 작업 처리 로직
                    complete_result = await self._process_task(task)
                    await self._complete_task(
                        task_id=task.task.id, complete_task=complete_result
                    )
                else:
                    break  # 더 이상 처리할 작업이 없으면 종료

    def _subscribe_handler(self, item: dict | None = None) -> None:
        """구독 핸들러를 설정합니다."""

        logger.info(f"구독 핸들러가 호출되었습니다 : {item}")

        asyncio.create_task(self._task_handler())

    async def start(self):
        self.running = True
        asyncio.create_task(
            self.task_manager.subscribe(
                self._subscribe_handler,
            )
        )

        await self._event.wait()

    async def stop(self):
        """작업을 중지합니다."""
        logger.info("TaskWorker를 중지합니다.")
        self.running = False
        await self.task_manager.unsubscribe(self._subscribe_handler)
        self._event.set()
