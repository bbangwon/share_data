import asyncio
import logging
import os
from urllib.parse import unquote

import fitz  # PyMuPDF
import httpx
from busan_bot_ui import BusanBotUIManager
from busan_bot_ui.static_messages import StaticMessageType
from db_manager import get_db_manager_using_env
from dotenv import load_dotenv
from request_queue import RequestQueueItem

from app.core import get_task_manager_using_env
from app.schemas.file_content import FileContent
from app.schemas.tasks import CompleteTask, Task

load_dotenv()
logger = logging.getLogger(__name__)


class FileTaskWorker:
    def __init__(self, max_workers: int = 1):
        self.task_was_base_url = os.getenv("TASK_WAS_BASE_URL")
        if not self.task_was_base_url:
            raise ValueError("TASK_WAS_BASE_URL 환경 변수가 설정되지 않았습니다.")

        self.task_manager = get_task_manager_using_env()

        self.max_workers = max_workers
        self.semaphore = asyncio.Semaphore(max_workers)

        self.running = False
        self._event = asyncio.Event()

        self.db_manager = get_db_manager_using_env()

    async def _get_next_file_task(self) -> Task | None:
        """다음 파일 작업을 가져오는 함수입니다.
        이 함수는 Task WAS에서 다음 파일 작업을 가져옵니다."""

        logger.info("다음 파일 작업을 요청합니다.")
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.task_was_base_url}/api/v1/tasks/next/file"
            )
            response.raise_for_status()

            if response.status_code == httpx.codes.OK:
                return Task(**response.json())
            elif response.status_code == httpx.codes.NO_CONTENT:
                logger.info("파일 작업이 없습니다.")
                return None

    async def _complete_file_task(self, task_id: str, complete_task: CompleteTask):
        """파일 작업을 완료하는 함수입니다.
        이 함수는 Task WAS에 파일 작업 완료 요청을 보냅니다."""
        logger.info(f"파일 작업 완료 요청: {task_id}, 완료정보 {complete_task}")

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.task_was_base_url}/api/v1/tasks/{task_id}/complete",
                json=complete_task.model_dump(),
            )
            response.raise_for_status()

            if response.status_code == httpx.codes.OK:
                logger.info(f"파일 작업 완료: {task_id}")
            else:
                logger.error(
                    f"파일 작업 완료 실패: {task_id}, 상태 코드: {response.status_code}"
                )

    def extract_pdf_text(self, file_path: str) -> str:
        """PDF 파일에서 텍스트를 추출하는 함수입니다."""
        text = ""
        try:
            with fitz.open(file_path) as doc:
                for page in doc:
                    text += page.get_text()
        except Exception as e:
            logger.error(f"PDF 파일에서 텍스트 추출 중 오류 발생: {e}")
        return text

    async def _process_file_task(self, task: Task):
        """
        파일 작업을 처리하는 함수입니다.
        이 함수는 실제 작업 처리 로직을 구현해야 합니다.
        """
        logger.info(f"파일 작업 처리: {task.task.id}")

        # 파일 작업 처리 로직 구현
        try:
            task_id = task.task.id
            user_id = task.task.get_user_id()
            bot_id = task.task.get_bot_id()
            file_id = task.task.get_file_id()

            bot_manager = BusanBotUIManager()
            db_manager = get_db_manager_using_env()

            await bot_manager.write_file_proc_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "was": "task-was",
                    "message": "1. 파일 처리 작업이 시작되었습니다.",
                    "task": task.model_dump(),
                },
            )

            # 처리 중 메시지 전송
            processing_message = bot_manager.get_typed_text(
                StaticMessageType.TXT_FILE_PROCESSING_MESSAGE.value
            )
            await bot_manager.send_text_message(
                bot_id=bot_id,
                user_id=user_id,
                text=processing_message,
                review_start_service=False,
            )

            download_file_info = await bot_manager.get_download_url(
                bot_id=bot_id, file_id=file_id
            )

            await bot_manager.write_file_proc_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "was": "task-was",
                    "message": "2. 파일 다운로드 정보를 가져왔습니다.",
                    "download_file_info": download_file_info.model_dump(),
                },
            )

            # 파일이름 길이가 너무 길경우(255자 초과) 오류 처리
            if len(download_file_info.file_name) > 255:
                error_message = f"파일 이름이 너무 깁니다. 255자 이하로 파일 이름을 변경 후 다시 시도해주세요. : {download_file_info.file_name}({len(download_file_info.file_name)})"
                logger.error(error_message)
                await bot_manager.send_typed_error_message(
                    bot_id=bot_id,
                    user_id=user_id,
                    type=StaticMessageType.ERR_INVALID_FILE_NAME_LENGTH.value,
                    task_id=task_id,
                    viewer_name="file-log-viewer",
                )

                await bot_manager.write_file_proc_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "was": "task-was",
                        "message": "에러가 발생했습니다.",
                        "error": error_message,
                    },
                )

                return CompleteTask(
                    status="failure",
                    reason=error_message,
                )

            # 파일 확장자 정보를 보고 지원여부 확인
            if download_file_info.file_extension not in ["txt", "pdf"]:
                error_message = f"지원하지 않는 파일 형식입니다: {download_file_info.file_extension}"
                logger.error(error_message)
                await bot_manager.send_typed_error_message(
                    bot_id=bot_id,
                    user_id=user_id,
                    type=StaticMessageType.ERR_INVALID_FILE_EXTENSION.value,
                    task_id=task_id,
                    viewer_name="file-log-viewer",
                )

                await bot_manager.write_file_proc_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "was": "task-was",
                        "message": "에러가 발생했습니다.",
                        "error": error_message,
                    },
                )

                return CompleteTask(
                    status="failure",
                    reason=error_message,
                )

            # 파일 다운로드
            downloaded_file_path = await bot_manager.download_and_save_file(
                download_file_info=download_file_info
            )
            logger.info(f"파일이 다운로드되었습니다: {downloaded_file_path}")

            # 파일 처리
            file_content = ""
            if download_file_info.file_extension == "txt":  # 텍스트 파일 처리
                with open(downloaded_file_path, "r", encoding="utf-8") as f:
                    file_content = f.read()
            elif download_file_info.file_extension == "pdf":  # PDF 파일 처리
                file_content = await asyncio.get_event_loop().run_in_executor(
                    None, self.extract_pdf_text, downloaded_file_path
                )

            await bot_manager.write_file_proc_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "was": "task-was",
                    "message": "3. 파일 저장후 내용을 읽어왔습니다.",
                    "file_content": file_content,
                    "file_length": len(file_content) if file_content else 0,
                },
            )

            file = FileContent(
                name=unquote(
                    os.path.basename(downloaded_file_path)
                ),  # 파일 이름에 한글이 들어갈 경우 URL 인코딩 되어 올 수 있어서 디코딩 처리
                size=os.path.getsize(downloaded_file_path),
                content=file_content,
            )

            # 파일 정리
            bot_manager.clean_up_downloaded_file(download_file_info)

            # 파일 내용 체크
            if not file.content or len(file.content.strip()) == 0:
                error_message = "파일 내용이 비어 있습니다."
                logger.error(error_message)
                await bot_manager.send_typed_error_message(
                    bot_id=bot_id,
                    user_id=user_id,
                    type=StaticMessageType.ERR_NO_CONTENT_IN_FILE.value,
                    task_id=task_id,
                    viewer_name="file-log-viewer",
                )

                await bot_manager.write_file_proc_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "was": "task-was",
                        "message": "에러가 발생했습니다.",
                        "error": error_message,
                    },
                )

                return CompleteTask(status="failure", reason=error_message)

            # 파일 길이 체크
            elif len(file.content) > 15000:
                error_message = "파일 길이가 15,000자를 초과합니다."
                logger.error(error_message)
                await bot_manager.send_typed_error_message(
                    bot_id=bot_id,
                    user_id=user_id,
                    type=StaticMessageType.ERR_INVALID_FILE_LENGTH.value,
                    task_id=task_id,
                    viewer_name="file-log-viewer",
                )

                await bot_manager.write_file_proc_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "was": "task-was",
                        "message": "에러가 발생했습니다.",
                        "error": error_message,
                    },
                )

                return CompleteTask(
                    status="failure",
                    reason=error_message,
                )

            # DB 처리
            if file_content:
                last_chat_session_id = await db_manager.get_last_chat_session_id(
                    user_id=user_id, bot_id=bot_id
                )

                chat_number = await db_manager.add_user_chat_history(
                    chat_session_id=last_chat_session_id,
                    message=file.model_dump_json(),
                    is_file_content=True,
                )

                # 성공 메시지 전송
                success_message = bot_manager.get_typed_text(
                    StaticMessageType.TXT_FILE_UPLOAD_SUCCESS_MESSAGE.value
                )

                await bot_manager.send_text_message(
                    bot_id=bot_id,
                    user_id=user_id,
                    text=success_message,
                )

                await bot_manager.write_file_proc_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "was": "task-was",
                        "message": "4. 정상처리되었습니다.",
                        "chat_session_id": last_chat_session_id,
                        "chat_number": chat_number,
                    },
                )

                return CompleteTask(
                    status="success",
                    reason="파일 작업이 성공적으로 처리되었습니다.",
                )

        except Exception as e:
            error_message = f"파일 작업 처리 중 오류 발생: {e}"
            logger.error(error_message)
            await bot_manager.send_typed_error_message(
                bot_id=bot_id,
                user_id=user_id,
                type=StaticMessageType.ERR_NETWORK_ERROR.value,
                task_id=task_id,
                viewer_name="file-log-viewer",
            )

            await bot_manager.write_file_proc_log(
                task_id=task_id,
                user_id=user_id,
                bot_id=bot_id,
                log={
                    "was": "task-was",
                    "message": "에러가 발생했습니다.",
                    "error": error_message,
                },
            )

            return CompleteTask(status="failure", reason=error_message)

    async def _file_task_handler(self):
        """
        파일 작업을 처리하는 핸들러입니다.
        이 함수는 파일 작업을 가져와서 처리합니다.
        """
        async with self.semaphore:
            if not self.running:
                return

            while True:
                task = await self._get_next_file_task()
                if task:
                    # 작업 처리 로직
                    complete_result = await self._process_file_task(task)
                    await self._complete_file_task(
                        task_id=task.task.id, complete_task=complete_result
                    )
                else:
                    break  # 더 이상 처리할 작업이 없으면 종료

    def _subscribe_handler(self, item: dict | None = None) -> None:
        """구독 핸들러를 설정합니다."""

        logger.info(f"구독 핸들러가 호출되었습니다 : {item}")

        if item:  # item이 있는 경우는 파일이 있는 경우만 처리
            req_queue_item = RequestQueueItem.model_validate(item)
            if req_queue_item.get_file_id():
                asyncio.create_task(self._file_task_handler())
        else:
            asyncio.create_task(self._file_task_handler())

    async def start(self):
        self.running = True
        asyncio.create_task(
            self.task_manager.subscribe(
                self._subscribe_handler,
            )
        )

        await self._event.wait()

    async def stop(self):
        """작업을 중지합니다."""
        logger.info("FileTaskWorker를 중지합니다.")
        self.running = False
        await self.task_manager.unsubscribe(self._subscribe_handler)
        self._event.set()
