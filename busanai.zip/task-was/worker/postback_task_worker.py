import asyncio
import base64
import json
import logging
import os
import re

import httpx
from busan_bot_ui import BusanBotUIManager
from db_manager import ChatSession, get_db_manager_using_env
from dotenv import load_dotenv
from feedback_item_processor import FeedbackItemProcessor, StaticFeedback
from naver_works_bot import TextContent
from naver_works_bot.bot.schemas.contents.base import ContentBase
from request_queue import RequestQueueItem

from app.core import get_task_manager_using_env
from app.schemas.tasks import CompleteTask, Task

load_dotenv()
logger = logging.getLogger(__name__)


class PostbackTaskWorker:
    def __init__(self, service_url: str, max_workers: int = 1):
        self.task_was_base_url = os.getenv("TASK_WAS_BASE_URL")
        if not self.task_was_base_url:
            raise ValueError("TASK_WAS_BASE_URL 환경 변수가 설정되지 않았습니다.")

        self.task_manager = get_task_manager_using_env()

        self.max_workers = max_workers
        self.semaphore = asyncio.Semaphore(max_workers)

        self.running = False
        self._event = asyncio.Event()

        self.db_manager = get_db_manager_using_env()
        self.feedback_item_processor: FeedbackItemProcessor = None

        self.service_url = service_url

    async def _get_next_postback_task(self) -> Task | None:
        """다음 포스트백 작업을 가져오는 함수입니다.
        이 함수는 Task WAS에서 다음 포스트백 작업을 가져옵니다."""

        logger.info("다음 포스트백 작업을 요청합니다.")
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.task_was_base_url}/api/v1/tasks/next/postback"
            )
            response.raise_for_status()

            if response.status_code == httpx.codes.OK:
                return Task(**response.json())
            elif response.status_code == httpx.codes.NO_CONTENT:
                logger.info("포스트백 작업이 없습니다.")
                return None

    async def _complete_postback_task(self, task_id: str, complete_task: CompleteTask):
        """포스트백 작업을 완료하는 함수입니다.
        이 함수는 Task WAS에 포스트백 작업 완료 요청을 보냅니다."""
        logger.info(f"포스트백 작업 완료 요청: {task_id}, 완료정보 {complete_task}")

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.task_was_base_url}/api/v1/tasks/{task_id}/complete",
                json=complete_task.model_dump(),
            )
            response.raise_for_status()

            if response.status_code == httpx.codes.OK:
                logger.info(f"포스트백 작업 완료: {task_id}")
            else:
                logger.error(
                    f"포스트백 작업 완료 실패: {task_id}, 상태 코드: {response.status_code}"
                )

    async def _process_recent_questions(
        self, task: Task, feedback_items: list[StaticFeedback]
    ) -> list[ContentBase] | None:
        """최근 질문 처리"""

        def get_urls(text: str) -> list[str]:
            # "참고링크" 이후의 텍스트에서 모든 URL 추출
            idx = text.find("참고링크")
            if idx == -1:
                return []
            after = text[idx:]
            return re.findall(r"https?://[^\s]+", after)

        def get_encoded_token(chat_session_id: int, chat_number: int) -> str:
            token_info = {
                "chat_session_id": chat_session_id,
                "chat_number": chat_number,
            }

            logger.info("토큰 정보: %s", token_info)

            encoded_token = base64.b64encode(
                json.dumps(token_info).encode("utf-8")
            ).decode("utf-8")

            logger.info("인코딩된 토큰: %s", encoded_token)

            return encoded_token

        chat_session_id = None
        chat_number = None

        postback = task.task.get_postback()
        user_id = task.task.get_user_id()
        bot_id = task.task.get_bot_id()

        contents = None

        if (
            len(postback.split(":")) == 3
        ):  # 답변을 보내주는 모드일 때(DB에서 바로 가져옴)
            _, chat_session_id, chat_number = postback.split(":")

            logger.info(
                f"최근 질문 내용 요청: {task.task.id} - {chat_session_id}, {chat_number}"
            )

            if chat_session_id and chat_number:
                chat_session_id = int(chat_session_id)
                chat_number = int(chat_number)
                chat_history = (
                    await self.db_manager.get_chat_history_by_session_and_chat_number(
                        chat_session_id=chat_session_id,
                        chat_number=chat_number,
                    )
                )

                if (
                    not chat_history or not chat_history.bot_message
                ):  # 이런 일은 없을테지만..
                    logger.error(
                        f"채팅 기록/답변을 찾을 수 없습니다. chat_session_id={chat_session_id}, chat_number={chat_number}"
                    )
                    return [
                        TextContent.from_text(
                            "죄송합니다. 해당 질문에 대한 답변을 찾을 수 없습니다."
                        )
                    ]

                # 정상적으로 답변은 찾았으면..

                # TODO: 답변 자세히보기 링크 처리
                encoded_token = get_encoded_token(
                    chat_session_id=chat_session_id, chat_number=chat_number
                )
                uri = f"{self.service_url}/views/detail?token={encoded_token}"

                # results = [TextContent.from_text(chat_history.bot_message)]

                results = [
                    self.bot_manager.get_bot_answer_message_content(
                        bot_message=chat_history.bot_message,
                        uri=uri,
                    )
                ]

                # 참고파일 파싱 처리
                urls = get_urls(chat_history.bot_message)
                results.extend(
                    self.bot_manager.get_contents_files_download_button_ui_message(urls)
                )

                return results

        # 최근 질문 로직
        logger.info(f"최근 질문 목록 요청: {task.task.id}")

        # 그 외에는 최근 질문 최대 30개 목록을 가져와서 처리
        chat_histories = (
            await self.db_manager.get_last_chat_histories_by_user_and_bot_id(
                user_id=user_id, bot_id=bot_id, count=30
            )
        )

        # DB애서는 오름차순으로 정렬되어 있음. 최신순으로 정렬
        chat_histories = sorted(
            chat_histories, key=lambda x: x.created_at, reverse=True
        )

        contents = self.feedback_item_processor.process_recent_question_list(
            feedback_items=feedback_items,
            chat_histories=chat_histories,
        )

        return contents

    async def _process_postback_task(self, task: Task):
        """
        포스트백 작업을 처리하는 함수입니다.
        이 함수는 실제 작업 처리 로직을 구현해야 합니다.
        """
        logger.info(f"포스트백 작업 처리: {task.task.id}")

        postback = task.task.get_postback()
        if not postback:
            logger.error(f"포스트백 작업에 포스트백 정보가 없습니다: {task.task.id}")
            return CompleteTask(
                status="failed",
                reason="포스트백 정보가 없습니다.",
            )

        # 포스트백 작업 처리 로직 구현
        logger.info(f"포스트백 작업 처리 중: {task.task.id}, {postback}")
        user_id = task.task.get_user_id()
        bot_id = task.task.get_bot_id()

        contents = None

        if postback == "start":
            # 작업 시작 로직
            logger.info(f"작업 시작: {task.task.id}")
            try:
                # start 포스트백에 대해서는 채팅 세션 생성 필요
                await self.db_manager.create_chat_session(
                    chat_session=ChatSession(
                        user_id=user_id,
                        bot_id=bot_id,
                    )
                )

                postback = "start_service"  # 이후 작업은 start_service로 처리
            except Exception as e:
                logger.error(f"채팅 세션 생성 중 오류 발생: {e}")
                await self.bot_manager.send_error_message(
                    user_id=user_id,
                    bot_id=bot_id,
                    error_message=f"채팅 세션 생성 중 오류가 발생했습니다: {e}",
                )
                return CompleteTask(
                    status="failed",
                    reason=f"채팅 세션 생성 실패: {e}",
                )

        # 봇 메타정보 체크(자동테스트중에는 봇이 없을수 있으므로.. 그러면 이후 처리하지 않음)
        bot_meta_info = self.bot_manager.get_bot_meta_info(bot_id=bot_id)
        if not bot_meta_info or not bot_meta_info.service:
            logger.warning(
                f"bot_id:{bot_id} 에 해당하는 봇 메타정보를 찾을 수 없습니다."
            )
            return CompleteTask(
                status="failed",
                reason="봇 메타정보 없음",
            )

        # 봇 피드백 검색
        feedback_items = await self.db_manager.get_feedback_items_by_postback(
            bot_service=bot_meta_info.service, postback=postback
        )

        if not feedback_items:
            logger.error(
                f"bot_id:{bot_id}, bot_service:{bot_meta_info.service} post_back:{postback} 작업에 해당하는 피드백 아이템이 없습니다."
            )
            return CompleteTask(
                status="failed",
                reason="피드백 아이템 없음",
            )

        # 나의 최근 질문의 경우. 안내 메시지 이후 실제 최근 질문 처리
        if postback[:16] == "recent_questions":
            contents = await self._process_recent_questions(
                task=task,
                feedback_items=feedback_items,
            )

        else:
            contents = self.feedback_item_processor.process(
                feedback_items=feedback_items,
            )

        if not contents:
            logger.error(f"{postback} 작업을 진행할 내용을 DB에서 찾을 수 없습니다.")
            await self.bot_manager.send_error_message(
                user_id=user_id,
                bot_id=bot_id,
                error_message=f"{postback} 작업을 진행할 내용을 DB에서 찾을 수 없습니다.",
                only_send_to_admin=True,
            )

            return CompleteTask(
                status="failed",
                reason="send_context 생성 실패",
            )

        for content in contents:
            # 봇 메시지 전송
            try:
                review_start_service = (
                    postback != "start_service"
                )  # start_service가 아닌 경우에만 시작 서비스로 처리
                await self.bot_manager.send_content_message(
                    bot_id=bot_id,
                    user_id=user_id,
                    content=content,
                    review_start_service=review_start_service,
                )

            except httpx.HTTPStatusError as e:
                logger.error(
                    f"봇 컨텐츠 전송 중 오류 발생: {e.response.status_code} - {e.response.text}"
                )
                await self.bot_manager.send_error_message(
                    user_id=user_id,
                    bot_id=bot_id,
                    error_message=f"봇 컨텐츠 전송 중 오류가 발생했습니다: {e.response.status_code} - {e.response.text}",
                )

                return CompleteTask(
                    status="failed",
                    reason=f"봇 컨텐츠 전송 실패: {e.response.status_code} - {e.response.text}",
                )

        return CompleteTask(
            status="success",
            reason="포스트백 작업이 성공적으로 처리되었습니다.",
        )

    async def _postback_task_handler(self):
        """
        포스트백 작업을 처리하는 핸들러입니다.
        이 함수는 포스트백 작업을 가져와서 처리합니다.
        """
        async with self.semaphore:
            if not self.running:
                return

            while True:
                task = await self._get_next_postback_task()
                if task:
                    # 작업 처리 로직
                    complete_result = await self._process_postback_task(task)
                    await self._complete_postback_task(
                        task_id=task.task.id, complete_task=complete_result
                    )
                else:
                    break  # 더 이상 처리할 작업이 없으면 종료

    def _subscribe_handler(self, item: dict | None = None) -> None:
        """구독 핸들러를 설정합니다."""

        logger.info(f"구독 핸들러가 호출되었습니다 : {item}")

        if item:  # item이 있는 경우는 postback이 있는 경우만 처리
            req_queue_item = RequestQueueItem.model_validate(item)
            if req_queue_item.get_postback():
                asyncio.create_task(self._postback_task_handler())
        else:
            asyncio.create_task(self._postback_task_handler())

    async def start(self):
        self.bot_manager = BusanBotUIManager()

        self.feedback_item_processor = FeedbackItemProcessor(
            config=FeedbackItemProcessor.Config(
                main_color=self.bot_manager.config.flex_style.main_color,
                button_text_color=self.bot_manager.config.flex_style.button_text_color,
            )
        )

        self.running = True
        asyncio.create_task(
            self.task_manager.subscribe(
                self._subscribe_handler,
            )
        )

        await self._event.wait()

    async def stop(self):
        """작업을 중지합니다."""
        logger.info("PostbackTaskWorker를 중지합니다.")
        self.running = False
        await self.task_manager.unsubscribe(self._subscribe_handler)
        self._event.set()
