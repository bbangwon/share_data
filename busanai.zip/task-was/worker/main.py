import asyncio
import logging
import logging.handlers
import os

if __name__ == "__main__":
    import sys

    # 현재 파일의 상위 디렉토리 경로를 sys.path에 추가
    path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(path)

from busan_bot_ui.utils import get_service_url
from dotenv import load_dotenv
from enqueue_task_worker import EnqueueTaskWorker
from file_task_worker import FileTaskWorker
from local_task_worker import LocalTaskWorker
from postback_task_worker import PostbackTaskWorker

load_dotenv()
LOG_LEVEL = os.getenv("LOG_LEVEL", "ERROR").upper()
if LOG_LEVEL not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
    raise ValueError(f"Invalid LOG_LEVEL: {LOG_LEVEL}")

LOG_DIR = os.getenv("LOG_DIR", "./logs")
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", 7))

ENV = os.getenv("ENV", "prod").lower()
if ENV not in ["local", "prod"]:
    raise ValueError(f"Invalid ENV: {ENV}")

log_file_path = os.path.join(LOG_DIR, "task-worker.log")
logging.basicConfig(
    level=LOG_LEVEL,
    format="[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s",
    handlers=[
        logging.StreamHandler(),  # 콘솔에 로그 출력
        logging.handlers.TimedRotatingFileHandler(
            log_file_path,
            when="midnight",  # 매일 자정에 로그 파일을 새로 만듭니다.
            interval=1,  # 1일마다 새 로그 파일 생성
            backupCount=LOG_BACKUP_COUNT,  # 최대 n개의 백업 로그 파일 유지
            encoding="utf-8",
        ),
    ],
)

logger = logging.getLogger(__name__)


def check_env_variables():
    """필수 환경 변수가 설정되었는지 확인합니다."""
    required_vars = ["REQUEST_REDIS_URL"]
    for var in required_vars:
        if not os.getenv(var):
            logger.error(f"{var} 환경 변수가 설정되지 않았습니다.")
            return False
    return True


async def main():
    try:
        if not check_env_variables():
            return

        service_url = get_service_url(ENV)
        task_worker_count = int(os.getenv("TASK_WORKER_COUNT", 1))
        if ENV == "prod":
            await asyncio.gather(
                EnqueueTaskWorker(max_workers=task_worker_count).start(),
                PostbackTaskWorker(
                    service_url=service_url, max_workers=task_worker_count
                ).start(),
                FileTaskWorker(max_workers=task_worker_count).start(),
            )
        elif ENV == "local":
            await asyncio.gather(
                EnqueueTaskWorker(max_workers=task_worker_count).start(),
                PostbackTaskWorker(
                    service_url=service_url, max_workers=task_worker_count
                ).start(),
                FileTaskWorker(max_workers=task_worker_count).start(),
                LocalTaskWorker(max_workers=task_worker_count).start(),
            )
    except asyncio.CancelledError:
        logger.info("작업이 취소되었습니다.")


if __name__ == "__main__":
    asyncio.run(main())
