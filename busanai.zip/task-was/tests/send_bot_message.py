import base64
import json
import logging

import httpx
from busan_bot_ui import (
    BusanBotUIManager,
    Button,
    ButtonContainer,
    ButtonTemplate,
    MainCarousel,
    MessageActionData,
    UriActionData,
)
from busan_bot_ui.utils import get_service_url
from dotenv import load_dotenv
from naver_works_bot import ButtonTemplateContent, MessageAction

logging.basicConfig(level="DEBUG")
logger = logging.getLogger(__name__)

load_dotenv()

bot_id = "10242846"
user_id = "95fe2166-112c-4597-1115-032ccd8f293c"


async def send_text_message():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    await bot_manager.send_text_message(
        bot_id=bot_id,
        user_id=user_id,
        text="""안녕하세요! 부산광역시 초고층 건물 재난 대응 계획에 대해 알려드리겠습니다.""",
    )


async def send_wait_message(chat_session_id: int, chat_number: int):
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    service_url = get_service_url(env="local")

    token_info = {
        "chat_session_id": chat_session_id,
        "chat_number": chat_number,
        "stream_url": f"{service_url}/views/test_api/v1/stream?chat_session_id={chat_session_id}",
    }

    logger.info("토큰 정보: %s", token_info)

    encoded_token = base64.b64encode(json.dumps(token_info).encode("utf-8")).decode(
        "utf-8"
    )

    logger.info("인코딩된 토큰: %s", encoded_token)

    page_url = f"{service_url}/views/detail?token={encoded_token}"

    await bot_manager.send_wait_message(bot_id=bot_id, user_id=user_id, uri=page_url)


async def send_typed_error_message():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    await bot_manager.send_typed_error_message(
        user_id=user_id,
        bot_id=bot_id,
        type="ERR_NETWORK_ERROR",
        only_send_to_admin=False,
        task_id="1234567890abcdef",
    )


async def send_main_carousel():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    result = await bot_manager.send_content_message(
        bot_id=bot_id,
        user_id=user_id,
        content=MainCarousel.from_data(
            MainCarousel.Data(
                columns=[
                    MainCarousel.Data.Column(
                        color="#FF5733",
                        image_url="https://example.com/image1.jpg",
                        text="첫번째 캐러셀 컬럼",
                        action_datas=[
                            MessageActionData(
                                label="첫번째 액션",
                                text="첫번째 액션 클릭 했어요!",
                            )
                        ],
                    ),
                    MainCarousel.Data.Column(
                        color="#33FF57",
                        image_url="https://example.com/image2.jpg",
                        text="두번째 캐러셀 컬럼",
                        action_datas=[
                            MessageActionData(
                                label="두번째 액션",
                                text="두번째 액션 클릭 했어요!",
                            )
                        ],
                    ),
                ]
            )
        ),
    )
    logger.info("메시지 전송 완료. 결과: %s", result)


async def send_button_ui():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    result = await bot_manager.send_content_message(
        bot_id=bot_id,
        user_id=user_id,
        content=Button.from_data(
            Button.Data(
                button_data=ButtonContainer.Data(
                    text="파일 다운로드",  # 버튼 컨테이너 텍스트
                    color="#FF5733",  # 버튼 배경색
                    text_color="#FFFFFF",  # 버튼 텍스트 색상
                    action_data=UriActionData(  # 버튼 클릭 시 동작
                        uri="https://example.com/download/sample.pdf",
                        label="파일이름.pdf 다운로드",
                    ),
                )
            )
        ),
    )
    logger.info("메시지 전송 완료. 결과: %s", result)


async def send_button_template():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    try:
        result = await bot_manager.send_content_message(
            bot_id=bot_id,
            user_id=user_id,
            content=ButtonTemplate.from_data(
                ButtonTemplate.Data(
                    color="#FF5733",
                    action_datas=[
                        MessageActionData(
                            label="짧은 글",
                            text="짧은 글을 클릭 했어요!",
                        ),
                        MessageActionData(
                            label="400자 정도",
                            text="3바람이 선선하게 불어오는 가을 아침, 사람들은 저마다의 하루를 준비하며 분주히 움직인다. 출근길 지하철 안에서는 졸린 눈을 비비며 휴대폰을 보는 이도 있고, 작은 이어폰을 꽂고 음악에 몸을 맡기는 이도 있다. 길가의 은행나무는 벌써 노랗게 물들기 시작했고, 낙엽은 바람에 흩날리며 계절의 변화를 알린다. 카페 앞 테라스에는 따뜻한 커피를 마시며 노트북을 펴놓고 작업하는 이들이 하나둘 자리 잡는다. 도시의 소음과 자연의 소리가 묘하게 뒤섞여, 평범하면서도 특별한 일상의 배경음을 만들어 낸다. 이런 순간들을 차분히 바라보면, 복잡하게만 느껴지는 하루도 사실은 작은 조각들이 모여 이루는 풍경일 뿐이라는 생각이 든다. 그렇게 우리는 오늘도 또 다른 하루를 살아가며, 어제와는 다른 이야기를 써 내려간다.",
                        ),
                    ],
                )
            ),
            review_start_service=False,
        )
    except httpx.HTTPStatusError as e:
        logger.error("메시지 전송 중 오류 발생: %s", e.response.text)
        return
    logger.info("메시지 전송 완료. 결과: %s", result)


async def send_button_download_uri():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    await bot_manager.send_file_download_button_ui_message_with_filepaths_vdb_meta(
        bot_id=bot_id,
        user_id=user_id,
        file_paths=[
            "/data/uploads/파일1.pdf",
            "/data/uploads/파일2.pdf",
            "/data/uploads/파일3.pdf",
            "/data/uploads/파일이름이길경우에어떻게나오는지확인이필요_어떻게나오니_알고싶어요.pdf",
        ],
    )


def get_button_download_uri_from_file_path():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    url = bot_manager.get_url_with_filepath_vdb_meta(
        file_path="/data/uploads/파일이름이길경우에어떻게나오는지확인이필요_어떻게나오니_알고싶어요.pdf",
    )

    print("파일 다운로드 URI:", url)


async def send_more_view_button():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    result = await bot_manager.send_message(
        bot_id=bot_id,
        user_id=user_id,
        content=ButtonTemplateContent(
            content_text="""제  목 : 2025년 겨울철 대설한파대책비(특별교부세) 지원계획
겨울철 제설장비·자재 보강을 위하여 시비보조금(市 재난관리기금)을 지원하여 겨울철 자연재난 대응에 만전을 기하고자 함.
   지원근거
  ○「재난 및 안전관리기본법」제55조1항(재난대비능력보강)

   지원내용
  ○ 지원대상 : 16개 구·군
  ○ 지원금액 : 380백만원
  ○ 재    원 : 특별교부세
  ○ 사용범위
    - (대설) 제설제 구매, 장비임차, 유류대 구입, 제설도구 구매 등
    - (한파) 방풍시설, 온열의자, 온열센서등* 설치, 방한용품 지원
      * 움직임을 자동 감지하여, 사람이 접근 시 자동으로 온열등이 작동하는 형태
   지원기준
  ○ 구·군별 결빙취약구간, 제설취약구간, 제설장비(자재) 보유량 등을 고려하여 최종 지원금액 확정

   행정사항
  ○ 예산교부 : ’25. 11월 ‣ 자치단체경상보조(시→구·군)
   - 예산과목 : 완벽한 재난예방체계 확립, 자연재난 예방, 자연재난 신속한 대응 및 복구, 자치단체등이전, 자치단체경상보조금
  ○ 집행정산
   - 집행완료 후 20일 이내 집행내역 정산(구·군)
   - 제설장비 및 자재 배치와 정산자료 제출(구·군→시)
   
지원계획에 대한 보도자료 초안을 작성해주세요""",
            actions=[
                MessageAction(label="더보기", text="더보기 클릭됨"),
            ],
        ),
    )
    logger.info("메시지 전송 완료. 결과: %s", result)


if __name__ == "__main__":
    get_button_download_uri_from_file_path()
    # asyncio.run(send_wait_message(chat_session_id=1, chat_number=1))
    # asyncio.run(send_button_download_uri())
    # asyncio.run(send_typed_error_message())
    # asyncio.run(send_text_message())
    # asyncio.run(send_more_view_button())
