import asyncio
import json

from busan_bot_ui.utils import get_service_url
from db_manager import get_db_manager_using_env
from db_manager.models import StaticFeedback
from dotenv import load_dotenv
from sqlalchemy import select


async def main():
    load_dotenv()
    service_url = get_service_url(env="local")
    if not service_url:
        return

    # 현재 서버의 DB 매니저를 가져옵니다.
    db_manager = get_db_manager_using_env()
    if db_manager is None:
        return

    async with db_manager.get_session() as session:
        select_stmt = select(StaticFeedback).where(
            StaticFeedback.message_type == "carousel_column"
        )

        result = await session.execute(select_stmt)
        columns = result.scalars().all()
        if not columns:
            print("업데이트할 피드백[carousel_column]이 없습니다.")
            return

        for column in columns:
            # ngrok URL을 사용하여 이미지 URL 업데이트
            content = json.loads(column.content)
            content["image_url"] = (
                f"{service_url}/views/assets/images/c{column.sort_number}.png"
            )
            column.content = json.dumps(content, ensure_ascii=False)

            session.add(column)
            await session.commit()

    async with db_manager.get_session() as session:
        select_stmt = select(StaticFeedback).where(StaticFeedback.message_type == "uri")
        result = await session.execute(select_stmt)
        columns = result.scalars().all()
        if not columns:
            print("업데이트할 피드백[uri]이 없습니다.")
            return

        for column in columns:
            content = json.loads(column.content)
            content["uri"] = f"{service_url}/views/guide?service=" + column.bot_service
            column.content = json.dumps(content, ensure_ascii=False)

            session.add(column)
            await session.commit()

    print("모든 피드백의 URL이 업데이트되었습니다.")


if __name__ == "__main__":
    asyncio.run(main())
