import asyncio
import logging

from busan_bot_ui import BusanBotUIManager
from dotenv import load_dotenv

logging.basicConfig(level="DEBUG")
logger = logging.getLogger(__name__)

load_dotenv()

bot_id = "10242846"
user_id = "95fe2166-112c-4597-1115-032ccd8f293c"

file_id = "kr1.1759658985102178125.1759745385.2.10242846.300223877.353087074.2333"


async def download_file():
    bot_manager = BusanBotUIManager()

    download_file_info = await bot_manager.get_download_url(
        bot_id=bot_id, file_id=file_id
    )
    logger.info(f"파일 다운로드 URL 조회 결과: {download_file_info}")

    if download_file_info:
        saved_path = await bot_manager.download_and_save_file(
            download_file_info, overwrite=True
        )
        logger.info(f"파일이 저장되었습니다: {saved_path}")
    else:
        logger.error("파일 다운로드 URL을 가져오지 못했습니다.")

    # bot_manager.clean_up_downloaded_file(download_file_info)
    # logger.info(f"파일이 삭제되었습니다: {download_file_info}")


if __name__ == "__main__":
    asyncio.run(download_file())
