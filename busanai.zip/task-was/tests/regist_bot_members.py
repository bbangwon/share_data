import asyncio
import csv
import logging
import sys

from busan_bot_ui import BusanBotUIManager

# 루트 로거에 핸들러 추가 (전역 적용)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("regist_bot_members.log", encoding="utf-8"),
    ],
)

logger = logging.getLogger(__name__)

BOT_ID = "10242846"
DOMAIN_ID = "300223877"
CSV_PATH = "./tests/봇등록테스트.csv"


def read_user_ids_from_csv(csv_path):
    user_ids = []
    with open(csv_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # 'ID' 또는 '이메일' 등 실제 컬럼명으로 교체 필요
            user_id = row.get("ID")
            if user_id:
                user_ids.append(user_id.strip())
    return user_ids


async def regist_bot_members():
    busan_bot_ui_manager = BusanBotUIManager(
        config_path="./busan-config.yaml",
        static_messages_path="./busan-static-messages.yaml",
    )

    members = read_user_ids_from_csv(CSV_PATH)

    logger.info(
        f"봇 사용자를 등록합니다. 봇 ID: {BOT_ID}, 도메인 ID: {DOMAIN_ID}, 총 유저수 {len(members)}"
    )

    for user_id in members:
        try:
            result = await busan_bot_ui_manager.regist_bot_member(
                bot_id=BOT_ID, domain_id=DOMAIN_ID, user_id=user_id
            )
            logger.info(f"봇 사용자({user_id}) 등록: {result}")
        except Exception as e:
            logger.error(f"봇 사용자({user_id}) 등록 중 오류 발생: {e}")

        await asyncio.sleep(0.1)  # 너무 빠른 요청을 피하기 위해 약간의 딜레이 추가


async def clear_bot_members():
    busan_bot_ui_manager = BusanBotUIManager(
        config_path="./busan-config.prod.yaml",
        static_messages_path="./busan-static-messages.yaml",
    )

    await busan_bot_ui_manager.clear_bot_members(bot_id=BOT_ID, domain_id=DOMAIN_ID)


async def main():
    await regist_bot_members()
    # await clear_bot_members()


if __name__ == "__main__":
    asyncio.run(main())
