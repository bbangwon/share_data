import asyncio

from admin_db_manager import ChatbotTypeEnum, get_admin_db_manager_using_env
from db_manager import ChatSession, get_db_manager_using_env
from dotenv import load_dotenv

bot_id = "10242846"
user_id = "95fe2166-112c-4597-1115-032ccd8f293c"
bot_service = "general"  # 내부문서 서비스 봇 "internal", "external" #외부문서 서비스 봇 "generate" #문서생성 봇
chat_session = 1
chat_number = 1


async def create_chat_session():
    load_dotenv()

    # 현재 server
    db_manager = get_db_manager_using_env()
    if db_manager is None:
        return

    session_id = await db_manager.create_chat_session(
        ChatSession(
            bot_id=bot_id,
            user_id=user_id,
        )
    )
    print(f"생성된 채팅세션 ID: {session_id}")
    return session_id


async def add_user_chat_history(
    chat_session: int, user_message: str = "유저 메시지입니다."
) -> int:
    load_dotenv()

    # 현재 server
    db_manager = get_db_manager_using_env()
    if db_manager is None:
        return

    chat_number = await db_manager.add_user_chat_history(chat_session, user_message)
    print(
        f"채팅세션 {chat_session} 채팅번호 {chat_number}에 유저 메시지를 추가했습니다."
    )
    return chat_number


async def add_bot_chat_history(
    chat_session: int, chat_number: int, bot_message: str = "봇 메시지입니다."
):
    load_dotenv()

    # 현재 server
    db_manager = get_db_manager_using_env()
    if db_manager is None:
        return

    await db_manager.add_bot_chat_history(chat_session, chat_number, bot_message)
    print(f"채팅세션 {chat_session} 채팅번호 {chat_number}에 봇 메시지를 추가했습니다.")


async def get_chat_histories_by_session_id():
    load_dotenv()

    # 현재 server
    db_manager = get_db_manager_using_env()
    if db_manager is None:
        return

    result = await db_manager.get_chat_histories_by_session_id(chat_number)
    print("채팅이력 조회 내용입니다.")
    for chat in result:
        print(
            f"채팅번호 {chat.chat_number} 유저 메시지 : {chat.user_message}, 봇 메시지 : {chat.bot_message}"
        )


async def get_feedback_items_by_postback():
    load_dotenv()

    # 현재 server
    db_manager = get_db_manager_using_env()
    if db_manager is None:
        return

    result = await db_manager.get_feedback_items_by_postback(
        bot_service=bot_service, postback="start_service"
    )

    print("피드백 항목 조회 내용입니다.")
    for feedback in result:
        print(f"피드백 ID: {feedback.id}, 내용: {feedback.content}")


async def get_setting_info():
    load_dotenv()

    # 현재 server
    db_manager = get_db_manager_using_env()
    if db_manager is None:
        return

    result = await db_manager.get_setting_value("app_name")
    print("설정 정보 조회 내용입니다.")
    print(f"설정 KEY: app_name, 내용: {result}")


async def create_and_user_and_bot_chat_histories(num_histories: int = 3):
    session_id = await create_chat_session()

    for i in range(num_histories):
        chat_number = await add_user_chat_history(
            session_id, f"감사합니다, 오늘 날씨 어때요? {i}"
        )
        await add_bot_chat_history(
            session_id,
            chat_number,
            f"감사합니다! 오늘 부산의 날씨는 맑고 화창합니다. {i}",
        )
        await asyncio.sleep(0.5)


async def get_static_message_from_intent():
    load_dotenv()

    # 현재 server
    db_manager = get_db_manager_using_env()
    if db_manager is None:
        return

    static_message = await db_manager.get_static_message_from_intent(901, "구내식당")

    if static_message:
        print(f"Static message for intent 901 '구내식당': {static_message}")
    else:
        print("None of Static message for intent 901 '구내식당'")


# 테스트용 엔드포인트: 특정 챗봇 타입에 대한 대기 메시지 가져오기
async def get_latest_waiting_message_by_type(
    typename: ChatbotTypeEnum,
):
    """
    특정 챗봇 타입에 대한 대기 메시지를 가져오는 엔드포인트
    """
    load_dotenv()

    admin_db_manager = get_admin_db_manager_using_env()
    if admin_db_manager is None:
        return None

    waiting_message = await admin_db_manager.get_latest_waiting_message_by_type(
        typename
    )

    print(f"{typename} 챗봇 타입에 대한 대기 메시지: {waiting_message}")

    await admin_db_manager.close()  # 명시적으로 close 처리해야 오류가 나지 않음

    return waiting_message


async def main():
    await get_latest_waiting_message_by_type(ChatbotTypeEnum.CREATE_DRAFT)


if __name__ == "__main__":
    asyncio.run(main())
