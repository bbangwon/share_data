import asyncio
import logging
import sys

from busan_bot_ui import BusanBotUIManager

# 루트 로거에 핸들러 추가 (전역 적용)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
    ],
)

logger = logging.getLogger(__name__)


class Custom(Exception):
    pass


async def main():
    busan_bot_ui_manager = BusanBotUIManager(
        config_path="./busan-config.yaml",
        static_messages_path="./busan-static-messages.yaml",
    )

    await busan_bot_ui_manager.write_error_log(
        task_id="test-task-001",
        user_id="test-user",
        bot_id="test-bot",
        log="문자열로 테스트",
    )

    # try:
    #     log = "테스트용 로그 메시지"
    #     raise httpx.TimeoutException(message="테스트용 타임아웃 예외 발생")
    # except Exception as e:
    #     log = e
    # finally:
    #     await busan_bot_ui_manager.write_log(
    #         task_id="test-task-001",
    #         user_id="test-user",
    #         bot_id="test-bot",
    #         log=log,
    #     )


if __name__ == "__main__":
    asyncio.run(main())
