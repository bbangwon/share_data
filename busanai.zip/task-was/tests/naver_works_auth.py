import asyncio
import logging

import httpx
from busan_bot_ui import BusanBotUIManager
from dotenv import load_dotenv

logging.basicConfig(level="DEBUG")
logger = logging.getLogger(__name__)

load_dotenv()

bot_id = "10242846"
user_id = "95fe2166-112c-4597-1115-032ccd8f293c"


async def issue_access_token():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    await bot_manager.bot_manager.auth_manager.issue_access_token()


async def revoke_access_token():
    bot_manager = BusanBotUIManager()

    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    await bot_manager.bot_manager.auth_manager.get_access_token()

    current_access_token = (
        bot_manager.bot_manager.auth_manager.access_token.access_token
    )

    logger.debug("현재 엑세스 토큰: %s", current_access_token)

    try:
        await bot_manager.bot_manager.auth_manager.revoke_access_token(
            current_access_token, "access_token"
        )
    except httpx.HTTPStatusError as e:
        logger.error("엑세스 토큰 취소 중 오류가 발생했습니다: %s", e.response.json())
        raise e
    except Exception as e:
        logger.error("엑세스 토큰 취소 중 알 수 없는 오류가 발생했습니다: %s", e)
        raise e


async def revoke_refresh_token():
    bot_manager = BusanBotUIManager()
    logger.debug("봇 메시지 매니저가 초기화되었습니다.")

    await bot_manager.bot_manager.auth_manager.get_access_token()
    current_refresh_token = (
        bot_manager.bot_manager.auth_manager.access_token.refresh_token
    )

    logger.debug("현재 리프레시 토큰: %s", current_refresh_token)

    try:
        await bot_manager.bot_manager.auth_manager.revoke_access_token(
            current_refresh_token, "refresh_token"
        )
    except httpx.HTTPStatusError as e:
        logger.error("리프레시 토큰 취소 중 오류가 발생했습니다: %s", e.response.json())
        raise e
    except Exception as e:
        logger.error("리프레시 토큰 취소 중 알 수 없는 오류가 발생했습니다: %s", e)
        raise e


if __name__ == "__main__":
    asyncio.run(revoke_refresh_token())
