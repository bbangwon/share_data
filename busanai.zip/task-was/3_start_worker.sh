#!/bin/bash

ENV=local uv run ./worker/main.py