#!/bin/bash

docker-compose -f docker-compose.prod.yml build --no-cache

# Remove unused images
docker rmi -f $(docker images -f "dangling=true" -q)

# Create dist
rm -rf ./dist
mkdir -p ./dist

# copy env files
cp .env.prod ./dist/.env
cp docker-compose.prod.yml ./dist/docker-compose.yml
cp private.prod.key ./dist/private.key
cp busan-config.prod.yaml ./dist/busan-config.yaml
cp busan-static-messages.yaml ./dist/busan-static-messages.yaml

docker save -o ./dist/task-was.tar task-was