from pydantic import BaseModel


class FileContent(BaseModel):
    name: str
    size: int
    content: str
