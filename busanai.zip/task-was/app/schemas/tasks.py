from pydantic import BaseModel, ConfigDict, Field
from request_queue import RequestQueueItem


def to_camel(string: str) -> str:
    parts = string.split("_")
    return parts[0] + "".join(word.capitalize() for word in parts[1:])


class Task(BaseModel):
    chat_id: int = Field(description="채팅 ID", examples=[123], default=0)
    task: RequestQueueItem = Field(
        ...,
        description="요청 큐 항목",
        examples=[
            {
                "id": "task_12345",
                "headers": {"Authorization": "Bearer token"},
                "body": {"chat_id": "1234567890", "message": "안녕하세요, 챗봇입니다!"},
            }
        ],
    )

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class CompleteTask(BaseModel):
    status: str = Field(
        description="작업 상태",
        examples=["success", "failed"],
        default="success",
    )
    reason: str | None = Field(
        description="작업 실패 사유",
        examples=[None, "네트워크 오류", "서버 오류"],
        default=None,
    )

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )
