import logging
from typing import Annotated

from admin_db_manager import AdminDBManager, get_admin_db_manager_using_env
from db_manager import DBManager, get_db_manager_using_env
from dotenv import load_dotenv
from fastapi import APIRouter, Body, Depends, Path, Response, status

from app.core import TaskManager, get_task_manager_using_env
from app.schemas.tasks import CompleteTask, Task

load_dotenv()
# 로깅 설정 (최상단에 배치)
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/tasks",
)


def get_db_manager():
    return get_db_manager_using_env()


def get_task_manager():
    return get_task_manager_using_env()


@router.get("/next")
async def get_next_task(
    db_manager: Annotated[DBManager, Depends(get_db_manager)],
    task_manager: Annotated[TaskManager, Depends(get_task_manager)],
):
    """
    다음 작업을 가져오는 엔드포인트
    """
    logger.debug("다음 작업을 요청합니다.")

    # 처리 중인 작업 수 제한(Throttling)
    available_process = await task_manager.available_process_tasks()
    if not available_process:
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    # 다음 작업 가져오기
    item = await task_manager.get_next_task()
    if item is None:
        logger.debug("다음 작업이 없습니다.")
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    # 데이터베이스에서 채팅세션을 조회하고, 필요한 경우 추가 정보를 가져옵니다.
    chat_id = await db_manager.get_last_chat_session_id(
        user_id=item.get_user_id(), bot_id=item.get_bot_id()
    )

    task = Task(
        task=item,
        chat_id=chat_id,
    )
    logger.info(f"다음 작업을 반환합니다: {task}")
    return task


@router.get("/status")
async def get_task_status(
    user_id: str,
    bot_id: str,
    task_manager: Annotated[TaskManager, Depends(get_task_manager)],
):
    """
    현재 특정 유저의 작업 상태를 확인하는 엔드포인트
    """
    logger.info("작업 상태를 확인합니다.")
    status = await task_manager.get_task_status(user_id=user_id, bot_id=bot_id)
    return {"status": status}


@router.get("/next/postback")
async def get_next_postback_task(
    task_manager: Annotated[TaskManager, Depends(get_task_manager)],
):
    """
    다음 포스트백 작업을 가져오는 엔드포인트
    """
    logger.info("다음 포스트백 작업을 요청합니다.")
    item = await task_manager.get_next_postback_task()
    if item is None:
        logger.info("다음 포스트백 작업이 없습니다.")
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    task = Task(task=item)
    logger.info(f"다음 포스트백 작업을 반환합니다: {task}")

    return task


@router.get("/next/file")
async def get_next_file_task(
    task_manager: Annotated[TaskManager, Depends(get_task_manager)],
):
    """
    다음 파일 작업을 가져오는 엔드포인트
    """
    logger.info("다음 파일 작업을 요청합니다.")
    item = await task_manager.get_next_file_task()
    if item is None:
        logger.info("다음 파일 작업이 없습니다.")
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    task = Task(task=item)
    logger.info(f"다음 파일 작업을 반환합니다: {task}")
    return task


@router.post("/{task_id}/complete")
async def complete_task(
    task_id: str,
    complete: Annotated[CompleteTask, Body(...)],
    task_manager: Annotated[TaskManager, Depends(get_task_manager)],
):
    """
    작업 완료 엔드포인트
    """
    logger.info(f"작업 완료 요청: {task_id}, 완료정보 {complete}")

    await task_manager.complete_task(task_id)
    logger.info(f"작업 {task_id}이(가) 완료되었습니다.")

    return Response(status_code=status.HTTP_200_OK)


# # Admin DB 연결 및 API 확인 후 삭제할 것


# # 테스트용 어드민 데이터베이스 매니저 가져오기
# def get_admin_db_manager():
#     return get_admin_db_manager_using_env()


# # 테스트용 엔드포인트: 특정 챗봇 타입에 대한 대기 메시지 가져오기
# @router.get("/get-waiting-message/{typename}")
# async def get_waiting_message(
#     admin_db_manager: Annotated[AdminDBManager, Depends(get_admin_db_manager)],
#     typename: str = Path(
#         ..., description="타입이름 (CREATE_DRAFT, EXTERNAL_ANALYSIS, QNA)"
#     ),
# ):
#     """
#     특정 챗봇 타입에 대한 대기 메시지를 가져오는 엔드포인트
#     """
#     logger.info(f"대기 메시지 요청: {typename}")

#     message = await admin_db_manager.get_latest_waiting_message_by_type(
#         chatbot_type=typename
#     )
#     if message is None:
#         logger.info(f"대기 메시지가 없습니다: {typename}")
#         return Response(status_code=status.HTTP_204_NO_CONTENT)

#     logger.info(f"대기 메시지를 반환합니다: {message}")
#     return {"message": message}
