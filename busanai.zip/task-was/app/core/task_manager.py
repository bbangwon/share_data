import asyncio
import json
import logging
import os
from typing import Callable, List, Literal

import redis.asyncio as redis
from busan_bot_ui import BusanBotUIManager
from db_manager import ChatHistory, DBManager, get_db_manager_using_env
from request_queue.schemes.request_queue_item import RequestQueueItem

from app.schemas.file_content import FileContent

logger = logging.getLogger(__name__)

POST_BACK_QUEUE_NAME = "postback_queue"
FILE_QUEUE_NAME = "file_queue"
READY_TASKS_PREFIX = "ready_tasks:"
READY_TASK_ORDER = "task_order"
PROCESSING_TASKS_PREFIX = "processing_tasks:"
PUBLISH_CHANNEL = "task_updates"


class TaskManager:
    def __init__(
        self,
        redis_url: str,
        publish_channel: str = PUBLISH_CHANNEL,
        task_ttl: int = 600,
        task_postback_ttl: int = 10,
        task_processing_limit_count: int = 0,
    ):
        self.redis_url = redis_url
        self.redis_client = None
        self.publish_channel = publish_channel
        self.task_ttl = task_ttl
        self.task_postback_ttl = task_postback_ttl
        self.task_processing_limit_count = task_processing_limit_count
        self.lock = asyncio.Lock()
        self.subscribed_channels = set()
        self.db_manager: DBManager = get_db_manager_using_env()
        self.bot_manager: BusanBotUIManager = BusanBotUIManager()

    async def connect(self):
        """Redis 연결"""
        if self.redis_client:
            logger.info("이미 Redis에 연결되어 있습니다.")
            return
        logger.debug(f"Redis에 연결 중: {self.redis_url}")
        try:
            self.redis_client = redis.from_url(self.redis_url, decode_responses=True)
            await self.redis_client.ping()
            logger.debug("Redis에 연결되었습니다.")
        except redis.ConnectionError as e:
            logger.error(f"Redis 연결 오류: {e}")
            self.redis_client = None
            raise e

    async def disconnect(self):
        """Redis 연결 종료"""
        if self.redis_client:
            await self.redis_client.close()
            logger.debug("Redis 연결이 종료되었습니다.")
            self.redis_client = None
        else:
            logger.debug("Redis 연결이 이미 종료되었습니다.")

    async def _process_last_file_content(self, queue_item: RequestQueueItem):
        """마지막 채팅 이력이 파일 컨텐츠일 경우 꺼내오고 파일 DB에서 삭제한다."""
        user_id = queue_item.get_user_id()
        bot_id = queue_item.get_bot_id()

        last_chats: List[
            ChatHistory
        ] = await self.db_manager.get_last_chat_histories_by_user_and_bot_id(
            user_id=user_id, bot_id=bot_id, allow_empty_bot_message=True, count=1
        )

        if last_chats:
            last_chat = last_chats[0]

            last_session_id = await self.db_manager.get_last_chat_session_id(
                user_id=user_id, bot_id=bot_id
            )

            if (
                last_chat.chat_session_id == last_session_id
                and last_chat.is_file_content
            ):
                result = last_chat.user_message
                await self.db_manager.delete_chat_history(last_chat)
                return result

        return None

    async def enqueue_task(
        self, queue_item: RequestQueueItem
    ) -> Literal["postback", "file", "task"]:  # Enqueue Type
        """
        특정 사용자의 작업을 작업 큐에 추가합니다.
        postback 작업은 실시간 처리되며, 일반 작업은 ready_tasks 목록에 추가됩니다.
        """
        if not self.redis_client:
            await self.connect()

        q_item = queue_item.model_copy()

        user_id = q_item.get_user_id()
        bot_id = q_item.get_bot_id()
        file_id = q_item.get_file_id()
        postback = q_item.get_postback()

        item_dict = q_item.model_dump()

        # 마지막 채팅이 파일 컨텐츠일 경우 컨텐츠를 가져오고 DB에서 삭제함
        last_file_content = await self._process_last_file_content(q_item)

        task_type = "task"
        if postback:
            item_json = q_item.model_dump_json()
            await self.redis_client.rpush(POST_BACK_QUEUE_NAME, item_json)
            task_type = "postback"
        elif file_id:
            item_json = q_item.model_dump_json()
            await self.redis_client.rpush(FILE_QUEUE_NAME, item_json)
            task_type = "file"
        else:
            # 파일 처리( 이전 채팅이 파일일 경우..) 가져와서 이번 작업에 포함..
            task_id = q_item.id

            if last_file_content:
                await self.bot_manager.write_file_proc_log(
                    task_id=task_id,
                    user_id=user_id,
                    bot_id=bot_id,
                    log={
                        "was": "task-manager",
                        "message": "0. 이전 파일 처리 내용을 이번 작업에 포함하여 큐에 적재합니다.",
                        "file_content": last_file_content,
                        "task_id": task_id,
                    },
                )

                file_content = FileContent.model_validate_json(last_file_content)
                q_item.add_attached_file(file_content.model_dump())

            # 파일 처리 완료.
            item_json = q_item.model_dump_json()

            # 사용자별로 ready_tasks 목록에 작업을 추가합니다. (병렬작업을 위해)
            pipeline = self.redis_client.pipeline()

            pipeline.rpush(f"{READY_TASKS_PREFIX}{user_id}_{bot_id}", item_json)
            pipeline.rpush(READY_TASK_ORDER, f"{user_id}_{bot_id}")
            await pipeline.execute()

        if self.publish_channel:
            await self.publish_message(item_dict)

        return task_type

    async def _set_processing_task(self, item: RequestQueueItem):
        """
        특정 사용자의 작업을 처리 중인 상태로 설정합니다.
        """
        if not self.redis_client:
            await self.connect()

        await self.redis_client.hset(
            name=f"{PROCESSING_TASKS_PREFIX}{item.id}",
            mapping={
                "task_id": item.id,
                "user_id": item.get_user_id(),
                "bot_id": item.get_bot_id(),
                "task": item.model_dump_json(),
            },
        )
        # TTL 설정
        await self.redis_client.expire(
            f"{PROCESSING_TASKS_PREFIX}{item.id}", self.task_ttl
        )

    async def get_next_file_task(self) -> RequestQueueItem | None:
        """
        파일 작업을 시작합니다.
        파일 작업은 큐에 있지만 거의 실시간으로 처리되며, 사용자 ID를 기반으로 작업을 시작합니다.
        """
        if not self.redis_client:
            await self.connect()

        task_json = await self.redis_client.lpop(FILE_QUEUE_NAME)
        if not task_json:
            logger.info("파일 작업이 없습니다.")
            return None

        item = RequestQueueItem.model_validate_json(task_json)
        await self._set_processing_task(item)

        logger.info(f"'{item.id}' 파일 작업을 가져왔습니다.")
        return item

    async def get_next_postback_task(self) -> RequestQueueItem | None:
        """
        포스트백 작업을 시작합니다.
        포스트백 작업은 큐에 있지만 거의 실시간으로 처리되며, 사용자 ID를 기반으로 작업을 시작합니다.
        """
        if not self.redis_client:
            await self.connect()

        task_json = await self.redis_client.lpop(POST_BACK_QUEUE_NAME)
        if not task_json:
            logger.info("포스트백 작업이 없습니다.")
            return None

        item = RequestQueueItem.model_validate_json(task_json)
        await self._set_processing_task(item)

        logger.info(f"'{item.id}' 포스트백 작업을 가져왔습니다.")
        return item

    async def get_next_task(self) -> RequestQueueItem | None:
        """
        준비된 작업중 하나를 시작합니다.
        현재 작업 중인 사용자는 제외하고, 준비된 사용자 목록에서 작업을 가져옵니다.
        만약 모든 사용자가 현재 작업 중이라면 None을 반환합니다.
        """
        if not self.redis_client:
            await self.connect()

        async with self.lock:
            # task_order 목록에서 가장 먼저 준비된 사용자를 가져옵니다.
            max_attempts = await self.redis_client.llen(READY_TASK_ORDER)
            if max_attempts == 0:
                logger.debug("준비된 사용자가 없습니다.")
                return None

            processing_users = set()
            async for key in self.redis_client.scan_iter(f"{PROCESSING_TASKS_PREFIX}*"):
                processing_user_id = await self.redis_client.hget(key, "user_id")
                processing_bot_id = await self.redis_client.hget(key, "bot_id")
                if processing_user_id and processing_bot_id:
                    processing_users.add(f"{processing_user_id}_{processing_bot_id}")

            for _ in range(max_attempts):
                user_and_bot_id = await self.redis_client.lpop(READY_TASK_ORDER)
                logger.debug(f"'{user_and_bot_id}' 사용자의 준비된 작업을 가져옵니다.")

                if not user_and_bot_id:
                    break

                # 사용자가 현재 작업이 끝나지 않았다면..  다음에 하도록 큐를 뒤로 미룸
                if user_and_bot_id in processing_users:
                    logger.debug(
                        f"'{user_and_bot_id}' 사용자는 현재 작업 중입니다. 다음 유저를 확인합니다."
                    )
                    await self.redis_client.rpush(READY_TASK_ORDER, user_and_bot_id)
                    continue

                task_json = await self.redis_client.lpop(
                    f"{READY_TASKS_PREFIX}{user_and_bot_id}"
                )
                if not task_json:
                    logger.warning(
                        f"'{user_and_bot_id}' 사용자의 작업이 없습니다. 다음 유저를 확인합니다."
                    )
                    continue

                item = RequestQueueItem.model_validate_json(task_json)
                await self._set_processing_task(item)

                logger.info(f"'{item.id}' 작업을 가져왔습니다.")
                return item

        logger.debug("모든 사용자가 현재 작업 중입니다.")
        return None

    async def get_task_status(
        self, user_id: str, bot_id: str
    ) -> Literal["idle", "ready", "processing"]:
        """
        특정 사용자의 작업의 상태를 가져옵니다.
        """
        if not self.redis_client:
            await self.connect()

        if f"{READY_TASKS_PREFIX}{user_id}_{bot_id}" in await self.redis_client.keys():
            logger.info(f"'{user_id}_{bot_id}' 사용자의 작업이 준비 중입니다.")
            return "ready"

        async for key in self.redis_client.scan_iter(f"{PROCESSING_TASKS_PREFIX}*"):
            processing_user_id = await self.redis_client.hget(key, "user_id")
            processing_bot_id = await self.redis_client.hget(key, "bot_id")
            if processing_user_id == user_id and processing_bot_id == bot_id:
                logger.info(f"'{user_id}_{bot_id}' 사용자의 작업이 현재 처리 중입니다.")
                return "processing"

        logger.info(f"'{user_id}_{bot_id}' 사용자의 작업이 현재 처리 중이지 않습니다.")
        return "idle"

    async def get_processing_task(self, task_id: str) -> RequestQueueItem:
        """
        특정 사용자의 현재 처리 중인 작업을 가져옵니다.
        """
        if not self.redis_client:
            await self.connect()

        task_data = await self.redis_client.hgetall(
            f"{PROCESSING_TASKS_PREFIX}{task_id}"
        )
        if not task_data:
            logger.info(f"'{task_id}' 작업이 처리 중이 아닙니다.")
            return None

        task_json = task_data.get("task")
        if not task_json:
            logger.error(f"'{task_id}' 작업 데이터가 손상되었습니다.")
            return None

        item = RequestQueueItem.model_validate_json(task_json)
        logger.info(f"'{task_id}' 작업을 가져왔습니다.")
        return item

    async def count_processing_tasks(self) -> int:
        """
        현재 처리 중인 작업의 수를 반환합니다.
        """
        if not self.redis_client:
            await self.connect()

        keys = await self.redis_client.keys(f"{PROCESSING_TASKS_PREFIX}*")
        count = len(keys)

        logger.debug(f"현재 처리 중인 작업 수 반환: {count}")
        return count

    async def available_process_tasks(self) -> bool:
        """
        현재 처리 가능한 작업인지 확인합니다.
        """
        if self.task_processing_limit_count <= 0:
            return True

        processing_count = await self.count_processing_tasks()
        if processing_count >= self.task_processing_limit_count:
            logger.debug(
                f"처리 중인 작업 수가 제한에 도달했습니다: {processing_count} / {self.task_processing_limit_count}"
            )
            return False
        return True

    async def complete_task(self, task_id: str):
        """
        특정 사용자의 작업을 완료하고, 해당 작업을 처리 중인 상태에서 제거합니다.
        """
        if not self.redis_client:
            await self.connect()

        await self.redis_client.delete(f"{PROCESSING_TASKS_PREFIX}{task_id}")
        logger.info(f"'{task_id}' 작업을 완료합니다.")

    async def publish_message(self, message: dict):
        """Redis Pub/Sub을 사용하여 메시지를 발행합니다."""
        if not self.redis_client:
            await self.connect()

        message_json = json.dumps(message, ensure_ascii=False)

        logger.info(
            f"'{self.publish_channel}' 채널에 메시지를 발행합니다: {message_json}"
        )
        await self.redis_client.publish(
            channel=self.publish_channel, message=message_json
        )

    async def subscribe(
        self, callback: Callable[[dict], None], call_callback_on_start=True
    ):
        """Redis Pub/Sub을 사용하여 큐를 구독합니다."""
        if not self.redis_client:
            await self.connect()
        try:
            async with self.redis_client.pubsub() as pubsub:
                await pubsub.subscribe(self.publish_channel)
                self.subscribed_channels.add(self.publish_channel)

                if call_callback_on_start:
                    callback()  # 구독 시작 시 콜백 호출

                while self.subscribed_channels.__contains__(self.publish_channel):
                    message = await pubsub.get_message()
                    if message and message["type"] == "message":
                        item = json.loads(message["data"])
                        callback(item)
        except redis.ConnectionError as e:
            logger.error(f"Redis 연결 오류...구독 복구를 시도합니다. {e}")
            await self.disconnect()
            asyncio.create_task(
                self._recover_subscribe(self.publish_channel, callback)
            )  # 연결 복구 시도

    async def unsubscribe(self):
        """Redis Pub/Sub 구독을 취소합니다."""
        if not self.redis_client:
            await self.connect()

        async with self.redis_client.pubsub() as pubsub:
            await pubsub.unsubscribe(self.publish_channel)
            self.subscribed_channels.discard(self.publish_channel)
            logger.info(f"'{self.publish_channel}' 구독을 취소했습니다.")

    async def _recover_subscribe(self, channel: str, callback: Callable[[dict], None]):
        """구독 복구 시도"""
        while self.subscribed_channels.__contains__(channel):
            try:
                logger.debug(f"'{channel}' 채널 구독을 복구 시도 중...")
                if not self.redis_client:
                    await self.connect()

                # 재구독
                asyncio.create_task(self.subscribe(callback))

                logger.info(f"'{channel}' 채널 구독을 복구했습니다.")
                return
            except redis.ConnectionError:
                await asyncio.sleep(5)  # 5초 후에 재시도


# Helper 함수: DBManager 인스턴스를 환경 변수에서 가져옵니다.
def get_task_manager_using_env(
    redis_url=None,
    task_ttl=None,
    task_postback_ttl=None,
    task_processing_limit_count=None,
) -> TaskManager:
    """환경 변수에서 Redis URL을 가져와 TaskManager 인스턴스를 반환합니다. redis_url을 직접 지정할 수 있습니다."""

    if not redis_url:
        env_name_redis_url = "TASK_REDIS_URL"
        redis_url = os.getenv(env_name_redis_url)
        if not redis_url:
            env_name_redis_url = "REQUEST_REDIS_URL"
            redis_url = os.getenv(env_name_redis_url)
        if not redis_url:
            raise ValueError(
                "TASK_REDIS_URL나 REQUEST_REDIS_URL 환경 변수가 설정되어 있지 않습니다."
            )

    if not task_ttl:
        env_name_task_ttl = "TASK_TTL"
        task_ttl = int(os.getenv(env_name_task_ttl))
        if not task_ttl:
            raise ValueError(f"{env_name_task_ttl} 환경 변수가 설정되어 있지 않습니다.")

    if not task_postback_ttl:
        env_name_task_postback_ttl = "TASK_POSTBACK_TTL"
        task_postback_ttl = int(os.getenv(env_name_task_postback_ttl))
        if not task_postback_ttl:
            raise ValueError(
                f"{env_name_task_postback_ttl} 환경 변수가 설정되어 있지 않습니다."
            )

    if not task_processing_limit_count:
        env_name_task_processing_limit_count = "TASK_PROCESSING_LIMIT_COUNT"
        task_processing_limit_count = int(
            os.getenv(env_name_task_processing_limit_count, "0")
        )

    logger.debug(
        f"TaskManager 인스턴스를 생성합니다. Redis URL: {redis_url}, Task TTL: {task_ttl}, Task Postback TTL: {task_postback_ttl}, Task Processing Limit Count: {task_processing_limit_count}"
    )
    return TaskManager(
        redis_url=redis_url,
        task_ttl=task_ttl,
        task_postback_ttl=task_postback_ttl,
        task_processing_limit_count=task_processing_limit_count,
    )
