import logging
import logging.handlers
import os

from dotenv import load_dotenv
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1 import tasks

load_dotenv()
LOG_LEVEL = os.getenv("LOG_LEVEL", "ERROR").upper()
if LOG_LEVEL not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
    raise ValueError(f"Invalid LOG_LEVEL: {LOG_LEVEL}")

LOG_DIR = os.getenv("LOG_DIR", "./logs")
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", 7))

log_file_path = os.path.join(LOG_DIR, "task-was.log")
logging.basicConfig(
    level=LOG_LEVEL,
    format="[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s",
    handlers=[
        logging.StreamHandler(),  # 콘솔에 로그 출력
        logging.handlers.TimedRotatingFileHandler(
            log_file_path,
            when="midnight",  # 매일 자정에 로그 파일을 새로 만듭니다.
            interval=1,  # 1일마다 새 로그 파일 생성
            backupCount=LOG_BACKUP_COUNT,  # 최대 n개의 백업 로그 파일 유지
            encoding="utf-8",
            utc=False,  # 로컬 시간 사용
        ),
    ],
)

app = FastAPI()


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    # 빈 응답
    return Response(status_code=404)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(tasks.router)


@app.get("/health")
async def health_check():
    return {"status": "healthy"}
