#!/bin/bash

uv run ./tests/update_static_html_url_from_ngrok.py