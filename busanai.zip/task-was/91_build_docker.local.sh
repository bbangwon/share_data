#!/bin/bash

docker-compose build --no-cache

# Remove unused images
docker rmi -f $(docker images -f "dangling=true" -q)

# Create dist
rm -rf ./dist
mkdir -p ./dist

# copy env files
cp .env ./dist/.env
cp docker-compose.yml ./dist/docker-compose.yml
cp private.key ./dist/private.key
cp busan-config.yaml ./dist/busan-config.yaml
cp busan-static-messages.yaml ./dist/busan-static-messages.yaml

docker save -o ./dist/task-was.tar task-was
