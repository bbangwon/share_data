#!/usr/bin/env python3
"""
원자력 안전 분야 골든셋 평가 테스트 스크립트.
Rerank 점수가 적용된 골든셋 데이터를 기반으로 /evaluate-simple-nuclear API를 호출하고
Reasoning-selector에 의해 업데이트된 점수와 Top 5 포함 여부 등을 결과 파일로 저장합니다.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

# 프로젝트 루트 디렉토리를 path에 추가하여 app 모듈을 임포트할 수 있도록 함
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# tqdm 사용 여부
try:
    from tqdm import tqdm
except ImportError:
    def tqdm(iterable, *args, **kwargs):
        return iterable

# API를 직접 호출할 경우를 위해 app.main을 조건부 임포트 (TestClient용)
try:
    from fastapi.testclient import TestClient
    from app.main import app
    HAS_TEST_CLIENT = True
except ImportError as e:
    HAS_TEST_CLIENT = False
    print(f"[경고] FastAPI TestClient를 로드하지 못했습니다: {e}. API URL을 통한 호출만 가능합니다.")


def sanitize_title(title: Any) -> str | None:
    """FastAPI SimpleChunk validation에 맞게 타이틀을 정제합니다."""
    if title is None:
        return None
    s_title = str(title).strip()
    if not s_title:
        return None
    return s_title


def compute_hits(scores: list[float], page_numbers: list[int], correct_pages: set[int]) -> tuple[bool, bool, bool]:
    """주어진 점수와 페이지 번호, 정답 페이지 번호를 바탕으로 Top 1, Top 5, Top 10 Hit 여부를 반환합니다."""
    sorted_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
    top_1_hit = False
    top_5_hit = False
    top_10_hit = False
    
    for rank, idx in enumerate(sorted_indices, start=1):
        page = page_numbers[idx]
        if page in correct_pages:
            if rank == 1:
                top_1_hit = True
            if rank <= 5:
                top_5_hit = True
            if rank <= 10:
                top_10_hit = True
                
    return top_1_hit, top_5_hit, top_10_hit


def compute_ranks_and_top5(scores: list[float]) -> tuple[list[int], list[bool]]:
    """점수 리스트의 순위(1-indexed)와 Top 5 포함 여부 리스트를 반환합니다."""
    n = len(scores)
    sorted_indices = sorted(range(n), key=lambda i: scores[i], reverse=True)
    ranks = [0] * n
    for rank, idx in enumerate(sorted_indices, start=1):
        ranks[idx] = rank
    top5_flags = [rank <= 5 for rank in ranks]
    return ranks, top5_flags


def call_api_url(api_url: str, payload: dict[str, Any], timeout: float) -> dict[str, Any]:
    """지정된 외부 API URL로 POST 요청을 보냅니다."""
    import httpx
    with httpx.Client(timeout=timeout) as client:
        response = client.post(api_url, json=payload)
        response.raise_for_status()
        return response.json()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="원자력 안전 분야 Rerank 골든셋 데이터를 사용하여 reasoning-selector 평가 테스트를 수행합니다."
    )
    parser.add_argument(
        "-i",
        "--input",
        default="tests/goldenset_qdrant_similarity_and_rerank_results_refined.json",
        help="입력 골든셋 JSON 파일 경로 (기본값: tests/goldenset_qdrant_similarity_and_rerank_results_refined.json)",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="tests/goldenset_nuclear_evaluation_results.json",
        help="출력 결과 JSON 파일 경로 (기본값: tests/goldenset_nuclear_evaluation_results.json)",
    )
    parser.add_argument(
        "-u",
        "--api-url",
        default=None,
        help="evaluate-simple-nuclear API URL (예: http://localhost:8000/evaluate-simple-nuclear). 지정하지 않을 경우 내부 TestClient를 사용하여 서버 기동 없이 직접 동작합니다.",
    )
    parser.add_argument(
        "-l",
        "--limit",
        type=int,
        default=None,
        help="평가할 질의의 최대 개수 (기본값: 전체 평가)",
    )
    parser.add_argument(
        "-t",
        "--timeout",
        type=float,
        default=120.0,
        help="API 호출 타임아웃(초) (기본값: 120)",
    )

    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)

    if not input_path.exists():
        print(f"[오류] 입력 파일이 존재하지 않습니다: {input_path}", file=sys.stderr)
        return 1

    print(f"골든셋 데이터 로드 중: {input_path}")
    with input_path.open("r", encoding="utf-8") as f:
        goldenset = json.load(f)

    if not isinstance(goldenset, list):
        print("[오류] 골든셋 파일 형식이 리스트가 아닙니다.", file=sys.stderr)
        return 1

    total_items = len(goldenset)
    limit = args.limit if args.limit is not None else total_items
    items_to_eval = goldenset[:limit]
    print(f"총 {total_items}건 중 {len(items_to_eval)}건의 질의 평가 진행 예정")

    results = []
    
    # 평가 수행 시간 측정
    start_time = time.time()
    
    # 모드에 따른 처리기 설정
    use_test_client = False
    if args.api_url is None:
        if HAS_TEST_CLIENT:
            use_test_client = True
            print("내부 TestClient(app)를 사용해 가상 호출로 평가를 시작합니다. (별도 uvicorn 구동 불필요)")
        else:
            print("[오류] TestClient를 사용할 수 없으며 --api-url이 지정되지 않았습니다.", file=sys.stderr)
            return 1
    else:
        print(f"외부 API 서버 호출 모드: {args.api_url}")

    # 통계 기록용
    total_queries = len(items_to_eval)
    
    # 원래 Rerank 기준 Hit 통계
    orig_top1_hits = 0
    orig_top5_hits = 0
    orig_top10_hits = 0
    
    # Reasoning Selector 기준 Hit 통계
    new_top1_hits = 0
    new_top5_hits = 0
    new_top10_hits = 0

    # API 호출 공통 요청 생성부
    def make_payload(item: dict[str, Any]) -> dict[str, Any]:
        chunks_payload = []
        for i in range(len(item["청크"])):
            chunks_payload.append({
                "content": item["청크"][i],
                "filename": item["검색 소스"][i],
                "title": sanitize_title(item["타이틀"][i]),
                "score": item["rerank 점수"][i]  # score는 rerank 점수로 전달
            })
        return {
            "query": item["질의문"],
            "chunks": chunks_payload
        }

    def process_item_result(orig_item: dict[str, Any], response_data: dict[str, Any], index: int, elapsed: float):
        nonlocal orig_top1_hits, orig_top5_hits, orig_top10_hits
        nonlocal new_top1_hits, new_top5_hits, new_top10_hits

        # 1. 원본 Rerank 점수 기반 Hit 계산
        correct_pages = set(orig_item.get("정답 쪽번호", []))
        page_numbers = orig_item.get("쪽번호", [])
        rerank_scores = orig_item.get("rerank 점수", [])
        
        orig_top1_hit, orig_top5_hit, orig_top10_hit = compute_hits(rerank_scores, page_numbers, correct_pages)
        if orig_top1_hit: orig_top1_hits += 1
        if orig_top5_hit: orig_top5_hits += 1
        if orig_top10_hit: orig_top10_hits += 1

        # 2. Reasoning Selector 결과 처리
        # 응답 chunks의 순서는 입력 chunks의 순서와 1:1 대응
        updated_chunks = response_data.get("chunks", [])
        new_scores = [chunk["score"] for chunk in updated_chunks]
        
        # 순위 및 Top 5 여부 계산
        ranks, top5_flags = compute_ranks_and_top5(new_scores)
        
        # Reasoning Selector 기준 Hit 계산
        new_top1_hit, new_top5_hit, new_top10_hit = compute_hits(new_scores, page_numbers, correct_pages)
        if new_top1_hit: new_top1_hits += 1
        if new_top5_hit: new_top5_hits += 1
        if new_top10_hit: new_top10_hits += 1

        # 결과 데이터 결합
        result_item = {
            "질의문": orig_item["질의문"],
            "정답 쪽번호": orig_item["정답 쪽번호"],
            "Hybrid Stage Hit": orig_item.get("Hybrid Stage Hit", False),
            "Rerank Stage Hit": orig_item.get("Rerank Stage Hit", False),
            
            # 원본 Rerank Hit 통계 저장
            "Original Rerank Top 1 Hit": orig_top1_hit,
            "Original Rerank Top 5 Hit": orig_top5_hit,
            "Original Rerank Top 10 Hit": orig_top10_hit,

            # Reasoning Selector Hit 통계 저장
            "Reasoning Selector Top 1 Hit": new_top1_hit,
            "Reasoning Selector Top 5 Hit": new_top5_hit,
            "Reasoning Selector Top 10 Hit": new_top10_hit,

            # 청크 리스트 상세 (순서 동일)
            "노드 ID": orig_item["노드 ID"],
            "타이틀": orig_item["타이틀"],
            "쪽번호": orig_item["쪽번호"],
            "청크": orig_item["청크"],
            "유사도 점수": orig_item["유사도 점수"],
            "rerank 점수": orig_item["rerank 점수"],
            "검색 소스": orig_item["검색 소스"],
            
            # Reasoning Selector 추가 필드
            "Reasoning Selector 점수": new_scores,
            "Reasoning Selector 순위": ranks,
            "Reasoning Selector Top 5 여부": top5_flags,
            "평가 소요시간": elapsed
        }
        results.append(result_item)

    try:
        if use_test_client:
            # TestClient context manager를 한 번만 감싸서 매번 시작/종료하는 비효율 방지
            with TestClient(app) as client:
                for idx, item in enumerate(tqdm(items_to_eval, desc="평가 진행 중")):
                    payload = make_payload(item)
                    q_start = time.time()
                    
                    response = client.post("/evaluate-simple-nuclear", json=payload)
                    if response.status_code != 200:
                        raise RuntimeError(f"API 호출 실패 ({response.status_code}): {response.text}")
                    
                    resp_data = response.json()
                    q_elapsed = time.time() - q_start
                    
                    # 결과 매핑 및 순위 계산
                    process_item_result(item, resp_data, idx, q_elapsed)
        else:
            for idx, item in enumerate(tqdm(items_to_eval, desc="평가 진행 중")):
                payload = make_payload(item)
                q_start = time.time()
                
                resp_data = call_api_url(args.api_url, payload, args.timeout)
                q_elapsed = time.time() - q_start
                
                # 결과 매핑 및 순위 계산
                process_item_result(item, resp_data, idx, q_elapsed)

    except Exception as e:
        print(f"\n[오류] 평가 수행 중 에러 발생: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return 1

    # 결과 파일 저장
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    total_elapsed = time.time() - start_time
    avg_elapsed = total_elapsed / total_queries if total_queries > 0 else 0

    # 콘솔에 평가 요약 통계 출력
    print("\n" + "=" * 60)
    print(" 원자력 안전 Rerank + Reasoning Selector 평가 결과 요약")
    print("=" * 60)
    print(f"평가 질의 개수: {total_queries}건")
    print(f"총 소요시간   : {total_elapsed:.2f}초 (평균 {avg_elapsed:.2f}초/질의)")
    print("-" * 60)
    print(f"메트릭 비교   | 원본 Rerank Hit Rate | Reasoning Selector Hit Rate")
    print("-" * 60)
    print(f"Top 1 Hit     |  {orig_top1_hits / total_queries * 100:6.2f}% ({orig_top1_hits}/{total_queries})   |  {new_top1_hits / total_queries * 100:6.2f}% ({new_top1_hits}/{total_queries})")
    print(f"Top 5 Hit     |  {orig_top5_hits / total_queries * 100:6.2f}% ({orig_top5_hits}/{total_queries})   |  {new_top5_hits / total_queries * 100:6.2f}% ({new_top5_hits}/{total_queries})")
    print(f"Top 10 Hit    |  {orig_top10_hits / total_queries * 100:6.2f}% ({orig_top10_hits}/{total_queries})   |  {new_top10_hits / total_queries * 100:6.2f}% ({new_top10_hits}/{total_queries})")
    print("=" * 60)
    print(f"결과가 성공적으로 저장되었습니다: {output_path}")
    print("=" * 60 + "\n")

    return 0


if __name__ == "__main__":
    sys.exit(main())
