# 패키징 및 배포 가이드 (Packaging & Deployment Guide)

이 가이드는 **RAG Chunk Evaluator (reasoning-selector-was)** 서비스를 패키징하고 대상 서버에 배포하는 방법을 설명합니다. 본 서비스는 폐쇄망(Air-Gapped) 환경으로의 배포를 지원하기 위해 오프라인 의존성 설치 방식을 채택하고 있습니다.

---

## 배포 아키텍처 및 특징

- **오프라인 빌드 지원**: 인터넷 연결이 되지 않는 환경을 고려하여, 필요한 Python 라이브러리(`.whl` 파일)를 빌드 시점에 사전에 다운로드 받아 Docker 이미지 내에 로컬 설치 모드(`--no-index --find-links=/wheels`)로 구성합니다.
- **컨테이너화 배포**: Docker와 Docker Compose를 사용하여 환경에 구애받지 않고 일관되게 서비스를 실행할 수 있도록 패키징합니다.
- **환경 분리**: 로컬/개발 검증용 배포 설정과 실제 서비스 운영용 배포 설정을 분리하여 관리합니다.

---

## 사전 요구 사항

1. **Docker 및 Docker Compose**가 빌드 환경과 배포 대상 서버에 설치되어 있어야 합니다.
2. **베이스 이미지 준비**: Dockerfile 빌드에 사용되는 베이스 이미지인 `busan-python-base:latest` 이미지가 빌드 호스트에 미리 로드되어 있어야 합니다.
3. **Whl 다운로더 이미지**: 오프라인 패키지 다운로드를 위해 `whl-downloader` Docker 이미지가 필요합니다.

---

## 1단계. 패키징 프로세스 (Packaging Process)

패키징 작업은 제공되는 3개의 쉘 스크립트를 사용하여 단계적으로 수행됩니다.

### 전체 흐름 요약
```mermaid
graph TD
    A[개발 환경] --> B(90_build_wheels.sh 실행)
    B --> C[requirements.txt 생성 및 wheels 폴더에 패키지 다운로드]
    C --> D{배포 환경 선택}
    D -->|로컬 테스트용| E(91_build_docker.local.sh 실행)
    D -->|운영 서버용| F(92_build_docker.prod.sh 실행)
    E --> G[./dist 폴더 생성<br>reasoning-selector-was.tar<br>.env / docker-compose.yml]
    F --> H[./dist 폴더 생성<br>reasoning-selector-was.tar<br>.env / docker-compose.yml]
```

---

## 2단계. 패키징 스크립트 상세 설명

### 1. `90_build_wheels.sh` (의존성 패키지 다운로드)
이 스크립트는 프로젝트에 명세된 Python 의존성 라이브러리들을 오프라인 설치용 휠(`.whl`) 파일로 일괄 다운로드합니다.

- **스크립트 위치**: [90_build_wheels.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/reasoning-selector-was/90_build_wheels.sh)
- **작동 기전**:
  1. `uv` 도구를 사용하여 개발용 패키지를 제외한 프로덕션 의존성 목록을 `requirements.txt`로 내보냅니다.
  2. 기존의 `./wheels` 디렉토리를 정리한 후 새로 생성합니다.
  3. `requirements.txt`를 `./wheels` 디렉토리로 임시 복사합니다.
  4. `whl-downloader` 컨테이너를 실행하여 리눅스(`linux/amd64`) 플랫폼에 맞는 `.whl` 패키지 파일들을 `./wheels` 디렉토리 내에 다운로드합니다.
  5. 다운로드가 완료되면 임시 복사했던 `requirements.txt` 파일을 정리합니다.
- **실행 방법**:
  ```bash
  chmod +x 90_build_wheels.sh
  ./90_build_wheels.sh
  ```

---

### 2. `91_build_docker.local.sh` (로컬 테스트용 Docker 빌드 및 아카이브)
로컬 테스트 환경을 타겟으로 Docker 이미지를 빌드하고, 배포에 필요한 파일들을 모아 `./dist` 디렉토리에 패키징합니다.

- **스크립트 위치**: [91_build_docker.local.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/reasoning-selector-was/91_build_docker.local.sh)
- **작동 기전**:
  1. `docker-compose build --no-cache` 명령을 통해 캐시 없이 로컬용 Docker 이미지를 빌드합니다. (이때 `./wheels`에 저장된 로컬 패키지들을 이미지 내부로 인입하여 설치합니다.)
  2. 빌드 과정에서 생성된 미사용 dangling 이미지(`dangling=true`)들을 일괄 삭제합니다.
  3. 기존 `./dist` 디렉토리를 삭제한 뒤 새로 생성합니다.
  4. 로컬용 환경 변수 파일 `.env`를 `./dist/.env`로 복사합니다.
  5. 로컬용 컴포즈 설정인 `docker-compose.yml`을 `./dist/docker-compose.yml`로 복사합니다.
  6. `docker save` 명령을 통해 빌드된 Docker 이미지(`reasoning-selector-was`)를 파일 형태인 `./dist/reasoning-selector-was.tar`로 저장합니다.
- **실행 방법**:
  ```bash
  chmod +x 91_build_docker.local.sh
  ./91_build_docker.local.sh
  ```

---

### 3. `92_build_docker.prod.sh` (운영 환경용 Docker 빌드 및 아카이브)
실제 상용/운영 환경(Production)을 타겟으로 하며, 전용 네트워크 및 리소스 설정 등이 반영된 배포 패키지를 `./dist` 디렉토리에 패키징합니다.

- **스크립트 위치**: [92_build_docker.prod.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/reasoning-selector-was/92_build_docker.prod.sh)
- **작동 기전**:
  1. 운영 환경 전용 컴포즈 파일(`docker-compose.prod.yml`)을 기반으로 캐시 없이 Docker 이미지를 빌드합니다.
  2. 빌드 중 생성된 미사용 dangling 이미지들을 청소합니다.
  3. 기존 `./dist` 디렉토리를 삭제한 뒤 새로 생성합니다.
  4. 운영 환경용 환경 변수 파일 `.env.prod`를 `./dist/.env`로 복사합니다.
  5. 운영 환경용 컴포즈 파일 `docker-compose.prod.yml`을 `./dist/docker-compose.yml`로 이름을 변경하여 복사합니다.
  6. 빌드 완료된 이미지를 `./dist/reasoning-selector-was.tar` 파일로 저장합니다.
- **실행 방법**:
  ```bash
  chmod +x 92_build_docker.prod.sh
  ./92_build_docker.prod.sh
  ```

---

## 3단계. 서버 배포 및 기동 방법 (Deployment & Startup)

빌드 스크립트 실행이 성공하면 프로젝트 루트 경로에 `./dist` 디렉토리가 생성됩니다. 대상 서버에 배포하기 위해 이 디렉토리 전체를 압축하거나 복사하여 이동합니다.

### 1. 배포 아티팩트 목록 (`./dist/`)
- `reasoning-selector-was.tar` (Docker 이미지 아카이브)
- `docker-compose.yml` (실행 대상 컴포즈 파일)
- `.env` (배포 대상 환경 변수 설정 파일)

### 2. 대상 서버로 파일 전송
NGS를 통해 대상 서버의 원하는 배포 디렉토리(예: `/home/naver`)로 전송합니다.

### 3. 대상 서버에서 서비스 기동
대상 서버의 전송된 디렉토리로 이동한 뒤 아래 단계를 실행합니다.

1. **Docker 이미지 로드**:
   ```bash
   cd /home/naver
   docker load -i reasoning-selector-was.tar
   ```
   *로드 후 `docker images` 명령어를 통해 `reasoning-selector-was:latest` 이미지가 등록되었는지 확인합니다.*

2. **환경 설정 확인 및 수정**:
   `.env` 파일을 열어 해당 환경의 LLM Endpoint 주소(`BASE_URL`), 모델 명(`MODEL`), API 키(`API_KEY`), 포트 번호(`PORT`), 워커 개수(`WORKERS`) 등이 올바르게 세팅되었는지 검토합니다.

3. **컨테이너 실행 (백그라운드)**:
   ```bash
   docker-compose up -d
   ```

4. **실행 및 상태 모니터링**:
   - **컨테이너 상태 확인**: `docker-compose ps` 또는 `docker ps`
   - **컨테이너 내부 로그 실시간 확인**: `docker-compose logs -f --tail=100`
   - **헬스체크 엔드포인트 테스트**:
     ```bash
     curl http://localhost:<설정한포트>/health
     ```
     *(성공 응답: `{"status": "healthy", ...}`)*
