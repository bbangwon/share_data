# reasoning-selector-was 서버 실행 가이드

## 1. 개요

- 서비스명: `reasoning-selector-was`
- 기본 목적: RAG 파이프라인에서 검색된 문서 청크의 연관성 점수를 LLM으로 재평가
- 서버 IP: `99.1.82.183`, `99.1.82.184`

---

## 2. 환경 설정

애플리케이션은 설정에 따라 아래의 환경 변수 파일을 참조합니다.
- **로컬 개발용**: `.env`
- **운영 환경용**: `.env.prod` (배포 패키지 빌드 시 `.env`로 복사됨)
- **타겟 서버 설정 파일 예시**: `.env.reasoning`

### 주요 환경 변수 상세

```env
# ----------------------------
# LLM API 및 모델 설정
# ----------------------------
BASE_URL=http://99.1.2.97:10080/v1       # OpenAI 호환 LLM API 엔드포인트 URL
MODEL=HCX-SEED-THINK-14B                 # 사용할 LLM 모델명
TEMPERATURE=0.0                          # 생성 온도 (결과의 일관성을 위해 0.0 권장)
TIMEOUT=60                               # LLM API 호출 제한 시간 (초)
API_KEY=none                             # LLM API 인증 키 (없을 경우 임의 문자열 입력)

# ----------------------------
# Reasoning & 평가 방식 설정
# ----------------------------
ENABLE_REASONING=false                   # reasoning(생각 과정) 활성화 여부 (true/false)
                                         # false로 설정하면 더욱 빠른 응답 제공
RESPONSE_MAX_TOKENS=4096                 # reasoning 비활성화 시 응답 토큰 제한

# ----------------------------
# 최종 점수 계산 가중치 설정
# 최종점수 = (ORIGINAL_SCORE_WEIGHT × 원본점수) + (LLM_SCORE_WEIGHT × LLM점수)
# 두 가중치의 합은 1.0이어야 함
# ----------------------------
ORIGINAL_SCORE_WEIGHT=0.1                # 원본 rerank 점수 가중치
LLM_SCORE_WEIGHT=0.9                     # LLM 평가 점수 가중치

# ----------------------------
# 고급 평가 매개변수 설정
# ----------------------------
PARENT_TEXT_MAX_LENGTH=-1                # parent text 최대 입력 길이 (-1로 설정하면 전체 사용)
LLM_MAX_CONCURRENCY=8                    # 단일 요청 내에서 동시 처리할 LLM API 개수
HEALTH_CHECK_TIMEOUT=5                   # /health LLM 연결성 체크 타임아웃 (초)

# ----------------------------
# 문서 타입 캐시 데이터베이스 설정 (SQLite)
# 문서 분류 결과 캐싱을 통해 중복 API 호출을 방지하고 빠른 성능을 보장합니다.
# ----------------------------
SQLITE_DB_PATH=./data/doc_type_cache.db  # 캐시 데이터베이스 파일 경로
SQLITE_DB_ECHO=false                     # SQL 질의 로그 출력 여부 (true/false)

# ----------------------------
# 동시성 및 큐 설정 (FastAPI 서버 레벨)
# ----------------------------
MAX_CONCURRENT_REQUESTS=5                # HTTP 서버 레벨 최대 동시 요청 처리 수
MAX_QUEUE_SIZE=20                        # 최대 대기열 크기 (초과 시 503 Service Unavailable 반환)

# ----------------------------
# 로그 설정
# ----------------------------
LOG_LEVEL=INFO                           # 로그 레벨 (DEBUG, INFO, WARNING, ERROR)
LOG_DIR=./logs                           # 로그 저장 디렉토리
LOG_BACKUP_COUNT=7                       # 로그 보관 일수
```

---

## 3. 서버 실행 방식

환경과 조건에 따라 아래 방식 중 하나를 선택하여 서버를 실행합니다.

### 3.1 로컬 개발 모드 (Python / uv)
로컬에 Python 3.11 환경과 `uv`가 준비되어 있는 경우 아래 스크립트로 실행합니다.
- **실행 스크립트**: [1_start_local_app.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/reasoning-selector-was/1_start_local_app.sh)
- **실행 명령어**:
  ```bash
  ./1_start_local_app.sh
  ```
  *내부적으로 `ENV=local uv run uvicorn app.main:app --reload --host=0.0.0.0 --port=8010`이 실행됩니다.*

### 3.2 Docker Compose 기반 실행 (로컬/원격 빌드)
Docker 환경이 구축된 상태에서 직접 빌드 및 컨테이너 실행 시 사용합니다.

#### 로컬 / 테스트 실행:
- **실행 명령어**:
  ```bash
  docker-compose up -d --build
  ```
  *`8010` 포트로 바인딩되며, `.env`를 참조합니다.*

#### 운영(Production) 환경 빌드 및 실행:
- **실행 명령어**:
  ```bash
  docker-compose -f docker-compose.prod.yml up -d --build
  ```
  *`38080` 포트로 바인딩되며, `.env`를 참조하고 호스트 도메인 매핑(`extra_hosts`)이 추가됩니다.*

---

## 4. 운영 서버(폐쇄망) 배포 및 기동

기동 환경에서 패키징한 결과물(`./dist/` 내 파일들)을 배포 대상 서버(IP: `99.1.82.183` / `99.1.82.184`)로 업로드하여 배포할 경우 실행 방법입니다.

자세한 패키징 과정은 [패키징 및 배포 가이드 (DEPLOYMENT.md)](file:///Users/youngilchung/workspace/Busan/busan-ai/reasoning-selector-was/docs/DEPLOYMENT.md)를 참고하십시오.

### 4.1 타겟 서버에서 기동 (Docker 로딩 및 실행)
대상 서버의 배포 경로로 복사된 배포용 디렉토리 내부에서 다음 명령을 실행합니다.

1. **Docker 이미지 아카이브 로드**:
   ```bash
   docker load -i reasoning-selector-was.tar
   ```
2. **Docker Compose 컨테이너 기동**:
   ```bash
   docker-compose up -d
   ```
3. **헬스체크 확인**:
   ```bash
   curl http://localhost:38080/health
   ```

### 4.2 기존 구동 쉘 활용 기동 (서버 전용 쉘)
대상 서버(naver 계정)의 기동 전용 쉘 스크립트를 사용하여 프로세스를 제어할 수도 있습니다.
- **실행**:
  ```bash
  /home/naver/sh start_reasoning.sh
  ```
- **종료**:
  ```bash
  /home/naver/sh stop_reasoning.sh
  ```

