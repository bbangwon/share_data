# RAG Chunk Evaluator

LLM 기반 RAG 파이프라인 문서 청크 연관성 평가 서비스

## 개요

RAG+Rerank 파이프라인에서 검색된 문서 청크를 OpenAI 호환 LLM을 통해 재평가하여, 사용자 질문과의 실제 연관성 점수를 제공하는 FastAPI 기반 WAS입니다.

### 주요 기능

- 🤖 **LLM 기반 평가**: OpenAI 호환 API를 사용한 지능적 연관성 평가
- 🔗 **LangChain 통합**: 프롬프트 관리 체계화 및 출력 파싱 자동화
- ⚡ **동기 처리**: 즉각적인 응답 제공
- 📊 **점수 업데이트**: Rerank 점수를 LLM 평가 점수로 업데이트
- 🔍 **계층적 평가**: 질의 유형, 문서 유형, 본문 근거를 함께 반영

## 아키텍처

```
┌─────────────┐      ┌──────────────────┐      ┌─────────────┐
│ RAG Pipeline│─────>│  FastAPI WAS     │─────>│  LLM API    │
│  + Rerank   │      │  (LangChain)     │      │ (OpenAI)   │
└─────────────┘      └──────────────────┘      └─────────────┘
                             │
                             ▼
                     Updated Scores
```

### 기술 스택

- **FastAPI**: 웹 프레임워크
- **LangChain**: LLM 통합 및 프롬프트 관리
- **OpenAI 호환 LLM API**: 엔드포인트 기반 LLM 호출
- **Pydantic v2**: 데이터 검증
- **Python 3.11+**: 프로그래밍 언어

## 요구사항

### 필수 사항

- Python 3.11 이상

### LLM 엔드포인트 설정

OpenAI 호환 API를 제공하는 LLM 엔드포인트를 준비하세요. 예:

- OpenAI API
- Azure OpenAI
- Ollama OpenAI 호환 엔드포인트
- 사내 프록시 LLM 게이트웨이

## 설치

1. 저장소 클론 및 디렉토리 이동:

```bash
cd reasoning-selector-was
```

2. 가상환경 생성 및 활성화 (uv 사용):

```bash
uv venv
source .venv/bin/activate  # macOS/Linux
```

3. 의존성 설치:

```bash
uv pip install -e .
```

4. 환경 변수 설정 (`.env` 파일은 이미 생성됨):

```bash
# 필요시 .env 파일 수정
cat .env
```

## 실행

### 기본 실행

```bash
python main.py
```

### 개발 모드 (자동 리로드)

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

서버가 시작되면 `http://localhost:8000`에서 접근 가능합니다.

## API 사용법

### 헬스체크

```bash
curl http://localhost:8000/health
```

**응답 예시:**

```json
{
  "status": "healthy",
  "llm_connected": true,
  "model": "gpt-oss:20b-cloud",
  "base_url": "https://ollama.com/v1"
}
```

### 청크 평가

```bash
curl -X POST http://localhost:8000/evaluate \
  -H "Content-Type: application/json" \
  -d @request.json
```

**요청 형식 (`request.json`):**

```json
[
  {
    "query": "질병 휴직을 신청할 때 필요한 서류가 무엇인지 알려주세요.",
    "retrieved_documents": [
      {
        "id": "4dd76483-87bf-48f6-9aba-010f654b29b4",
        "score": 0.992672860622406,
        "payload": {
          "file": "지방공무원_인사제도_운영지침.pdf",
          "page_num": 22,
          "group": "내부자료",
          "parent_text": "...",
          "text": "질병휴직은 신체·정신상의 장애...",
          "chunk_index": 43,
          "parent_id": "...",
          "parent_idx": 21,
          "parent_table_statuses": [0],
          "child_idx": 1,
          "child_table_statuses": [0],
          "dept": "인사과",
          "service": ["법령", "직원복지"],
          "ner": false,
          "summary": "",
          "file_path": "/data/uploads/internal/...",
          "boost_keywords": "휴직 신청 절차...",
          "parent_chunk_length": 1607,
          "child_chunk_length": 315,
          "file_index": "1261913"
        }
      }
    ]
  }
]
```

**응답 형식:**

```json
[
  {
    "query": "질병 휴직을 신청할 때 필요한 서류가 무엇인지 알려주세요.",
    "retrieved_documents": [
      {
        "id": "4dd76483-87bf-48f6-9aba-010f654b29b4",
        "score": 0.85,
        "payload": { ... }
      }
    ]
  }
]
```

### 간단 포맷 평가

```bash
curl -X POST http://localhost:8000/evaluate-simple \
  -H "Content-Type: application/json" \
  -d @example/simple_input.json
```

**요청 형식 (`example/simple_input.json`):**

```json
{
  "query": "질병 휴직을 신청할 때 필요한 서류가 무엇인지 알려주세요.",
  "chunks": [
    {
      "content": "질병휴직은 신체·정신상의 장애, 불임 또는 난임 치료가 필요한 경우 가능하며, 진단서 또는 휴직 사유를 증빙할 수 있는 자료를 통해 휴직여부를 판단한다.",
      "filename": "지방공무원_인사제도_운영지침.pdf",
      "score": 0.992672860622406
    }
  ]
}
```

**응답 형식:**

```json
{
  "query": "질병 휴직을 신청할 때 필요한 서류가 무엇인지 알려주세요.",
  "chunks": [
    {
      "content": "질병휴직은 신체·정신상의 장애, 불임 또는 난임 치료가 필요한 경우 가능하며, 진단서 또는 휴직 사유를 증빙할 수 있는 자료를 통해 휴직여부를 판단한다.",
      "filename": "지방공무원_인사제도_운영지침.pdf",
      "score": 0.85
    }
  ]
}
```

### API 문서

FastAPI 자동 생성 문서:

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## 환경 변수

`.env` 파일 설정:

```env
# Model 설정
BASE_URL=https://ollama.com/v1
MODEL=gpt-oss:20b-cloud
TEMPERATURE=0.0
TIMEOUT=60
API_KEY=YOUR_API_KEY

# Reasoning & 평가 설정
ENABLE_REASONING=true                # reasoning 활성화 여부 (true/false)
                                    # false: 더 빠른 응답, true: 정교한 평가
RESPONSE_MAX_TOKENS=500              # reasoning 비활성화 시 응답 토큰 제한
                                    # 낮을수록 빠른 응답 (기본값: 500)

# 애플리케이션 설정
LOG_LEVEL=INFO
```

### Reasoning 옵션 (ENABLE_REASONING)

| 설정            | 특징                                 | 권장 사항                  |
| --------------- | ------------------------------------ | -------------------------- |
| `true` (기본값) | 정교한 평가, 느린 응답 속도          | 정확도 중시 시 사용        |
| `false`         | 빠른 응답 속도, max_tokens 자동 제한 | 응답 속도가 중요할 때 사용 |

**Reasoning 비활성화 시 효과:**

- ChatOpenAI에 `max_tokens={RESPONSE_MAX_TOKENS}` 자동 설정
- hierarchical 최종 점수 프롬프트가 간소화되어 응답 속도 향상

**예시:**

빠른 응답을 위해 reasoning을 비활성화한 경우:

```env
ENABLE_REASONING=false
RESPONSE_MAX_TOKENS=500
```

이 전환을 기반으로 로깅 시작됨을 알림:

```
[INFO] Reasoning 비활성화됨. max_tokens=500으로 제한
```

### hierarchical (3단계 계층적 평가)

- **설명**: 다음 3단계를 순차적으로 수행하는 정교한 평가 방식
  1. **1단계**: 질의 유형 분류 (규정형/운영형)
  2. **2단계**: 문서 유형 분류 (규정*일반, 규정*특정, 조례, 계획, 규정*지침, 운영*지침, 매뉴얼, 공문, 법령)
  3. **3단계**: 질의 유형과 문서 유형의 매칭도, 본문 내용의 적합도를 종합하여 최종 점수 계산
- **특징**: 가장 정교한 평가 방식으로 질의와 문서의 성격을 모두 고려
- **적합한 경우**: 부산광역시 업무 문서처럼 규정/운영 구분이 중요하고 문서 유형이 명확한 경우
- **장점**:
  - 질의의 목적(규정 확인 vs 절차 수행)을 정확히 파악
  - 문서의 법적/실무적 위계를 고려한 점수 부여
  - 본문 내용의 실제 연관성까지 종합 평가
## 패키징 및 배포

본 프로젝트는 인터넷 연결이 제한된 폐쇄망(Air-Gapped) 환경 배포를 원활하게 지원하기 위해 Docker 이미지 빌드 시 필요한 Python 패키지를 오프라인으로 자동 수급하여 이미지 내부에 로컬 설치하는 방식을 따릅니다. 이를 위해 3가지 패키징 쉘 스크립트가 제공됩니다.

자세한 빌드 및 배포 절차는 [패키징 및 배포 가이드 (DEPLOYMENT.md)] 문서에서 확인할 수 있습니다.

### 패키징 스크립트 설명

| 스크립트명 | 역할 | 설명 |
|---|---|---|
| 90_build_wheels.sh | **의존성 패키지 다운로드** | `uv`로 추출한 프로덕션 의존성을 폐쇄망 빌드용으로 사용할 수 있도록 리눅스(`linux/amd64`) 기반의 휠(`.whl`) 패키지 파일들로 `./wheels` 디렉토리에 미리 다운로드합니다. |
| 91_build_docker.local.sh | **로컬 테스트용 Docker 패키징** | 로컬 환경(`.env`, `docker-compose.yml`) 기준의 빌드 후, 해당 이미지를 `./dist/reasoning-selector-was.tar` 파일로 저장합니다. |
| 92_build_docker.prod.sh | **운영 환경용 Docker 패키징** | 운영 환경(`.env.prod`, `docker-compose.prod.yml`) 기준의 빌드 후, 해당 이미지를 `./dist/reasoning-selector-was.tar` 파일로 저장합니다. |

### 배포 패키지 구성 (`./dist/`)

빌드 스크립트(`91_build_docker.local.sh` 또는 `92_build_docker.prod.sh`)를 실행하면 프로젝트 루트에 `./dist` 디렉토리가 생성됩니다. 이 디렉토리를 압축하여 배포 대상 서버에 복사한 후 실행합니다.
- `reasoning-selector-was.tar`: 서비스의 Docker 이미지 아카이브
- `docker-compose.yml`: 실행을 위한 Docker Compose 설정
- `.env`: 해당 환경의 환경 변수 설정 파일

### 실행 방법
대상 서버에서 아카이브를 로드하고 컨테이너를 실행합니다.
```bash
# 1. Docker 이미지 로드
docker load -i reasoning-selector-was.tar

# 2. 컨테이너 백그라운드 기동
docker-compose up -d
```

## 프로젝트 구조

```
reasoning-selector-was/
├── app/
│   ├── __init__.py          # 패키지 초기화
│   ├── main.py              # FastAPI 애플리케이션
│   ├── models.py            # Pydantic 모델
│   ├── config.py            # 설정 관리
│   ├── prompts.py           # LangChain 프롬프트 템플릿
│   └── services/
│       ├── __init__.py
│       └── llm_evaluator.py # LLM 평가 로직
├── main.py                  # 진입점
├── .env                     # 환경 변수
├── pyproject.toml           # 프로젝트 설정
├── 90_build_wheels.sh       # 의존성 패키지 다운로드 스크립트
├── 91_build_docker.local.sh # 로컬 테스트용 Docker 빌드/저장 스크립트
├── 92_build_docker.prod.sh  # 운영 환경용 Docker 빌드/저장 스크립트
├── README.md                # 기본 가이드 문서
└── DEPLOYMENT.md            # 패키징 및 배포 가이드 문서
```


## LangChain 사용 이유

1. **프롬프트 관리**: ChatPromptTemplate로 체계적인 프롬프트 관리
2. **출력 파싱**: PydanticOutputParser로 자동 JSON 파싱 및 검증
3. **유연성**: 다른 LLM으로 쉽게 교체 가능 (ChatOpenAI ↔ 기타 OpenAI 호환 모델)
4. **LCEL**: 파이프라인 구성으로 코드 간결성 향상
5. **커뮤니티**: 풍부한 문서와 활발한 커뮤니티 지원

## 트러블슈팅

### LLM 연결 실패

**증상:** `health` 엔드포인트에서 `llm_connected: false`

**해결:**

- `BASE_URL`, `API_KEY`가 올바른지 확인
- LLM 엔드포인트가 접근 가능한지 확인
- 방화벽 또는 프록시 설정 확인

### 느린 응답 시간

**원인:** LLM 추론 시간

**해결:**

- 더 작은 모델 사용
- `TIMEOUT` 증가
- 향후 병렬 처리 구현 (LCEL batch() 메서드)

### 점수가 업데이트되지 않음

**원인:** LLM 평가 실패 시 원래 rerank score 유지

**확인:**

```bash
# 로그 확인
# "Keeping original score" 메시지 확인
```

## 개발

### 테스트 요청 생성

```bash
cat > test_request.json <<EOF
[
  {
    "query": "테스트 질문",
    "retrieved_documents": [
      {
        "id": "test-id",
        "score": 0.9,
        "payload": {
          "file": "test.pdf",
          "page_num": 1,
          "group": "test",
          "parent_text": "상위 컨텍스트",
          "text": "평가 대상 텍스트",
          "chunk_index": 0,
          "parent_id": "parent-id",
          "parent_idx": 0,
          "parent_table_statuses": [0],
          "child_idx": 0,
          "child_table_statuses": [0],
          "dept": "테스트",
          "service": ["test"],
          "ner": false,
          "summary": "",
          "file_path": "/test.pdf",
          "boost_keywords": "",
          "parent_chunk_length": 100,
          "child_chunk_length": 50,
          "file_index": "1"
        }
      }
    ]
  }
]
EOF
```

### 로그 확인

```bash
# INFO 레벨 로그
tail -f logs/app.log

# DEBUG 레벨로 변경
export LOG_LEVEL=DEBUG
```


