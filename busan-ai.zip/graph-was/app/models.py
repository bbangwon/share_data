from __future__ import annotations

from pydantic import BaseModel, Field


# --- Search Models ---

class SearchRequest(BaseModel):
    query: str = Field(
        description=(
            "원본 사용자 질의입니다. query_complete가 비어 있으면 이 값이 dense/sparse query embedding과 "
            "query routing에 사용됩니다."
        ),
        examples=["방사능 누출 초기 대응 절차는?"],
    )
    query_complete: str | None = Field(
        default=None,
        description=(
            "질의 확장 API를 통해 생성된 정제된 사용자 질의입니다. 값이 있으면 query보다 우선해서 "
            "검색 실행, query routing, 답변 생성 질문으로 사용됩니다."
        ),
        examples=["방사능 누출 초기 대응 절차에 대해 알려주세요."],
    )
    search_queries: list[str] | None = Field(
        default=None,
        description="질의 확장 API를 통해 생성된 검색용 사용자 질의 목록 입니다.",
        examples=[["부산광역시청 하수처리장의 방사능 누출 사고 초기 대응 절차는?", ""]],
    )
    limit: int | None = Field(
        default=None,
        gt=0,
        description="최종 반환할 검색 결과 개수입니다. 생략하면 설정의 search.final_limit 값을 사용합니다.",
        examples=[5],
    )
    dense_limit: int | None = Field(
        default=None,
        gt=0,
        description="Qdrant dense vector prefetch 후보 개수입니다. 생략하면 설정의 search.dense_limit 값을 사용합니다.",
        examples=[50],
    )
    sparse_limit: int | None = Field(
        default=None,
        gt=0,
        description="Qdrant sparse vector prefetch 후보 개수입니다. 생략하면 설정의 search.sparse_limit 값을 사용합니다.",
        examples=[50],
    )
    graph_boost_limit: int | None = Field(
        default=None,
        gt=0,
        description="Graph boost vector prefetch 후보 개수입니다. 생략하면 설정의 search.graph_boost_limit 값을 사용합니다.",
        examples=[30],
    )
    reasoning_rerank_top_n: int | None = Field(
        default=None,
        gt=0,
        description="Reasoning evaluation을 수행할 상위 후보 개수입니다. 생략하면 설정의 reasoning_rerank_top_n 값을 사용합니다.",
        examples=[30],
    )
    use_graph_boost: bool = Field(
        default=True,
        description="검색 시 Graph boost를 적용하여 키워드 매칭 후보군을 보강할지 여부입니다. 기본값은 True (hybrid + graph boost) 이며, False로 설정 시 hybrid(dense + sparse)만 수행합니다.",
        examples=[True],
    )

    def effective_query(self) -> str:
        """값이 있으면 query_complete를, 없으면 query를 반환합니다."""
        return self.query_complete if self.query_complete and self.query_complete.strip() else self.query



class SearchPromptResultItem(BaseModel):
    rank: int | None = Field(
        description="프롬프트 context에 포함된 참고자료 순번입니다.",
        examples=[1],
    )
    id: str | None = Field(
        default=None,
        description="검색 결과 chunk_id입니다. 프롬프트 XML의 source id와 같습니다.",
        examples=["child:31:0"],
    )
    filename: str | None = Field(
        default=None,
        description="원본 파일명입니다.",
        examples=["(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정 251013).pdf"],
    )
    page: list[int] = Field(
        default_factory=list,
        description="참고자료가 포함된 페이지 번호 목록입니다.",
        examples=[[46]],
    )
    context_text: str = Field(
        description="답변 생성 프롬프트에 context로 전달되는 본문입니다.",
        examples=["주민 보호 조치는 상황 접수 후 관계기관 전파와 함께 검토한다."],
    )


class SearchPromptResponse(BaseModel):
    query: str = Field(
        description="실제 검색과 프롬프트 생성에 사용한 질의입니다.",
        examples=["방사능 누출 초기 대응 절차는?"],
    )
    search_result: list[SearchPromptResultItem] = Field(
        description="답변 프롬프트 context로 들어간 최종 참고자료 목록입니다.",
    )
    empty_prompt: str = Field(
        description="YAML 프롬프트 template 원문입니다. query/context placeholder가 채워지기 전 상태입니다.",
    )
    prompt: str = Field(
        description="query와 검색 결과 XML context가 채워진 최종 프롬프트 문자열입니다.",
    )
    total_duration_ms: float = Field(
        description="검색 workflow 실행과 prompt preview 생성까지 걸린 전체 수행시간입니다.",
        examples=[123.45],
    )
