import os
import requests
import logging
from typing import List, Union, Tuple
from langchain_core.embeddings import Embeddings

logger = logging.getLogger("graphrag_model_utils")

class OpenAICompatibleEmbeddings(Embeddings):
    """
    vLLM, Ollama, 또는 OpenAI 규격을 준수하는 원격 API용 Embeddings 래퍼 클래스.
    """
    def __init__(self, api_url: str, model_name: str):
        self.api_url = api_url.rstrip('/')
        # 엔드포인트 자동 정제
        if not self.api_url.endswith('/embeddings'):
            if self.api_url.endswith('/v1'):
                self.api_url += '/embeddings'
            else:
                self.api_url += '/v1/embeddings'
        self.model_name = model_name
        logger.info(f"Initialized OpenAICompatibleEmbeddings for API URL: {self.api_url}, Model: {self.model_name}")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []
        
        headers = {"Content-Type": "application/json"}
        payload = {
            "model": self.model_name,
            "input": texts
        }
        
        try:
            response = requests.post(self.api_url, json=payload, headers=headers, timeout=120)
            response.raise_for_status()
            data = response.json()
            # OpenAI API 응답 스펙: data: [{"embedding": [...], "index": 0}, ...]
            embeddings = [item["embedding"] for item in data["data"]]
            return embeddings
        except Exception as e:
            logger.error(f"Error fetching embeddings from remote API ({self.api_url}): {e}")
            raise RuntimeError(f"Remote embedding API failed: {e}")

    def embed_query(self, text: str) -> List[float]:
        embeddings = self.embed_documents([text])
        if embeddings:
            return embeddings[0]
        return []

class APICompatibleReranker:
    """
    vLLM (/v1/rerank) 또는 Text Embeddings Inference (/rerank) API를 지원하는 Reranker 래퍼 클래스.
    CrossEncoder와 인터페이스(predict 메소드) 호환됩니다.
    """
    def __init__(self, api_url: str, model_name: str):
        self.api_url = api_url.rstrip('/')
        self.model_name = model_name
        logger.info(f"Initialized APICompatibleReranker for API URL: {self.api_url}, Model: {self.model_name}")

    def predict(self, pairs: List[Union[List[str], Tuple[str, str]]], batch_size: int = 16, show_progress_bar: bool = False) -> List[float]:
        if not pairs:
            return []

        # query는 대개 동일하므로 첫번째 요소에서 추출
        query = pairs[0][0]
        docs = [p[1] for p in pairs]

        headers = {"Content-Type": "application/json"}

        # 1. TEI(Text Embeddings Inference) 형식 (/rerank로 끝나고 v1/rerank가 아님)
        if self.api_url.endswith('/rerank') and not 'v1/rerank' in self.api_url:
            payload = {
                "query": query,
                "texts": docs
            }
            try:
                response = requests.post(self.api_url, json=payload, headers=headers, timeout=120)
                response.raise_for_status()
                data = response.json()
                # TEI 응답 스펙: [{"index": 0, "score": 0.9}, ...] 순서 보장이 안 될 수 있으므로 index 정렬
                scores = [0.0] * len(docs)
                for item in data:
                    scores[item["index"]] = float(item["score"])
                return scores
            except Exception as e:
                logger.error(f"TEI Rerank API call failed: {e}")
                raise RuntimeError(f"TEI Rerank API call failed: {e}")

        # 2. vLLM / Cohere 호환 API (/v1/rerank)
        api_endpoint = self.api_url
        if not api_endpoint.endswith('/rerank'):
            if api_endpoint.endswith('/v1'):
                api_endpoint += '/rerank'
            else:
                api_endpoint += '/v1/rerank'

        payload = {
            "model": self.model_name,
            "query": query,
            "documents": docs
        }

        try:
            response = requests.post(api_endpoint, json=payload, headers=headers, timeout=120)
            response.raise_for_status()
            data = response.json()
            # Cohere/vLLM 응답 스펙: {"results": [{"index": 0, "relevance_score": 0.9}, ...]}
            results = data.get("results", [])
            scores = [0.0] * len(docs)
            for res in results:
                scores[res["index"]] = float(res.get("relevance_score", res.get("score", 0.0)))
            return scores
        except Exception as e:
            # v1/rerank 규격 호출 에러 시, TEI 호환 규격으로 fallback 시도
            try:
                logger.warning(f"vLLM Rerank API failed, falling back to TEI payload format: {e}")
                tei_payload = {
                    "query": query,
                    "texts": docs
                }
                response = requests.post(api_endpoint, json=tei_payload, headers=headers, timeout=120)
                response.raise_for_status()
                data = response.json()
                scores = [0.0] * len(docs)
                for item in data:
                    scores[item["index"]] = float(item["score"])
                return scores
            except Exception as fallback_err:
                logger.error(f"Rerank API call and fallback both failed. Main error: {e}, Fallback error: {fallback_err}")
                raise RuntimeError(f"Rerank API failed at {api_endpoint}: {e}")

def get_embeddings_model(model_name: str = None) -> Embeddings:
    """
    환경 변수 EMBEDDING_API_URL 여부에 따라 원격 API용 Embeddings 또는 로컬 HuggingFaceEmbeddings를 반환합니다.
    """
    embedding_api_url = os.getenv("EMBEDDING_API_URL", "").strip()
    embedding_model_name = model_name or os.getenv("EMBEDDING_MODEL_NAME", "dragonkue/BGE-m3-ko")
    
    if embedding_api_url:
        return OpenAICompatibleEmbeddings(api_url=embedding_api_url, model_name=embedding_model_name)
    else:
        from langchain_huggingface import HuggingFaceEmbeddings
        logger.info(f"Loading local HuggingFaceEmbeddings: {embedding_model_name}")
        return HuggingFaceEmbeddings(
            model_name=embedding_model_name,
            model_kwargs={"device": "cpu"}
        )

def get_reranker(model_name: str = None) -> Union[APICompatibleReranker, "CrossEncoder"]:
    """
    환경 변수 RERANK_API_URL 여부에 따라 원격 API용 Reranker 또는 로컬 CrossEncoder를 반환합니다.
    """
    rerank_api_url = os.getenv("RERANK_API_URL", "").strip()
    rerank_model_name = model_name or os.getenv("RERANK_MODEL_NAME", "dragonkue/bge-reranker-v2-m3-ko")

    if rerank_api_url:
        return APICompatibleReranker(api_url=rerank_api_url, model_name=rerank_model_name)
    else:
        from sentence_transformers import CrossEncoder
        logger.info(f"Loading local CrossEncoder: {rerank_model_name}")
        return CrossEncoder(rerank_model_name, device="cpu")
