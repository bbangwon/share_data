from __future__ import annotations

import logging
import logging.handlers
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.kiwi_bm25 import KiwiBM25
import app.model_utils as model_utils
import app.state as state
from app.routers import health, search

from langchain_neo4j import Neo4jGraph
from qdrant_client import QdrantClient
from kiwipiepy import Kiwi

# Setup logging
if not os.path.exists(settings.log_dir):
    os.makedirs(settings.log_dir)

log_file_path = os.path.join(settings.log_dir, "graph-was.log")
logging.basicConfig(
    level=settings.log_level,
    format="[%(asctime)s][%(levelname)s|%(filename)s:%(lineno)s] >> %(message)s",
    handlers=[
        logging.StreamHandler(),  # Console output
        logging.handlers.TimedRotatingFileHandler(
            log_file_path,
            when="midnight",
            interval=1,
            backupCount=settings.log_backup_count,
            encoding="utf-8",
            utc=False,
        ),
    ],
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # App startup
    logger.info("Initializing search dependencies on startup...")
    
    # Initialize Neo4j graph connection
    try:
        state.graph = Neo4jGraph(
            url=settings.neo4j_uri,
            username=settings.neo4j_username,
            password=settings.neo4j_password,
            refresh_schema=False,
        )
        logger.info("Successfully connected to Neo4j database.")
    except Exception as e:
        logger.error(f"Failed to connect to Neo4j database: {e}")
        state.graph = None

    # Initialize Qdrant Client
    try:
        if settings.qdrant_url.strip():
            state.qdrant_client = QdrantClient(url=settings.qdrant_url)
            logger.info(f"Successfully connected to Qdrant Server at {settings.qdrant_url}.")
        else:
            state.qdrant_client = QdrantClient(path=settings.qdrant_path)
            logger.info(f"Successfully connected to Local Qdrant DB at {settings.qdrant_path}.")
    except Exception as e:
        logger.error(f"Failed to connect to Qdrant database: {e}")
        state.qdrant_client = None

    # Load Terminology map
    state.term_expansion_map = {}
    if state.graph is not None:
        try:
            # Get all terminology node names
            cypher_terms = """
            MATCH (t:Terminology)
            RETURN t.name AS term_name
            """
            terms_res = state.graph.query(cypher_terms)
            for row in terms_res:
                term = row.get("term_name", "").strip()
                if term:
                    state.term_expansion_map[term] = term

            # Get all synonym mappings
            cypher_synonyms = """
            MATCH (s:Synonym)-[:SYNONYM_OF]->(t:Terminology)
            RETURN s.name AS syn_name, t.name AS term_name
            """
            synonyms_res = state.graph.query(cypher_synonyms)
            for row in synonyms_res:
                syn = row.get("syn_name", "").strip()
                term = row.get("term_name", "").strip()
                if syn and term:
                    state.term_expansion_map[syn] = term

            logger.info(f"Successfully loaded terminology map from Neo4j DB with {len(state.term_expansion_map)} entries.")
        except Exception as e:
            logger.error(f"Failed to load terminology map from Neo4j DB: {e}")
    else:
        logger.warning("Neo4j database connection is offline. Synonym expansion disabled.")

    # Load Kiwi BM25 model
    state.kiwi_bm25 = None
    if os.path.exists(settings.kiwi_bm25_model_path):
        try:
            state.kiwi_bm25 = KiwiBM25.load(settings.kiwi_bm25_model_path)
            logger.info("Successfully loaded KiwiBM25 model.")
        except Exception as e:
            logger.error(f"Failed to load KiwiBM25 model: {e}")
    else:
        logger.warning(f"KiwiBM25 model file '{settings.kiwi_bm25_model_path}' not found. Sparse retrieval disabled.")

    # Load Kiwi tokenizer
    try:
        state.kiwi = Kiwi()
        logger.info("Successfully initialized Kiwi analyzer.")
    except Exception as e:
        logger.error(f"Failed to initialize Kiwi analyzer: {e}")
        state.kiwi = None

    # Initialize Embeddings model
    try:
        state.embeddings_model = model_utils.get_embeddings_model(settings.embedding_model_name)
        logger.info(f"Successfully loaded Embeddings model: {settings.embedding_model_name}")
    except Exception as e:
        logger.error(f"Failed to load Embeddings model: {e}")
        state.embeddings_model = None

    # Initialize Reranker model
    try:
        state.reranker = model_utils.get_reranker(settings.rerank_model_name)
        logger.info(f"Successfully loaded Reranker model: {settings.rerank_model_name}")
    except Exception as e:
        logger.error(f"Failed to load Reranker model: {e}")
        state.reranker = None

    yield
    logger.info("Application cleanup finished.")


# FastAPI app initialization
app = FastAPI(
    title=settings.app_title,
    version=settings.app_version,
    description=settings.app_description,
    lifespan=lifespan,
)

# CORS middleware configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    """Custom empty 404 response to match reasoning-selector-was"""
    return Response(status_code=404)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler to match reasoning-selector-was"""
    logger.error(f"Unhandled exception: {type(exc).__name__}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal Server Error",
            "error_type": type(exc).__name__,
        },
    )

# Include routers
app.include_router(health.router)
app.include_router(search.router)
