"""Pydantic Settings를 사용한 애플리케이션 설정"""

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """환경 변수에서 로드되는 애플리케이션 설정"""

    # 애플리케이션 설정
    app_title: str = "Mock GraphRAG WAS API"
    app_version: str = "0.1.0"
    app_description: str = "Mock GraphRAG WAS HybridRAG API matching ontology-app specifications"
    log_level: str = "INFO"
    log_dir: str = "./logs"
    log_backup_count: int = 7
    host: str = "0.0.0.0"
    port: int = 8000
    reload: bool = False

    # Neo4j Database Configuration
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_username: str = "neo4j"
    neo4j_password: str = "password"

    # Qdrant Database Configuration
    qdrant_url: str = ""
    qdrant_path: str = "./qdrant_db"
    qdrant_collection_name: str = "document_sections"

    # Model Configuration
    embedding_model_name: str = "dragonkue/BGE-m3-ko"
    embedding_api_url: str = ""
    rerank_model_name: str = "dragonkue/BGE-reranker-v2-m3-ko"
    rerank_api_url: str = ""

    # Model/Dictionary File Paths
    kiwi_bm25_model_path: str = "kiwi_bm25_model.json"
    default_filename: str = "(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).pdf"

    # Search Limits
    search_limit: int = 5
    search_dense_limit: int = 50
    search_sparse_limit: int = 50
    search_graph_boost_limit: int = 30

    # Sibling WAS URL Configuration
    reasoning_selector_was_url: str = "http://localhost:8010"
    reasoning_rerank_top_n: int = 30
    reasoning_selector_timeout: float | None = None

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @field_validator("reasoning_selector_timeout", mode="before")
    @classmethod
    def validate_timeout_nullable(cls, v):
        """None 문자열이나 빈 값을 None으로 처리하고 숫자는 float로 변환합니다."""
        if v is None:
            return None
        if isinstance(v, str):
            v_strip = v.strip()
            if not v_strip or v_strip.lower() in ("none", "null", "undefined"):
                return None
            try:
                return float(v_strip)
            except ValueError:
                raise ValueError(f"Timeout must be a float or 'None'. Got: {v}")
        return float(v)

    @field_validator("port", "log_backup_count")
    @classmethod
    def validate_positive_integers(cls, v: int) -> int:
        """양수 정수 설정값 검증"""
        if v <= 0:
            raise ValueError(f"양수 값이어야 합니다. 입력값: {v}")
        return v

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """로그 레벨이 유효한 값인지 검증"""
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if v.upper() not in valid_levels:
            raise ValueError(
                f"log_level은 {valid_levels} 중 하나여야 합니다. 입력값: {v}"
            )
        return v.upper()


# 전역 설정 인스턴스
settings = Settings()
