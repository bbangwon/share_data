from __future__ import annotations

from fastapi import APIRouter
from app.models import SearchRequest, SearchPromptResponse
from app.services.search_service import run_hybrid_search

router = APIRouter()


@router.post("/search", response_model=SearchPromptResponse)
async def search(request: SearchRequest) -> SearchPromptResponse:
    """Run GraphRAG hybrid search and generate context prompt."""
    return run_hybrid_search(request)
