from __future__ import annotations

import logging
import time
from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse

import app.state as state
from app.config import settings

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/health")
async def health(
    retrieval_profile: str | None = Query(
        default=None,
        description="확인할 retrieval profile 이름입니다. 지정하면 해당 profile의 Qdrant collection과 Neo4j URI를 사용합니다.",
    ),
    collection_name: str | None = Query(
        default=None,
        description="profile 없이 특정 Qdrant collection만 직접 확인할 때 사용합니다.",
    ),
    check_collection: bool = Query(
        default=True,
        description="true이면 Qdrant 연결뿐 아니라 collection 존재 여부까지 확인합니다.",
    ),
) -> JSONResponse:
    """Mock health check endpoint matching ontology-app specifications."""
    profile = retrieval_profile or "large"
    coll_name = collection_name or settings.qdrant_collection_name
    
    qdrant_status = "ok"
    qdrant_connected = True
    qdrant_collections = []
    qdrant_collection_exists = None
    qdrant_duration = 0.0
    
    q_start = time.perf_counter()
    try:
        if state.qdrant_client is not None:
            # In QdrantClient v1.18+, get_collections returns collections list
            collections_res = state.qdrant_client.get_collections()
            qdrant_collections = [c.name for c in collections_res.collections]
            if check_collection:
                qdrant_collection_exists = coll_name in qdrant_collections
        else:
            qdrant_status = "unavailable"
            qdrant_connected = False
    except Exception as e:
        logger.error(f"Health check: Qdrant failure: {e}")
        qdrant_status = f"error: {type(e).__name__}"
        qdrant_connected = False
    qdrant_duration = round((time.perf_counter() - q_start) * 1000, 2)
    
    neo4j_status = "ok"
    neo4j_connected = True
    neo4j_query_ok = True
    neo4j_duration = 0.0
    
    n_start = time.perf_counter()
    try:
        if state.graph is not None:
            res = state.graph.query("RETURN 1 AS val")
            if not res or res[0].get("val") != 1:
                neo4j_query_ok = False
        else:
            neo4j_status = "unavailable"
            neo4j_connected = False
            neo4j_query_ok = False
    except Exception as e:
        logger.error(f"Health check: Neo4j failure: {e}")
        neo4j_status = f"error: {type(e).__name__}"
        neo4j_connected = False
        neo4j_query_ok = False
    neo4j_duration = round((time.perf_counter() - n_start) * 1000, 2)
    
    overall_status = "ok" if (qdrant_connected and neo4j_connected and neo4j_query_ok) else "degraded"
    
    health_response = {
        "status": overall_status,
        "app": {"status": "ok"},
        "retrieval_profile": profile,
        "collection_name": coll_name,
        "neo4j_database": "neo4j",
        "checks": {
            "qdrant": {
                "status": qdrant_status,
                "host": settings.qdrant_url or "localhost",
                "port": 6333,
                "collection_name": coll_name,
                "collections": qdrant_collections,
                "collection_count": len(qdrant_collections),
                "collection_exists": qdrant_collection_exists,
                "duration_ms": qdrant_duration,
            },
            "neo4j": {
                "status": neo4j_status,
                "uri": settings.neo4j_uri,
                "database": "neo4j",
                "query_ok": neo4j_query_ok,
                "connected": neo4j_connected,
                "duration_ms": neo4j_duration,
            }
        }
    }
    return JSONResponse(status_code=200 if overall_status == "ok" else 500, content=health_response)
