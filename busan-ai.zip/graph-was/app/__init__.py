"""FastAPI Application for GraphRAG WAS"""
