import json
import math
from collections import Counter
from kiwipiepy import Kiwi

class KiwiBM25:
    """
    한국어 형태소 분석기(Kiwi)와 BM25 알고리즘을 결합한 Sparse Vector 생성 모델
    """
    def __init__(self, k1=1.5, b=0.75):
        self.k1 = k1
        self.b = b
        self.kiwi = Kiwi()
        self.vocab = {}      # 형태소 토큰 -> 정수 인덱스
        self.idf = {}        # 정수 인덱스 -> IDF 값
        self.avgdl = 0.0     # 코퍼스 내 평균 문서 형태소 길이
        self.doc_count = 0

    def tokenize(self, text):
        """
        텍스트를 토큰화하고 핵심 형태소(명사, 동사, 형용사, 부사 등)를 추출합니다.
        """
        if not text:
            return []
            
        tokens = []
        # 형태소 분석 실행
        for token in self.kiwi.tokenize(text):
            # N(체언/명사 등), V(용언/동사/형용사 등), XR(어근), MAG(일반부사) 태그 추출
            if token.tag.startswith(('N', 'V', 'XR', 'MAG')):
                # 형태소 충돌 방지를 위해 '형태/태그' 구조로 결합
                tokens.append(f"{token.form}/{token.tag}")
        return tokens

    def fit(self, corpus):
        """
        문서 코퍼스 리스트를 학습하여 IDF 및 평균 문서 길이를 계산합니다.
        """
        tokenized_corpus = [self.tokenize(doc) for doc in corpus]
        self.doc_count = len(tokenized_corpus)
        
        # 문서별 길이 계산
        doc_lengths = [len(tokens) for tokens in tokenized_corpus]
        self.avgdl = sum(doc_lengths) / self.doc_count if self.doc_count > 0 else 0.0
        
        # 형태소당 문헌 빈도(Document Frequency) 계산
        term_doc_counts = Counter()
        vocab_set = set()
        for tokens in tokenized_corpus:
            unique_tokens = set(tokens)
            vocab_set.update(unique_tokens)
            for token in unique_tokens:
                term_doc_counts[token] += 1
                
        # 알파벳/한글 순으로 정렬하여 일관된 인덱스 할당
        self.vocab = {token: idx for idx, token in enumerate(sorted(vocab_set))}
        
        # IDF 계산 (Lucene BM25 공식 사용: 항상 양수값 보장)
        self.idf = {}
        for token, count in term_doc_counts.items():
            idx = self.vocab[token]
            self.idf[idx] = math.log(1.0 + (self.doc_count - count + 0.5) / (count + 0.5))

    def get_document_vector(self, text):
        """
        인덱싱용 문서(청크)에 대한 BM25 Sparse Vector(indices, values)를 구합니다.
        """
        tokens = self.tokenize(text)
        if not tokens:
            return [], []
            
        doc_len = len(tokens)
        tf_counter = Counter(tokens)
        
        indices = []
        values = []
        
        for token, tf in tf_counter.items():
            if token in self.vocab:
                idx = self.vocab[token]
                # BM25 TF 가중치 계산 공식 적용
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (1.0 - self.b + self.b * (doc_len / self.avgdl))
                weight = numerator / denominator
                
                indices.append(idx)
                values.append(weight)
                
        # Qdrant의 요구사항에 맞춰 인덱스 오름차순으로 정렬
        sorted_pairs = sorted(zip(indices, values))
        if not sorted_pairs:
            return [], []
        idx_list, val_list = zip(*sorted_pairs)
        return list(idx_list), list(val_list)

    def get_query_vector(self, text):
        """
        검색 질의(Query)에 대한 BM25 Sparse Vector(indices, values)를 구합니다.
        """
        tokens = self.tokenize(text)
        if not tokens:
            return [], []
            
        tf_counter = Counter(tokens)
        
        indices = []
        values = []
        
        for token, tf in tf_counter.items():
            if token in self.vocab:
                idx = self.vocab[token]
                # 질의에 대해서는 IDF * TF 가중치 적용
                weight = self.idf[idx] * tf
                indices.append(idx)
                values.append(weight)
                
        # 인덱스 오름차순으로 정렬
        sorted_pairs = sorted(zip(indices, values))
        if not sorted_pairs:
            return [], []
        idx_list, val_list = zip(*sorted_pairs)
        return list(idx_list), list(val_list)

    def save(self, filepath):
        """
        학습된 모델 정보를 파일로 직렬화합니다.
        """
        state = {
            "k1": self.k1,
            "b": self.b,
            "vocab": self.vocab,
            "idf": self.idf,
            "avgdl": self.avgdl,
            "doc_count": self.doc_count
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=4)

    @classmethod
    def load(cls, filepath):
        """
        직렬화된 파일로부터 모델 정보를 역직렬화하여 객체를 생성합니다.
        """
        with open(filepath, "r", encoding="utf-8") as f:
            state = json.load(f)
        bm25 = cls(k1=state["k1"], b=state["b"])
        bm25.vocab = state["vocab"]
        # JSON 키가 문자열로 로드되므로 정수로 캐스팅
        bm25.idf = {int(k): v for k, v in state["idf"].items()}
        bm25.avgdl = state["avgdl"]
        bm25.doc_count = state["doc_count"]
        return bm25
