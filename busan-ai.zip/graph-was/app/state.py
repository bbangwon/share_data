from __future__ import annotations
from langchain_neo4j import Neo4jGraph
from qdrant_client import QdrantClient
from kiwipiepy import Kiwi
from app.kiwi_bm25 import KiwiBM25

# Global instance holders for caching/reuse
graph: Neo4jGraph | None = None
qdrant_client: QdrantClient | None = None
term_expansion_map: dict[str, str] = {}
kiwi_bm25: KiwiBM25 | None = None
kiwi: Kiwi | None = None
embeddings_model = None
reranker = None
