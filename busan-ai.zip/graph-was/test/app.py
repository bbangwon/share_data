import streamlit as st
import httpx
import json
import datetime
from typing import Generator

# Set Streamlit Page Configuration
st.set_page_config(
    page_title="Busan-AI RAG Chatbot Tester",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Premium Styling using CSS
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');

/* Global Font Override */
html, body, [class*="css"] {
    font-family: 'Outfit', sans-serif;
}

/* Gradient Title Container */
.title-container {
    background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
    padding: 2.5rem;
    border-radius: 16px;
    color: white;
    margin-bottom: 2rem;
    box-shadow: 0 10px 30px rgba(30, 60, 114, 0.2);
    text-align: center;
}

.title-container h1 {
    font-size: 2.5rem;
    font-weight: 800;
    margin: 0;
    letter-spacing: -0.5px;
}

.title-container p {
    font-size: 1.1rem;
    font-weight: 300;
    margin-top: 0.5rem;
    opacity: 0.9;
}

/* Custom Metric Card styling */
.metric-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    padding: 1rem;
    border-radius: 12px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
}

.dark .metric-card {
    background: #1e293b;
    border: 1px solid #334155;
}

/* RAG Reference Card Styling */
.ref-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-left: 5px solid #3b82f6;
    padding: 1.2rem;
    margin-bottom: 1rem;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.ref-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.05);
}

.dark .ref-card {
    background: #1e293b;
    border: 1px solid #334155;
    border-left: 5px solid #60a5fa;
}

.ref-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.6rem;
}

.ref-title {
    font-weight: 600;
    font-size: 1rem;
    color: #1e293b;
}

.dark .ref-title {
    color: #f1f5f9;
}

.ref-badge {
    background: #eff6ff;
    color: #1d4ed8;
    padding: 0.2rem 0.6rem;
    font-size: 0.75rem;
    border-radius: 20px;
    font-weight: 600;
}

.dark .ref-badge {
    background: #1e3a8a;
    color: #93c5fd;
}

.ref-text {
    font-size: 0.9rem;
    color: #475569;
    line-height: 1.5;
    background: #f8fafc;
    padding: 0.8rem;
    border-radius: 6px;
}

.dark .ref-text {
    color: #cbd5e1;
    background: #0f172a;
}
</style>
""", unsafe_allow_html=True)

# Main Title Area
st.markdown("""
<div class="title-container">
    <h1>🤖 Busan-AI RAG Chatbot Tester</h1>
    <p>Graph-WAS Hybrid Search & LLM-Studio-API-Tester Joint Simulation Interface</p>
</div>
""", unsafe_allow_html=True)

# Sidebar Configuration Layout
st.sidebar.image("https://img.icons8.com/nolan/96/bot.png", width=70)
st.sidebar.markdown("### ⚙️ System Settings")

graph_was_url = st.sidebar.text_input(
    "🔗 Graph-WAS URL", 
    value="http://localhost:8110",
    help="Address of the running graph-was server"
)

api_tester_url = st.sidebar.text_input(
    "🔗 API Tester URL", 
    value="http://localhost:18700",
    help="Address of the running llm-studio-api-tester server"
)

mode = st.sidebar.selectbox(
    "🎯 LLM Studio Mode", 
    options=["real", "mock"], 
    index=0,
    help="Switch between actual LLM Studio call or pre-defined mock response"
)

stream_enabled = st.sidebar.checkbox(
    "🌊 Use SSE Streaming", 
    value=True,
    help="Enable streaming event response from upstream LLM"
)

st.sidebar.markdown("---")
st.sidebar.markdown("### 📝 Session Control")

# Initialize Chat Session State
if "messages" not in st.session_state:
    st.session_state.messages = []
if "last_search_info" not in st.session_state:
    st.session_state.last_search_info = None

# Clear History Button
if st.sidebar.button("🗑️ Clear Chat History", use_container_width=True):
    st.session_state.messages = []
    st.session_state.last_search_info = None
    st.rerun()

# Layout Configuration: Main chatbot and right-side developer console
col_chat, col_dev = st.columns([2, 1])

# Left column: Conversation interface
with col_chat:
    st.markdown("### 💬 Chat Room")
    
    # Display Chat Messages
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            
            # If RAG details are available for assistant bubble, display them inline
            if msg["role"] == "assistant" and "search_result" in msg and msg["search_result"]:
                with st.expander("🔍 RAG Retrieval Sources & Prompt Context", expanded=False):
                    st.markdown(f"**⏱️ Retrieval & Generation Time:** `{msg.get('duration_ms', 0):.2f} ms`")
                    st.markdown("#### 📚 Document Chunks Used:")
                    for idx, doc in enumerate(msg["search_result"]):
                        pages = ", ".join(map(str, doc.get("page", [])))
                        st.markdown(f"""
                        <div class="ref-card">
                            <div class="ref-card-header">
                                <span class="ref-title">[{idx+1}] {doc.get('filename', 'Unknown Source')}</span>
                                <span class="ref-badge">Page: {pages if pages else 'N/A'}</span>
                            </div>
                            <div class="ref-text">{doc.get('context_text', '')}</div>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    if "prompt" in msg and msg["prompt"]:
                        st.markdown("#### 📝 Raw Prompt Payload Sent to LLM:")
                        st.code(msg["prompt"], language="markdown")

    # Chat Input Box
    if user_query := st.chat_input("Ask a question regarding safety manual guidelines..."):
        # 1. Append & render user message
        st.chat_message("user").markdown(user_query)
        st.session_state.messages.append({"role": "user", "content": user_query})
        
        # Initialize assistant UI elements
        with st.chat_message("assistant"):
            status_placeholder = st.empty()
            answer_placeholder = st.empty()
            
            # Step 1: Query Graph-WAS for hybrid search & prompt building
            status_placeholder.info("🔍 Retrieving documents and building RAG prompt from Graph-WAS...")
            
            search_result = []
            final_prompt = ""
            total_duration_ms = 0.0
            
            try:
                with httpx.Client(timeout=15.0) as client:
                    search_response = client.post(
                        f"{graph_was_url}/search",
                        json={"query": user_query}
                    )
                    search_response.raise_for_status()
                    search_data = search_response.json()
                    
                    search_result = search_data.get("search_result", [])
                    final_prompt = search_data.get("prompt", "")
                    total_duration_ms = search_data.get("total_duration_ms", 0.0)
                    
                    # Cache last search info in session state for dev tab
                    st.session_state.last_search_info = {
                        "query": user_query,
                        "search_result": search_result,
                        "prompt": final_prompt,
                        "duration_ms": total_duration_ms
                    }
                    
            except Exception as e:
                status_placeholder.error(f"❌ Failed to reach Graph-WAS search endpoint: {e}")
                # Fallback to empty search
                search_result = []
                final_prompt = user_query
                total_duration_ms = 0.0
            
            # Step 2: Trigger QA response through LLM Studio API Tester
            status_placeholder.info("⚡ Generating final answer via LLM-Studio-API-Tester...")
            
            # Construct standard ProxyRequest body
            dialog_history = []
            # Map existing chat history (excluding the current user_query which is sent as main user_query)
            for m in st.session_state.messages[:-1]:
                if m["role"] in ["user", "assistant"]:
                    dialog_history.append({"role": m["role"], "content": m["content"]})
            
            # Map search result to API Tester expectation (id, passage)
            rag_psgs = []
            for doc in search_result:
                rag_psgs.append({
                    "id": doc.get("id") or "",
                    "passage": doc.get("context_text") or ""
                })
            
            current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            proxy_payload = {
                "mode": mode,
                "payload": {
                    "user_query": user_query,
                    "datetime": current_time,
                    "stream": stream_enabled,
                    "dialog_history": dialog_history,
                    "is_rag": True,
                    "rag_psgs": rag_psgs
                }
            }
            
            final_answer = ""
            
            try:
                if stream_enabled:
                    # Stream Generator
                    def stream_response_generator() -> Generator[str, None, None]:
                        nonlocal final_answer
                        # We use HTTPX streaming post
                        with httpx.stream(
                            "POST", 
                            f"{api_tester_url}/api/llm/qa-response", 
                            json=proxy_payload, 
                            timeout=60.0
                        ) as r:
                            r.raise_for_status()
                            for line in r.iter_lines():
                                if not line:
                                    continue
                                if line.startswith("data:"):
                                    data_str = line[len("data:"):].strip()
                                    try:
                                        data_json = json.loads(data_str)
                                        # Detect custom errors
                                        if data_json.get("response_code") and data_json.get("response_code") != "C20000":
                                            err_msg = data_json.get("response_message") or "Unknown upstream error"
                                            yield f"\n\n🚨 *Upstream Error:* {err_msg}"
                                            break
                                        
                                        chunk = data_json.get("llm_result", {}).get("answer", "")
                                        if chunk:
                                            final_answer += chunk
                                            yield chunk
                                    except Exception:
                                        pass
                                        
                    # Stream rendering in Streamlit
                    status_placeholder.empty()
                    final_answer = answer_placeholder.write_stream(stream_response_generator())
                else:
                    # Non-stream standard request
                    with httpx.Client(timeout=60.0) as client:
                        response = client.post(
                            f"{api_tester_url}/api/llm/qa-response", 
                            json=proxy_payload
                        )
                        response.raise_for_status()
                        res_json = response.json()
                        
                        # Handle potential error codes in custom model
                        if res_json.get("response_code") and res_json.get("response_code") != "C20000":
                            err_msg = res_json.get("response_message") or "Unknown error code"
                            final_answer = f"🚨 *Upstream Error:* {err_msg}"
                        else:
                            final_answer = res_json.get("llm_result", {}).get("answer", "")
                        
                        status_placeholder.empty()
                        answer_placeholder.markdown(final_answer)
                
            except Exception as e:
                status_placeholder.empty()
                final_answer = f"⚠️ *Failed to generate answer from LLM Studio API:* {e}"
                answer_placeholder.markdown(final_answer)
            
            # Save the final result into conversation log with retrieval metadata
            st.session_state.messages.append({
                "role": "assistant",
                "content": final_answer,
                "search_result": search_result,
                "prompt": final_prompt,
                "duration_ms": total_duration_ms
            })
            
            # Display inline Sources
            if search_result:
                with st.expander("🔍 RAG Retrieval Sources & Prompt Context", expanded=False):
                    st.markdown(f"**⏱️ Retrieval & Generation Time:** `{total_duration_ms:.2f} ms`")
                    st.markdown("#### 📚 Document Chunks Used:")
                    for idx, doc in enumerate(search_result):
                        pages = ", ".join(map(str, doc.get("page", [])))
                        st.markdown(f"""
                        <div class="ref-card">
                            <div class="ref-card-header">
                                <span class="ref-title">[{idx+1}] {doc.get('filename', 'Unknown Source')}</span>
                                <span class="ref-badge">Page: {pages if pages else 'N/A'}</span>
                            </div>
                            <div class="ref-text">{doc.get('context_text', '')}</div>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    if final_prompt:
                        st.markdown("#### 📝 Raw Prompt Payload Sent to LLM:")
                        st.code(final_prompt, language="markdown")

# Right column: Developer control & inspection board
with col_dev:
    st.markdown("### 🛠️ Developer Inspector")
    
    if st.session_state.last_search_info:
        info = st.session_state.last_search_info
        st.success("✅ Latest Transaction Loaded")
        
        # Metrics Display
        st.markdown(f"""
        <div class="metric-card">
            <small style="color: #64748b;">Graph-WAS Search Duration</small>
            <h3 style="color: #3b82f6; margin: 0; font-size: 1.8rem;">{info['duration_ms']:.2f} ms</h3>
            <small style="color: #64748b;">Source Chunks: <b>{len(info['search_result'])}</b> items</small>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Inspect Prompt
        st.markdown("#### 📝 Formatted System Prompt")
        st.text_area(
            "Copy or inspect the raw prompt built by Graph-WAS:", 
            value=info["prompt"], 
            height=250,
            disabled=True
        )
        
        # Raw JSON output for inspection
        st.markdown("#### 📦 Raw Search JSON")
        st.json(info["search_result"])
    else:
        st.info("💡 Transactions will appear here as soon as you submit a prompt.")
