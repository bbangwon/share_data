import unittest
import sys
import os

# app 폴더가 있는 루트 디렉토리를 최우선 검색 경로로 지정하고, test 폴더는 제거하여 app.py 이름 충돌을 방지합니다.
test_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(test_dir)
if test_dir in sys.path:
    sys.path.remove(test_dir)
if "" in sys.path:
    sys.path.remove("")
sys.path.insert(0, parent_dir)

from app.services.search_service import rewrite_query_if_synonym_detected

class TestSynonymRewriter(unittest.TestCase):
    def setUp(self):
        # 모의 동의어 사전 구축
        self.term_expansion_map = {
            # 공식 용어
            "방사능 누출": "방사능 누출",
            "주민대피": "주민대피",
            # 동의어 매핑 (synonym -> official_term)
            "방사능 유출": "방사능 누출",
            "방사성 누출": "방사능 누출",
            "주민 대피": "주민대피",
            "대피": "주민대피",
        }

    def test_no_synonym_in_query(self):
        # 동의어가 없는 쿼리 -> 치환 없음
        query = "방사능 누출 시 대책은 무엇인가요?"
        rewritten, replaced = rewrite_query_if_synonym_detected(query, self.term_expansion_map, None)
        self.assertFalse(replaced)
        self.assertEqual(rewritten, query)

    def test_single_synonym_replaced(self):
        # 단일 동의어가 있는 쿼리 -> 치환 발생
        query = "방사능 유출 초기 대응은 어떻게 하나요?"
        rewritten, replaced = rewrite_query_if_synonym_detected(query, self.term_expansion_map, None)
        self.assertTrue(replaced)
        self.assertEqual(rewritten, "방사능 누출 초기 대응은 어떻게 하나요?")

    def test_multiple_synonyms_replaced(self):
        # 복수의 동의어가 있는 쿼리 -> 모든 동의어 치환 발생
        query = "방사성 누출 발생 시 주민 대피 요령은?"
        rewritten, replaced = rewrite_query_if_synonym_detected(query, self.term_expansion_map, None)
        self.assertTrue(replaced)
        self.assertEqual(rewritten, "방사능 누출 발생 시 주민대피 요령은?")

    def test_longest_word_priority(self):
        # "주민 대피"와 "대피"가 둘 다 매칭 가능할 때, 더 긴 "주민 대피"가 먼저 치환되는지 검증
        # 만약 "대피"가 먼저 치환되면 "주민 주민대피"가 되어 버림.
        query = "원전 근처 주민 대피 상황"
        rewritten, replaced = rewrite_query_if_synonym_detected(query, self.term_expansion_map, None)
        self.assertTrue(replaced)
        self.assertEqual(rewritten, "원전 근처 주민대피 상황")

    def test_empty_map(self):
        # 맵이 비어 있을 때
        query = "방사능 유출 시 조치사항"
        rewritten, replaced = rewrite_query_if_synonym_detected(query, {}, None)
        self.assertFalse(replaced)
        self.assertEqual(rewritten, query)

    def test_kiwi_tokenization_matching(self):
        # Kiwi 형태소 분석기가 활성화되었을 때 조사 등이 붙은 형태에서 명사 추출 후 치환되는지 검증
        try:
            from kiwipiepy import Kiwi
            kiwi = Kiwi()
        except ImportError:
            self.skipTest("kiwipiepy is not installed")
            
        # "대피"가 동의어 사전에 있고 쿼리에는 "대피를"로 수식되어 있음
        query = "원전 누출 시 대피를 어떻게 하나요?"
        # 만약 단순 substring 매칭만 한다면 "대피" (2글자)는 substring check(len >= 3)에서 걸러지므로 치환이 안 되지만,
        # 형태소 분석기를 통하면 명사 토큰 "대피"가 추출되어 치환되어야 함.
        rewritten, replaced = rewrite_query_if_synonym_detected(query, self.term_expansion_map, kiwi)
        self.assertTrue(replaced)
        self.assertEqual(rewritten, "원전 누출 시 주민대피를 어떻게 하나요?")

if __name__ == "__main__":
    unittest.main()
