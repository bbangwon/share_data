"""GraphRAG WAS HybridRAG API Entrypoint"""

import uvicorn
from app.config import settings


def main():
    """Run the FastAPI application with uvicorn"""
    uvicorn.run(
        "app.main:app",
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    main()
