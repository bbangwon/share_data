# graph-was 서버 실행 가이드

## 1. 개요

- 서비스명: `graph-was`
- 기본 목적: 온톨로지(Ontology) 매뉴얼 스펙에 따라 구현된 GraphRAG WAS HybridRAG 검색 및 답변 프롬프트 생성 서비스
- 포트 정보:
  - **운영 환경 (Production)**: 외부 바인딩 포트 `38110` (내부 컨테이너 포트 `8080`)
  - **로컬 개발 환경 (Local)**: 포트 `8110`

---

## 2. 환경 설정

애플리케이션은 기동 환경 및 프로필 형태에 따라 다음의 환경 변수 설정을 참조합니다.
- **로컬 개발용**: `.env` (포트 `8110` 기반)
- **운영 환경용**: `.env.prod` (배포 아티팩트 빌드 시 `.env` 이름으로 복사 및 대체)

### 주요 환경 변수 상세

```env
# ----------------------------
# 애플리케이션 및 로그 설정
# ----------------------------
LOG_LEVEL=INFO                           # 로그 레벨 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
LOG_DIR=./logs                           # 로그 저장 디렉토리
LOG_BACKUP_COUNT=7                       # 로그 보관 일수

# ----------------------------
# Neo4j Database 설정
# ----------------------------
NEO4J_URI=bolt://99.1.82.188:7687        # Neo4j DB 접속 URI
NEO4J_USERNAME=neo4j                     # Neo4j 사용자명
NEO4J_PASSWORD=password123               # Neo4j 암호

# ----------------------------
# Qdrant Database 설정
# ----------------------------
QDRANT_URL=http://99.1.82.188:6333       # Qdrant 서버 API 주소
QDRANT_PATH=./qdrant_db                  # Qdrant 로컬 DB 캐시/스토리지 주소 (URL이 비어있을 때 사용)
QDRANT_COLLECTION_NAME=document_sections # RAG 문서 청크 컬렉션 이름

# ----------------------------
# Embedding Model 설정 (HuggingFace API / Remote GPU Server)
# ----------------------------
EMBEDDING_MODEL_NAME=dragonkue/BGE-m3-ko # 사용할 임베딩 모델명
EMBEDDING_API_URL=http://99.1.2.97:10080/v1 # TEI 혹은 vLLM 임베딩 엔드포인트

# ----------------------------
# Rerank Model 설정 (HuggingFace API / Remote GPU Server)
# ----------------------------
RERANK_MODEL_NAME=dragonkue/BGE-reranker-v2-m3-ko # 사용할 리랭커 모델명
RERANK_API_URL=http://99.1.2.97:10080/v1     # Cross-Encoder 리랭커 엔드포인트

# ----------------------------
# 로컬 모델 및 토크나이저 사전 파일 경로
# ----------------------------
KIWI_BM25_MODEL_PATH=kiwi_bm25_model.json # 희소(Sparse) 검색을 위한 Kiwi 형태소 BM25 덤프 파일 경로

# ----------------------------
# 검색 리트리벌 개수 제한 설정 (Retrieval Limits)
# ----------------------------
SEARCH_LIMIT=5                           # 최종적으로 RAG 답변 프롬프트에 실릴 Parent Chunk 개수
SEARCH_DENSE_LIMIT=50                    # 밀집(Dense) 벡터 검색 prefetch 후보 개수
SEARCH_SPARSE_LIMIT=50                   # 희소(Sparse) 벡터 검색 prefetch 후보 개수
SEARCH_GRAPH_BOOST_LIMIT=30              # 지식그래프(Neo4j) 기반 필터링으로 걸러낼 Qdrant 검색 후보 수

# ----------------------------
# Sibling WAS(reasoning-selector-was) 연동 설정
# ----------------------------
REASONING_SELECTOR_WAS_URL=http://localhost:38080 # reasoning-selector-was API 호스트 및 포트
REASONING_RERANK_TOP_N=30                # 지능적 연관성 재채점(Nuclear Re-scoring)을 요청할 상위 후보 개수
REASONING_SELECTOR_TIMEOUT=None          # reasoning-selector-was 호출 제한 시간 (None = 무한대기)
```

---

## 3. 서버 실행 방식

개발 시점의 로컬 환경 혹은 컨테이너 기동 방식에 맞게 아래의 실행 명령을 사용합니다.

### 3.1 로컬 개발 모드 (Python / uv)
로컬에 Python 3.11 이상 개발 환경과 `uv` 툴이 설치되어 있는 경우 제공된 쉘 스크립트를 사용하여 구동합니다.
- **실행 스크립트**: [1_start_local_app.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/1_start_local_app.sh)
- **실행 명령어**:
  ```bash
  ./1_start_local_app.sh
  ```
  *내부적으로 `ENV=local uv run uvicorn app.main:app --reload --host=0.0.0.0 --port=8110`이 구동됩니다.*

### 3.2 Docker Compose 기반 실행
Docker 컨테이너 가상화 기술을 기반으로 빌드 및 컨테이너를 직접 제어합니다.

#### 로컬 / 테스트 실행:
- **실행 명령어**:
  ```bash
  docker-compose up -d --build
  ```
  *호스트의 `8110` 포트가 바인딩되며, `.env`를 참조합니다.*

#### 운영(Production) 환경 빌드 및 실행:
- **실행 명령어**:
  ```bash
  docker-compose -f docker-compose.prod.yml up -d --build
  ```
  *호스트의 `38110` 포트가 바인딩되며, `.env`를 참조하고, 사내망/기관망 호스트 바인딩(`extra_hosts`) 및 컨테이너 다중 워커 프로세스(`WORKERS=6`) 옵션이 활성화됩니다.*

---

## 4. 운영 서버(폐쇄망) 배포 및 기동

빌드 호스트에서 패키징이 끝난 `./dist/` 내 아카이브 파일들을 운영 대상 기동 서버로 복사하여 배포하는 경우 실행 방법입니다.

상세 빌드 절차는 [패키징 및 배포 가이드 (DEPLOYMENT.md)](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/docs/DEPLOYMENT.md) 문서에서 보실 수 있습니다.

### 4.1 타겟 서버에서 기동 (Docker 아카이브 로드 및 컨테이너 가동)
대상 기동 서버의 배포 경로로 복사된 배포용 폴더 내부에서 다음 단계를 순서대로 진행합니다.

1. **Docker 이미지 아카이브 로드**:
   ```bash
   docker load -i graph-was.tar
   ```
2. **Docker Compose 컨테이너 가동 (백그라운드)**:
   ```bash
   docker-compose up -d
   ```
3. **헬스체크 동작 검증**:
   ```bash
   curl http://localhost:38110/health
   ```

### 4.2 기존 구동 쉘 활용 기동 (서버 전용 쉘)
서버 계정 수준에 구동 쉘 스크립트가 구성되어 있는 경우 프로세스 기동/중지 도구를 활용할 수 있습니다.
- **서비스 구동**:
  ```bash
  /home/naver/sh start_graph.sh
  ```
- **서비스 중지**:
  ```bash
  /home/naver/sh stop_graph.sh
  ```
