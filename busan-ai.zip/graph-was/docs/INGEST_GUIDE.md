# GraphRAG 데이터 적재 가이드 (ingest.py)

이 가이드는 원전 안전 매뉴얼 및 용어사전 데이터를 가공하여 Neo4j 지식 그래프와 Qdrant 벡터 데이터베이스에 적재하는 [tools/ingest.py] 파이프라인의 사용법 및 내부 아키텍처를 설명합니다.

---

## 📌 개요

`ingest.py`는 원본 매뉴얼 데이터(JSON)와 용어사전 데이터(JSON)를 가공하여 **하이브리드 검색(Dense + Sparse)** 및 **지식 그래프 구조(Neo4j)**를 생성하는 핵심 데이터 전처리 스크립트입니다.

```mermaid
graph TD
    A[매뉴얼 원본 JSON] --> B[ingest.py 파이프라인 실행]
    C[용어사전 JSON] --> B
    B --> D[Qdrant Vector DB]
    B --> E[Neo4j Graph DB]
    B --> F[KiwiBM25 모델 파일]
    
    style B fill:#f9f,stroke:#333,stroke-width:2px
    style D fill:#bbf,stroke:#333,stroke-width:1px
    style E fill:#bfb,stroke:#333,stroke-width:1px
```

---

## 🛠️ 사전 준비 사항

스크립트를 실행하기 전 다음의 필수 구성 요소가 작동하고 있어야 합니다.

1. **환경 변수 설정 (`.env`)**
   프로젝트 루트 디렉토리의 `.env` 파일에 데이터베이스 연결 정보가 정상적으로 설정되어 있어야 합니다.
   ```env
   # Neo4j 설정
   NEO4J_URI=bolt://localhost:7687
   NEO4J_USERNAME=neo4j
   NEO4J_PASSWORD=your_password_here

   # Qdrant 설정
   # QDRANT_URL을 비워두면 로컬 파일 임베디드 모드(./qdrant_db)로 동작합니다.
   QDRANT_URL=
   QDRANT_COLLECTION_NAME=document_sections

   # 임베딩 모델 설정
   EMBEDDING_MODEL_NAME=dragonkue/BGE-m3-ko
   ```

2. **의존성 라이브러리 설치**
   아래의 필요 라이브러리가 가상환경(`venv`)에 설치되어 있어야 합니다.
   ```bash
   pip install -r requirements.txt
   ```

---

## 📄 입력 데이터 포맷

### 1. 매뉴얼 원본 데이터
* **기본 경로**: `tools/(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).json`
* **구조**: 한국딥러닝 ETL 변환 포맷을 따르며, 페이지별로 `Section-header`, `Text`, `Table` 등의 카테고리를 포함합니다.

### 2. 용어사전 데이터
* **기본 경로**: [tools/terminology_shortcuts.json]
* **스키마**:
  ```json
  [
      {
          "id": 1,
          "term": "갑상샘 방호 약품",
          "alternatives": [
              "방호약품",
              "KI"
          ]
      }
  ]
  ```
  > [!NOTE]
  > 최근 개선사항에 따라 한글 키(`매뉴얼 상 용어`, `대체용어1`~`3`)에서 영문 키(`id`, `term`, `alternatives`)로 전환되었으며, 대체 용어들은 배열(`list`) 형태로 관리됩니다.

---

## 🚀 실행 방법

기본 설정값을 사용할 경우, 다음과 같이 간편하게 실행할 수 있습니다.

```bash
python3 tools/ingest.py
```

### 선택 옵션 (Arguments)

특정 파일 경로를 지정하려면 아래 인자값을 제공하면 됩니다.

| 옵션명 | 단축형 | 설명 | 기본값 |
| :--- | :--- | :--- | :--- |
| `--input` | 없음 | 가공할 원본 매뉴얼 JSON 파일 경로 | `tools/(사회재난-17) 2025-2차 원전안전 분야...json` |
| `--terminology` | 없음 | 영문 키 형태의 용어사전 JSON 파일 경로 | `tools/terminology_shortcuts.json` |

**예시:**
```bash
python3 tools/ingest.py --input ./custom_manual.json --terminology ./custom_terms.json
```

---

## ⚙️ 주요 파이프라인 단계

`ingest.py`는 총 9개의 단계로 나누어 작업을 수행합니다.

### Step 1. 문서 계층 파싱 및 청킹
* **부모-자식 트리 구조 생성**: `Section-header`를 분석하여 계층 구조(Level 1~4)를 정의합니다.
* **Parent-Child Chunking**:
  * **Parent Chunks**: 최대 2,048자 (Overlap 200자). *표(`Table`) 구조 데이터는 분할하지 않고 단일 청크로 유지합니다.*
  * **Child Chunks**: 최대 512자 (Overlap 50자). 검색 매칭 성능 향상을 위해 좁은 범위로 쪼갭니다.

### Step 2. 임베딩 모델 초기화 및 벡터 생성
* `BGE-m3-ko` 임베딩 모델을 로드하여 각 Child Chunk의 dense vector를 생성합니다. (기본 64 배치 처리)

### Step 3. KiwiBM25 학습 및 저장
* 한국어 형태소 분석기 `Kiwi`를 사용하여 Child Chunk 기반의 BM25 희소 벡터 모델을 학습시키고 `tools/kiwi_bm25_model.json` 파일에 빌드 결과를 영구 저장합니다.

### Step 4. Qdrant 데이터 인덱싱
* Qdrant 컬렉션을 새로 빌드하고 다음 페이로드를 인제스트합니다:
  * Dense vector (`""`)
  * Sparse vector (`text-sparse`)
  * 메타데이터 페이로드 (텍스트, 시작 페이지, 부모/섹션 매핑 정보 등)

### Step 5 ~ 8. Neo4j 데이터 적재
* 기존 DB를 초기화하고, 성능 및 데이터 일관성을 위해 고유 제약조건(Constraints) 및 인덱스를 생성합니다.
* 다음 지식 그래프 스키마에 따라 노드와 엣지를 생성합니다:

```mermaid
classDiagram
    class DocumentSection {
        node_id
        title
        level
        start_page
        body_content
    }
    class ParentChunk {
        chunk_id
        text
        start_page
    }
    class ChildChunk {
        chunk_id
        text
        start_page
    }
    class Terminology {
        name
    }
    class Synonym {
        name
    }

    DocumentSection "1" --> "*" DocumentSection : PARENT_OF
    DocumentSection "1" --> "*" ParentChunk : HAS_PARENT_CHUNK
    ParentChunk "1" --> "*" ChildChunk : HAS_CHILD_CHUNK
    Synonym "*" --> "1" Terminology : SYNONYM_OF
    ChildChunk "*" --> "*" Terminology : MENTIONS
```

### Step 8.5 MENTIONS 관계 분석 구축
* `Kiwi` 형태소 분석기를 사용해 각 `ChildChunk` 텍스트의 형태소 분석(명사 `N` 및 외국어 `SL`)을 수행합니다.
* 형태소 토큰이 용어사전의 용어 또는 대체 용어와 일치하거나, 3글자 이상 단어가 본문에 포함될 경우 `(:ChildChunk)-[:MENTIONS]->(:Terminology)` 연결을 자동 수립합니다.

### Step 9. 검증 및 확인
* 작업 완료 후 Neo4j DB의 상태 쿼리를 실행하여 각 노드 및 엣지 수량을 집계 및 출력합니다.

---

## 📝 산출물 목록

적재 실행 후 생성 및 업데이트되는 데이터 리소스 목록입니다.

* **Qdrant DB**: `.env`에 정의된 Qdrant 데이터 디렉토리 생성 (예: `./qdrant_db`)
* **Neo4j Graph**: Neo4j 서버 내 지식 그래프 노드 및 엣지 적재
* **KiwiBM25 모델**: `tools/kiwi_bm25_model.json`
