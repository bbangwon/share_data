# 패키징 및 배포 가이드 (Packaging & Deployment Guide)

이 가이드는 **GraphRAG WAS HybridRAG (graph-was)** 서비스를 패키징하고 대상 서버에 배포하는 방법을 설명합니다. 본 서비스는 폐쇄망(Air-Gapped) 환경으로의 배포를 지원하기 위해 오프라인 의존성 설치 방식을 채택하고 있습니다.

---

## 배포 아키텍처 및 특징

- **오프라인 빌드 지원**: 인터넷 연결이 제한적인 환경을 고려하여, 필요한 Python 라이브러리(`.whl` 파일)를 빌드 시점에 사전에 다운로드 받아 Docker 이미지 내에 로컬 설치 모드(`--no-index --find-links=/wheels` 규격)로 주입 및 빌드합니다.
- **컨테이너화 배포**: Docker와 Docker Compose를 사용하여 환경 격리 및 일관된 실행이 가능한 형태로 패키징합니다.
- **환경 분리**: 개발/로컬 검증용 배포 설정(`.env` 및 `docker-compose.yml`)과 실제 서버 운영용 배포 설정(`.env.prod` 및 `docker-compose.prod.yml`)을 분리 관리합니다.

---

## 사전 요구 사항

1. **Docker 및 Docker Compose**가 빌드 장비와 대상 운영 서버에 설치되어 있어야 합니다.
2. **베이스 이미지 준비**: Dockerfile 빌드 시 참조하는 파이썬 기본 환경 이미지 `busan-python-base:latest`가 빌드 호스트에 미리 로드되어 있어야 합니다.
3. **Whl 다운로더 이미지**: 오프라인 패키지 수급용 `whl-downloader` Docker 이미지가 필요합니다.

---

## 1단계. 패키징 프로세스 (Packaging Process)

제공되는 3개의 쉘 스크립트를 차례대로 수행하여 폐쇄망 배포용 아카이브 디렉토리(`./dist`)를 생성합니다.

### 전체 흐름 요약

```mermaid
graph TD
    A[개발 환경] --> B(90_build_wheels.sh 실행)
    B --> C[requirements.txt 생성 및 wheels 폴더에 패키지 다운로드]
    C --> D{배포 환경 선택}
    D -->|로컬 테스트용| E(91_build_docker.local.sh 실행)
    D -->|운영 서버용| F(92_build_docker.prod.sh 실행)
    E --> G[./dist 폴더 생성<br>graph-was.tar<br>.env / docker-compose.yml]
    F --> H[./dist 폴더 생성<br>graph-was.tar<br>.env / docker-compose.yml]
```

---

## 2단계. 패키징 스크립트 상세 설명

### 1. `90_build_wheels.sh` (의존성 패키지 다운로드)
프로젝트에 기술된 Python 의존성 라이브러리들을 오프라인 설치용 휠(`.whl`) 파일 형태로 다운로드합니다.

- **스크립트 위치**: [90_build_wheels.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/90_build_wheels.sh)
- **작동 기전**:
  1. `uv export` 도구를 사용하여 프로덕션(`--no-dev`) 환경에 필요한 의존성 목록을 `requirements.txt`로 출력합니다.
  2. 기존의 `./wheels` 디렉토리를 비운 후 새로 생성합니다.
  3. `requirements.txt`를 임시로 `./wheels` 디렉토리 하위로 복사합니다.
  4. `whl-downloader` 컨테이너를 가동하여 리눅스(`linux/amd64`) 타겟 플랫폼용 `.whl` 파일들을 `./wheels` 내에 일괄 내려받습니다.
  5. 다운로드가 완료되면 복사했던 임시 `requirements.txt` 파일을 제거합니다.
- **실행 방법**:
  ```bash
  chmod +x 90_build_wheels.sh
  ./90_build_wheels.sh
  ```

---

### 2. `91_build_docker.local.sh` (로컬 테스트용 Docker 빌드 및 아카이브)
로컬 검증 목적의 배포 패키지를 `./dist` 디렉토리에 빌드 및 수집합니다.

- **스크립트 위치**: [91_build_docker.local.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/91_build_docker.local.sh)
- **작동 기전**:
  1. `docker-compose build --no-cache` 명령을 수행하여 캐시 없이 로컬 호스트 기준의 Docker 이미지를 빌드합니다. (이때 `./wheels` 디렉토리의 로컬 패키지들을 컨테이너 내부로 인입하여 `pip` 설치합니다.)
  2. 빌드 과정 중 생성된 미사용 댕글링(`dangling=true`) 이미지들을 일괄 청소합니다.
  3. 프로젝트 루트에 기존 `./dist`가 있다면 삭제 후 재생성합니다.
  4. 로컬 개발 환경용 설정인 `.env` 파일을 `./dist/.env` 경로로 복사합니다.
  5. 로컬용 컴포즈 규격인 `docker-compose.yml`을 `./dist/docker-compose.yml` 경로로 복사합니다.
  6. `docker save` 명령을 실행해 빌드된 `graph-was` 이미지를 파일 형태인 `./dist/graph-was.tar`로 내보냅니다.
- **실행 방법**:
  ```bash
  chmod +x 91_build_docker.local.sh
  ./91_build_docker.local.sh
  ```

---

### 3. `92_build_docker.prod.sh` (운영 환경용 Docker 빌드 및 아카이브)
실제 상용/운영 환경(Production)을 타겟으로 빌드하며, 운영 네트워크 정보 및 호스트 매핑, 다중 워커 프로세스 설정 등이 반영된 릴리즈 아카이브를 패키징합니다.

- **스크립트 위치**: [92_build_docker.prod.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/92_build_docker.prod.sh)
- **작동 기전**:
  1. 운영 전용 컴포즈 명세서(`docker-compose.prod.yml`)를 기반으로 캐시 없이 `graph-was` 이미지를 빌드합니다.
  2. 빌드 완료 후 불필요해진 댕글링 이미지를 소거합니다.
  3. 기존 `./dist` 폴더를 정리하고 새로 만듭니다.
  4. 상용 환경용 설정 파일인 `.env.prod`를 `./dist/.env` 이름으로 변경 복사합니다.
  5. 상용 환경용 컴포즈 스펙인 `docker-compose.prod.yml`을 `./dist/docker-compose.yml` 이름으로 변경 복사합니다.
  6. 빌드 완료된 `graph-was` 컨테이너 이미지를 `./dist/graph-was.tar` 파일로 아카이브 저장합니다.
- **실행 방법**:
  ```bash
  chmod +x 92_build_docker.prod.sh
  ./92_build_docker.prod.sh
  ```

---

## 3단계. 서버 배포 및 기동 방법 (Deployment & Startup)

빌드 가이드에 따라 성공적으로 패키징이 끝나면 프로젝트 루트에 `./dist` 디렉토리가 생성됩니다. 해당 디렉토리 전체를 압축하여 대상 배포 서버로 전송합니다.

### 1. 배포 패키지 구성 요소 (`./dist/`)
- `graph-was.tar` (Docker 이미지 파일)
- `docker-compose.yml` (기동용 Docker Compose 스펙 파일)
- `.env` (배포 대상 환경 변수 프로필)

### 2. 대상 서버 파일 전송
NGS 등을 활용해 대상 기동 서버의 전용 경로(예: `/home/naver`)에 압축을 푼 상태로 배치합니다.

### 3. 대상 서버에서 서비스 기동
대상 서버의 전송된 디렉토리 내로 진입하여 이하 단계를 적용합니다.

1. **Docker 이미지 로드**:
   ```bash
   docker load -i graph-was.tar
   ```
   *로드 후 `docker images` 명령어를 통해 `graph-was:latest` 이미지가 정상 로드되었는지 확인합니다.*

2. **환경 변수 검토**:
   `.env` 파일을 열어 외부 DB 연동 주소(`NEO4J_URI`, `QDRANT_URL`), 연동 모델 엔드포인트(`EMBEDDING_API_URL`, `RERANK_API_URL`), 형제 WAS 주소(`REASONING_SELECTOR_WAS_URL`), 포트(`PORT`), 워커 개수(`WORKERS`) 등이 상용 환경의 기준에 부합하게 작성되었는지 최종 조율합니다.

3. **컨테이너 실행 (백그라운드)**:
   ```bash
   docker-compose up -d
   ```

4. **상태 모니터링 및 실시간 로그 확인**:
   - **컨테이너 가동 상태 확인**: `docker-compose ps` 또는 `docker ps`
   - **컨테이너 내부 로그 스트림 출력**: `docker-compose logs -f --tail=100`
   - **헬스체크 동작 검증**:
     ```bash
     curl http://localhost:<기동포트>/health
     ```
     *(정상 성공 응답: `{"status": "ok", ...}`)*
