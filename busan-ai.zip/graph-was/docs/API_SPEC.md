# graph-was API 규격서

## 1. 개요

- 서비스명: `graph-was`
- 기본 목적: 온톨로지(Ontology) 매뉴얼 스펙에 부합하는 GraphRAG HybridRAG (Dense + Sparse + Graph Boost + Neo4j Hierarchy + LLM Re-scoring) 검색 및 프롬프트 생성 서비스
- 기본 URL: `http://99.1.82.188:38110` (운영 환경 기본 포트 `38110` / 로컬 개발 환경 포트 `8110`)
- 콘텐츠 타입: `application/json`

## 2. 공통 사항

### 2.1 버전/메타

- App title: `Mock GraphRAG WAS API`
- App version: `0.1.0`
- App description: `Mock GraphRAG WAS HybridRAG API matching ontology-app specifications`

### 2.2 CORS

- `allow_origins = ["*"]`
- `allow_methods = ["*"]`
- `allow_headers = ["*"]`
- `allow_credentials = true`

### 2.3 에러 응답 형식

#### FastAPI 기본 HTTPException 형식

```json
{
  "detail": "에러 메시지"
}
```

#### 전역 예외 핸들러 형식 (예기치 않은 오류)

```json
{
  "detail": "Internal Server Error",
  "error_type": "ExceptionClassName"
}
```

### 2.4 상태 코드 요약

- `200 OK`: 정상 처리
- `500 Internal Server Error`: 데이터베이스 연결 유실 또는 서버 내부 처리 오류

---

## 3. API 목록

### 3.1 `GET /health`

애플리케이션 상태와 Qdrant 및 Neo4j 데이터베이스 연결 상태를 점검합니다.

#### 요청

- Method: `GET`
- Path: `/health`
- Query Parameters:
  - `retrieval_profile` (string, 선택): 확인할 검색 프로필 명칭 (기본값: `"large"`)
  - `collection_name` (string, 선택): 확인할 Qdrant 컬렉션명 (기본값: 설정된 `QDRANT_COLLECTION_NAME`인 `"document_sections"`)
  - `check_collection` (boolean, 선택): Qdrant 컬렉션 존재 여부 체크 활성화 (기본값: `true`)

#### 응답 (`200` 정상 또는 `500` 연결 장애/degraded)

```json
{
  "status": "ok",
  "app": {
    "status": "ok"
  },
  "retrieval_profile": "large",
  "collection_name": "document_sections",
  "neo4j_database": "neo4j",
  "checks": {
    "qdrant": {
      "status": "ok",
      "host": "99.1.82.188",
      "port": 6333,
      "collection_name": "document_sections",
      "collections": [
        "document_sections"
      ],
      "collection_count": 1,
      "collection_exists": true,
      "duration_ms": 12.34
    },
    "neo4j": {
      "status": "ok",
      "uri": "bolt://99.1.82.188:7687",
      "database": "neo4j",
      "query_ok": true,
      "connected": true,
      "duration_ms": 5.67
    }
  }
}
```

#### 필드 설명

- `status`: 전체 시스템 상태 (`ok` 또는 `degraded` - qdrant와 neo4j 연결 상태가 모두 정상일 때 `ok` 반환)
- `app.status`: 웹 애플리케이션 프레임워크 자체의 기동 상태
- `retrieval_profile`: 요청 시 넘겨받은 프로필 명칭
- `collection_name`: 점검 대상 Qdrant 컬렉션 명
- `neo4j_database`: 대상 Neo4j DB 이름
- `checks.qdrant`: Qdrant 세부 연결 확인 결과
  - `status`: Qdrant 연결 진단 상태 (`ok`, `unavailable`, `error:...`)
  - `host`: Qdrant 서버 호스트
  - `port`: Qdrant 기본 포트 (`6333`)
  - `collection_name`: 체크한 컬렉션명
  - `collections`: Qdrant 내에 존재하는 모든 컬렉션 목록
  - `collection_count`: Qdrant 컬렉션 수
  - `collection_exists`: 해당 컬렉션의 실제 존재 여부
  - `duration_ms`: Qdrant 응답 속도 (밀리초)
- `checks.neo4j`: Neo4j 세부 연결 확인 결과
  - `status`: Neo4j 연결 진단 상태 (`ok`, `unavailable`, `error:...`)
  - `uri`: Neo4j DB 접속 URI
  - `database`: Neo4j 활성 DB
  - `query_ok`: 단순 쿼리 (`RETURN 1`) 실행 검증 성공 여부
  - `connected`: Neo4j 연결 여부
  - `duration_ms`: Neo4j 응답 속도 (밀리초)

---

### 3.2 `POST /search`

사용자 질문을 입력받아 하이브리드 검색 및 Neo4j의 계층적 연관 문서 확장을 처리하고, `reasoning-selector-was` 서비스를 통한 원자력 재 Rescoring을 적용하여 최종 프롬프트를 빌드합니다.

#### 요청

- Method: `POST`
- Path: `/search`
- Headers: `Content-Type: application/json`

#### 요청 바디 스키마

```json
{
  "query": "사용자 원본 질의",
  "query_complete": "질의 확장/정제 처리된 정형 질문 (선택)",
  "search_queries": [
    "확장/다중 검색용 질문 목록 (선택)"
  ],
  "limit": 5,
  "dense_limit": 50,
  "sparse_limit": 50,
  "graph_boost_limit": 30,
  "reasoning_rerank_top_n": 30,
  "use_graph_boost": true
}
```

#### 요청 필드 상세

- `query`:
  - 타입: `string`
  - 필수
  - 설명: 사용자 원본 질의. `query_complete`가 누락된 경우 검색과 라우팅에 메인 쿼리로 활용됩니다.
- `query_complete`:
  - 타입: `string` (선택, 기본값: `None`)
  - 설명: 질의 확장 API 등을 거쳐 정제된 완성형 쿼리. 기입된 경우 원본 `query` 대신 이 값이 모든 검색 흐름과 프롬프트 생성에 우선 사용됩니다.
- `search_queries`:
  - 타입: `array of strings` (선택, 기본값: `None`)
  - 설명: 질의 확장 API가 만든 다중 검색용 서브 질문 목록.
- `limit`:
  - 타입: `integer` (선택, 기본값: 설정값 `SEARCH_LIMIT`인 `5`)
  - 설명: 최종 응답 및 프롬프트에 담길 계층 노드(Parent) 기준 최대 결과 개수.
- `dense_limit`:
  - 타입: `integer` (선택, 기본값: 설정값 `SEARCH_DENSE_LIMIT`인 `50`)
  - 설명: Qdrant Dense vector 검색 시 로드할 후보군 수.
- `sparse_limit`:
  - 타입: `integer` (선택, 기본값: 설정값 `SEARCH_SPARSE_LIMIT`인 `50`)
  - 설명: Qdrant Sparse vector 검색 시 로드할 후보군 수.
- `graph_boost_limit`:
  - 타입: `integer` (선택, 기본값: 설정값 `SEARCH_GRAPH_BOOST_LIMIT`인 `30`)
  - 설명: Neo4j에 검출된 공식 매뉴얼 용어 기반으로 필터링되어 Qdrant에서 로드할 후보군 수.
- `reasoning_rerank_top_n`:
  - 타입: `integer` (선택, 기본값: 설정값 `REASONING_RERANK_TOP_N`인 `30`)
  - 설명: `reasoning-selector-was` 재평가 서비스로 보낼 상위 후보 개수.
- `use_graph_boost`:
  - 타입: `boolean` (선택, 기본값: `true`)
  - 설명: `true` 설정 시 Neo4j 지식그래프 연동 동의어 치환 및 키워드 매칭 보강 필터 검색을 동시 적용. `false` 설정 시 기본적인 Dense/Sparse 하이브리드 검색만 수행.

#### 응답 (`200 OK`)

```json
{
  "query": "실제 검색에 사용된 최종 질의",
  "searched_query": "동의어 치환이 완료된 경우 실제 검색 쿼리 (치환 미발생 시 null)",
  "search_result": [
    {
      "rank": 1,
      "id": "child:31:0",
      "filename": "(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).pdf",
      "page": [
        46
      ],
      "context_text": "### [섹션 제목: 제2장 상황 대응 - 제2절 초기 조치]\n- 파일명: (사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).pdf\n- 페이지: 46\n- 상위 카테고리/섹션: 제2장 상황 대응\n  (상위 맥락: 방사능 재난 발생 시 초기 전파 및 보고 체계...)\n- 본문 내용:\n비상 단계별 주민 보호 조치 기준에 따른 긴급 대피명령을..."
    }
  ],
  "empty_prompt": "참고자료를 바탕으로 사용자 질문에 답하세요.\n\n{context}\n\n사용자 질문: {query}",
  "prompt": "참고자료를 바탕으로 사용자 질문에 답하세요.\n\n### [매뉴얼 용어 및 동의어 정보]\n- 매뉴얼 용어: 백색비상 (동의어: 백색 비상 단계, 백색 경보)\n\n### [섹션 제목: 제2장 상황 대응 - 제2절 초기 조치] ...",
  "total_duration_ms": 154.23
}
```

#### 필드 설명

- `query`: 시스템이 최종 채택한 질의 문자열 (우선순위: `query_complete` > `query`)
- `searched_query`: Neo4j 사전에 정의된 동의어로 치환된 최종 쿼리. 치환이 일어나지 않았다면 `null`.
- `search_result`: 답변 생성 프롬프트에 context로 삽입된 최종 참고 자료(ParentChunk 위주 계층 확장본) 배열.
  - `rank`: context에서의 순번 (1부터 시작)
  - `id`: 검색 결과의 고유 식별자 (`ChildChunk` ID 혹은 계층 노드 ID)
  - `filename`: 해당 자료를 추출한 PDF 파일명
  - `page`: 해당 구문이 존재하는 원본 문서 페이지 번호 목록
  - `context_text`: 최종 프롬프트 `{context}` 영역에 삽입된 포맷팅된 문서 본문 및 메타데이터, 계층(부모/자식/형제) 내용의 조립 텍스트
- `empty_prompt`: context와 query가 치환되기 전 YAML 설정에서 로드된 프롬프트 템플릿 원본
- `prompt`: `empty_prompt` 템플릿의 `{context}`와 `{query}` 영역에 데이터가 적용 완료된 최종 프롬프트 텍스트
- `total_duration_ms`: 전체 하이브리드 검색, 동의어 처리, Rerank, 리스크 재채점 API 호출, 계층 정보 쿼리, 조립까지 소요된 총 수행 시간(밀리초)

---

## 4. 호출 예시

### 4.1 헬스체크 호출

```bash
curl -X GET "http://localhost:8110/health"
```

### 4.2 하이브리드 검색 및 프롬프트 생성 호출

```bash
curl -X POST "http://localhost:8110/search" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "백색비상 발령 시 초기 보고 체계를 알려줘.",
    "use_graph_boost": true,
    "limit": 3
  }'
```

## 5. 참고

- Swagger UI 대화형 API 문서: `http://localhost:8110/docs`
- ReDoc 읽기용 API 문서: `http://localhost:8110/redoc`
