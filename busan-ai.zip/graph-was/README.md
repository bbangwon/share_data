# GraphRAG WAS HybridRAG API

이 프로젝트는 온톨로지(Ontology) 매뉴얼 스펙에 따라 구현된 GraphRAG WAS HybridRAG API 서비스입니다.  
소스코드 정리 및 구조화를 통해 모듈성과 가독성을 높이고 각 기능의 관심사를 분리(Separation of Concerns)하였습니다.

---

## 📂 프로젝트 구조 (Directory Structure)

```text
graph-was/
├── 1_start_local_app.sh    # 로컬 서버 실행 스크립트
├── main.py                 # uvicorn 실행을 위한 루트 진입점
├── requirements.txt        # 패키지 의존성 파일
├── pyproject.toml          # python 프로젝트 설정
├── kiwi_bm25_model.json    # Kiwi BM25 사전 빌드된 어휘 사전 파일
├── test/
│   └── app.py              # Streamlit 기반 RAG 챗봇 테스트 앱
└── app/
    ├── __init__.py
    ├── main.py             # FastAPI 앱 생성, 미들웨어/예외 처리 및 라우터 등록
    ├── state.py            # 데이터베이스 및 모델 클라이언트 인스턴스 싱글톤 관리
    ├── config.py           # Pydantic Settings 기반의 설정 정의 및 검증
    ├── models.py           # Pydantic 기반 Request/Response 데이터 모델 정의
    ├── kiwi_bm25.py        # Kiwi 형태소 기반의 BM25 희소 벡터화 처리
    ├── model_utils.py      # 임베딩/리랭커 모델 로드 및 vLLM/TEI API 호출 래퍼
    ├── routers/            # API 엔드포인트 관리
    │   ├── __init__.py
    │   ├── health.py       # 헬스 체크 엔드포인트 (/health)
    │   └── search.py       # 하이브리드 RAG 검색 엔드포인트 (/search)
    └── services/           # 핵심 비즈니스 로직 관리
        ├── __init__.py
        └── search_service.py # 검색 후보 조회/병합/리랭크/계층 조회/포맷팅 파이프라인
```

---

## ⚙️ 모듈 설명 (Module Details)

### 1. `app/state.py`
- 데이터베이스 클라이언트 (`Neo4jGraph`, `QdrantClient`) 및 ML 모델 (`embeddings_model`, `reranker`), 토크나이저 등 전역적으로 재사용되는 리소스를 관리하는 싱글톤 상태 홀더 모듈입니다.
- 글로벌 변수를 직접 관리함으로써 순환 참조 문제를 예방하고 일관된 생명주기 제어가 가능합니다.

### 2. `app/services/search_service.py`
- 기존 단일 엔드포인트 내 거대했던 검색 플로우를 각각 독립적이고 단일 역할을 가지는 함수들로 잘게 쪼개어 구성했습니다:
  - `retrieve_dense_candidates`: Dense vector 임베딩 기반 검색
  - `retrieve_sparse_candidates`: Kiwi BM25 기반 Sparse 검색
  - `retrieve_graph_boost_candidates`: Neo4j 키워드 기반 Graph Boost 필터 검색
  - `merge_and_deduplicate_candidates`: 검색 소스를 보존하며 후보 목록 병합
  - `rerank_candidates`: Cross-Encoder 리랭크 모델 적용
  - `retrieve_hierarchy_info`: Neo4j를 통한 자식-부모-형제-하위 항목 계층 관계 조회 및 백업 포맷팅
  - `format_search_results`: 검색 결과를 XML 및 프롬프트 포맷으로 정형화

### 3. `app/routers/`
- 각 기능별 엔드포인트를 라우터 모듈로 분리하여 HTTP 요청 검증 및 직관적인 API 설정을 유지하도록 하였습니다.

---

## 🚀 시작하기 (How to Run)

### 1. 가상환경 및 패키지 설치
`uv` 툴이 설치되어 있는 경우 아래와 같이 간편하게 실행할 수 있습니다.
```bash
uv sync
```

### 2. 로컬 앱 실행
`1_start_local_app.sh` 또는 직접 `uvicorn`을 통해 실행합니다.
```bash
bash 1_start_local_app.sh
```
또는
```bash
uv run uvicorn app.main:app --reload --host=0.0.0.0 --port=8110
```

### 3. Streamlit RAG 챗봇 테스트 앱 실행 (선택)
`graph-was` 검색 결과(참고 문서, 최종 프롬프트)와 `llm-studio-api-tester`의 `qa-response` 연동을 한눈에 확인할 수 있는 Streamlit 기반 챗봇 화면을 제공합니다.

> [!NOTE]
> 테스트 앱 구동 전에 `graph-was` (기본 포트 8110) 및 `llm-studio-api-tester` (기본 포트 18700) 서버가 모두 정상 실행되어 있어야 정상 연동이 가능합니다.

```bash
uv run --extra test streamlit run test/app.py
```
