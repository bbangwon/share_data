# GraphRAG WAS HybridRAG API

온톨로지(Ontology) 매뉴얼 지식그래프 연동 및 Qdrant 밀집/희소 벡터 하이브리드 검색 기반의 FastAPI 웹 애플리케이션 서비스

## 개요

지식그래프(Neo4j)와 벡터 데이터베이스(Qdrant)를 상호보완적으로 융합한 HybridRAG 검색 서비스입니다. 질문 내 공식 용어 자동 치환, 그래프 키워드 보강(Graph Boost) 필터링, 그리고 상위-하위-형제 노드 관계에 따른 계층적 컨텍스트 확장을 통해 LLM 답변 생성을 돕는 정교한 컨텍스트 프롬프트를 자동으로 조립하여 제공합니다. 특히, 방사능 누출 등 재난 대응 분야의 전문 평가 엔진인 `reasoning-selector-was` 서비스와의 유기적인 연동을 통해 검색 결과의 품질을 극대화합니다.

### 주요 기능

- ⚡ **하이브리드 다중 검색**: Qdrant Dense 벡터와 Kiwi BM25 형태소 기반 Sparse 벡터 검색을 병합 적용
- 🔗 **지식그래프 보강 (Graph Boost)**: Neo4j 상에 저장된 용어집 매핑 정보를 조회하여 동의어를 공식 매뉴얼 용어로 치환하고, 관련성 높은 청크를 검색 후보로 추가 보강
- 📊 **교차 검증 및 리랭킹**: Cross-Encoder 모델을 사용한 1차 순위 재조정 수행
- 🤖 **원자력 재해 대응 분야 특화 재채점 (Nuclear Re-scoring)**: Sibling 서비스인 `reasoning-selector-was` (/evaluate-simple-nuclear) 연동을 통해 원자력 대응 관점의 상황 판단 및 조치 수준을 재산출하여 점수를 최종 보정
- 🔍 **계층적 구조 확장 (Hierarchy Retrieval)**: Neo4j Cypher 쿼리를 통해 매칭된 하위 청크의 부모(Parent), 형제(Sibling), 하위(Children) 구조화 텍스트 본문과 메타데이터를 일괄 병합
- 📝 **프롬프트 조립**: 동의어 이력 및 계층적 검색 결과가 XML 규격 형태로 내장된 완성형 LLM 질의 프롬프트를 최종 렌더링

## 아키텍처

```
                                              ┌────────────────────────┐
                                         ┌───>│ Neo4j (Graph Database) │
                                         │    └────────────────────────┘
┌──────────────┐      ┌─────────────┐    │    ┌────────────────────────┐
│   FastAPI    │─────>│  graph-was  │────┼───>│ Qdrant (Vector DB)     │
│ Chatbot App  │<─────│ (HybridRAG) │    │    └────────────────────────┘
└──────────────┘      └─────────────┘    │    ┌────────────────────────┐
                             │           └───>│ Embedding/Rerank Model │
                             ▼                └────────────────────────┘
                   [Nuclear Re-scoring]
                             │
                             ▼
               ┌──────────────────────────┐
               │  reasoning-selector-was  │
               └──────────────────────────┘
```

### 기술 스택

- **FastAPI**: 대기시간 최소화 및 고성능 비동기 API 웹 프레임워크
- **Neo4j & langchain-neo4j**: 지식그래프 탐색 및 온톨로지 계층 조회
- **Qdrant & qdrant-client**: 고성능 밀집(Dense)/희소(Sparse) 벡터 유사도 검색 엔진
- **Kiwi (kiwipiepy) BM25**: 한국어 형태소 분석 기반의 희소 임베딩 파이프라인
- **vLLM / TEI API Client**: 원격 GPU 서버 모델 호출 인터페이스
- **Pydantic v2 & Pydantic Settings**: 환경 변수 관리 및 데이터 유효성 검사

---

## 요구사항

### 필수 사항

- Python 3.11 이상
- Neo4j Database 인스턴스 (지식그래프 및 용어 사전 저장용)
- Qdrant Database 인스턴스 (문서 청크 벡터 세그먼트 저장용)

---

## 설치

1. 저장소 클론 및 디렉토리 이동:

```bash
cd graph-was
```

2. 가상환경 생성 및 활성화 (`uv` 사용 권장):

```bash
uv venv
source .venv/bin/activate  # macOS/Linux
```

3. 의존성 설치:

```bash
# 개발 및 프로덕션 의존성 일괄 설치
uv sync
```

4. 환경 변수 설정:
`.env` 파일이 루트 폴더에 미리 작성되어 있습니다. 필요시 외부 접속 정보 등을 변경하십시오.

---

## 실행

### 기본 로컬 구동 스크립트 실행

```bash
bash 1_start_local_app.sh
```

### uvicorn 수동 구동 (자동 리로드)

```bash
uv run uvicorn app.main:app --reload --host=0.0.0.0 --port=8110
```

서버가 실행되면 `http://localhost:8110`에서 접근 가능합니다.

---

## API 사용법

### 헬스체크

```bash
curl http://localhost:8110/health
```

**응답 예시:**

```json
{
  "status": "ok",
  "app": {
    "status": "ok"
  },
  "retrieval_profile": "large",
  "collection_name": "document_sections",
  "neo4j_database": "neo4j",
  "checks": {
    "qdrant": {
      "status": "ok",
      "host": "localhost",
      "port": 6333,
      "collection_name": "document_sections",
      "collections": [
        "document_sections"
      ],
      "collection_count": 1,
      "collection_exists": true,
      "duration_ms": 12.34
    },
    "neo4j": {
      "status": "ok",
      "uri": "bolt://localhost:7687",
      "database": "neo4j",
      "query_ok": true,
      "connected": true,
      "duration_ms": 5.67
    }
  }
}
```

### 하이브리드 GraphRAG 검색

```bash
curl -X POST http://localhost:8110/search \
  -H "Content-Type: application/json" \
  -d @request.json
```

**요청 형식 (`request.json`):**

```json
{
  "query": "백색비상 발령 시 초기 보고 체계를 알려줘.",
  "query_complete": null,
  "limit": 3,
  "dense_limit": 50,
  "sparse_limit": 50,
  "graph_boost_limit": 30,
  "reasoning_rerank_top_n": 30,
  "use_graph_boost": true
}
```

**응답 형식:**

```json
{
  "query": "백색비상 발령 시 초기 보고 체계를 알려줘.",
  "searched_query": "백색비상 발령 시 초기 보고 체계를 알려줘.",
  "search_result": [
    {
      "rank": 1,
      "id": "child:22:1",
      "filename": "(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).pdf",
      "page": [
        25
      ],
      "context_text": "### [섹션 제목: 제2장 상황 대응 - 제1절 이상상태 조치사항]\n- 파일명: (사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).pdf\n- 페이지: 25\n- 상위 카테고리/섹션: 제2장 상황 대응\n- 본문 내용:\n백색비상 발령 시..."
    }
  ],
  "empty_prompt": "참고자료를 바탕으로 사용자 질문에 답하세요.\n\n{context}\n\n사용자 질문: {query}",
  "prompt": "참고자료를 바탕으로 사용자 질문에 답하세요.\n\n### [매뉴얼 용어 및 동의어 정보]\n- 매뉴얼 용어: 백색비상 (동의어: 백색 비상 단계, 백색 경보)\n\n### [섹션 제목: 제2장 상황 대응 - 제1절 이상상태 조치사항]\n...\n\n사용자 질문: 백색비상 발령 시 초기 보고 체계를 알려줘.",
  "total_duration_ms": 125.43
}
```

### API 문서

FastAPI 자동 생성 대화형 인터페이스:

- Swagger UI: `http://localhost:8110/docs`
- ReDoc: `http://localhost:8110/redoc`
- API 상세 설계서: [API 규격서 (API_SPEC.md)](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/docs/API_SPEC.md)

---

## 환경 변수

`.env` 파일 파라미터 세팅:

```env
# ----------------------------
# 애플리케이션 기본 설정
# ----------------------------
LOG_LEVEL=INFO                           # 로그 출력 기준 레벨
LOG_DIR=./logs                           # 로그 저장 폴더
LOG_BACKUP_COUNT=7                       # 일자별 로그 보관 주기 (일 단위)

# ----------------------------
# Neo4j 데이터베이스 연동 정보
# ----------------------------
NEO4J_URI=bolt://localhost:7687          # Neo4j 볼트 통신 엔드포인트
NEO4J_USERNAME=neo4j                     # Neo4j DB 유저 아이디
NEO4J_PASSWORD=password123               # Neo4j DB 접속 패스워드

# ----------------------------
# Qdrant 벡터 스토어 연동 정보
# ----------------------------
QDRANT_URL=http://localhost:6333         # 외부 Qdrant 클러스터 API 호스트 (비어있는 경우 로컬 DB 참조)
QDRANT_PATH=./qdrant_db                  # Qdrant 로컬 저장용 DB 디렉토리 주소
QDRANT_COLLECTION_NAME=document_sections # 적재 및 검색 대상 컬렉션 명

# ----------------------------
# 텍스트 임베딩 모델(Embedding Model) 설정
# ----------------------------
EMBEDDING_MODEL_NAME=dragonkue/BGE-m3-ko # 임베딩 허깅페이스 모델 ID
EMBEDDING_API_URL=                       # vLLM/TEI 등의 임베딩 모델 API 서버 URL (로컬 로딩 시 생략)

# ----------------------------
# 교차 인코더 리랭커(Reranker) 모델 설정
# ----------------------------
RERANK_MODEL_NAME=dragonkue/BGE-reranker-v2-m3-ko # 리랭커 허깅페이스 모델 ID
RERANK_API_URL=                          # vLLM/TEI 등의 리랭커 모델 API 서버 URL (로컬 로딩 시 생략)

# ----------------------------
# 파일 및 사전 리소스 경로 설정
# ----------------------------
KIWI_BM25_MODEL_PATH=kiwi_bm25_model.json # 미리 구축된 Kiwi 형태소 빈도 정보 파일 경로

# ----------------------------
# 검색 최대 한도 파라미터
# ----------------------------
SEARCH_LIMIT=5                           # 프롬프트에 제공할 상위 부모 청크 수
SEARCH_DENSE_LIMIT=50                    # Qdrant Dense vector 검색 후보 수
SEARCH_SPARSE_LIMIT=50                   # Qdrant BM25 희소 벡터 검색 후보 수
SEARCH_GRAPH_BOOST_LIMIT=30              # Neo4j 지식그래프 가중 검색 후보 수

# ----------------------------
# Sibling WAS(평가 모듈) 연동
# ----------------------------
REASONING_SELECTOR_WAS_URL=http://localhost:8010 # reasoning-selector-was 접속 호스트 주소
REASONING_RERANK_TOP_N=30                # 평가 모듈에 재채점을 전달할 후보군 크기
REASONING_SELECTOR_TIMEOUT=None          # 평가 호출 API 타임아웃 제한 시간 (None = 제한 없음)
```

---

## 검색 및 프롬프트 생성 메커니즘 개요

본 하이브리드 검색기 파이프라인은 아래의 순서로 실행됩니다.

### 1단계. 동의어 매칭 및 공식 용어 치환
사용자의 자연어 질문이 들어오면, Neo4j의 `Terminology` 및 `Synonym` 엔터티를 대조하여 대체 동의어를 공식 용어로 강제 교환(Query Rewriting)합니다.

### 2단계. 다중 검색 후보 확보 (Dense + Sparse + Graph Boost)
- **Dense Retrieval**: 질문의 의미(Semantic) 벡터를 기반으로 유사 문서를 검색합니다.
- **Sparse Retrieval**: 형태소 분석기 Kiwi를 이용해 형태소를 쪼개고 미리 적재된 어휘 사전 통계(BM25)를 사용하여 텍스트 키워드 기반 유사 문서를 검색합니다.
- **Graph Boost**: 질문에서 포착된 공식 용어와 Neo4j 상에서 연관 관계(`MENTIONS`)로 매핑된 `ChildChunk`들의 ID 목록을 획득하고, 이 ID들로 한정하여 Qdrant에서 유사도 검색을 추가 수행하여 후보군을 집중 보완합니다.

### 3단계. 후보군 병합 및 Reranking
Dense, Sparse, Graph Boost 결과들을 중복 없이 합산하고 가중 소스를 표시합니다. 이후 교차 인코더(Cross-Encoder) 리랭커 모델을 이용하여 의미적 밀접도가 높은 순서대로 1차 재정렬합니다.

### 4단계. Sibling WAS 연동 재채점 (Nuclear Re-scoring)
상위 `REASONING_RERANK_TOP_N` 범위 내의 검색 결과 청크들을 `reasoning-selector-was` 서비스의 `/evaluate-simple-nuclear` API로 실시간 전송합니다. 평가 서비스의 대규모 규정 검증 LLM 체인이 상황에 따른 적합성(원자력 방재 매뉴얼 기준 조치/전파 부합 여부)을 평가하여 반환한 점수로 업데이트하고, 최종 내림차순으로 2차 재정렬합니다.

### 5단계. 계층적 컨텍스트 복원 및 포맷팅
최종 채택된 상위 `SEARCH_LIMIT` 내 청크들의 Neo4j ID를 매개로 자식-부모-형제-하위 관계를 Cypher로 추적하여 주변 문맥 구조를 완벽히 복구합니다. 이 내용들을 용어 설명 메타 블록과 함께 하나의 XML/텍스트 형태 context로 통합 렌더링한 최종 프롬프트를 리턴합니다.

---

## 패키징 및 배포

인터넷 연결이 차단된 특수 네트워크(폐쇄망) 환경에 대응하기 위해 Docker 빌드 및 타르 아카이브를 사용한 배포 과정을 자동으로 돕는 패키징 스크립트 3종이 내장되어 있습니다.

상세 프로세스는 [패키징 및 배포 가이드 (DEPLOYMENT.md)](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/docs/DEPLOYMENT.md) 문서에서 확인할 수 있습니다.

### 배포 자동화 스크립트 일람

| 스크립트명 | 역할 | 설명 |
|---|---|---|
| [90_build_wheels.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/90_build_wheels.sh) | **의존성 다운로드** | `uv export`로 프로덕션용 패키지를 requirements로 뽑고, `whl-downloader` 컨테이너를 돌려 리눅스 용 `.whl` 파일들을 `./wheels` 디렉토리에 오프라인 획득합니다. |
| [91_build_docker.local.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/91_build_docker.local.sh) | **로컬 빌드 및 패키징** | `.env`와 `docker-compose.yml`을 기반으로 Docker 이미지를 빌드한 후 `./dist/graph-was.tar` 파일로 생성 저장합니다. |
| [92_build_docker.prod.sh](file:///Users/youngilchung/workspace/Busan/busan-ai/graph-was/92_build_docker.prod.sh) | **운영 빌드 및 패키징** | `.env.prod`와 `docker-compose.prod.yml` 명세를 활용하여 상용 최적화 이미지를 빌드하고 `./dist/graph-was.tar` 파일로 생성 저장합니다. |

---

## 프로젝트 구조

```
graph-was/
├── app/
│   ├── main.py                  # FastAPI 앱 부트스트랩, 미들웨어 및 라우터 마운트
│   ├── models.py                # Pydantic 2.0 규격 입출력 스키마
│   ├── config.py                # Pydantic Settings 환경 구성 로드 모듈
│   ├── state.py                 # 전역 데이터베이스 클라이언트 및 ML 모델 인스턴스 싱글톤 관리자
│   ├── model_utils.py           # 임베딩/리랭커 모델 로더 및 외부 vLLM/TEI 래퍼
│   ├── kiwi_bm25.py             # 형태소 기반 BM25 쿼리 벡터 변환 로직
│   ├── prompts/
│   │   └── answer_graph_generation.yaml # 프롬프트 템플릿 파일
│   ├── routers/
│   │   ├── health.py            # 시스템 상태 체크 (/health)
│   │   └── search.py            # 하이브리드 GraphRAG 검색 (/search)
│   └── services/
│       └── search_service.py    # 검색/병합/리랭킹/평가 연동/계층 조회를 총괄하는 파이프라인 로직
├── docs/
│   ├── API_SPEC.md              # API 인터페이스 스펙 문서
│   ├── DEPLOYMENT.md            # 오프라인 패키징 배포 상세 지침서
│   └── RUN_SERVER.md            # 서버 기동 상세 설정 매뉴얼
├── test/
│   └── app.py                   # Streamlit RAG 모니터링 테스트용 데모 챗봇 화면
├── main.py                      # uvicorn 실행을 위한 루트 진입 스크립트
├── .env                         # 로컬 기본 설정
├── .env.prod                    # 운영 배포 기본 설정
├── pyproject.toml               # 의존성 및 프로젝트 패키징 설정 파일
├── requirements.txt             # 의존성 일괄 텍스트 파일
├── 90_build_wheels.sh           # 프로덕션 wheels 다운로드 스크립트
├── 91_build_docker.local.sh     # 로컬 배포 패키지 추출 스크립트
├── 92_build_docker.prod.sh      # 운영 배포 패키지 추출 스크립트
└── README.md                    # 통합 개발/기동 개요서
```

---

## 트러블슈팅

### 1. Neo4j 접속 오류 또는 DB 쿼리 실패
- **증상**: `/health` 체크 시 `checks.neo4j.status: "error: ..."` 또는 `query_ok: false`.
- **해결**:
  - `.env` 내 `NEO4J_URI`, `NEO4J_USERNAME`, `NEO4J_PASSWORD` 설정값이 올바른지 확인하십시오.
  - 사내/기관 방화벽 등으로 인해 포트 `7687` (bolt) 또는 `7474` (http) 통신이 막혀있는지 점검하십시오.
  - Neo4j 가동 유실 시 시스템은 자동으로 Qdrant 페이로드 정보를 기반으로 하는 Fallback 모드로 탐색을 계속하며 용어 매치 기능은 임시 정지됩니다.

### 2. Qdrant 접속 오류
- **증상**: `/health` 체크 시 `checks.qdrant.status: "error: ..."` 또는 컬렉션 부재.
- **해결**:
  - `QDRANT_URL` 접속 주소의 오탈자 여부를 확인하십시오.
  - 외부 Qdrant 클러스터 없이 단독 로컬 임베디드 모드로 실행하는 경우 `QDRANT_URL` 값을 공백으로 비워두면 `./qdrant_db` 로컬 캐시를 점검합니다.

### 3. Sibling WAS (재채점 모듈) 호출 실패
- **증상**: 검색 서비스 실행 중 로그상에 `Failed to run nuclear re-scoring via reasoning-selector-was: ... Fallback to original scores.` 발생.
- **해결**:
  - `REASONING_SELECTOR_WAS_URL` (로컬의 경우 `http://localhost:8010`, 상용의 경우 `http://localhost:38080` 등) 서버 인스턴스가 현재 정상 기동되어 동작 중인지 확인하십시오.
  - 대상 재채점 서버의 부하로 인해 지연이 발생하는 경우 `REASONING_SELECTOR_TIMEOUT`을 합당하게 조절하십시오. 호출 실패 시 자동으로 Cross-Encoder 1차 리랭크 점수 순으로 Fallback하여 무중단 응답합니다.
