import argparse
import json
import os
import re
import sys
import time
import uuid

from dotenv import load_dotenv

# Add workspace root to sys.path to resolve app imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import app.model_utils as model_utils
from app.kiwi_bm25 import KiwiBM25

from langchain_neo4j import Neo4jGraph
from kiwipiepy import Kiwi
from qdrant_client import QdrantClient
from qdrant_client.models import (
    Distance,
    PointStruct,
    SparseIndexParams,
    SparseVector,
    SparseVectorParams,
    VectorParams,
)

# Load environment variables
load_dotenv()

NEO4J_URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "password")
EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "dragonkue/BGE-m3-ko")
# Path resolution relative to the script's folder
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_FILE = os.path.join(
    SCRIPT_DIR,
    "(사회재난-17) 2025-2차 원전안전 분야(방사능 누출) 현장조치 행동 매뉴얼(4차 개정  251013).json"
)
TERMINOLOGY_FILE = os.path.join(SCRIPT_DIR, "terminology_shortcuts.json")

# Qdrant configuration
QDRANT_URL = os.getenv("QDRANT_URL", "")
QDRANT_PATH = os.getenv("QDRANT_PATH", "./qdrant_db")
QDRANT_COLLECTION_NAME = os.getenv("QDRANT_COLLECTION_NAME", "document_sections")


def get_header_level(content):
    """
    행동 매뉴얼의 번호 체계를 분석하여 헤더 레벨(Level 1~4)을 분류합니다.
    """
    # Level 1: 대제목 (I, II, III, IV... 또는 로마자 대문자)
    if re.match(r"^[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫXIV\d]+\s*[\.\,]", content):
        return 1
    # Level 2: 중제목 (1, 2, 3...)
    if re.match(r"^\d+\s*[\.\,]", content):
        return 2
    # Level 3: 소제목 (가, 나, 다...)
    if re.match(r"^[가-힣]\s*[\.\,]", content):
        return 3
    # Level 4: 세부제목 (①, ② 또는 1), 가) 등)
    if re.match(r"^(\d+\)|[가-힣]\)|[①-⑳])", content):
        return 4

    return 3


def group_units_into_chunks(units, target_size, overlap):
    """
    문장/표 단위의 units 리스트를 target_size에 맞춰 병합하되,
    표(is_table=True)는 쪼개지 않고 독립된 단일 청크로 유지하고,
    일반 텍스트는 overlap 크기를 적용해 경계 문맥을 이으며 청크를 분할합니다.
    """
    chunks = []
    if not units:
        return chunks

    current_chunk_units = []
    current_size = 0

    i = 0
    while i < len(units):
        unit = units[i]
        unit_text = unit["text"]
        unit_len = len(unit_text)

        # 표 데이터인 경우 예외 처리
        if unit["is_table"]:
            # 현재 쌓여 있는 텍스트가 있으면 청크로 배출
            if current_chunk_units:
                chunks.append(
                    {
                        "text": " ".join([u["text"] for u in current_chunk_units]),
                        "units": current_chunk_units,
                    }
                )
                current_chunk_units = []
                current_size = 0
            # 표 자체를 독립된 청크로 배출
            chunks.append({"text": unit_text, "units": [unit]})
            i += 1
            continue

        # 일반 텍스트인 경우
        if current_chunk_units and current_size + unit_len > target_size:
            chunks.append(
                {
                    "text": " ".join([u["text"] for u in current_chunk_units]),
                    "units": current_chunk_units,
                }
            )

            # 오버랩 버퍼 수집: 이전 청크의 끝에서부터 overlap 크기만큼의 유닛을 역순 수집
            overlap_units = []
            overlap_len = 0
            for ou in reversed(current_chunk_units):
                if ou["is_table"]:
                    break  # 표는 오버랩 경계에 포함시키지 않음
                if overlap_len + len(ou["text"]) > overlap:
                    break
                overlap_units.insert(0, ou)
                overlap_len += len(ou["text"])

            current_chunk_units = overlap_units
            current_size = sum(len(u["text"]) for u in current_chunk_units)

        current_chunk_units.append(unit)
        current_size += unit_len
        i += 1

    if current_chunk_units:
        chunks.append(
            {
                "text": " ".join([u["text"] for u in current_chunk_units]),
                "units": current_chunk_units,
            }
        )

    return chunks


def parse_hierarchical_json(json_file_path):
    """
    ETL 가공된 원본 JSON을 읽어 부모-자식 관계를 가진 계층형 구조로 파싱합니다.
    """
    if not os.path.exists(json_file_path):
        raise FileNotFoundError(f"파일을 찾을 수 없습니다: {json_file_path}")

    with open(json_file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    exclude_categories = {"Page-header", "Page-footer", "Caption"}
    ignore_patterns = re.compile(
        r"(^\s*목\s*차\s*$|^\s*차\s*례\s*$|^\s*-\s*\d+\s*-\s*$)"
    )

    all_sections = []
    current_path = {1: None, 2: None, 3: None, 4: None}
    section_id_counter = 0

    for page in data.get("pages", []):
        page_num = page.get("page_number", 0)

        for element in page.get("elements", []):
            category = element.get("category", "")
            content = element.get("content", "").strip()

            if (
                category in exclude_categories
                or ignore_patterns.search(content)
                or not content
            ):
                continue

            # Section-header를 만났을 때 노드 생성 및 부모 계층 연결
            if category == "Section-header":
                section_id_counter += 1
                level = get_header_level(content)

                new_section = {
                    "node_id": f"SEC_{section_id_counter:04d}",
                    "node_type": "DocumentSection",
                    "level": level,
                    "title": content,
                    "parent_id": None,  # GraphRAG 상에서 상위 노드와 연결할 Key
                    "start_page": page_num,
                    "body_content": "",  # 하위 텍스트들을 병합할 텍스트 스페이스
                    "raw_elements": [],  # 문맥 유실 방지 및 쪼개기용 임시 리스트
                    "parent_chunks": [],  # 3단계 계층 구조
                }

                # 역순으로 탐색하여 직계 부모(나보다 숫자가 작은 가장 최신 상위 레벨) 탐색
                for parent_level in range(level - 1, 0, -1):
                    if current_path[parent_level] is not None:
                        new_section["parent_id"] = current_path[parent_level]["node_id"]
                        break

                # 스택 상태 업데이트 및 하위 레벨 초기화
                current_path[level] = new_section
                for l in range(level + 1, 5):
                    current_path[l] = None

                all_sections.append(new_section)

            # 일반 본문 텍스트나 표를 만났을 때, 가장 가까운 하위 섹션에 텍스트 병합
            else:
                active_section = None
                for l in range(4, 0, -1):
                    if current_path[l] is not None:
                        active_section = current_path[l]
                        break

                if active_section:
                    # raw_elements에 순차적으로 원본 요소 수집
                    active_section["raw_elements"].append(
                        {"category": category, "content": content, "page_num": page_num}
                    )

                    # 표 데이터는 LLM과 검색 인덱스가 구분하기 좋게 마킹 추가
                    if category == "Table":
                        formatted_content = f"\n[표 구조 데이터]\n{content}\n"
                    else:
                        formatted_content = f"\n{content}"

                    active_section["body_content"] += formatted_content

    # 최종 정제: 양끝 공백 제거 및 3단계 청크 계층 구조 생성
    for sec in all_sections:
        sec["body_content"] = sec["body_content"].strip()

        # 1. raw_elements로부터 기본 문장/표 units 추출
        units = []
        for elem in sec["raw_elements"]:
            cat = elem["category"]
            cnt = elem["content"].strip()
            elem_page = elem.get("page_num", sec["start_page"])
            if not cnt:
                continue

            if cat == "Table":
                units.append({"text": f"[표 구조 데이터]\n{cnt}", "is_table": True, "page_num": elem_page})
            else:
                # 마침표, 물음표, 느낌표 뒤에 공백이 오는 패턴으로 문장을 분할
                sentences = re.split(r"(?<=[.?!])\s+", cnt)
                for sent in sentences:
                    sent = sent.strip()
                    if sent:
                        units.append({"text": sent, "is_table": False, "page_num": elem_page})

        # 2. Parent Chunk 생성 (최대 2048자, overlap 200자)
        parent_chunks_raw = group_units_into_chunks(units, 2048, 200)

        sec_parent_chunks = []
        for p_idx, p_raw in enumerate(parent_chunks_raw):
            parent_chunk_id = f"{sec['node_id']}_P{p_idx + 1:02d}"
            p_start_page = p_raw["units"][0]["page_num"] if p_raw["units"] else sec["start_page"]

            # 3. Parent Chunk 내부의 units를 바탕으로 Child Chunk 생성 (최대 512자, overlap 50자)
            child_chunks_raw = group_units_into_chunks(p_raw["units"], 512, 50)

            sec_child_chunks = []
            for c_idx, c_raw in enumerate(child_chunks_raw):
                child_chunk_id = f"{parent_chunk_id}_C{c_idx + 1:02d}"
                c_start_page = c_raw["units"][0]["page_num"] if c_raw["units"] else p_start_page
                sec_child_chunks.append(
                    {
                        "child_chunk_id": child_chunk_id,
                        "text": c_raw["text"],
                        "start_page": c_start_page,
                    }
                )

            sec_parent_chunks.append(
                {
                    "parent_chunk_id": parent_chunk_id,
                    "text": p_raw["text"],
                    "start_page": p_start_page,
                    "child_chunks": sec_child_chunks,
                }
            )

        sec["parent_chunks"] = sec_parent_chunks

        # 임시 보관한 raw_elements 제거로 JSON 크기 최적화
        if "raw_elements" in sec:
            del sec["raw_elements"]

    return all_sections


def main():
    parser = argparse.ArgumentParser(description="GraphRAG Ingestion Pipeline")
    parser.add_argument(
        "--input",
        type=str,
        default=INPUT_FILE,
        help="한국딥러닝 ETL 포맷의 문서(JSON)"
    )
    parser.add_argument(
        "--terminology",
        type=str,
        default=TERMINOLOGY_FILE,
        help="용어사전 문서(JSON)"
    )
    args = parser.parse_args()

    input_file = args.input
    terminology_file = args.terminology

    print("🚀 GraphRAG Ingestion Pipeline Starting...")
    print(f"📄 Input manual path: {input_file}")
    print(f"📖 Terminology path: {terminology_file}")

    # 1. Parse manual data hierarchy directly in memory
    if not os.path.exists(input_file):
        print(
            f"❌ Error: Input manual JSON file '{input_file}' not found."
        )
        return

    print(f"📖 Parsing hierarchical structures directly from '{input_file}'...")
    try:
        sections = parse_hierarchical_json(input_file)
        print(f"✅ Successfully parsed {len(sections)} document sections directly in memory.")
    except Exception as e:
        print(f"❌ Error parsing manual JSON file: {e}")
        return

    # Load terminology shortcuts
    if not os.path.exists(terminology_file):
        print(f"❌ Error: Terminology file '{terminology_file}' not found.")
        return
    print(f"📖 Loading terminology shortcuts from '{terminology_file}'...")
    with open(terminology_file, "r", encoding="utf-8") as f:
        terminologies = json.load(f)
    print(f"✅ Loaded {len(terminologies)} terminology mapping entries.")

    # 2. Initialize Embeddings Model
    print(f"🧠 Initializing Embeddings model: '{EMBEDDING_MODEL_NAME}'...")
    start_time = time.time()
    embeddings_model = model_utils.get_embeddings_model(EMBEDDING_MODEL_NAME)
    print(f"✅ Embeddings model loaded in {time.time() - start_time:.2f}s")

    # 3. Flatten child chunks and prepare texts to embed
    print("✍️ Preparing child chunks for embedding...")
    flat_child_chunks = []
    texts_to_embed = []

    for sec in sections:
        title = sec.get("title", "").strip()
        for p_chunk in sec.get("parent_chunks", []):
            p_id = p_chunk["parent_chunk_id"]
            p_text = p_chunk["text"]
            for c_chunk in p_chunk.get("child_chunks", []):
                c_id = c_chunk["child_chunk_id"]
                c_text = c_chunk["text"]

                # Title + Child Text 조합하여 매칭 정확도 확장
                combined_text = f"{title}\n{c_text}".strip()

                flat_child_chunks.append(
                    {
                        "child_chunk_id": c_id,
                        "text": c_text,
                        "parent_chunk_id": p_id,
                        "parent_chunk_text": p_text,
                        "node_id": sec["node_id"],
                        "title": title,
                        "level": sec.get("level"),
                        "parent_id": sec.get("parent_id"),
                        "start_page": c_chunk.get("start_page"),
                        "parent_start_page": p_chunk.get("start_page"),
                        "section_start_page": sec.get("start_page"),
                    }
                )
                texts_to_embed.append(
                    combined_text if combined_text else "Empty Section"
                )

    total_chunks = len(flat_child_chunks)
    print(f"✍️ Generating embeddings for {total_chunks} child chunks...")

    # Batch embedding generation
    batch_size = 64
    all_embeddings = []

    start_time = time.time()
    for i in range(0, total_chunks, batch_size):
        batch_texts = texts_to_embed[i : i + batch_size]
        batch_embeddings = embeddings_model.embed_documents(batch_texts)
        all_embeddings.extend(batch_embeddings)
        print(
            f"   Processed {min(i + batch_size, total_chunks)}/{total_chunks} chunks..."
        )

    print(f"✅ Generated all embeddings in {time.time() - start_time:.2f}s")

    # Get embedding dimension
    embedding_dimension = len(all_embeddings[0])
    print(f"📏 Embedding vector dimension: {embedding_dimension}")

    # 3.5 Fit KiwiBM25 model
    print("🧠 Fitting KiwiBM25 model on child chunk texts...")
    kiwi_bm25 = KiwiBM25()
    kiwi_bm25.fit(texts_to_embed)
    bm25_model_path = os.path.join(SCRIPT_DIR, "kiwi_bm25_model.json")
    kiwi_bm25.save(bm25_model_path)
    print(
        f"✅ Fitted and saved KiwiBM25 model to '{bm25_model_path}' (Vocab size: {len(kiwi_bm25.vocab)})."
    )

    # 4. Connect to Qdrant & Index vectors
    print("🔗 Connecting to Qdrant...")
    if QDRANT_URL.strip():
        qdrant_client = QdrantClient(url=QDRANT_URL)
        print(f"   Using Qdrant Server at {QDRANT_URL}")
    else:
        qdrant_client = QdrantClient(path=QDRANT_PATH)
        print(f"   Using Local Qdrant DB at '{QDRANT_PATH}'")

    print(f"📦 Recreating Qdrant collection '{QDRANT_COLLECTION_NAME}'...")
    if qdrant_client.collection_exists(collection_name=QDRANT_COLLECTION_NAME):
        qdrant_client.delete_collection(collection_name=QDRANT_COLLECTION_NAME)

    qdrant_client.create_collection(
        collection_name=QDRANT_COLLECTION_NAME,
        vectors_config={
            "": VectorParams(size=embedding_dimension, distance=Distance.COSINE)
        },
        sparse_vectors_config={
            "text-sparse": SparseVectorParams(
                index=SparseIndexParams(
                    on_disk=True,
                )
            )
        },
    )

    print("📥 Ingesting child chunks and embeddings into Qdrant...")
    points = []
    for idx, chunk in enumerate(flat_child_chunks):
        c_id = chunk["child_chunk_id"]
        # Generate a deterministic UUID based on child_chunk_id to prevent duplicates on re-runs
        point_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, c_id))

        # Generate BM25 sparse vector
        c_text = chunk["text"]
        title = chunk["title"]
        combined_text = f"{title}\n{c_text}".strip()
        sparse_indices, sparse_values = kiwi_bm25.get_document_vector(combined_text)

        points.append(
            PointStruct(
                id=point_id,
                vector={
                    "": all_embeddings[idx],
                    "text-sparse": SparseVector(
                        indices=sparse_indices, values=sparse_values
                    ),
                },
                payload={
                    "child_chunk_id": c_id,
                    "text": chunk["text"],
                    "body_content": chunk["text"],
                    "parent_chunk_id": chunk["parent_chunk_id"],
                    "parent_chunk_text": chunk["parent_chunk_text"],
                    "node_id": chunk["node_id"],
                    "title": chunk["title"],
                    "level": chunk["level"],
                    "parent_id": chunk["parent_id"],
                    "start_page": chunk["start_page"],
                    "parent_start_page": chunk.get("parent_start_page"),
                    "section_start_page": chunk.get("section_start_page"),
                },
            )
        )

    # Ingest in Qdrant in batches
    q_batch_size = 500
    for i in range(0, len(points), q_batch_size):
        qdrant_client.upsert(
            collection_name=QDRANT_COLLECTION_NAME, points=points[i : i + q_batch_size]
        )
    print(f"✅ Ingested {len(points)} vectors into Qdrant.")

    # 5. Connect to Neo4j
    print(f"🔗 Connecting to Neo4j at {NEO4J_URI}...")
    try:
        graph = Neo4jGraph(
            url=NEO4J_URI,
            username=NEO4J_USERNAME,
            password=NEO4J_PASSWORD,
            refresh_schema=False,
        )
        print("✅ Successfully connected to Neo4j!")
    except Exception as e:
        print(f"❌ Failed to connect to Neo4j: {e}")
        print(
            "💡 Please check your credentials in the .env file and ensure Neo4j is running."
        )
        return

    # Clear database
    print(
        "🧹 Cleaning existing DocumentSection, ParentChunk, ChildChunk, Terminology, and Synonym nodes in Neo4j..."
    )
    graph.query("MATCH (n:DocumentSection) DETACH DELETE n")
    graph.query("MATCH (n:ParentChunk) DETACH DELETE n")
    graph.query("MATCH (n:ChildChunk) DETACH DELETE n")
    graph.query("MATCH (n:Terminology) DETACH DELETE n")
    graph.query("MATCH (n:Synonym) DETACH DELETE n")

    # Drop existing index if any
    try:
        graph.query("DROP INDEX document_section_embeddings IF EXISTS")
    except Exception as e:
        print(f"ℹ️ (Optional index drop info): {e}")

    # Create unique constraints (which automatically create indexes) for lookup properties
    print("🔑 Creating unique constraints and indexes in Neo4j...")
    try:
        graph.query(
            "CREATE CONSTRAINT document_section_node_id IF NOT EXISTS FOR (s:DocumentSection) REQUIRE s.node_id IS UNIQUE"
        )
        graph.query(
            "CREATE CONSTRAINT parent_chunk_chunk_id IF NOT EXISTS FOR (p:ParentChunk) REQUIRE p.chunk_id IS UNIQUE"
        )
        graph.query(
            "CREATE CONSTRAINT child_chunk_chunk_id IF NOT EXISTS FOR (c:ChildChunk) REQUIRE c.chunk_id IS UNIQUE"
        )
        graph.query(
            "CREATE CONSTRAINT terminology_name IF NOT EXISTS FOR (t:Terminology) REQUIRE t.name IS UNIQUE"
        )
        graph.query(
            "CREATE CONSTRAINT synonym_name IF NOT EXISTS FOR (s:Synonym) REQUIRE s.name IS UNIQUE"
        )
    except Exception as e:
        print(f"ℹ️ (Constraint creation info): {e}")

    # 6. Ingest DocumentSections
    print("📥 Ingesting DocumentSections into Neo4j...")
    ingest_batch_size = 200
    for i in range(0, len(sections), ingest_batch_size):
        batch_nodes = sections[i : i + ingest_batch_size]

        # Cypher query to create nodes (without storing embeddings)
        create_nodes_query = """
        UNWIND $batch AS row
        MERGE (s:DocumentSection {node_id: row.node_id})
        SET s.title = row.title,
            s.level = toInteger(row.level),
            s.start_page = toInteger(row.start_page),
            s.body_content = row.body_content
        """
        graph.query(create_nodes_query, {"batch": batch_nodes})
        print(
            f"   Uploaded {min(i + ingest_batch_size, len(sections))}/{len(sections)} sections..."
        )

    # 7. Create parent-child relationships between DocumentSections
    print("⛓️ Constructing hierarchical relationships (PARENT_OF)...")
    create_relationships_query = """
    UNWIND $batch AS row
    WITH row WHERE row.parent_id IS NOT NULL
    MATCH (child:DocumentSection {node_id: row.node_id})
    MATCH (parent:DocumentSection {node_id: row.parent_id})
    MERGE (parent)-[:PARENT_OF]->(child)
    """
    for i in range(0, len(sections), ingest_batch_size):
        batch_nodes = sections[i : i + ingest_batch_size]
        graph.query(create_relationships_query, {"batch": batch_nodes})

    # 8. Ingest ParentChunks & ChildChunks and link them
    print("📥 Ingesting ParentChunks and ChildChunks into Neo4j...")

    parent_batch = []
    child_batch = []

    for sec in sections:
        node_id = sec["node_id"]
        for p_chunk in sec.get("parent_chunks", []):
            parent_batch.append(
                {
                    "node_id": node_id,
                    "parent_chunk_id": p_chunk["parent_chunk_id"],
                    "text": p_chunk["text"],
                    "start_page": p_chunk.get("start_page"),
                }
            )
            for c_chunk in p_chunk.get("child_chunks", []):
                child_batch.append(
                    {
                        "parent_chunk_id": p_chunk["parent_chunk_id"],
                        "child_chunk_id": c_chunk["child_chunk_id"],
                        "text": c_chunk["text"],
                        "start_page": c_chunk.get("start_page"),
                    }
                )

    # Ingest ParentChunks
    print(f"   Uploading {len(parent_batch)} ParentChunks...")
    create_parents_query = """
    UNWIND $batch AS row
    MATCH (s:DocumentSection {node_id: row.node_id})
    MERGE (p:ParentChunk {chunk_id: row.parent_chunk_id})
    SET p.text = row.text,
        p.start_page = toInteger(row.start_page)
    MERGE (s)-[:HAS_PARENT_CHUNK]->(p)
    """
    for i in range(0, len(parent_batch), ingest_batch_size):
        graph.query(
            create_parents_query, {"batch": parent_batch[i : i + ingest_batch_size]}
        )

    # Ingest ChildChunks
    print(f"   Uploading {len(child_batch)} ChildChunks...")
    create_children_query = """
    UNWIND $batch AS row
    MATCH (p:ParentChunk {chunk_id: row.parent_chunk_id})
    MERGE (c:ChildChunk {chunk_id: row.child_chunk_id})
    SET c.text = row.text,
        c.start_page = toInteger(row.start_page)
    MERGE (p)-[:HAS_CHILD_CHUNK]->(c)
    """
    for i in range(0, len(child_batch), ingest_batch_size):
        graph.query(
            create_children_query, {"batch": child_batch[i : i + ingest_batch_size]}
        )

    print("✅ Parent-Child chunks created successfully in Neo4j.")

    # 8.5 Ingest Terminology & Synonym and link to ChildChunks
    print("📥 Ingesting Terminology and Synonym nodes into Neo4j...")
    terminology_batch = []
    synonym_batch = []

    for item in terminologies:
        term = item.get("term", "").strip()
        if not term:
            continue
        terminology_batch.append({"name": term})

        for syn in item.get("alternatives", []):
            if syn and syn.strip():
                synonym_batch.append({"term_name": term, "syn_name": syn.strip()})

    # Terminology MERGE
    create_terminology_query = """
    UNWIND $batch AS row
    MERGE (t:Terminology {name: row.name})
    """
    graph.query(create_terminology_query, {"batch": terminology_batch})

    # Synonym MERGE 및 관계 생성
    create_synonym_query = """
    UNWIND $batch AS row
    MATCH (t:Terminology {name: row.term_name})
    MERGE (s:Synonym {name: row.syn_name})
    MERGE (s)-[:SYNONYM_OF]->(t)
    """
    graph.query(create_synonym_query, {"batch": synonym_batch})
    print(
        f"✅ Ingested {len(terminology_batch)} Terminology nodes and {len(synonym_batch)} Synonym nodes."
    )

    print("🧠 Analyzing ChildChunks to link Terminology nodes (MENTIONS)...")
    kiwi = Kiwi()

    # 사전의 용어/대체용어 맵 구성
    term_match_map = {}
    for item in terminologies:
        term = item.get("term", "").strip()
        if not term:
            continue
        match_words = {term}
        for syn in item.get("alternatives", []):
            if syn and syn.strip():
                match_words.add(syn.strip())
        term_match_map[term] = match_words

    mentions_batch = []

    for c in child_batch:
        c_id = c["child_chunk_id"]
        text = c["text"]

        # Kiwi 형태소 분석을 통해 명사(N) 및 외국어(SL) 추출
        noun_tokens = set()
        for token in kiwi.tokenize(text):
            if token.tag.startswith("N") or token.tag == "SL":
                noun_tokens.add(token.form)

        for term, match_words in term_match_map.items():
            matched = False
            for word in match_words:
                # 3자 이상인 단어는 단순 텍스트 포함 확인
                if len(word) >= 3 and word in text:
                    matched = True
                    break
                # 2자 이하는 명사/외국어 형태소 토큰과 정확히 일치 확인
                elif word in noun_tokens:
                    matched = True
                    break
            if matched:
                mentions_batch.append({"child_id": c_id, "term_name": term})

    # Mentions 엣지 생성 (UNWIND)
    print(
        f"🔗 Linking {len(mentions_batch)} MENTIONS relationships between ChildChunks and Terminologies..."
    )
    create_mentions_query = """
    UNWIND $batch AS row
    MATCH (c:ChildChunk {chunk_id: row.child_id})
    MATCH (t:Terminology {name: row.term_name})
    MERGE (c)-[:MENTIONS]->(t)
    """

    mentions_batch_size = 1000
    for i in range(0, len(mentions_batch), mentions_batch_size):
        graph.query(
            create_mentions_query,
            {"batch": mentions_batch[i : i + mentions_batch_size]},
        )
    print("✅ Successfully constructed MENTIONS relationships.")

    # 9. Verify database status
    verification_query = """
    RETURN count { MATCH (s:DocumentSection) } AS section_count, 
           count { MATCH (p:ParentChunk) } AS parent_count,
           count { MATCH (c:ChildChunk) } AS child_count,
           count { MATCH (t:Terminology) } AS terminology_count,
           count { MATCH (sy:Synonym) } AS synonym_count,
           count { MATCH ()-[r:PARENT_OF]->() } AS rel_parent_of,
           count { MATCH ()-[r:HAS_PARENT_CHUNK]->() } AS rel_has_parent,
           count { MATCH ()-[r:HAS_CHILD_CHUNK]->() } AS rel_has_child,
           count { MATCH ()-[r:MENTIONS]->() } AS rel_mentions
    """
    res = graph.query(verification_query)
    if res:
        print(f"\n📊 Neo4j Database Status:")
        print(f"   - Total DocumentSection Nodes: {res[0]['section_count']}")
        print(f"   - Total ParentChunk Nodes: {res[0]['parent_count']}")
        print(f"   - Total ChildChunk Nodes: {res[0]['child_count']}")
        print(f"   - Total Terminology Nodes: {res[0]['terminology_count']}")
        print(f"   - Total Synonym Nodes: {res[0]['synonym_count']}")
        print(f"   - Total PARENT_OF (Section-Section) Rel: {res[0]['rel_parent_of']}")
        print(f"   - Total HAS_PARENT_CHUNK Rel: {res[0]['rel_has_parent']}")
        print(f"   - Total HAS_CHILD_CHUNK Rel: {res[0]['rel_has_child']}")
        print(f"   - Total MENTIONS (Chunk-Terminology) Rel: {res[0]['rel_mentions']}")

    print("\n🎉 Ingestion and Indexing complete! You can now query using query.py.")


if __name__ == "__main__":
    main()
