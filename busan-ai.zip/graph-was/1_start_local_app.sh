#!/bin/bash

ENV=local uv run uvicorn app.main:app --reload --host=0.0.0.0 --port=8110
